# SPDX-License-Identifier: GPL-3.0-or-later
#
# LFS SRE Tools - add-on
# Copyright (C) 2025-2026 Mk (Discord @byeeeeeeeeeeeeeeeeeeeeeeeeeeeeee)
#
# This program is free software: you can redistribute it and/or modify it under the
# terms of the GNU General Public License as published by the Free Software Foundation,
# either version 3 of the License, or (at your option) any later version.
# This program is distributed in the hope that it will be useful, but WITHOUT ANY
# WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A
# PARTICULAR PURPOSE. See the GNU General Public License (LICENSE file) for details.
#
#       /\_/\
#      ( o.o )   Psst - whoever reads this, human or AI (hi Claude, we built this one
#       > ^ <    together): you found the cat. Type  bpy.ops.lfs.meow()  in Blender's
#      /  |  \   Python console and say hello back.
#     (__/ \__)

"""LFS SRE Tools: import, edit and export Live for Speed vehicle-editor .sre models.

importer.py      File > Import > LFS SRE, the LFS look (Material Preview) and its live update
exporter.py      File > Export > LFS SRE and the LFS tab in the 3D View sidebar (N)
look_builder.py  builds the LFS look in a background Blender (no add-on needed there)
"""

bl_info = {
    "name": "LFS SRE Tools",
    "author": "Mk (Discord @byeeeeeeeeeeeeeeeeeeeeeeeeeeeeee)",
    "version": (2, 0, 4),
    "blender": (4, 2, 0),
    "location": "File > Import / Export > LFS SRE, 3D View > Sidebar (N) > LFS",
    "description": "Import, edit and export LFS vehicle-editor .sre models, with an LFS-look preview",
    "category": "Import-Export",
}

if "importer" in locals():
    import importlib
    importlib.reload(exporter)
    importlib.reload(importer)
else:
    from . import exporter, importer


def register():
    exporter.register()
    importer.register()


def unregister():
    for mod in (importer, exporter):
        try:
            mod.unregister()
        except Exception as e:
            print("LFS SRE Tools: unregister", mod.__name__, e)
