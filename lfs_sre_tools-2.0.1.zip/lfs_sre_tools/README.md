# LFS SRE Tools 2.0.1

Import, edit and export **Live for Speed** vehicle-editor `.sre` models in Blender 4.2 or newer
(made and tested on Blender 5.2).

## Install
Blender 4.2 or newer installs it as an **extension**:
1. Drag `lfs_sre_tools-2.0.1.zip` (do not unzip it) onto the Blender window and
   press **Install**, or: **Edit > Preferences > Add-ons**, the arrow menu (top right) >
   **Install from Disk...** and pick the zip. It is switched on straight away.
2. Read the next part: the add-on needs to know where your LFS textures are.
3. Used the older single-file versions (*LFS SRE Exporter* / *LFS SRE Importer*)? Turn them off
   and remove them: two copies get in each other's way (the LFS tab warns you).

## Updates
When the release comes with an update link (a web address ending in `index.json`), add it once:
**Edit > Preferences > Get Extensions**, the arrow menu (top right) > **Repositories** > **+** >
**Add Remote Repository**, paste the link and tick **Check for Updates on Startup**. Install
LFS SRE Tools from there; Blender then tells you when there is a new version and updates it
with one click.

## Slower PC?
The **LFS look** (Material Preview in the editor's light) is built by a second Blender in the
background. In the add-on's preferences you can switch off **Build it on import** (build it
later with **Build LFS look**) and **Follow your edits** (it then updates when you press
**Rebuild LFS look**).

## Folders - check this on every PC
The add-on uses your LFS **texture folder**: `data\png` inside your LFS folder
(for example `C:\LFS\data\png`).
* It finds it by itself when the `.sre` is in the `data\3dob` folder next to it, or when the
  car's `.png` files sit next to the `.sre`.
* Anywhere else (a car saved in some other folder, textures in your LFS folder) set
  **PNG Texture Folder** in the add-on's preferences, or in the box in the LFS tab's
  SRE Import panel. Blender keeps it with its preferences.
* Once a folder has been found, later imports in the same `.blend` use it too.
* With nothing found it also looks in the usual LFS places (`C:\LFS` and the like on each drive).
* After an import the status bar says how many texture pages were not found and where it
  looked, and the SRE Import panel shows the box to fix it. Import again after setting it.
* **Bake Textures for LFS** writes its texture pages into that folder: set it before baking a
  model from another format (FBX, OBJ...).
* Export cars into `data\3dob` so the vehicle editor lists them.

## Where things are
* **File > Import > LFS SRE (.sre)** - one object per sub-object, textures, LFS shading.
  Material Preview shows the **LFS look** (the editor's lighting); it follows your edits.
* **File > Export > LFS SRE** - parts you did not touch are written back byte for byte.
* **3D View > Sidebar (N) > LFS** - setup, textures, sub-objects, Dish / Curve Part,
  smoothing groups and more.

The illustrated guide that comes with this release walks through all of it.

Website, updates and the guide: https://byemk.github.io/lfs-sre-tools/

## Licence
GPL-3.0-or-later - see `LICENSE`. Credit: Mk (Discord @byeeeeeeeeeeeeeeeeeeeeeeeeeeeeee).
