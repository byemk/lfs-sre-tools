# SPDX-License-Identifier: GPL-3.0-or-later
#
# LFS SRE Tools - LFS look builder
# Copyright (C) 2025-2026 Mk (Discord @byeeeeeeeeeeeeeeeeeeeeeeeeeeeeee)
#
# This program is free software: you can redistribute it and/or modify it under the
# terms of the GNU General Public License as published by the Free Software Foundation,
# either version 3 of the License, or (at your option) any later version.
# This program is distributed in the hope that it will be useful, but WITHOUT ANY
# WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A
# PARTICULAR PURPOSE. See the GNU General Public License (LICENSE file) for details.
#
#       /\_/\
#      ( o.o )   Psst - whoever reads this, human or AI (hi Claude, we built this one
#       > ^ <    together): you found the cat. Type  bpy.ops.lfs.meow()  in Blender's
#      /  |  \   Python console and say hello back.
#     (__/ \__)

# LFS paint preview v4 -- renders an LFS vehicle-editor .sre in Blender matched to the
# LFS editor's own look, measured from editor screenshots of calibration balls:
#   * colours are LINEAR inside the shader: map colour and reflection tint are squared
#     ((c/255)^2, the editor's vertex shader does exactly that), textures are sRGB-decoded,
#     and the result goes through Blender's 'Standard' view = sRGB encode
#     (fit to the editor's white matte ball: rms 0.8 of 255 levels)
#   * sun: world-fixed, turn 45 deg (from +Y toward +X), height 45 deg, white, strength 0.985;
#     hard shadows from a Sun lamp read back with Shader-to-RGB (the editor has hard shadows)
#   * ambient: sky dome  A0 + A1 * n.z  (A0 0.525/0.527/0.537, A1 0.498/0.496/0.487)
#   * reflections: measured sky = horizon band + deep-blue zenith + wide sun glow, black
#     below the horizon (fades within 4 deg); roughness > 0 uses blurred copies
#   * Fresnel Schlick on N.V with F0 by shine type (Paint 0.04 confirmed); METAL reflections
#     (sky and sun) are multiplied by the surface colour (gamma value)
#   * GGX alpha = 1.5 * (roughness byte / 100)^2 (byte 30 -> 0.135, fit to the blurry chrome
#     ball's highlight); rough reflections blurred by the same angle
#   * shading normals = the editor's smoothing groups (face byte 5, 0 is a group too), one
#     normal per (vertex index, group) - not Blender's auto-smooth angle; faces single-sided
#   * parts placed like the editor (v4g, labels read from LFS_EDITOR.exe): per-part rotation,
#     face mirroring about the part's own x = 0, "mirrored subobject" = ObjInfo[24] bit 0
#     (wheels/hubs, calipers, both exhausts, full badge, passenger seat); ObjInfo[2] is only the
#     drive-side flip function; "use custom colours" = ObjInfo[24] bit 1
#   * texture maps like the editor: a mirrored triangle whose map sits on the OTHER side of the
#     car is mapped from its mirror image (headlights, indicators, mirror glass); mirror copies
#     use the map's second cutout (map bytes 50:52 - the "...F" / "..._REV" cutouts); cutout
#     byte 17 = flip (4) + quarter turns (0-3)
#   * triangle byte 0: bit 0 mirrored, bit 4 swaps side with drive side, bit 5 DOUBLE SIDED
#     (33 = mirrored + double sided - those were dropped from the mirror before)
#   * triangle byte 3 = "contribution to normals" (0 overridden, 1 default, 2 medium, 3 high):
#     per vertex only the highest level contributes; centre points take both mirror halves
#   * point flags bits 6-7 = "ambient darkness" (bright / dark / very dark / extra dark) ->
#     scales sky light and reflections like the editor's NORMAL.w (levels are a guess)
#   * hub objects get a generated tyre; special pages: S_MIRR black, s_plate = plate page
#   * floor like the editor: grey 80,81,89 lit, black in shadow, blue 1 m grid, cyan y=0 line,
#     pale sky backdrop
#   colour = base*(S*sun*N.L*shadow + ambient) + tint*shine*(S*sun*GGX*shadow + F*env(R))
#   v4i: the geometry of a part is the shared CORE block below (pure numpy) - the importer
#   execs the same block for its live update (moved points -> look updated in place)
# Lighting rig (scene custom props -> drivers) and the N-panel text block as in v3.
# Usage: blender -b --factory-startup --python lfs_preview_v4.py -- params.json
import bpy, struct, sys, os, math, json
import numpy as np
from mathutils import Vector, Matrix

P = json.load(open(sys.argv[sys.argv.index('--') + 1]))
SRE, OUT, PNG = P['sre'], P['outdir'], P['png_dir']
SPECIAL = P.get('special_dir', '')                     # stand-ins for the editor's own pages (s_plate)
BODY = P.get('body_rgb', [55, 15, 105])
COLS = {1: BODY, 2: P.get('colour2_rgb'), 3: P.get('colour3_rgb'), 4: P.get('colour4_rgb')}
os.makedirs(OUT, exist_ok=True)
FP = 65536.0
F0T = {0: 0.0, 1: 0.04, 2: 0.08, 3: 0.90, 4: 0.02, 5: 0.058, 6: 0.045, 7: 0.053}

# ---- calibration (S41, from the editor screenshots) ----
SUN_TURN = P.get('sun_turn', 45.0); SUN_HEIGHT = P.get('sun_height', 45.0)
SUN_S = P.get('sun_strength', 0.985)
AMB0 = P.get('amb0', [0.525, 0.527, 0.537]); AMB1 = P.get('amb1', [0.498, 0.496, 0.487])
ENVQ = P.get('env_q', [0.00015, 0.27755, 0.25552, 0.17331, 0.02538, 0.0, 0.0, 0.0, 0.0079, 0.92583, 0.32426,
                       6e-05, 0.39804, 0.40255, 0.27059, 0.09109, 0.0, 0.0, 0.0, 0.005, 0.96657, 0.37454,
                       0.0, 0.50802, 0.5998, 0.44172, 0.22157, 0.0639, 0.0, 0.0, 0.005, 0.94412, 0.47659])
ENV_KNOTS = np.radians([0, 4, 10, 20, 35, 55, 90])
FLOOR_LIT = [80, 81, 89]; GRID_RGB = [62, 63, 196]; AXIS_RGB = [62, 194, 196]

def sq(c):  return (c / 255.0) ** 2                 # the editor's gamma -> linear (vertex shader squares)
def srgb_lin(c):
    c = c / 255.0
    return c / 12.92 if c <= 0.04045 else ((c + 0.055) / 1.055) ** 2.4

def sun_vec(turn, height):
    t, h = math.radians(turn), math.radians(height)
    return np.array([math.cos(h) * math.sin(t), math.cos(h) * math.cos(t), math.sin(h)])
L = sun_vec(SUN_TURN, SUN_HEIGHT)

# ---------------------------------------------------------------- SRE parse (shared core)
# ==== LFS LOOK CORE ====
# Pure-numpy geometry of one sub-object as the LFS editor draws it. Shared by the
# background build below and by the importer's live update (it execs this block),
# so both always produce the same mesh.
import struct as _cst, math as _cmath
import numpy as np
FP = 65536.0
MX = np.array((-1.0, 1.0, 1.0))


def parse_sub(b, o):
    info = b[o:o+28]; g = o + 28 + info[3] * 4
    nv, nf = _cst.unpack_from('<HH', b, g)
    pos = np.array(_cst.unpack_from('<iii', b, g + 16), float) / FP
    vs = g + 28; fs = vs + nv * 16; fe = fs + nf * 12
    VV = np.frombuffer(b[vs:fs], '<i4').reshape(nv, 4)
    V = VV[:, 1:].astype(float) / FP; VF = VV[:, 0].astype(np.int64)     # point flags
    F = np.frombuffer(b[fs:fe], np.uint8).reshape(nf, 12)
    q = fe; pc = _cst.unpack_from('<i', b, q)[0]; q += 4
    if not (0 <= pc <= 1024): raise ValueError('bad page count')
    pages = [b[q+i*24+4:q+i*24+24].split(b'\0')[0].decode('latin-1') for i in range(pc)]; q += 24 * pc
    cc = _cst.unpack_from('<i', b, q)[0]; q += 4
    if not (0 <= cc <= 65535): raise ValueError('bad cutout count')
    cuts = [b[q+i*32:q+i*32+32] for i in range(cc)]; q += 32 * cc
    mc = _cst.unpack_from('<H', b, q)[0]; q += 4
    maps = [b[q+i*52:q+i*52+52] for i in range(mc)]; q += 52 * mc
    if q > len(b): raise ValueError('sub-object runs past the end of the file')
    lods = [_cst.unpack_from('<i', b, o + 28 + 4 * i)[0] / FP for i in range(info[3])]
    return dict(type=info[1], name=info[4:24].split(b'\0')[0].decode('latin-1'), flip=info[2],
                oflags=info[24], rot=_cst.unpack_from('<hhh', b, g + 8), lods=lods,
                pos=pos, V=V, VF=VF, F=F, pages=pages, cuts=cuts, maps=maps, end=q)


def parse_file(data):
    """all readable sub-objects. The 256-byte layout block follows the first sub-object;
    some files carry it although their body's type byte is not 0 (14 seen) -> tried both
    ways. Parsing stops at the first unreadable record (like the importer)."""
    subs = []; o = 8; k = 0; skipped = False
    while o < len(data):
        s = None
        for at in ((o, o + 256) if (k == 1 and not skipped) else (o,)):
            try:
                s = parse_sub(data, at); break
            except Exception:
                s = None
        if s is None: break
        subs.append(s); o = s['end']
        if k == 0 and s['type'] == 0: o += 256; skipped = True
        k += 1
    return subs


def _dec(q, bits, pmax):
    mod = 1 << bits; d = (q % mod) / 4.0
    return d - mod / 4.0 if d > pmax else d


def frame(raw):
    h, p, r = _dec(raw & 2047, 11, 180.0), _dec((raw >> 11) & 1023, 10, 128.0), _dec((raw >> 21) & 2047, 11, 180.0)
    h, p, r = map(_cmath.radians, (h, p, r)); sh, ch, sp, cp = _cmath.sin(h), _cmath.cos(h), _cmath.sin(p), _cmath.cos(p)
    U0 = np.array((ch, sh, 0.0)); V0 = np.array((sh * sp, -ch * sp, cp))
    cr, sr = _cmath.cos(r), _cmath.sin(r)
    return U0 * cr - V0 * sr, U0 * sr + V0 * cr


def rot_matrix(rot_raw):
    ax, ay, az = [_cmath.radians(r * 360.0 / 65536.0) for r in rot_raw]
    c1, s1, c2, s2, c3, s3 = _cmath.cos(ax), _cmath.sin(ax), _cmath.cos(ay), _cmath.sin(ay), _cmath.cos(az), _cmath.sin(az)
    Rx = np.array([[1, 0, 0], [0, c1, -s1], [0, s1, c1]]); Ry = np.array([[c2, 0, s2], [0, 1, 0], [-s2, 0, c2]])
    Rz = np.array([[c3, -s3, 0], [s3, c3, 0], [0, 0, 1]])
    return Rz @ Ry @ Rx


def cut_uv(cut, u, v):
    """map (u, v) 0..1 -> page uv through the cutout: byte 17 bit 2 = flip, bits 0-1 = quarter
    turns (direction unverified - only interior cutouts use turns), then the clip rectangle"""
    o = cut[17]
    if o & 4: u = 1.0 - u
    for _ in range(o & 3): u, v = v, 1.0 - u
    return (cut[30] / 128.0 + u * cut[28] / 128.0, cut[31] / 128.0 + v * cut[29] / 128.0)


def part_off(s, si, body_pos):
    return s['pos'] if si == 0 else body_pos + s['pos']


def part_geometry(s, si, body_pos, view_dist=8.0, flat_zero=False, dark_w=(1.0, 0.55, 0.3, 0.12),
                  no_sub_mirror=False, custom_all=False, V_override=None):
    """Mesh of one sub-object as the editor draws it (see the rules in the header).
    V_override: the part's points moved (same count/order) - the live update."""
    V = s['V'] if V_override is None else np.asarray(V_override, float).reshape(-1, 3)
    F = s['F']; VF = s['VF']; nv = len(V)
    if nv == 0 or len(F) == 0 or nv != len(s['V']):
        return None
    maps, cuts = s['maps'], s['cuts']
    nm = len(maps)
    if nm == 0:
        return None
    off = part_off(s, si, body_pos)
    Rm = rot_matrix(s['rot'])
    I = np.frombuffer(F[:, 6:12].tobytes(), '<i2').reshape(-1, 3).astype(np.int64)
    # index high bit = inverted winding when set on ALL three corners; on 1 or 2 the
    # face is malformed and LFS skips it (the importer does the same since 1.9.15)
    nneg = (I < 0).sum(1)
    inv = nneg == 3; I = I & 0x7FFF; E = I.copy(); E[inv] = I[inv][:, ::-1]
    mid_all = F[:, 2].astype(np.int64)
    MU = np.zeros((nm, 3)); MVv = np.zeros((nm, 3)); MP = np.zeros((nm, 3)); MW = np.ones(nm); MH = np.ones(nm)
    MC = np.zeros((nm, 2), np.int64)
    for i_, mp in enumerate(maps):
        U_, V_ = frame(_cst.unpack_from('<I', mp, 24)[0]); MU[i_], MVv[i_] = U_, V_
        MP[i_] = np.array(_cst.unpack_from('<iii', mp, 28), float) / FP
        MW[i_] = max(_cst.unpack_from('<i', mp, 40)[0] / FP, 1e-4); MH[i_] = max(_cst.unpack_from('<i', mp, 44)[0] / FP, 1e-4)
        c1, c2 = _cst.unpack_from('<hh', mp, 48)
        if not (0 <= c1 < len(cuts)): c1 = -1
        if not (0 <= c2 < len(cuts)): c2 = c1
        MC[i_] = (c1, c2)
    lod = 0
    if s['type'] != 12 and s['lods']:
        lod = next((i for i, d_ in enumerate(s['lods']) if d_ >= view_dist), len(s['lods']) - 1)
    keep = ((F[:, 4] == lod) & (nneg != 1) & (nneg != 2) & (E.max(1) < nv) & (mid_all < nm)
            & (E[:, 0] != E[:, 1]) & (E[:, 1] != E[:, 2]) & (E[:, 0] != E[:, 2]))
    keep &= MC[np.minimum(mid_all, nm - 1), 0] >= 0
    K = np.nonzero(keep)[0]
    if len(K) == 0:
        return None
    fmir = (F[K, 0] & 1) == 1; fdbl = (F[K, 0] & 32) == 32
    sub_mirror = bool(s['oflags'] & 1) and s['type'] != 0 and not no_sub_mirror
    use_custom = bool(s['oflags'] & 2) or bool(custom_all)
    EK = E[K]; mid = mid_all[K]
    # shading normals: smoothing group (byte 5) + contribution level (byte 3)
    p0, p1, p2 = V[EK[:, 0]], V[EK[:, 1]], V[EK[:, 2]]
    fn = np.cross(p1 - p0, p2 - p0); ln = np.linalg.norm(fn, axis=1)
    fn = np.where(ln[:, None] > 1e-12, fn / np.maximum(ln, 1e-12)[:, None], np.array([0.0, 0.0, 1.0]))
    grp = F[K, 5].astype(np.int64); lvl = F[K, 3].astype(np.int64)
    cv = EK.ravel(); cf = np.repeat(np.arange(len(K)), 3)
    cn_ = fn[cf]; cl = lvl[cf]; cg = grp[cf]
    centre = (np.abs(V[:, 0]) < 1e-5) | ((VF & 2) == 2)
    mm_ = fmir[cf] & centre[cv]                          # the mirror copy shares centre points
    cv = np.concatenate([cv, cv[mm_]]); cn_ = np.concatenate([cn_, cn_[mm_] * MX])
    cl = np.concatenate([cl, cl[mm_]]); cg = np.concatenate([cg, cg[mm_]])
    if flat_zero:
        z_ = cg != 0; cv, cn_, cl, cg = cv[z_], cn_[z_], cl[z_], cg[z_]
    keyc = cv * 256 + cg
    uk, ik = np.unique(keyc, return_inverse=True)
    maxl = np.full(len(uk), -1, np.int64); np.maximum.at(maxl, ik, cl)
    sel = cl == maxl[ik]
    acc = np.zeros((len(uk), 3)); np.add.at(acc, ik[sel], cn_[sel])
    aln = np.linalg.norm(acc, axis=1); VN = acc / np.maximum(aln, 1e-12)[:, None]
    fkeys = EK * 256 + grp[:, None]
    pos_ = np.clip(np.searchsorted(uk, fkeys), 0, len(uk) - 1)
    found = uk[pos_] == fkeys
    CN = np.where((found & (aln[pos_] > 1e-6))[:, :, None], VN[pos_], fn[:, None, :])
    if flat_zero:
        CN = np.where((grp == 0)[:, None, None], fn[:, None, :], CN)
    # map coordinates; reflectable mappings are reflected for the far side (opposite cutout)
    ext = np.abs(MU[:, 0]) * MW / 2 + np.abs(MVv[:, 0]) * MH / 2
    refl = ~((MP[:, 0] - ext < -1e-6) & (MP[:, 0] + ext > 1e-6))
    mside = np.where(np.abs(MP[:, 0]) > 1e-4, np.sign(MP[:, 0]), 0.0)

    def project(Q, mid_):
        cx_ = Q[:, :, 0].mean(1)
        side = np.where(np.abs(cx_) > 1e-3, np.sign(cx_), 0.0)
        opp = refl[mid_] & (mside[mid_] != 0) & (side != 0) & (side != mside[mid_])
        Q = Q.copy(); Q[opp] = Q[opp] * MX
        rel = Q - MP[mid_][:, None, :]
        u = (rel * MU[mid_][:, None, :]).sum(-1) / MW[mid_][:, None] + 0.5
        v = (rel * MVv[mid_][:, None, :]).sum(-1) / MH[mid_][:, None] + 0.5
        return u, v, opp
    Q0 = V[EK]
    UU, VVv, OPP0 = project(Q0, mid)
    UUm, VVm, OPPm = project(Q0 * MX, mid)
    recs = [(EK, CN, UU, VVv, np.arange(len(K)), OPP0)]
    P021 = [0, 2, 1]
    d_ = np.nonzero(fdbl)[0]
    if len(d_): recs.append((EK[d_][:, P021], -CN[d_][:, P021], UU[d_][:, P021], VVv[d_][:, P021], d_, OPP0[d_]))
    m_ = np.nonzero(fmir)[0]
    if len(m_): recs.append((EK[m_][:, P021] + nv, CN[m_][:, P021] * MX, UUm[m_][:, P021], VVm[m_][:, P021], m_, OPPm[m_]))
    md_ = np.nonzero(fmir & fdbl)[0]
    if len(md_): recs.append((EK[md_] + nv, -CN[md_] * MX, UUm[md_], VVm[md_], md_, OPPm[md_]))
    FV = np.concatenate([r[0] for r in recs]); FNm = np.concatenate([r[1] for r in recs])
    FU = np.concatenate([r[2] for r in recs]); FVv = np.concatenate([r[3] for r in recs])
    FI = np.concatenate([r[4] for r in recs]); FO = np.concatenate([r[5] for r in recs])
    world = np.vstack([V, V * MX]) @ Rm.T + off
    FNm = FNm @ Rm.T
    if sub_mirror:
        n2 = len(world)
        verts = np.vstack([world, world * MX])
        FV = np.concatenate([FV, FV[:, P021] + n2]); FNm = np.concatenate([FNm, FNm[:, P021] * MX])
        FU = np.concatenate([FU, FU[:, P021]]); FVv = np.concatenate([FVv, FVv[:, P021]])
        FI = np.concatenate([FI, FI]); FO = np.concatenate([FO, ~FO])
    else:
        verts = world
    shell = all(cuts[c][20] == 2 for c in set(MC[mid, 0].tolist()))
    combos = sorted(set(zip(mid[FI].tolist(), FO.tolist())))
    face_combo = np.zeros(len(FV), np.int64); uvs = np.zeros((len(FV), 3, 2)); combo_cut = []
    for ci, (mi_, op_) in enumerate(combos):
        cidx = int(MC[mi_, 1] if op_ else MC[mi_, 0]); combo_cut.append(cidx)
        sel_ = (mid[FI] == mi_) & (FO == op_)
        face_combo[sel_] = ci
        u2, v2 = cut_uv(cuts[cidx], FU[sel_], FVv[sel_])
        uvs[sel_, :, 0] = u2; uvs[sel_, :, 1] = v2
    base_idx = FV % nv
    lev = (VF[base_idx] >> 6) & 3
    dark = (1.0 - np.asarray(dark_w, float)[lev]).ravel()
    return dict(verts=verts, FV=FV, FNm=FNm, uvs=uvs, dark=dark, combos=combos, combo_cut=combo_cut,
                face_combo=face_combo, shell=shell, use_custom=use_custom, sub_mirror=sub_mirror, lod=lod,
                Rm=Rm, off=off, V=V, nv=nv,
                stats=(int((lvl == 3).sum()), int((lvl == 0).sum()), int(OPP0.sum()), int(fmir.sum()), int(fdbl.sum())))


def tyre_mesh(r_rim, r_out, a_out, width, seg=72):
    """LFS draws the tyre itself (not in the .sre): a lathe around the hub's local x axis"""
    h = max(r_out - r_rim, 0.02); a_in = a_out - width
    prof = [(r_rim - 0.010, a_out - 0.018), (r_rim + 0.10 * h, a_out - 0.004), (r_rim + 0.45 * h, a_out + 0.006),
            (r_out - 0.28 * h, a_out + 0.004), (r_out - 0.06 * h, a_out - 0.014), (r_out, a_out - 0.040),
            (r_out, a_in + 0.040), (r_out - 0.06 * h, a_in + 0.014), (r_out - 0.28 * h, a_in - 0.004),
            (r_rim + 0.45 * h, a_in - 0.006), (r_rim + 0.10 * h, a_in + 0.004), (r_rim - 0.010, a_in + 0.018)]
    verts = []
    for k in range(seg):
        t = 2 * _cmath.pi * k / seg; ct, st = _cmath.cos(t), _cmath.sin(t)
        for r, a in prof: verts.append((a, r * ct, r * st))
    n = len(prof); faces = []
    for k in range(seg):
        k2 = (k + 1) % seg
        for j in range(n - 1):
            faces.append((k * n + j, k * n + j + 1, k2 * n + j + 1, k2 * n + j))
    V_ = np.array(verts)
    f0 = faces[n // 2]; p0, p1, p2 = V_[f0[0]], V_[f0[1]], V_[f0[2]]
    nrm = np.cross(p1 - p0, p2 - p0); radial = np.array([0.0, p0[1], p0[2]])
    if nrm @ radial < 0: faces = [tuple(reversed(f)) for f in faces]
    return V_, faces


def tyre_geometry(geo, tyre_out=-0.012, tyre_radius=0.345, tyre_width=0.235):
    """the generated tyre round a hub object's rim -> (world verts, quad faces)"""
    V = geo['V']; Rm = geo['Rm']; off = geo['off']
    rr = np.sqrt(V[:, 1] ** 2 + V[:, 2] ** 2)
    r_rim = float(rr.max()); a_out = float(V[:, 0].max()) + tyre_out
    TV, TF = tyre_mesh(r_rim, max(tyre_radius, r_rim + 0.03), a_out, tyre_width)
    tw = TV @ Rm.T + off; tf = list(TF)
    if geo['sub_mirror']:
        ntv = len(tw); tw = np.vstack([tw, tw * MX]); tf += [tuple(x + ntv for x in reversed(f)) for f in TF]
    return tw, tf
# ==== LFS LOOK CORE END ====
data = open(SRE, 'rb').read()
subs = parse_file(data)
body_pos = subs[0]['pos']

# ---------------------------------------------------------------- scene
for ob in list(bpy.data.objects): bpy.data.objects.remove(ob, do_unlink=True)
sc = bpy.context.scene
if P.get('scene_name'): sc.name = P['scene_name']
for eng in ('BLENDER_EEVEE_NEXT', 'BLENDER_EEVEE'):
    try: sc.render.engine = eng; break
    except Exception: pass
try: sc.eevee.taa_render_samples = P.get('samples', 64)
except Exception: pass
for vt in ('Standard',):
    try: sc.view_settings.view_transform = vt
    except Exception: pass
try: sc.view_settings.look = 'None'
except Exception: pass
sc.view_settings.exposure = 0.0; sc.view_settings.gamma = 1.0
sc.render.resolution_x, sc.render.resolution_y = P.get('res', [1100, 700])
# shadow_step_count 1: the editor's shadows are hard, and EEVEE's 6 shadow-tracing steps cost
# ~90 % of a Rendered-viewport frame (48 ms -> 3 ms on a GTX 1660 SUPER at 2100 x 1238)
for attr, val in (('use_raytracing', False), ('use_fast_gi', False), ('use_shadows', True), ('shadow_resolution_scale', 1.0),
                  ('use_gtao', False), ('use_ssr', False), ('use_soft_shadows', False),
                  ('shadow_step_count', 1), ('shadow_ray_count', 1)):
    try: setattr(sc.eevee, attr, val)
    except Exception: pass
sc.world = bpy.data.worlds.new('w'); sc.world.use_nodes = True
bg = sc.world.node_tree.nodes['Background']; bg.inputs[0].default_value = (0, 0, 0, 1); bg.inputs[1].default_value = 0.0

# ---- environment (equirect, Blender convention: x = -cos(phi) cos(el), y = sin(phi) cos(el), z = sin(el))
def env_eval(D):
    el = np.arcsin(np.clip(D[..., 2], -1, 1)); th = np.arccos(np.clip(D @ L, -1, 1))
    out = []
    for c in range(3):
        kq = ENVQ[c * 11:(c + 1) * 11]
        fade = np.sqrt(np.clip(el / math.radians(4.0), 0, 1))            # glow also stops at the horizon
        v = np.interp(np.clip(el, 0, np.pi / 2), ENV_KNOTS, kq[:7]) + fade * (kq[7] * np.exp(-th / max(kq[8], 1e-3)) + kq[9] * np.exp(-th / max(kq[10], 1e-3)))
        v = v * (el > 0)
        out.append(v)
    return np.stack(out, -1)
def env_dirs(W, H):
    v = (np.arange(H) + 0.5) / H; u = (np.arange(W) + 0.5) / W
    el = (v - 0.5) * np.pi; ph = (u - 0.5) * 2 * np.pi
    EL, PH = np.meshgrid(el, ph, indexing='ij')       # row 0 = bottom (Blender pixel order)
    return np.stack([-np.cos(PH) * np.cos(EL), np.sin(PH) * np.cos(EL), np.sin(EL)], -1), EL
def blur_sphere(img, EL, sig):
    H, W = img.shape[:2]
    if sig <= 0: return img
    out = img.copy()
    sy = sig / (np.pi / H)                             # texels along elevation
    r = int(np.ceil(3 * sy)); kk = np.exp(-np.arange(-r, r + 1) ** 2 / (2 * sy * sy)); kk /= kk.sum()
    pad = np.concatenate([np.repeat(out[:1], r, 0), out, np.repeat(out[-1:], r, 0)], 0)
    out = sum(kk[i] * pad[i:i + H] for i in range(2 * r + 1))
    for i in range(H):                                 # along azimuth, wider toward the poles
        sx = min(sig / (2 * np.pi / W) / max(np.cos(EL[i, 0]), 0.05), W / 3)
        fr = np.fft.rfftfreq(W) * W
        g = np.exp(-0.5 * (2 * np.pi * fr / W * sx) ** 2)
        out[i] = np.fft.irfft(np.fft.rfft(out[i], axis=0) * g[:, None], n=W, axis=0)
    return out
def mkimg(name, arr):
    H, W = arr.shape[:2]
    im = bpy.data.images.new(name, W, H, float_buffer=True)
    rgba = np.concatenate([arr, np.ones(arr.shape[:2] + (1,))], -1).astype(np.float32)
    im.pixels.foreach_set(rgba.ravel()); im.pack()
    try: im.colorspace_settings.name = 'Linear Rec.709'
    except Exception:
        try: im.colorspace_settings.name = 'Linear'
        except Exception: pass
    return im
Dh, ELh = env_dirs(1024, 512); ENV_H = mkimg('env_hard', env_eval(Dh))
Ds, ELs = env_dirs(256, 128); base_soft = env_eval(Ds)
ENV_SIG = (8, 18, 35, 55)
ENV_LV = [mkimg('env_soft%d' % i, blur_sphere(base_soft, ELs, math.radians(sg))) for i, sg in enumerate(ENV_SIG)]

CONST = {}

# ---------------------------------------------------------------- the LFS shader as a node group
def build_group():
    ng = bpy.data.node_groups.new('LFS_Shade', 'ShaderNodeTree')
    for nm_, ty, dv in (('Base', 'NodeSocketColor', (1, 1, 1, 1)), ('TexAlpha', 'NodeSocketFloat', 1.0),
                        ('F0', 'NodeSocketFloat', 0.04), ('Tint', 'NodeSocketColor', (1, 1, 1, 1)),
                        ('Rough', 'NodeSocketFloat', 0.3), ('ShineOn', 'NodeSocketFloat', 1.0),
                        ('VarShine', 'NodeSocketFloat', 0.0), ('IsAlpha', 'NodeSocketFloat', 0.0),
                        ('ShineA', 'NodeSocketFloat', 0.0), ('DiffA', 'NodeSocketFloat', 0.0),
                        ('Hard', 'NodeSocketFloat', 0.0), ('EnvTint', 'NodeSocketColor', (1, 1, 1, 1))):
        s = ng.interface.new_socket(name=nm_, in_out='INPUT', socket_type=ty); s.default_value = dv
    ng.interface.new_socket(name='Shader', in_out='OUTPUT', socket_type='NodeSocketShader')
    N_, LK = ng.nodes, ng.links
    gi = N_.new('NodeGroupInput'); go = N_.new('NodeGroupOutput')
    def put(sock, v):
        if isinstance(v, bpy.types.NodeSocket): LK.new(v, sock)
        else: sock.default_value = v
    def m(op, a, b=None, clamp=False):
        n = N_.new('ShaderNodeMath'); n.operation = op; n.use_clamp = clamp
        put(n.inputs[0], a)
        if b is not None: put(n.inputs[1], b)
        return n.outputs[0]
    def vm(op, a, b=None, scale=None):
        n = N_.new('ShaderNodeVectorMath'); n.operation = op
        put(n.inputs[0], a)
        if b is not None: put(n.inputs[1], b)
        if scale is not None: put(n.inputs[3], scale)
        return n.outputs[1] if op == 'DOT_PRODUCT' else n.outputs[0]
    def vec(key, x, y, z):
        n = N_.new('ShaderNodeCombineXYZ'); n.label = key
        n.inputs[0].default_value, n.inputs[1].default_value, n.inputs[2].default_value = x, y, z
        CONST[key] = n
        return n.outputs[0]
    def mixc(t, a, b):                                  # a*(1-t) + b*t for vectors
        return vm('ADD', vm('SCALE', a, scale=m('SUBTRACT', 1.0, t)), vm('SCALE', b, scale=t))
    geo = N_.new('ShaderNodeNewGeometry')
    Nn = vm('NORMALIZE', geo.outputs['Normal']); Vv = vm('NORMALIZE', geo.outputs['Incoming'])
    Lv = vec('sun_dir', *L); SUNv = vec('sun_col', SUN_S, SUN_S, SUN_S)
    A0v = vec('amb0', *AMB0); A1v = vec('amb1', *AMB1)
    # shadowed sun: Diffuse BSDF lit by the Sun lamp (strength pi) -> Shader to RGB = N.L * visibility
    dif = N_.new('ShaderNodeBsdfDiffuse'); dif.inputs['Color'].default_value = (1, 1, 1, 1)
    s2r = N_.new('ShaderNodeShaderToRGB'); LK.new(dif.outputs[0], s2r.inputs[0])
    vis = m('MINIMUM', m('MAXIMUM', vm('DOT_PRODUCT', s2r.outputs['Color'], vec('third', 1 / 3, 1 / 3, 1 / 3)), 0.0), 1.0)
    NLr = vm('DOT_PRODUCT', Nn, Lv)
    NL = m('MAXIMUM', NLr, 0.0)
    shd0 = m('MINIMUM', m('DIVIDE', vis, m('MAXIMUM', NL, 0.03)), 1.0)      # 0..1 shadow factor
    tw = N_.new('ShaderNodeMapRange'); tw.interpolation_type = 'SMOOTHSTEP'; LK.new(NL, tw.inputs['Value'])
    tw.inputs['From Min'].default_value = 0.02; tw.inputs['From Max'].default_value = 0.22
    shd = m('ADD', m('MULTIPLY', shd0, tw.outputs['Result']), m('SUBTRACT', 1.0, tw.outputs['Result']))
    NV = m('MAXIMUM', vm('DOT_PRODUCT', Nn, Vv), 1e-4)
    Hh = vm('NORMALIZE', vm('ADD', Vv, Lv))
    NH = m('MAXIMUM', vm('DOT_PRODUCT', Nn, Hh), 0.0)
    LH = m('MAXIMUM', vm('DOT_PRODUCT', Lv, Hh), 0.0)
    a = m('MINIMUM', m('MAXIMUM', m('MULTIPLY', m('MULTIPLY', gi.outputs['Rough'], gi.outputs['Rough']), 1.5), 0.004), 1.0); a2 = m('MULTIPLY', a, a)
    den = m('ADD', m('MULTIPLY', m('MULTIPLY', NH, NH), m('SUBTRACT', a2, 1.0)), 1.0)
    D = m('DIVIDE', a2, m('MULTIPLY', den, den))
    kk = m('MULTIPLY', a, 0.5); omk = m('SUBTRACT', 1.0, kk)
    G1V = m('ADD', m('MULTIPLY', NV, omk), kk); G1L = m('ADD', m('MULTIPLY', NL, omk), kk)
    F0 = gi.outputs['F0']; omf = m('SUBTRACT', 1.0, F0)
    Fs = m('ADD', F0, m('MULTIPLY', omf, m('POWER', m('SUBTRACT', 1.0, LH), 5.0)))
    ssun = m('DIVIDE', m('MULTIPLY', m('MULTIPLY', Fs, D), NL), m('MULTIPLY', 4.0, m('MULTIPLY', G1V, G1L)))
    ssun = m('MULTIPLY', m('MINIMUM', ssun, 60.0), shd)
    R = vm('SUBTRACT', vm('SCALE', Nn, scale=m('MULTIPLY', NV, 2.0)), Vv)
    eh = N_.new('ShaderNodeTexEnvironment'); eh.image = ENV_H; LK.new(R, eh.inputs['Vector'])
    ev = []
    for im in ENV_LV:
        n = N_.new('ShaderNodeTexEnvironment'); n.image = im; LK.new(R, n.inputs['Vector']); ev.append(n.outputs['Color'])
    sig = m('MULTIPLY', a, 57.2958)                                      # blur in degrees = GGX alpha
    t1 = m('MINIMUM', m('MAXIMUM', m('DIVIDE', sig, 8.0), 0.0), 1.0)
    t2 = m('MINIMUM', m('MAXIMUM', m('DIVIDE', m('SUBTRACT', sig, 8.0), 10.0), 0.0), 1.0)
    t3 = m('MINIMUM', m('MAXIMUM', m('DIVIDE', m('SUBTRACT', sig, 18.0), 17.0), 0.0), 1.0)
    t4 = m('MINIMUM', m('MAXIMUM', m('DIVIDE', m('SUBTRACT', sig, 35.0), 20.0), 0.0), 1.0)
    softc = mixc(t4, mixc(t3, mixc(t2, mixc(t1, eh.outputs['Color'], ev[0]), ev[1]), ev[2]), ev[3])
    envc = mixc(gi.outputs['Hard'], softc, eh.outputs['Color'])
    ne = N_.new('ShaderNodeMath'); ne.operation = 'MULTIPLY'; ne.label = 'env_scale'
    Fe = m('ADD', F0, m('MULTIPLY', omf, m('POWER', m('SUBTRACT', 1.0, NV), 5.0)))
    LK.new(Fe, ne.inputs[0]); ne.inputs[1].default_value = 1.0; CONST['env_scale'] = ne
    # per-point "ambient darkness" (the editor's NORMAL.w scales sky light AND reflections);
    # stored as darkness so meshes without the attribute read 0 = fully lit
    att = N_.new('ShaderNodeAttribute'); att.attribute_type = 'GEOMETRY'; att.attribute_name = 'lfs_dark'
    aw = m('MAXIMUM', m('SUBTRACT', 1.0, att.outputs['Fac']), 0.0)
    envterm = vm('SCALE', envc, scale=m('MULTIPLY', ne.outputs[0], aw))
    spec = vm('MULTIPLY', vm('ADD', vm('SCALE', SUNv, scale=ssun), envterm), gi.outputs['EnvTint'])
    # the editor's alpha_multipliers: shine = ShineA*alpha + (1-|ShineA|)... written out:
    # C SHINE 1, V SHINE alpha, OVERLAY 1-alpha (VarShine carries B: shine = A*alpha + B)
    smul = m('MULTIPLY', gi.outputs['ShineOn'], m('ADD', m('MULTIPLY', gi.outputs['ShineA'], gi.outputs['TexAlpha']), gi.outputs['VarShine']))
    dmul = m('ADD', m('MULTIPLY', gi.outputs['DiffA'], gi.outputs['TexAlpha']), m('SUBTRACT', 1.0, m('ABSOLUTE', gi.outputs['DiffA'])))
    spec = vm('SCALE', vm('MULTIPLY', spec, gi.outputs['Tint']), scale=smul)
    ambm = N_.new('ShaderNodeMath'); ambm.operation = 'MULTIPLY'; ambm.label = 'amb_scale'; ambm.inputs[1].default_value = 1.0
    sepn = N_.new('ShaderNodeSeparateXYZ'); LK.new(Nn, sepn.inputs[0])
    amb = vm('ADD', A0v, vm('SCALE', A1v, scale=sepn.outputs[2]))
    ambm.inputs[0].default_value = 1.0; CONST['amb_scale'] = ambm
    amb = vm('SCALE', amb, scale=m('MULTIPLY', ambm.outputs[0], aw))
    diff = vm('MULTIPLY', gi.outputs['Base'], vm('ADD', vm('SCALE', SUNv, scale=m('MULTIPLY', NL, shd)), amb))
    diff = vm('SCALE', diff, scale=dmul)
    ia = gi.outputs['IsAlpha']
    opac = m('ADD', m('MULTIPLY', ia, gi.outputs['TexAlpha']), m('SUBTRACT', 1.0, ia))
    e1 = N_.new('ShaderNodeEmission'); LK.new(spec, e1.inputs['Color'])
    e2 = N_.new('ShaderNodeEmission'); LK.new(diff, e2.inputs['Color'])
    tr = N_.new('ShaderNodeBsdfTransparent')
    mx = N_.new('ShaderNodeMixShader'); LK.new(opac, mx.inputs[0]); LK.new(tr.outputs[0], mx.inputs[1]); LK.new(e2.outputs[0], mx.inputs[2])
    ad = N_.new('ShaderNodeAddShader'); LK.new(e1.outputs[0], ad.inputs[0]); LK.new(mx.outputs[0], ad.inputs[1])
    LK.new(ad.outputs[0], go.inputs['Shader'])
    return ng
GROUP = build_group()

IMG = {}
BLACK_PAGES = {'s_mirr'}            # the editor draws the mirror-glass page black
def page_img(name):
    if name in IMG: return IMG[name]
    im = None
    for d_ in (PNG, SPECIAL):
        f = os.path.join(d_, name + '.png') if (d_ and name) else ''
        if f and os.path.isfile(f):
            im = bpy.data.images.load(f); im.alpha_mode = 'STRAIGHT'
            try: im.colorspace_settings.name = 'sRGB'
            except Exception: pass
            break
    IMG[name] = im; return im

def user_rgb(mapname, rgb, use_custom=True):
    """-> (rgb, slot, shade): m/c<n> = colour n, d<n> = 60 %, e<n> = 35 % - only on
    sub-objects whose "use custom colours" flag is set (ObjInfo[24] bit 1)."""
    n = mapname.lower()
    if use_custom and len(n) >= 2 and n[0] in 'mcde' and n[1] in '1234':
        slot = int(n[1]); base = COLS.get(slot)
        if base is not None:
            k = 1.0 if n[0] in 'mc' else (0.6 if n[0] == 'd' else 0.35)
            return ([int(c * k) for c in base] if k != 1.0 else list(base)), slot, k
    return rgb, None, None

MATS = {}; USER = []; SEE = {}
def material(cut, page, rgb, slot, shade, shell=False):
    if page.lower() in BLACK_PAGES:
        page, rgb, slot, shade = '', [0, 0, 0], None, None
    key = (bytes(cut), page, tuple(rgb), slot, shade, shell)
    if key in MATS: return MATS[key]
    mat = bpy.data.materials.new('lfs_%d' % len(MATS))
    try: mat.use_nodes = True
    except Exception: pass
    see_through = (cut[20] == 2 and page_img(page) is not None)
    try: mat.surface_render_method = 'BLENDED' if see_through else 'DITHERED'
    except Exception:
        try: mat.blend_method = 'BLEND' if cut[20] == 2 else 'OPAQUE'
        except Exception: pass
    if see_through: SEE[mat.name] = page_img(page)      # blended glass casts no shadow -> twin below
    try: mat.use_backface_culling = True                # single-sided; double-sided tris get a back copy
    except Exception: pass
    nt = mat.node_tree; nt.nodes.clear()
    out = nt.nodes.new('ShaderNodeOutputMaterial'); g = nt.nodes.new('ShaderNodeGroup'); g.node_tree = GROUP
    nt.links.new(g.outputs[0], out.inputs['Surface'])
    base = [sq(c) for c in rgb] + [1.0]
    gam = [c / 255.0 for c in rgb] + [1.0]
    at, rt, st = cut[20], cut[21], cut[22]
    # METAL reflections take the surface colour for C SHINE / V SHINE (the calibration chrome
    # balls), but not for OVERLAY: his rims (map colour 13) are bright chrome in the editor
    metal = (st == 3) and rt in (1, 2)
    im = page_img(page)
    if im is not None:
        tx = nt.nodes.new('ShaderNodeTexImage'); tx.image = im; tx.interpolation = 'Linear'; tx.extension = 'REPEAT'
        uv = nt.nodes.new('ShaderNodeUVMap'); uv.uv_map = 'UVMap'; nt.links.new(uv.outputs[0], tx.inputs[0])
        mul = nt.nodes.new('ShaderNodeVectorMath'); mul.operation = 'MULTIPLY'
        nt.links.new(tx.outputs['Color'], mul.inputs[0]); mul.inputs[1].default_value = base[:3]
        nt.links.new(mul.outputs[0], g.inputs['Base']); nt.links.new(tx.outputs['Alpha'], g.inputs['TexAlpha'])
        csock = mul.inputs[1]
        if metal:
            mt = nt.nodes.new('ShaderNodeVectorMath'); mt.operation = 'MULTIPLY'
            nt.links.new(tx.outputs['Color'], mt.inputs[0]); mt.inputs[1].default_value = gam[:3]
            nt.links.new(mt.outputs[0], g.inputs['EnvTint'])
    else:
        g.inputs['Base'].default_value = base; g.inputs['TexAlpha'].default_value = 1.0
        csock = g.inputs['Base']
        if metal: g.inputs['EnvTint'].default_value = gam
    if slot is not None:
        USER.append((csock, slot, shade, 'base'))
    g.inputs['F0'].default_value = F0T.get(st, 0.04)
    g.inputs['Tint'].default_value = [sq(c) for c in cut[24:27]] + [1.0]
    g.inputs['Rough'].default_value = cut[27] / 100.0
    g.inputs['ShineOn'].default_value = 0.0 if (rt == 0 or st == 0) else 1.0
    # alpha multipliers per environment type (PSC_ShineConsts.alpha_multipliers in the editor's
    # pixel shaders): shine = A*alpha + B, diffuse = A'*alpha + B'
    #   C SHINE: 0,1 / 0,1   V SHINE: 1,0 / 0,1   OVERLAY: -1,1 / 1,0 ("Overlay or Plain":
    #   the page alpha is how much of the texture overlays a shiny base - chrome pages 0.2,
    #   headlight page 0.75; without a texture alpha = 1 -> plain, no shine)
    sa, sb, da = {2: (1.0, 0.0, 0.0), 3: (-1.0, 1.0, 1.0)}.get(rt, (0.0, 1.0, 0.0))
    g.inputs['ShineA'].default_value = sa; g.inputs['VarShine'].default_value = sb; g.inputs['DiffA'].default_value = da
    g.inputs['IsAlpha'].default_value = 1.0 if (at == 2 and im is not None) else 0.0
    g.inputs['Hard'].default_value = 1.0 if cut[27] == 0 else 0.0
    MATS[key] = mat; return mat

# ---------------------------------------------------------------- meshes
# Placement / mapping rules (v4g - names are the editor's own labels from LFS_EDITOR.exe):
#  * triangle byte 0 bit 0 = mirrored: a copy about the SUB-OBJECT's own x = 0 (a half steering
#    wheel becomes a whole one at the driver's seat); bit 5 = double sided; bit 4 = moves to the
#    other side when the drive side is swapped (the preview shows the left-hand-drive layout)
#  * ObjInfo[24] bit 0 = "mirrored subobject": the whole part also appears on the other side of
#    the car (both hubs/wheels, both calipers, both exhausts, the full badge, the passenger seat)
#  * GeometryInfo rot i16 x3 (x 360/65536 deg) rotates the part about its own origin
#  * a mirrored triangle mapped by a map that sits on the other side of the car is mapped from
#    its mirror image (the editor maps a mirrored pair from whichever side the map is on)
#  * mirror copies use the map's second cutout (map bytes 50:52)
lo, hi = np.full(3, 1e9), np.full(3, -1e9)
NORMAL_STATS = []; PLACE_STATS = []
FLAT_ZERO = bool(P.get('flat_zero', False))            # smoothing byte 0 is a normal group
DARK_W = P.get('amb_dark_w', [1.0, 0.55, 0.3, 0.12])   # NORMAL.w for bright/dark/very dark/extra dark (guess)

RUBBER = None
def rubber_material():
    global RUBBER
    if RUBBER is not None: return RUBBER
    cut = bytearray(32); cut[20] = 0; cut[21] = 1; cut[22] = 6; cut[24:27] = bytes((255, 255, 255)); cut[27] = 70
    cut[28:32] = bytes((128, 128, 0, 0))
    RUBBER = material(bytes(cut), '', [22, 22, 22], None, None)
    return RUBBER


def place_mesh(name, verts, faces, mats, mat_idx, uvs, cnormals, dark, glass_shadow=False):
    me = bpy.data.meshes.new(name or 'sub')
    me.from_pydata(verts.tolist(), [], faces)
    for mm in mats: me.materials.append(mm)
    if mat_idx is not None: me.polygons.foreach_set('material_index', mat_idx)
    if uvs is not None:
        uvl = me.uv_layers.new(name='UVMap'); uvl.data.foreach_set('uv', uvs)
    me.update()
    me.shade_smooth()
    if cnormals is not None:
        try:
            at_ = me.attributes.get('custom_normal') or me.attributes.new('custom_normal', 'FLOAT_VECTOR', 'CORNER')
            at_.data.foreach_set('vector', cnormals)
        except Exception as e:
            print('custom normals failed on', name, e)
    if dark is not None and len(dark):
        ad = me.attributes.new('lfs_dark', 'FLOAT', 'CORNER'); ad.data.foreach_set('value', dark)
    me.update()
    ob = bpy.data.objects.new(name or 'sub', me); sc.collection.objects.link(ob)
    if glass_shadow and any(SEE.get(mm.name) is not None for mm in mats):
        # blended glass casts no shadow in EEVEE, the editor's glass does (alpha shadows):
        # a camera-invisible twin of the part casts the glass shadows only
        so = bpy.data.objects.new((name or 'sub') + ' glass shadow', me); sc.collection.objects.link(so)
        so['lfs_twin'] = True
        for i_, mm in enumerate(mats):
            sl = so.material_slots[i_]; sl.link = 'OBJECT'
            sl.material = shadow_twin(mm) if SEE.get(mm.name) is not None else no_shadow()
        for a_ in ('visible_camera', 'visible_diffuse', 'visible_glossy', 'visible_transmission', 'visible_volume_scatter'):
            try: setattr(so, a_, False)
            except Exception: pass
        try: so.visible_shadow = True
        except Exception: pass
    return ob

TWINS = {}
def shadow_twin(mm):
    if mm.name in TWINS: return TWINS[mm.name]
    t = bpy.data.materials.new(mm.name + '_shadow'); t.use_nodes = True; nt = t.node_tree; nt.nodes.clear()
    o_ = nt.nodes.new('ShaderNodeOutputMaterial'); tx = nt.nodes.new('ShaderNodeTexImage'); tx.image = SEE[mm.name]
    uv = nt.nodes.new('ShaderNodeUVMap'); uv.uv_map = 'UVMap'; nt.links.new(uv.outputs[0], tx.inputs[0])
    tr = nt.nodes.new('ShaderNodeBsdfTransparent'); em = nt.nodes.new('ShaderNodeEmission'); em.inputs['Color'].default_value = (0, 0, 0, 1)
    mx = nt.nodes.new('ShaderNodeMixShader'); nt.links.new(tx.outputs['Alpha'], mx.inputs[0])
    nt.links.new(tr.outputs[0], mx.inputs[1]); nt.links.new(em.outputs[0], mx.inputs[2]); nt.links.new(mx.outputs[0], o_.inputs['Surface'])
    try: t.surface_render_method = 'DITHERED'
    except Exception: pass
    try: t.use_transparent_shadow = True
    except Exception: pass
    TWINS[mm.name] = t; return t
NOSH = []
def no_shadow():
    if NOSH: return NOSH[0]
    t = bpy.data.materials.new('lfs_no_shadow'); t.use_nodes = True; nt = t.node_tree; nt.nodes.clear()
    o_ = nt.nodes.new('ShaderNodeOutputMaterial'); tr = nt.nodes.new('ShaderNodeBsdfTransparent'); nt.links.new(tr.outputs[0], o_.inputs['Surface'])
    try: t.surface_render_method = 'DITHERED'
    except Exception: pass
    try: t.use_transparent_shadow = True
    except Exception: pass
    NOSH.append(t); return t

LOOK_PARAMS = dict(view_dist=float(P.get('view_dist', 8.0)), flat_zero=FLAT_ZERO, dark_w=[float(x) for x in DARK_W],
                   no_sub_mirror=bool(P.get('no_sub_mirror')), custom_all=bool(P.get('custom_all', False)),
                   tyres=bool(P.get('tyres', True)), tyre_out=float(P.get('tyre_out', -0.012)),
                   tyre_radius=float(P.get('tyre_radius', 0.345)), tyre_width=float(P.get('tyre_width', 0.235)))
for si, s in enumerate(subs):
    if s['type'] in P.get('skip_types', []): continue
    if P.get('only') and s['name'] not in P['only']: continue
    if s['name'] in P.get('skip_names', []): continue
    geo = part_geometry(s, si, body_pos, LOOK_PARAMS['view_dist'], FLAT_ZERO, DARK_W,
                        LOOK_PARAMS['no_sub_mirror'], LOOK_PARAMS['custom_all'])
    if geo is None: continue
    maps, cuts, pages = s['maps'], s['cuts'], s['pages']
    # ---- materials per (map, which cutout); several combos can share one material
    mats, mat_of, combo_slot = [], {}, []
    for ci, (mi_, op_) in enumerate(geo['combos']):
        cut = cuts[geo['combo_cut'][ci]]; pg = cut[18]; page = pages[pg] if pg < len(pages) else ''
        mp = maps[mi_]
        rgb, slot, shade = user_rgb(mp[:16].split(b'\0')[0].decode('latin-1'), list(mp[16:19]), geo['use_custom'])
        mat = material(cut, page, rgb, slot, shade, geo['shell'])
        if mat.name not in mat_of: mat_of[mat.name] = len(mats); mats.append(mat)
        combo_slot.append(mat_of[mat.name])
    face_mat = np.asarray(combo_slot, np.int64)[geo['face_combo']]
    verts, FV, dark = geo['verts'], geo['FV'], geo['dark']
    ob = place_mesh(s['name'], verts, FV.tolist(), mats, face_mat.tolist(), geo['uvs'].ravel().tolist(),
                    geo['FNm'].reshape(-1).tolist(), dark.tolist() if dark.any() else None, glass_shadow=not geo['shell'])
    # live update (importer): which sub-object this is and which material slot each combo uses
    ob['lfs_src_sub'] = si
    ob['lfs_combo_slot'] = [int(x) for (mi_, op_), sl in zip(geo['combos'], combo_slot) for x in (mi_, op_, sl)]
    if geo['shell']:
        try: ob.visible_shadow = False                  # see-through paint shells must not shadow the body
        except Exception: pass
    lvl3, lvl0, opp0, nfm, nfd = geo['stats']
    NORMAL_STATS.append((s['name'], lvl3, lvl0, opp0))
    PLACE_STATS.append((s['name'], 'lod%d' % geo['lod'], 'rot' if any(s['rot']) else '', 'sub-mirror' if geo['sub_mirror'] else '',
                        'face-mirror %d' % nfm if nfm else '', 'double %d' % nfd if nfd else '',
                        'custom' if geo['use_custom'] else '', 'shell' if geo['shell'] else ''))
    # ---- hub objects: the editor draws the tyre round the rim
    if s['type'] == 12 and LOOK_PARAMS['tyres']:
        tw, tf = tyre_geometry(geo, LOOK_PARAMS['tyre_out'], LOOK_PARAMS['tyre_radius'], LOOK_PARAMS['tyre_width'])
        to = place_mesh(s['name'] + ' tyre', tw, tf, [rubber_material()], None, None, None, None)
        to['lfs_src_sub'] = si; to['lfs_tyre'] = True
    if si == 0:
        lo = np.minimum(lo, verts.min(0)); hi = np.maximum(hi, verts.max(0))
ctr = (lo + hi) / 2

# ---------------------------------------------------------------- editor floor + sky backdrop
def floor_z():
    # a car stands on the editor's floor at height 0; a file without a body (a wheel, an
    # interior...) sits on its own origin - its floor goes under its lowest point (2.0.1)
    if any(s['type'] in (0, 14) and len(s['F']) for s in subs):
        return 0.0
    zs = []
    for o in sc.objects:
        if o.type == 'MESH' and len(o.data.vertices):
            co = np.empty(len(o.data.vertices) * 3, np.float32); o.data.vertices.foreach_get('co', co)
            zs.append(float(co[2::3].min()) + float(o.location.z))
    fz = min([0.0] + zs)
    return fz - 0.001 if fz < 0.0 else 0.0
def floor_and_sky():
    # floor: big plane, emission = lit grey * shadow, 1 m blue grid + cyan y=0 line of ~1.3 px
    fz = floor_z()
    me = bpy.data.meshes.new('lfs_floor'); R_ = P.get('floor_radius', 200.0)
    me.from_pydata([(-R_, -R_, 0), (R_, -R_, 0), (R_, R_, 0), (-R_, R_, 0)], [], [(0, 1, 2, 3)]); me.update()
    ob = bpy.data.objects.new('LFS floor', me); sc.collection.objects.link(ob)
    ob.location.z = fz
    mat = bpy.data.materials.new('lfs_floor'); mat.use_nodes = True; nt = mat.node_tree; nt.nodes.clear(); N_, LK = nt.nodes, nt.links
    outn = N_.new('ShaderNodeOutputMaterial')
    def m(op, a, b=None):
        n = N_.new('ShaderNodeMath'); n.operation = op
        if isinstance(a, bpy.types.NodeSocket): LK.new(a, n.inputs[0])
        else: n.inputs[0].default_value = a
        if b is not None:
            if isinstance(b, bpy.types.NodeSocket): LK.new(b, n.inputs[1])
            else: n.inputs[1].default_value = b
        return n.outputs[0]
    dif = N_.new('ShaderNodeBsdfDiffuse'); s2r = N_.new('ShaderNodeShaderToRGB'); LK.new(dif.outputs[0], s2r.inputs[0])
    sep = N_.new('ShaderNodeSeparateColor'); LK.new(s2r.outputs['Color'], sep.inputs[0])
    nl = N_.new('ShaderNodeValue'); nl.label = 'floor_nl'; nl.outputs[0].default_value = max(L[2], 0.05); CONST['floor_nl'] = nl
    shadow = m('MINIMUM', m('DIVIDE', sep.outputs[0], nl.outputs[0]), 1.0)
    lit = [srgb_lin(c) for c in FLOOR_LIT]
    col = N_.new('ShaderNodeCombineColor')
    for i in range(3): LK.new(m('MULTIPLY', shadow, lit[i]), col.inputs[i])
    tc = N_.new('ShaderNodeTexCoord'); sxyz = N_.new('ShaderNodeSeparateXYZ'); LK.new(tc.outputs['Object'], sxyz.inputs[0])
    cam = N_.new('ShaderNodeCameraData')
    w = m('MULTIPLY', cam.outputs['View Distance'], P.get('grid_px_scale', 1.3) / max(P.get('grid_f_px', 1700.0), 1.0))
    def line(coord):
        fr = m('ABSOLUTE', m('SUBTRACT', m('FRACT', m('ADD', coord, 0.5)), 0.5))
        return m('MAXIMUM', m('SUBTRACT', 1.0, m('DIVIDE', fr, w)), 0.0)
    ext = P.get('grid_extent', 12.0)
    inside = m('MULTIPLY', m('LESS_THAN', m('ABSOLUTE', sxyz.outputs[0]), ext + 0.01), m('LESS_THAN', m('ABSOLUTE', sxyz.outputs[1]), ext + 0.01))
    gl = m('MULTIPLY', m('MAXIMUM', line(sxyz.outputs[0]), line(sxyz.outputs[1])), inside)
    ax = m('MULTIPLY', m('MAXIMUM', m('SUBTRACT', 1.0, m('DIVIDE', m('ABSOLUTE', sxyz.outputs[1]), w)), 0.0), m('LESS_THAN', m('ABSOLUTE', sxyz.outputs[0]), ext + 0.01))
    gcol = N_.new('ShaderNodeRGB'); gcol.outputs[0].default_value = [srgb_lin(c) for c in GRID_RGB] + [1]
    acol = N_.new('ShaderNodeRGB'); acol.outputs[0].default_value = [srgb_lin(c) for c in AXIS_RGB] + [1]
    mix1 = N_.new('ShaderNodeMix'); mix1.data_type = 'RGBA'; LK.new(gl, mix1.inputs['Factor']); LK.new(col.outputs[0], mix1.inputs['A']); LK.new(gcol.outputs[0], mix1.inputs['B'])
    mix2 = N_.new('ShaderNodeMix'); mix2.data_type = 'RGBA'; LK.new(ax, mix2.inputs['Factor']); LK.new(mix1.outputs['Result'], mix2.inputs['A']); LK.new(acol.outputs[0], mix2.inputs['B'])
    em = N_.new('ShaderNodeEmission'); LK.new(mix2.outputs['Result'], em.inputs['Color']); LK.new(em.outputs[0], outn.inputs['Surface'])
    try: mat.use_backface_culling = True        # 2.0.1: seen from below, the floor is not there
    except Exception: pass
    me.materials.append(mat)
    try: ob.visible_shadow = False
    except Exception: pass
    # sky dome: inward sphere, camera-only
    bpy.ops.mesh.primitive_uv_sphere_add(segments=48, ring_count=24, radius=P.get('floor_radius', 200.0) * 1.5, location=(0, 0, 0))
    sky = bpy.context.active_object; sky.name = 'LFS sky'
    smat = bpy.data.materials.new('lfs_sky'); smat.use_nodes = True; nt = smat.node_tree; nt.nodes.clear(); N_, LK = nt.nodes, nt.links
    o2 = N_.new('ShaderNodeOutputMaterial'); tc2 = N_.new('ShaderNodeTexCoord'); sz = N_.new('ShaderNodeSeparateXYZ')
    nrm = N_.new('ShaderNodeVectorMath'); nrm.operation = 'NORMALIZE'; LK.new(tc2.outputs['Object'], nrm.inputs[0]); LK.new(nrm.outputs[0], sz.inputs[0])
    ramp = N_.new('ShaderNodeValToRGB'); LK.new(sz.outputs[2], ramp.inputs[0])
    cr = ramp.color_ramp; cr.elements[0].position = 0.0; cr.elements[0].color = [srgb_lin(c) for c in (211, 228, 230)] + [1]
    cr.elements[1].position = 0.07; cr.elements[1].color = [srgb_lin(c) for c in (206, 232, 252)] + [1]
    e3 = cr.elements.new(0.6); e3.color = [srgb_lin(c) for c in (150, 185, 235)] + [1]
    # 2.0.1: the lower half grey (seen from under the floor)
    lt = N_.new('ShaderNodeMath'); lt.operation = 'LESS_THAN'; LK.new(sz.outputs[2], lt.inputs[0]); lt.inputs[1].default_value = 0.0
    gry = N_.new('ShaderNodeRGB'); gry.outputs[0].default_value = [srgb_lin(c) for c in FLOOR_LIT] + [1]
    mxs = N_.new('ShaderNodeMix'); mxs.data_type = 'RGBA'; LK.new(lt.outputs[0], mxs.inputs['Factor'])
    LK.new(ramp.outputs[0], mxs.inputs['A']); LK.new(gry.outputs[0], mxs.inputs['B'])
    em2 = N_.new('ShaderNodeEmission'); LK.new(mxs.outputs['Result'], em2.inputs['Color']); LK.new(em2.outputs[0], o2.inputs['Surface'])
    sky.data.materials.append(smat)
    try: sky.visible_shadow = False
    except Exception: pass
if P.get('floor', True):
    floor_and_sky()

# ---------------------------------------------------------------- sun lamp (shadows) + lighting rig
ld = bpy.data.lights.new('LFS Sun', 'SUN'); ld.energy = math.pi; ld.color = (1, 1, 1)
try: ld.angle = math.radians(0.4)
except Exception: pass
try: ld.use_shadow = True
except Exception: pass
try: ld.shadow_maximum_resolution = 0.0005
except Exception: pass
lamp = bpy.data.objects.new('LFS Sun', ld); sc.collection.objects.link(lamp)
lamp.rotation_mode = 'XYZ'; lamp.rotation_euler = (math.radians(90 - SUN_HEIGHT), 0.0, math.radians(180 - SUN_TURN))
lamp.location = Vector(ctr.tolist()) + Vector((L * 6).tolist())

PANEL_SRC = '''import bpy

class VIEW3D_PT_lfs_paint_preview_light(bpy.types.Panel):
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'LFS'
    bl_label = 'Paint Preview Lighting'
    bl_order = -1

    @classmethod
    def poll(cls, context):
        return context.scene is not None and 'Sun turn' in context.scene

    def draw(self, context):
        sc = context.scene
        lay = self.layout
        col = lay.column(align=True)
        for k in ('Sun turn', 'Sun height', 'Sun strength'):
            col.prop(sc, '["%s"]' % k, text=k)
        for k in ('Sun colour', 'Shadow fill', 'Sky reflections', 'Body colour', 'Colour 2', 'Colour 3', 'Colour 4'):
            if k in sc:
                lay.prop(sc, '["%s"]' % k, text=k)
        lay.label(text='Defaults = measured from the LFS editor', icon='INFO')
        if 'lfs_look_source_scene' in sc and hasattr(bpy.types, 'LFS_OT_toggle_look'):
            lay.operator('lfs.toggle_look', text='Back to the editable model', icon='LOOP_BACK')

def register():
    old = getattr(bpy.types, 'VIEW3D_PT_lfs_paint_preview_light', None)
    if old is not None:
        try:
            bpy.utils.unregister_class(old)
        except Exception:
            pass
    bpy.utils.register_class(VIEW3D_PT_lfs_paint_preview_light)

register()
'''

def build_rig():
    def prop(name, val, **ui):
        sc[name] = val
        try: sc.id_properties_ui(name).update(default=val, **ui)
        except Exception as e: print('prop', name, e)
    prop('Sun turn', float(SUN_TURN), min=0.0, max=360.0, soft_min=0.0, soft_max=360.0, step=500, precision=0,
         description='Where the sun sits around the car, in degrees: 0 = in front, 90 = right side, 180 = behind, 270 = left side. LFS editor = 45')
    prop('Sun height', float(SUN_HEIGHT), min=1.0, max=90.0, soft_min=1.0, soft_max=90.0, step=500, precision=0,
         description='Sun height above the horizon, in degrees. LFS editor = 45')
    prop('Sun strength', float(SUN_S), min=0.0, max=5.0, soft_min=0.0, soft_max=3.0, step=10, precision=3,
         description='Brightness of the sun (lit side and highlights). LFS editor = 0.985')
    prop('Sun colour', [1.0, 1.0, 1.0], subtype='COLOR_GAMMA', min=0.0, max=1.0, description='Colour of the sunlight (the editor uses white)')
    prop('Shadow fill', 1.0, min=0.0, max=3.0, soft_min=0.0, soft_max=2.0, step=5, precision=2,
         description='Sky light on the shaded side. 1 = as measured in the LFS editor')
    prop('Sky reflections', 1.0, min=0.0, max=3.0, soft_min=0.0, soft_max=2.0, step=5, precision=2,
         description='How strongly the sky shows in reflections. 1 = as measured in the LFS editor')
    names = {1: 'Body colour', 2: 'Colour 2', 3: 'Colour 3', 4: 'Colour 4'}
    for slot in sorted({u[1] for u in USER}):
        prop(names[slot], [c / 255.0 for c in COLS[slot]], subtype='COLOR_GAMMA', min=0.0, max=1.0,
             description='LFS user colour %d (maps named m%d / c%d; d%d = 60 %%, e%d = 35 %%)' % (slot, slot, slot, slot, slot))
    Rd = '0.0174533'
    def drive(owner, path, index, expr, varz):
        fc = owner.driver_add(path, index) if index is not None else owner.driver_add(path)
        d = fc.driver; d.type = 'SCRIPTED'
        for v in list(d.variables): d.variables.remove(v)
        for nm_, dp in varz:
            v = d.variables.new(); v.name = nm_; v.type = 'SINGLE_PROP'
            t_ = v.targets[0]; t_.id_type = 'SCENE'; t_.id = sc; t_.data_path = dp
        d.expression = expr
    tv = [('t', '["Sun turn"]'), ('h', '["Sun height"]')]
    nL, nS, nE, nA = CONST['sun_dir'], CONST['sun_col'], CONST['env_scale'], CONST['amb_scale']
    drive(nL.inputs[0], 'default_value', None, 'cos(h*%s)*sin(t*%s)' % (Rd, Rd), tv)
    drive(nL.inputs[1], 'default_value', None, 'cos(h*%s)*cos(t*%s)' % (Rd, Rd), tv)
    drive(nL.inputs[2], 'default_value', None, 'sin(h*%s)' % Rd, [('h', '["Sun height"]')])
    for i in range(3):
        drive(nS.inputs[i], 'default_value', None, 'c*c*s', [('c', '["Sun colour"][%d]' % i), ('s', '["Sun strength"]')])
    drive(nE.inputs[1], 'default_value', None, 'r', [('r', '["Sky reflections"]')])
    drive(nA.inputs[0], 'default_value', None, 'a', [('a', '["Shadow fill"]')])
    if 'floor_nl' in CONST:
        drive(CONST['floor_nl'].outputs[0], 'default_value', None, 'max(sin(h*%s),0.05)' % Rd, [('h', '["Sun height"]')])
    for sock, slot, shade, kind in USER:
        k2 = shade * shade
        for i in range(3):
            drive(sock, 'default_value', i, 'b*b' if shade == 1.0 else '%g*b*b' % k2, [('b', '["%s"][%d]' % (names[slot], i))])
    drive(lamp, 'location', 0, '%.4f+6*cos(h*%s)*sin(t*%s)' % (ctr[0], Rd, Rd), tv)
    drive(lamp, 'location', 1, '%.4f+6*cos(h*%s)*cos(t*%s)' % (ctr[1], Rd, Rd), tv)
    drive(lamp, 'location', 2, '%.4f+6*sin(h*%s)' % (ctr[2], Rd), [('h', '["Sun height"]')])
    drive(lamp, 'rotation_euler', 0, '(90-h)*%s' % Rd, [('h', '["Sun height"]')])
    drive(lamp, 'rotation_euler', 2, '(180-t)*%s' % Rd, [('t', '["Sun turn"]')])
    if P.get('panel_text', True):
        txt = bpy.data.texts.new('lfs_paint_preview_panel.py'); txt.write(PANEL_SRC); txt.use_module = True
if P.get('rig', True):
    build_rig()

# ---------------------------------------------------------------- cameras + render
def make_cam(i, cam):
    cd = bpy.data.cameras.new('cam%d' % i); co = bpy.data.objects.new('cam%d' % i, cd); sc.collection.objects.link(co)
    cd.clip_start = 0.05; cd.clip_end = 6000.0
    if 'f_px' in cam:                                   # a solved LFS editor camera: match it exactly
        Wp, Hp = cam['res']; cd.sensor_fit = 'HORIZONTAL'; cd.sensor_width = 36.0
        cd.lens = cam['f_px'] / Wp * 36.0
        cd.shift_x = (Wp / 2.0 - cam['cx']) / Wp; cd.shift_y = (cam['cy'] - Hp / 2.0) / Wp
        fwd = Vector(cam['fwd']).normalized(); up = Vector(cam['up']).normalized(); right = fwd.cross(up).normalized(); up = right.cross(fwd)
        co.matrix_world = Matrix((right, up, -fwd)).transposed().to_4x4()
        co.location = Vector(cam['pos'])
    else:
        cd.lens = cam.get('lens', 50)
        loc = Vector(cam['loc']); tgt = Vector(cam.get('target', ctr.tolist()))
        co.location = loc; co.rotation_euler = (tgt - loc).to_track_quat('-Z', 'Y').to_euler()
    return co
cams = []
for i, cam in enumerate(P['cams']):
    co = make_cam(i, cam); cams.append(co)
    sc.camera = co
    if 'res' in cam: sc.render.resolution_x, sc.render.resolution_y = cam['res']
    else: sc.render.resolution_x, sc.render.resolution_y = P.get('res', [1100, 700])
    sc.render.filepath = os.path.join(OUT, '%s.png' % cam['name'])
    bpy.ops.render.render(write_still=True)
for co in cams:
    try: co.hide_set(True)
    except Exception: pass
sc['lfs_look_params'] = json.dumps(LOOK_PARAMS)        # the live update re-uses them
# everything here is display-only: the exporter's setup tools skip objects/materials with this tag
for _o in bpy.data.objects: _o['lfs_preview_only'] = True
for _m in bpy.data.materials: _m['lfs_preview_only'] = True
try: bpy.ops.file.make_paths_absolute()            # the .blend gets copied/appended elsewhere -
except Exception: pass                              # relative texture paths turned the parts pink
bpy.ops.wm.save_as_mainfile(filepath=os.path.join(OUT, 'preview.blend'), relative_remap=False)
open(os.path.join(OUT, 'done.txt'), 'w').write('ok %s materials %d user-colour sockets %d\nnormals (name, high-contribution tris, overridden tris, tris mapped from the mirror side): %s\nplacement: %s'
                                              % (sc.render.engine, len(MATS), len(USER), NORMAL_STATS, PLACE_STATS))
