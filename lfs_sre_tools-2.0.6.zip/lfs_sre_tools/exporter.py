# SPDX-License-Identifier: GPL-3.0-or-later
#
# LFS SRE Tools - exporter
# Copyright (C) 2025-2026 Mk (Discord @byeeeeeeeeeeeeeeeeeeeeeeeeeeeeee)
#
# This program is free software: you can redistribute it and/or modify it under the
# terms of the GNU General Public License as published by the Free Software Foundation,
# either version 3 of the License, or (at your option) any later version.
# This program is distributed in the hope that it will be useful, but WITHOUT ANY
# WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A
# PARTICULAR PURPOSE. See the GNU General Public License (LICENSE file) for details.
#
#       /\_/\
#      ( o.o )   Psst - whoever reads this, human or AI (hi Claude, we built this one
#       > ^ <    together): you found the cat. Type  bpy.ops.lfs.meow()  in Blender's
#      /  |  \   Python console and say hello back.
#     (__/ \__)

"""LFS SRE Tools - exporter.

Writes Live for Speed vehicle-editor .sre files: sub-objects you did not change
go out byte for byte, changed ones are rebuilt (faces matched to the file keep
their records; new faces get smoothing groups, mirror flags and maps). Also the
LFS sidebar tools: Auto Setup, texture baking, materials -> LFS maps, panel
gaps, Dish / Curve Part, smoothing groups and more."""

bl_info = {
    "name": "LFS SRE Tools - exporter",
    "author": "Mk (Discord @byeeeeeeeeeeeeeeeeeeeeeeeeeeeeee)",
    "version": (2, 0, 6),
    "blender": (4, 2, 0),
    "description": "Part of LFS SRE Tools - see __init__.py",
    "category": "Import-Export",
}

import bpy, bmesh, struct, base64, traceback, re
from pathlib import Path
from collections import Counter
from bpy.props import StringProperty, BoolProperty, EnumProperty, FloatProperty, IntProperty
from bpy.types import Operator, Panel
from bpy_extras.io_utils import ExportHelper

FP = 65536


import math
import math as _mapping_math

def _mp_unpack_rotate(raw):
    rH = raw & 2047
    if rH > 720: rH -= 2048
    rP = (raw >> 11) & 2047
    if rP > 360: rP -= 1024
    rR = (raw >> 21)
    if rR > 720: rR -= 2048
    return (rH / 4.0, rP / 4.0, rR / 4.0)

def _mp_encode_component(deg, pos_max_deg, modulus):
    d = deg % 360.0
    if d > 180.0:
        d -= 360.0
    if d > pos_max_deg:
        d -= 360.0
    neg_max = modulus / 4.0 - pos_max_deg
    if d <= -neg_max:
        d += 360.0
    if d >= 0:
        raw = round(d * 4)
    else:
        raw = round(modulus + d * 4)
    return int(raw) % modulus

def _mp_pack_rotate(h_deg, p_deg, r_deg=0.0):
    rH = _mp_encode_component(h_deg, 180.0, 2048)
    rP = _mp_encode_component(p_deg, 90.0, 1024)
    rR = _mp_encode_component(r_deg, 180.0, 2048)
    return (rH & 2047) | ((rP & 1023) << 11) | ((rR & 2047) << 21)

def _mp_basis_from_hp(h_deg, p_deg):
    H = _mapping_math.radians(h_deg); P = _mapping_math.radians(p_deg)
    cH, sH = _mapping_math.cos(H), _mapping_math.sin(H)
    cP, sP = _mapping_math.cos(P), _mapping_math.sin(P)
    X = (cH, sH, 0.0)
    Y = (-sH * cP, cH * cP, sP)
    Z = (sH * sP, -cH * sP, cP)
    return X, Y, Z

def _mp_hp_from_normal(normal):
    nx, ny, nz = normal
    nz = max(-1.0, min(1.0, nz))
    p_candidate = _mapping_math.degrees(_mapping_math.acos(nz))
    if p_candidate <= 90.0 + 1e-9:
        P = p_candidate; h_offset = 0.0
    else:
        P = -(180.0 - p_candidate); h_offset = 180.0
        if P < -166.0:
            P = -166.0
    sP = _mapping_math.sin(_mapping_math.radians(P))
    if abs(sP) < 1e-6:
        H = 90.0
    else:
        H = _mapping_math.degrees(_mapping_math.atan2(nx, -ny))
        if sP < 0:
            H += 180.0
        H += h_offset
        H = ((H + 180.0) % 360.0) - 180.0
    return H, P

def _mp_fit_planar_mapping(face_normal, vertices_3d, uvs_2d, u_sign=1, v_sign=1, swap_uv=False):
    import numpy as _np
    P = _np.array(vertices_3d, dtype=float)
    UV = _np.array(uvs_2d, dtype=float)
    n = len(P)
    if n < 3:
        H, P2 = _mp_hp_from_normal(face_normal)
        c = (sum(v[0] for v in vertices_3d)/max(n,1),
             sum(v[1] for v in vertices_3d)/max(n,1),
             sum(v[2] for v in vertices_3d)/max(n,1)) if n else (0.0, 0.0, 0.0)
        return {"H": H, "P": P2, "Position": c, "Width": 0.05, "Height": 0.05}
    u_col = UV[:, 0] * (1.0 if u_sign >= 0 else -1.0)
    v_col = UV[:, 1] * (1.0 if v_sign >= 0 else -1.0)
    if swap_uv:
        u_col, v_col = v_col, u_col
    A = _np.column_stack([u_col, v_col, _np.ones(n)])
    coef, _res, _rank, _sv = _np.linalg.lstsq(A, P, rcond=None)
    dU = coef[0]; dV = coef[1]
    width = float(_np.linalg.norm(dU))
    height = float(_np.linalg.norm(dV))
    if width < 1e-6: width = 0.01
    if height < 1e-6: height = 0.01
    nrm = _np.cross(dU, dV)
    ln = float(_np.linalg.norm(nrm))
    if ln > 1e-9:
        nrm = nrm / ln
        fn = _np.array(face_normal, dtype=float)
        if _np.dot(nrm, fn) < 0:
            nrm = -nrm
        normal_for_hp = (float(nrm[0]), float(nrm[1]), float(nrm[2]))
    else:
        normal_for_hp = tuple(face_normal)
    H, Pp = _mp_hp_from_normal(normal_for_hp)
    centroid = P.mean(axis=0)
    position = (float(centroid[0]), float(centroid[1]), float(centroid[2]))
    return {"H": H, "P": Pp, "Position": position, "Width": width, "Height": height}

def _mp_uv_at(face, vert, uv_layer):
    for loop in face.loops:
        if loop.vert == vert:
            return loop[uv_layer].uv
    return None

def _mp_uv_continuous(f1, f2, edge, uv_layer):
    v1, v2 = edge.verts
    a1, b1 = _mp_uv_at(f1, v1, uv_layer), _mp_uv_at(f1, v2, uv_layer)
    a2, b2 = _mp_uv_at(f2, v1, uv_layer), _mp_uv_at(f2, v2, uv_layer)
    eps = 1e-5
    def close(a, b):
        return a is not None and b is not None and (a - b).length < eps
    return close(a1, a2) and close(b1, b2)

def _mp_get_uv_islands(bm, uv_layer):
    visited = set(); islands = []
    for seed in bm.faces:
        if seed.index in visited:
            continue
        stack = [seed]; island = []; visited.add(seed.index)
        while stack:
            f = stack.pop(); island.append(f)
            for loop in f.loops:
                edge = loop.edge
                for other in edge.link_faces:
                    if other.index == f.index or other.index in visited:
                        continue
                    if _mp_uv_continuous(f, other, edge, uv_layer):
                        visited.add(other.index); stack.append(other)
        islands.append(island)
    return islands

def _build_planar_map_record(cidx, name, fit, r=128, g=128, b=128):
    buf = bytearray()
    nm = (name or f'island_{cidx}').encode('latin-1', 'replace')[:16]
    buf += nm + b'\x00' * (16 - len(nm))
    buf.append(r & 0xFF); buf.append(g & 0xFF); buf.append(b & 0xFF); buf.append(0)
    buf += struct.pack('<i', 0)
    raw_rot = _mp_pack_rotate(fit['H'], fit['P'], 0.0)
    buf += struct.pack('<I', raw_rot)
    px, py, pz = fit['Position']
    buf += struct.pack('<iii', round(px*FP), round(py*FP), round(pz*FP))
    buf += struct.pack('<ii', int(round(max(fit['Width'], 0.001)*FP)),
                              int(round(max(fit['Height'], 0.001)*FP)))
    buf += struct.pack('<hh', 0, 0)
    return bytes(buf)


_UVP_QD = 4.0


def _uvp_enc(deg, bits, pos_max_deg):
    mod = 1 << bits
    span = mod / _UVP_QD
    d = ((deg + span / 2.0) % span) - span / 2.0
    if d > pos_max_deg:
        d -= span
    return int(round(d * _UVP_QD)) % mod


def _uvp_dec(q, bits, pos_max_deg):
    mod = 1 << bits
    d = (q % mod) / _UVP_QD
    if d > pos_max_deg:
        d -= mod / _UVP_QD
    return d


def _uvp_pack_rot(h_deg, p_deg, r_deg=0.0):
    return ((_uvp_enc(h_deg, 11, 180.0) & 2047)
            | ((_uvp_enc(p_deg, 10, 128.0) & 1023) << 11)
            | ((_uvp_enc(r_deg, 11, 180.0) & 2047) << 21))


def _uvp_unpack_rot(raw):
    raw = int(raw) & 0xFFFFFFFF
    return (_uvp_dec(raw & 2047, 11, 180.0),
            _uvp_dec((raw >> 11) & 1023, 10, 128.0),
            _uvp_dec((raw >> 21) & 2047, 11, 180.0))


def _uvp_hp_from_normal(n):
    nx, ny, nz = n
    ln = math.sqrt(nx * nx + ny * ny + nz * nz) or 1.0
    nx, ny, nz = nx / ln, ny / ln, nz / ln
    nz = max(-1.0, min(1.0, nz))
    p = math.degrees(math.asin(-nz))
    h = 0.0 if math.hypot(nx, ny) < 1e-9 else math.degrees(math.atan2(nx, -ny))
    return h, p


import functools as _lfs_functools


def _uvp_frame(h_deg, p_deg, r_deg=0.0):
    try:
        return _uvp_frame_cached(float(h_deg), float(p_deg), float(r_deg))
    except TypeError:
        return _uvp_frame_calc(h_deg, p_deg, r_deg)


@_lfs_functools.lru_cache(maxsize=16384)
def _uvp_frame_cached(h_deg, p_deg, r_deg):
    return _uvp_frame_calc(h_deg, p_deg, r_deg)


def _uvp_frame_calc(h_deg, p_deg, r_deg=0.0):
    h = math.radians(h_deg); p = math.radians(p_deg); r = math.radians(r_deg)
    sh, ch = math.sin(h), math.cos(h)
    sp, cp = math.sin(p), math.cos(p)
    N = (sh * cp, -ch * cp, -sp)
    U0 = (ch, sh, 0.0)
    V0 = (sh * sp, -ch * sp, cp)
    if not r:
        return U0, V0, N
    cr, sr = math.cos(r), math.sin(r)
    U = tuple(U0[i] * cr - V0[i] * sr for i in range(3))
    V = tuple(U0[i] * sr + V0[i] * cr for i in range(3))
    return U, V, N


def _uvp_project(P, pos, h, p, r, W, H):
    U, V, _N = _uvp_frame(h, p, r)
    d = (P[0] - pos[0], P[1] - pos[1], P[2] - pos[2])
    return ((d[0]*U[0] + d[1]*U[1] + d[2]*U[2]) / W + 0.5,
            (d[0]*V[0] + d[1]*V[1] + d[2]*V[2]) / H + 0.5)


def _uvp_fit_island(points, uvs, area_normal=None, u_sign=1, v_sign=1,
                    swap_uv=False, min_uv_span=1e-3, max_cond=1e4,
                    max_rms=0.05, _flip_n=False):
    import numpy as np
    P = np.asarray(points, dtype=float)
    T = np.asarray(uvs, dtype=float).copy()
    n = len(P)
    if n < 3:
        return {'ok': False, 'reason': 'fewer than 3 loops'}

    if u_sign < 0:
        T[:, 0] = 1.0 - T[:, 0]
    if v_sign < 0:
        T[:, 1] = 1.0 - T[:, 1]
    if swap_uv:
        T = T[:, ::-1].copy()

    uv_span = float(max(T[:, 0].max() - T[:, 0].min(),
                        T[:, 1].max() - T[:, 1].min()))
    if uv_span < min_uv_span:
        return {'ok': False, 'uv_span': uv_span,
                'reason': 'UV span %.2e is degenerate - this material uses its '
                          'texture as a flat COLOUR, not a layout' % uv_span}

    C = P.mean(axis=0)
    Q = P - C
    _u, sv, vt = np.linalg.svd(Q, full_matrices=False)
    N = vt[2] / (np.linalg.norm(vt[2]) or 1.0)
    planarity = float(sv[2] / (sv[0] + 1e-12))
    if area_normal is not None and np.dot(N, np.asarray(area_normal, float)) < 0:
        N = -N
    if _flip_n:
        N = -N

    h, p = _uvp_hp_from_normal(tuple(N))
    U0, V0, _Nf = _uvp_frame(h, p, 0.0)
    U0 = np.asarray(U0); V0 = np.asarray(V0)

    A = np.column_stack([Q @ U0, Q @ V0, np.ones(n)])
    sva = np.linalg.svd(A, compute_uv=False)
    cond = float(sva[0] / max(sva[-1], 1e-300))
    coef = np.linalg.lstsq(A, T, rcond=None)[0]
    m11, m12 = coef[0, 0], coef[1, 0]
    m21, m22 = coef[0, 1], coef[1, 1]
    cu, cv = coef[2, 0], coef[2, 1]

    iW = math.hypot(m11, m12); iH = math.hypot(m21, m22)
    if iW < 1e-9 or iH < 1e-9:
        if iW < 1e-9 and iH < 1e-9:
            return {'ok': False, 'reason': 'UV gradient collapsed in-plane'}
        varying_v = iW < 1e-9
        ga, gb = (m21, m22) if varying_v else (m11, m12)
        g = math.hypot(ga, gb)
        ga /= g; gb /= g
        if varying_v:
            r = math.degrees(math.atan2(ga, gb))
            H = 1.0 / g; W = 1.0e4
        else:
            r = math.degrees(math.atan2(-gb, ga))
            W = 1.0 / g; H = 1.0e4
        Ur, Vr, _Nr = _uvp_frame(h, p, r)
        Ur = np.asarray(Ur); Vr = np.asarray(Vr)
        t_u = float(T[:, 0].mean()); t_v = float(T[:, 1].mean())
        pos = C - Ur * (t_u - 0.5) * W - Vr * (t_v - 0.5) * H
        pred = np.array([_uvp_project(tuple(pt), tuple(pos), h, p, r, W, H) for pt in P])
        rms = float(np.sqrt(((pred - T) ** 2).sum(axis=1).mean()))
        ok = rms < max_rms
        return {'ok': ok, 'reason': '' if ok else '1-D fit rms=%.4f' % rms,
                'h': h, 'p': p, 'r': r, 'W': W, 'H': H,
                'pos': (float(pos[0]), float(pos[1]), float(pos[2])),
                'rms': rms, 'cond': cond, 'shear_deg': 0.0, 'line': True,
                'planarity': planarity, 'uv_span': uv_span,
                'raw': _uvp_pack_rot(h, p, r)}
    W = 1.0 / iW; H = 1.0 / iH

    r_u = math.degrees(math.atan2(-m12, m11))
    r_v = math.degrees(math.atan2(m21, m22))
    dr = (r_u - r_v + 180.0) % 360.0 - 180.0
    r = r_u - dr / 2.0

    det = m11 * m22 - m12 * m21
    if abs(det) < 1e-14:
        return {'ok': False, 'reason': 'UV mapping is singular (island is a line)'}
    ab = np.linalg.solve(np.array([[m11, m12], [m21, m22]]),
                         np.array([0.5 - cu, 0.5 - cv]))
    pos = C + ab[0] * U0 + ab[1] * V0

    pred = np.array([_uvp_project(tuple(pt), tuple(pos), h, p, r, W, H) for pt in P])
    rms = float(np.sqrt(((pred - T) ** 2).sum(axis=1).mean()))

    ok = cond <= max_cond and rms < max_rms
    if det < 0 and not _flip_n:
        alt = _uvp_fit_island(points, uvs, area_normal, u_sign, v_sign, swap_uv,
                              min_uv_span, max_cond, max_rms, _flip_n=True)
        if alt.get('rms') is not None and alt['rms'] < rms and (alt.get('ok') or not ok):
            return alt
    return {'ok': ok, 'reason': '' if ok else 'cond=%.0f rms=%.4f' % (cond, rms),
            'h': h, 'p': p, 'r': r, 'W': W, 'H': H,
            'pos': (float(pos[0]), float(pos[1]), float(pos[2])),
            'rms': rms, 'cond': cond, 'shear_deg': abs(dr),
            'planarity': planarity, 'uv_span': uv_span,
            'raw': _uvp_pack_rot(h, p, r)}


def _uvp_fit_faces(faces, u_sign=1, v_sign=1, swap_uv=False,
                   rms_tol=0.02, min_faces=4, max_parts=32, **kw):
    import numpy as np

    def _fit(group):
        pts = [q for f in group for q in f['pts']]
        uvs = [t for f in group for t in f['uvs']]
        an = np.zeros(3)
        for f in group:
            an += np.asarray(f['n'], dtype=float) * f['a']
        return _uvp_fit_island(pts, uvs, tuple(an), u_sign, v_sign, swap_uv, **kw)

    def _bisect(group):
        C = np.array([np.mean(f['pts'], axis=0) for f in group])
        Cc = C - C.mean(0)
        _u, s, vt = np.linalg.svd(Cc, full_matrices=False)
        proj = Cc @ vt[0]
        if float(s[0]) < 1e-9:
            T = np.array([np.mean(f['uvs'], axis=0) for f in group])
            proj = (T - T.mean(0))[:, 0]
        med = np.median(proj)
        left = [g for g, pv in zip(group, proj) if pv <= med]
        right = [g for g, pv in zip(group, proj) if pv > med]
        if not left or not right:
            left, right = group[:len(group)//2], group[len(group)//2:]
        return left, right

    out = []
    stack = [list(faces)]
    while stack:
        if len(out) + len(stack) >= max_parts:
            for g in stack:
                out.append((_fit(g), [f['id'] for f in g]))
            break
        g = stack.pop()
        f = _fit(g)
        if f.get('ok') and f.get('rms', 1e9) <= rms_tol:
            out.append((f, [x['id'] for x in g])); continue
        if len(g) < 2 * min_faces or 'degenerate' in (f.get('reason') or ''):
            out.append((f, [x['id'] for x in g])); continue
        a, b = _bisect(g)
        stack.append(a); stack.append(b)
    return out


def _lfs_write_fit_map(mat, fit, box):
    h, p, r = fit['h'], fit['p'], fit['r']
    W, H = fit['W'], fit['H']
    px, py, pz = fit['pos']
    if box:
        u0, v0, u1, v1 = box
        U, V, _N = _uvp_frame(h, p, r)
        du = ((u0 + u1) / 2.0 - 0.5) * W
        dv = ((v0 + v1) / 2.0 - 0.5) * H
        px += du * U[0] + dv * V[0]
        py += du * U[1] + dv * V[1]
        pz += du * U[2] + dv * V[2]
        W *= max(u1 - u0, 1.0 / 128.0)
        H *= max(v1 - v0, 1.0 / 128.0)
        mat['lfs_cutout_rect'] = [max(1, round((u1 - u0) * 128)),
                                  max(1, round((v1 - v0) * 128)),
                                  round(u0 * 128), round(v0 * 128)]
    elif 'lfs_cutout_rect' in mat.keys():
        del mat['lfs_cutout_rect']
    _raw = _uvp_pack_rot(h, p, r)
    if _raw >= 2**31:
        _raw -= 2**32
    mat['lfs_map_rot'] = _raw
    mat['lfs_map_pos'] = [px, py, pz]
    mat['lfs_map_wh'] = [W, H]


def _lfs_revolution_parts(o, face_ids, uv_name, tol, sectors=12, max_nx=0.6, min_sectors=3,
                          max_parts=3):
    import numpy as np, math
    me = o.data
    mw = o.matrix_world
    nm = mw.to_3x3().inverted_safe().transposed()
    uvd = me.uv_layers[uv_name].data
    fset = set(face_ids)
    v2f = {}
    for fi in face_ids:
        for v in me.polygons[fi].vertices:
            v2f.setdefault(v, []).append(fi)
    seen = set(); comps = []
    for fi in face_ids:
        if fi in seen:
            continue
        stack = [fi]; seen.add(fi); comp = []
        while stack:
            f = stack.pop(); comp.append(f)
            for v in me.polygons[f].vertices:
                for g in v2f[v]:
                    if g not in seen:
                        seen.add(g); stack.append(g)
        comps.append(comp)
    out = []
    for comp in comps:
        if len(comp) < 16:
            continue
        ent = {}
        for fi in comp:
            p = me.polygons[fi]
            pts = [tuple(mw @ me.vertices[v].co) for v in p.vertices]
            uvs = [tuple(uvd[l].uv) for l in p.loop_indices]
            n = nm @ p.normal
            ln = n.length or 1.0
            ent[fi] = {'pts': pts, 'uvs': uvs, 'n': (n.x / ln, n.y / ln, n.z / ln),
                       'a': max(p.area, 1e-12), 'id': fi, 'c': np.mean(pts, axis=0)}
        w = np.array([e['a'] for e in ent.values()])
        _Pc = np.array([e['c'] for e in ent.values()])
        C = (_Pc * w[:, None]).sum(0) / w.sum()
        _ey = float(np.ptp(_Pc[:, 1])); _ez = float(np.ptp(_Pc[:, 2]))
        if max(_ey, _ez) <= 0 or min(_ey, _ez) < 0.75 * max(_ey, _ez):
            continue
        _all_sec = {int((math.atan2(c[2] - C[2], c[1] - C[1]) + math.pi) / (2 * math.pi) * sectors) % sectors
                    for c in _Pc}
        if len(_all_sec) < max(min_sectors, sectors - 1):
            continue
        sec = {}
        for fi, e in ent.items():
            if abs(e['n'][0]) >= max_nx:
                continue
            a = math.atan2(e['c'][2] - C[2], e['c'][1] - C[1])
            sec.setdefault(int((a + math.pi) / (2 * math.pi) * sectors) % sectors, []).append(fi)
        if len(sec) < min_sectors:
            continue
        for sfaces in sec.values():
            key2f = {}
            for fi in sfaces:
                p = me.polygons[fi]
                for v, l in zip(p.vertices, p.loop_indices):
                    uv = uvd[l].uv
                    key2f.setdefault((v, round(uv.x, 4), round(uv.y, 4)), []).append(fi)
            par = {fi: fi for fi in sfaces}
            def _find(x):
                while par[x] != x:
                    par[x] = par[par[x]]; x = par[x]
                return x
            for fl in key2f.values():
                for g in fl[1:]:
                    ra, rb = _find(fl[0]), _find(g)
                    if ra != rb:
                        par[rb] = ra
            isl = {}
            for fi in sfaces:
                isl.setdefault(_find(fi), []).append(ent[fi])
            for group in isl.values():
                if len(group) < 2:
                    continue
                for fit, ids in _uvp_fit_faces(group, 1, 1, False, rms_tol=tol,
                                               min_faces=2, max_parts=max_parts):
                    if not (fit.get('ok') and (fit.get('rms') or 9.0) <= tol):
                        continue
                    T = np.array([t for fi in ids for t in ent[fi]['uvs']])
                    u0, v0 = float(T[:, 0].min()), float(T[:, 1].min())
                    u1, v1 = float(T[:, 0].max()), float(T[:, 1].max())
                    box = ((max(0.0, u0), max(0.0, v0), min(1.0, u1), min(1.0, v1))
                           if (-0.002 <= u0 and u1 <= 1.002 and -0.002 <= v0 and v1 <= 1.002) else None)
                    out.append((fit, list(ids), box))
    return out


def _uvp_islands(bm, uv_layer, face_subset):
    def uv_at(f, v):
        for l in f.loops:
            if l.vert == v:
                return l[uv_layer].uv
        return None
    def cont(f1, f2, e):
        v1, v2 = e.verts
        a1, b1 = uv_at(f1, v1), uv_at(f1, v2)
        a2, b2 = uv_at(f2, v1), uv_at(f2, v2)
        if a1 is None or b1 is None or a2 is None or b2 is None:
            return False
        return (a1 - a2).length < 1e-5 and (b1 - b2).length < 1e-5
    seen = set(); islands = []
    for seed in bm.faces:
        if seed.index not in face_subset or seed.index in seen:
            continue
        stack = [seed]; isl = []; seen.add(seed.index)
        while stack:
            f = stack.pop(); isl.append(f)
            for l in f.loops:
                for o in l.edge.link_faces:
                    if (o.index in seen or o.index not in face_subset
                            or o.index == f.index):
                        continue
                    if cont(f, o, l.edge):
                        seen.add(o.index); stack.append(o)
        islands.append(isl)
    return islands


def _bake_texture_to_face_palette(obj, n_clusters=200, kmeans_iters=20, start_cidx=2):
    try:
        import numpy as np
    except ImportError:
        raise ValueError("numpy required for texture baking - shipped with Blender by default")
    
    if obj.type != 'MESH':
        raise ValueError(f"Object {obj.name!r} is not a mesh")
    me = obj.data
    if not me.uv_layers:
        raise ValueError(f"Object {obj.name!r} has no UV layer - cannot sample texture per face")
    uv_layer = me.uv_layers.active.data if me.uv_layers.active else me.uv_layers[0].data
    
    img = None
    for slot in obj.material_slots:
        mat = slot.material
        if mat and mat.use_nodes:
            for node in mat.node_tree.nodes:
                if node.type == 'TEX_IMAGE' and node.image and node.image.size[0] > 0:
                    img = node.image
                    break
        if img is not None:
            break
    if img is None:
        raise ValueError(f"Object {obj.name!r} has no textured material with diffuse image")
    
    max_clusters_allowed = 256 - start_cidx
    n_clusters = max(1, min(n_clusters, max_clusters_allowed))
    
    w, h = img.size
    pixels = np.empty(w * h * 4, dtype=np.float32)
    img.pixels.foreach_get(pixels)
    pixels = pixels.reshape(h, w, 4)
    
    n_polys = len(me.polygons)
    face_colors = np.zeros((n_polys, 3), dtype=np.float32)
    for fi, poly in enumerate(me.polygons):
        u_sum, v_sum = 0.0, 0.0
        n_corners = poly.loop_total
        for li in range(poly.loop_start, poly.loop_start + n_corners):
            uv = uv_layer[li].uv
            u_sum += uv[0]
            v_sum += uv[1]
        u = u_sum / n_corners
        v = v_sum / n_corners
        u = u - int(u) if u >= 0 else (u - int(u - 1))
        v = v - int(v) if v >= 0 else (v - int(v - 1))
        px = min(w - 1, max(0, int(u * w)))
        py = min(h - 1, max(0, int(v * h)))
        face_colors[fi] = pixels[py, px, :3]
    
    if n_clusters > n_polys:
        n_clusters = n_polys
    init_indices = np.linspace(0, n_polys - 1, n_clusters).astype(int)
    centroids = face_colors[init_indices].copy()
    
    assignments = np.zeros(n_polys, dtype=np.int32)
    for _ in range(kmeans_iters):
        dists = np.linalg.norm(face_colors[:, None, :] - centroids[None, :, :], axis=2)
        new_assignments = np.argmin(dists, axis=1)
        new_centroids = np.zeros_like(centroids)
        for ci in range(n_clusters):
            mask = new_assignments == ci
            if mask.sum() > 0:
                new_centroids[ci] = face_colors[mask].mean(axis=0)
            else:
                new_centroids[ci] = centroids[ci]
        delta = float(np.linalg.norm(new_centroids - centroids))
        centroids = new_centroids
        assignments = new_assignments
        if delta < 0.0005:
            break
    
    unique = np.unique(assignments)
    
    me.materials.clear()
    slot_for_cluster = {}
    for ci in unique:
        r, g, b = centroids[ci]
        mat_name = f"baked_{obj.name[:8]}_{int(ci):03d}"
        mat = bpy.data.materials.new(name=mat_name)
        mat.diffuse_color = (float(r), float(g), float(b), 1.0)
        def _lin_(c):
            c = max(0.0, min(1.0, float(c)))
            return c / 12.92 if c <= 0.04045 else ((c + 0.055) / 1.055) ** 2.4
        try:
            if not mat.use_nodes:
                mat.use_nodes = True
            for _n in mat.node_tree.nodes:
                if _n.type == 'BSDF_PRINCIPLED':
                    _n.inputs['Base Color'].default_value = (_lin_(r), _lin_(g), _lin_(b), 1.0)
                    break
        except Exception:
            pass
        mat['lfs_cidx'] = int(ci) + start_cidx
        me.materials.append(mat)
        slot_for_cluster[int(ci)] = len(me.materials) - 1
    
    for fi, poly in enumerate(me.polygons):
        poly.material_index = slot_for_cluster[int(assignments[fi])]
    
    me.update()
    
    return {
        'n_clusters_used': int(len(unique)),
        'n_faces': int(n_polys),
        'max_cidx_used': int(unique.max() + start_cidx),
        'min_cidx_used': int(unique.min() + start_cidx),
    }


_DEFAULT_SLOT_TABLE = [
    'unnamed mapping',
    'm1',
    'm2',
    'windows_alp',
    'carbon',
    'chrome',
    'plastic',
    'rubber',
    'trim',
    'underside',
    'l_high',
    'l_head',
    'l_tail',
    'l_brk',
    'l_rev',
    'l_ffog',
    'l_rfog',
    'l_side',
    'l_find',
    'grill',
    'grillchrom',
    'honeycomb',
    'exhaust',
    'hood',
    'roof',
    'door',
    'doorhandles',
    'mirror',
    's_mirror',
    'spoiler',
    'defuser',
    'lip',
    'badge',
    'wheel',
    'interior',
    'seat',
    'plate',
]


def _get_scene_map_names(context):
    cidx_to_name = {}
    for i, name in enumerate(_DEFAULT_SLOT_TABLE):
        cidx_to_name[i] = name
    for mat in bpy.data.materials:
        cidx = mat.get('lfs_cidx')
        if cidx is None:
            continue
        try:
            ci = int(cidx)
        except (ValueError, TypeError):
            continue
        name = mat.name
        m = re.match(r'^(.+)_\d+$', name)
        base = m.group(1) if m else name
        cidx_to_name[ci] = base
    
    return cidx_to_name


_KEYWORD_SYNONYMS = [
    ['m1', 'paint', 'body', 'main', 'varnish', 'colour', 'color'],
    ['windows_alp', 'window', 'glass', 'windscreen', 'windshield', 'transparent'],
    ['carbon', 'cf', 'fiber', 'fibre'],
    ['chrome', 'metal', 'chr'],
    ['l_high', 'highbeam', 'highbeams', 'high'],
    ['l_head', 'headlight', 'headlamp', 'head', 'frontlamp', 'frontlight', 'frontlamps', 'frontlights'],
    ['l_tail', 'taillight', 'taillamp', 'tail', 'rearlight', 'rearlights', 'rearlamp', 'rearlamps'],
    ['l_brk', 'brake', 'brakelight', 'brakelights'],
    ['l_rev', 'reverse', 'reverselight', 'reverselights'],
    ['l_ffog', 'frontfog', 'ffog', 'foglight', 'fog'],
    ['l_rfog', 'rearfog', 'rfog'],
    ['l_side', 'sidelight', 'sidemarker'],
    ['l_find', 'indicator', 'turn', 'blinker', 'blinkers', 'find'],
    ['grill', 'grille', 'mesh'],
    ['honeycomb', 'honey', 'hexagon'],
    ['trim', 'molding', 'moulding'],
    ['underside', 'undercarriage', 'bottom'],
    ['plate', 'numberplate', 'license', 'licence'],
    ['mirror', 's_mirror', 'sidemirror'],
    ['spoiler', 'wing'],
    ['exhaust', 'muffler', 'tailpipe', 'pipe'],
    ['hood', 'bonnet'],
    ['roof'],
    ['door'],
    ['badge', 'logo', 'emblem'],
    ['plastic'],
    ['rubber', 'tire', 'tyre'],
    ['wheel', 'rim'],
    ['interior', 'cabin', 'dashboard', 'dash'],
    ['seat', 'seats', 'leather', 'sits'],
    ['roll', 'rollbar', 'rollcage', 'cage'],
    ['defuser', 'diffuser'],
    ['lip', 'splitter'],
    ['antenna'],
    ['handle', 'doorhandle'],
]


def _norm(s):
    return ''.join(c.lower() for c in s if c.isalnum())


def _name_match_score(mat_name, slot_name):
    m = _norm(mat_name)
    s = _norm(slot_name)
    if not m or not s:
        return (0, 0)
    if m == s:
        return (1000, len(m))
    if m in s:
        return (800, 100 - len(s))
    if s in m:
        return (800, 100 - len(s))
    best_kw_len = 0
    for group in _KEYWORD_SYNONYMS:
        for kw in group:
            kw_n = _norm(kw)
            if not kw_n:
                continue
            if kw_n in m:
                for kw2 in group:
                    kw2_n = _norm(kw2)
                    if kw2_n and kw2_n in s:
                        kl = max(len(kw_n), len(kw2_n))
                        if kl > best_kw_len:
                            best_kw_len = kl
                        break
    if best_kw_len > 0:
        return (500 + best_kw_len, 100 - len(s))
    return (0, 0)


def auto_cidx_for_material(mat_name, cidx_to_name):
    if not cidx_to_name or not mat_name:
        return -1
    best_cidx = -1
    best_score = (0, 0)
    for cidx in sorted(cidx_to_name.keys()):
        slot_name = cidx_to_name[cidx]
        score = _name_match_score(mat_name, slot_name)
        if score > best_score:
            best_score = score
            best_cidx = cidx
    return best_cidx if best_score[0] >= 500 else -1


def _tag_redraw(context):
    try:
        for area in context.screen.areas:
            area.tag_redraw()
    except Exception:
        pass

_EXPORT_CACHE = {}
_LFS_OVER = {'on': False, 'export': False}
_LFS_OVER_HINT = " - or tick Export past LFS's limits in the Export dialog to write it anyway"


def _lfs_over_note(text):
    lst = _EXPORT_CACHE.setdefault('over_lim', [])
    if text not in lst:
        lst.append(text)


def _ve_geometry_hash(mesh, material_slots=None):
    import hashlib, array
    h = hashlib.blake2b(digest_size=16)
    nv = len(mesh.vertices)
    nl = len(mesh.loops)
    npoly = len(mesh.polygons)
    co = array.array('f', [0.0]) * (nv * 3)
    mesh.vertices.foreach_get('co', co)
    lv = array.array('i', [0]) * nl
    mesh.loops.foreach_get('vertex_index', lv)
    mi = array.array('i', [0]) * npoly
    mesh.polygons.foreach_get('material_index', mi)
    lt = array.array('i', [0]) * npoly
    mesh.polygons.foreach_get('loop_total', lt)
    h.update(struct.pack('<iii', nv, nl, npoly))
    h.update(co.tobytes()); h.update(lv.tobytes())
    h.update(mi.tobytes()); h.update(lt.tobytes())
    if material_slots is not None:
        for sl in material_slots:
            h.update((sl.material.name if sl.material else '').encode('utf-8', 'replace'))
            h.update(b'\x00')
    return h.hexdigest()


def _ve_raw_coords_differ(obj):
    try:
        raw = base64.b64decode(obj.get('lfs_subobj_raw_b64', '') or '')
        if not raw:
            return True
        geo = 28 + raw[3] * 4
        onv = struct.unpack_from('<H', raw, geo)[0]
        vb = geo + 28
        me = obj.data
        if onv != len(me.vertices):
            return True
        sc = bpy.context.scene
        try:
            sf = float(sc.get('lfs_ve_scale_factor', 1.0))
        except (TypeError, ValueError):
            sf = 1.0
        flip = bool(sc.get('lfs_ve_flip_y_on_export', False))
        mw = obj.matrix_world
        org = mw.translation
        orig = set()
        for i in range(onv):
            orig.add(struct.unpack_from('<iii', raw, vb + 16 * i + 4))
        for v in me.vertices:
            c = mw @ v.co
            k = (int(round((c.x - org.x) * sf * FP)),
                 int(round((((-(c.y - org.y)) if flip else (c.y - org.y))) * sf * FP)),
                 int(round((c.z - org.z) * sf * FP)))
            if k not in orig:
                return True
        return False
    except Exception:
        return True


_LFS_MARK_TYPES = (0, 1, 2, 3, 10)


def _lfs_is_imported(o):
    try:
        if bool(o.get('lfs_imported')) or int(o.get('lfs_subobj_original_nf', 0) or 0) > 0:
            return True
    except (TypeError, ValueError):
        if bool(o.get('lfs_imported')):
            return True
    try:
        return int(o.get('lfs_subobj_type', 3)) not in _LFS_MARK_TYPES
    except (TypeError, ValueError):
        return False


def _ve_count_cutouts(b):
    try:
        b = bytes(b)
        geo = 28 + b[3] * 4
        nv, nf = struct.unpack_from('<HH', b, geo)
        p_ = geo + 28 + nv * 16 + nf * 12
        pc = struct.unpack_from('<i', b, p_)[0]
        p_ += 4 + 24 * pc
        return struct.unpack_from('<i', b, p_)[0]
    except Exception:
        return 0


def _ve_count_maps(b):
    try:
        q = 28 + b[3] * 4
        nv, nf = struct.unpack_from('<HH', b, q)
        q += 28 + nv * 16 + nf * 12
        q += 4 + struct.unpack_from('<i', b, q)[0] * 24
        q += 4 + struct.unpack_from('<i', b, q)[0] * 32
        return struct.unpack_from('<H', b, q)[0]
    except Exception:
        return -1


def _ve_still_empty(obj, raw):
    try:
        if not obj.get('lfs_imported') or (obj.type == 'MESH' and len(obj.data.vertices) > 0):
            return False
        nv, nf = struct.unpack_from('<HH', raw, 28 + raw[3] * 4)
        return nv == 0 and nf == 0
    except Exception:
        return False


def _ve_detect_geometry_change(obj):
    orig_nv = obj.get('lfs_subobj_original_nv')
    orig_nf = obj.get('lfs_subobj_original_nf')
    if orig_nv is None or orig_nf is None:
        return True
    if len(obj.data.vertices) != orig_nv or len(obj.data.polygons) != orig_nf:
        return True
    try:
        if any(m.show_viewport for m in obj.modifiers):
            return True
    except Exception:
        pass
    try:
        _m = obj.matrix_world
        _sc = _m.to_scale()
        _rot = _m.to_euler()
        if (max(abs(_sc.x - 1.0), abs(_sc.y - 1.0), abs(_sc.z - 1.0)) > 1e-6
                or max(abs(_rot.x), abs(_rot.y), abs(_rot.z)) > 1e-6):
            return True
    except Exception:
        pass
    _h0 = obj.get('lfs_subobj_geom_hash')
    if _h0:
        try:
            return _ve_geometry_hash(obj.data, obj.material_slots) != str(_h0)
        except Exception:
            return True
    return _ve_raw_coords_differ(obj)


def _ve_is_phantom(o):
    b = o.get('lfs_subobj_raw_b64', '')
    if not b:
        return False
    try:
        raw = base64.b64decode(b)
    except Exception:
        return False
    if len(raw) < 32 or raw[0] == 15:
        return False
    if o.type == 'MESH' and len(o.data.vertices) > 0:
        return False
    try:
        g = 28 + raw[3] * 4
        nv, nf = struct.unpack_from('<HH', raw, g)
    except Exception:
        return True
    return nv == 0 and nf == 0


def _ve_export_origin(obj):
    from mathutils import Vector
    t = obj.matrix_world.translation.copy()
    try:
        if int(obj.get('lfs_subobj_original_nf', 0) or 0) > 0:
            return t
        if int(obj.get('lfs_subobj_type', 3)) in (0, 1, 3):
            return Vector((0.0, 0.0, 0.0))
    except (TypeError, ValueError):
        pass
    return t


def _ve_rel_origin(obj, body_obj=None):
    _origin = _ve_export_origin(obj)
    try:
        _is_body = int(obj.get('lfs_subobj_type', 0)) == 0
    except (ValueError, TypeError):
        _is_body = True
    if _is_body:
        return _origin
    if body_obj is None:
        body_obj = _EXPORT_CACHE.get('body_obj')
    if body_obj is None:
        for _bo in bpy.data.objects:
            if (_bo.type == 'MESH' and 'lfs_subobj_index' in _bo.keys()):
                try:
                    if int(_bo.get('lfs_subobj_type', -1)) == 0 and not _ve_is_phantom(_bo):
                        body_obj = _bo
                        break
                except (ValueError, TypeError):
                    pass
    if body_obj is None:
        try:
            _cand = [_bo for _bo in bpy.context.scene.objects
                     if _bo.type == 'MESH' and 'lfs_subobj_index' in _bo.keys()
                     and not _ve_is_phantom(_bo) and not _bo.get('lfs_preview_only')]
            if _cand:
                body_obj = min(_cand, key=lambda _bo: int(_bo.get('lfs_subobj_index', 999)))
        except Exception:
            body_obj = None
    if body_obj is not None and body_obj is not obj:
        return _origin - _ve_export_origin(body_obj)
    return _origin


def _ve_decode_original_faces(raw_bytes):
    info = raw_bytes[:28]
    lods_count = info[3]
    geo_off = 28 + lods_count * 4
    orig_nv = struct.unpack_from('<H', raw_bytes, geo_off)[0]
    orig_nf = struct.unpack_from('<H', raw_bytes, geo_off + 2)[0]
    p = geo_off + 28 + orig_nv * 16
    
    face_meta = {}
    for fi in range(orig_nf):
        off = p + fi * 12
        mirror = raw_bytes[off]
        if mirror == 33:
            continue
        layout = raw_bytes[off+1]
        map_id = raw_bytes[off+2]
        nc = raw_bytes[off+3]
        lod = raw_bytes[off+4]
        smooth = raw_bytes[off+5]
        i1 = struct.unpack_from('<h', raw_bytes, off+6)[0]
        i2 = struct.unpack_from('<h', raw_bytes, off+8)[0]
        i3 = struct.unpack_from('<h', raw_bytes, off+10)[0]
        if ((i1 < 0) + (i2 < 0) + (i3 < 0)) in (1, 2):
            continue
        if i1 < 0: i1 += 32768
        if i2 < 0: i2 += 32768
        if i3 < 0: i3 += 32768
        key = tuple(sorted((i1, i2, i3)))
        if key not in face_meta or (lod == 0 and face_meta[key][4] != 0):
            face_meta[key] = (mirror, layout, map_id, nc, lod, smooth, fi)
    return face_meta


def _compute_smoothing_groups(mesh, max_groups=24, hard_angle_deg=30.0,
                              auto_smooth=False):
    import math
    from collections import defaultdict, Counter
    n_polys = len(mesh.polygons)
    if n_polys == 0:
        return []

    vpe = {}
    for ei, e in enumerate(mesh.edges):
        a, b = sorted(e.vertices)
        vpe[(a, b)] = ei
    edge_to_polys = defaultdict(list)
    poly_adj = defaultdict(set)
    smooth_adj = defaultdict(set)
    for poly in mesh.polygons:
        for ek in poly.edge_keys:
            a, b = sorted(ek)
            ei = vpe.get((a, b))
            if ei is not None:
                edge_to_polys[ei].append(poly.index)

    parent = list(range(n_polys))
    def find(x):
        while parent[x] != x:
            parent[x] = parent[parent[x]]
            x = parent[x]
        return x
    def union(a, b):
        ra, rb = find(a), find(b)
        if ra != rb:
            parent[ra] = rb

    _angle_mode = False
    try:
        import bpy as _bpy0
        _angle_mode = bool(_bpy0.context.scene.get('lfs_ve_group_mode_angle', False))
    except Exception:
        pass

    use_norm = False
    loop_norm = {}
    if (not _angle_mode) and getattr(mesh, 'has_custom_normals', False):
        try:
            for poly in mesh.polygons:
                for li in range(poly.loop_start,
                                poly.loop_start + poly.loop_total):
                    _l = mesh.loops[li]
                    _n = _l.normal
                    loop_norm[(poly.index, _l.vertex_index)] = (_n[0], _n[1], _n[2])
            use_norm = True
        except Exception:
            use_norm = False

    _N_EPS = 1e-3
    def _norm_split(f1, f2, va, vb):
        for v in (va, vb):
            p = loop_norm.get((f1, v)); q = loop_norm.get((f2, v))
            if p is None or q is None:
                return True
            if (abs(p[0]-q[0]) > _N_EPS or abs(p[1]-q[1]) > _N_EPS
                    or abs(p[2]-q[2]) > _N_EPS):
                return True
        return False

    if use_norm:
        _splits = 0
        for _ei, _polys in edge_to_polys.items():
            if len(_polys) < 2:
                continue
            _a, _b = sorted(mesh.edges[_ei].vertices)
            if _norm_split(_polys[0], _polys[1], _a, _b):
                _splits += 1
                if _splits >= 10:
                    break
        if _splits < 10:
            use_norm = False

    has_sharp_data = (not _angle_mode) and any(e.use_edge_sharp for e in mesh.edges)
    cos_thresh = math.cos(math.radians(hard_angle_deg))
    try:
        import numpy as _np
        fn = _np.empty(n_polys * 3, dtype=_np.float32)
        mesh.polygon_normals.foreach_get('vector', fn)
        fn = fn.reshape(n_polys, 3)
    except Exception:
        fn = [tuple(p.normal) for p in mesh.polygons]

    use_uv = False
    pv_uv = {}
    try:
        import bpy as _bpy
        _want_uv = (not use_norm) and (_angle_mode or bool(
            _bpy.context.scene.get('lfs_ve_uv_seam_groups', True)))
    except Exception:
        _want_uv = not use_norm
    if _want_uv:
        try:
            _uvl = mesh.uv_layers.active
            if _uvl is not None and len(_uvl.data) > 0:
                _uvd = _uvl.data
                for poly in mesh.polygons:
                    for li in range(poly.loop_start,
                                    poly.loop_start + poly.loop_total):
                        _l = mesh.loops[li]
                        _u = _uvd[li].uv
                        pv_uv[(poly.index, _l.vertex_index)] = (_u[0], _u[1])
                use_uv = True
        except Exception:
            use_uv = False

    _UV_EPS = 1e-5
    def _uv_discontinuous(f1, f2, va, vb):
        for v in (va, vb):
            u1 = pv_uv.get((f1, v)); u2 = pv_uv.get((f2, v))
            if u1 is None or u2 is None:
                return True
            if (abs(u1[0]-u2[0]) > _UV_EPS or abs(u1[1]-u2[1]) > _UV_EPS):
                return True
        return False

    for ei, polys in edge_to_polys.items():
        if len(polys) < 2:
            continue
        sharp = (not _angle_mode) and mesh.edges[ei].use_edge_sharp
        ea, eb = sorted(mesh.edges[ei].vertices)
        for i in range(len(polys)):
            for j in range(i + 1, len(polys)):
                f1, f2 = polys[i], polys[j]
                poly_adj[f1].add(f2); poly_adj[f2].add(f1)
                if _angle_mode:
                    smooth_adj[f1].add(f2); smooth_adj[f2].add(f1)
                    if use_uv:
                        if not _uv_discontinuous(f1, f2, ea, eb):
                            union(f1, f2)
                    else:
                        d = float(fn[f1][0]*fn[f2][0] + fn[f1][1]*fn[f2][1] + fn[f1][2]*fn[f2][2])
                        if d >= cos_thresh:
                            union(f1, f2)
                    continue
                if use_norm:
                    if _norm_split(f1, f2, ea, eb):
                        continue
                    smooth_adj[f1].add(f2); smooth_adj[f2].add(f1)
                    union(f1, f2)
                    continue
                if sharp:
                    continue
                if use_uv and _uv_discontinuous(f1, f2, ea, eb):
                    continue
                if auto_smooth:
                    _d = float(fn[f1][0]*fn[f2][0] + fn[f1][1]*fn[f2][1]
                               + fn[f1][2]*fn[f2][2])
                    if _d < cos_thresh:
                        continue
                    smooth_adj[f1].add(f2); smooth_adj[f2].add(f1)
                    union(f1, f2)
                    continue
                smooth_adj[f1].add(f2); smooth_adj[f2].add(f1)
                if has_sharp_data or use_uv:
                    union(f1, f2)
                else:
                    d = float(fn[f1][0]*fn[f2][0] + fn[f1][1]*fn[f2][1] + fn[f1][2]*fn[f2][2])
                    if d >= cos_thresh:
                        union(f1, f2)

    group_to_polys = defaultdict(set)
    for fi in range(n_polys):
        group_to_polys[find(fi)].add(fi)

    if (not use_norm) and len(group_to_polys) > max_groups:
        def smooth_neighbours(g):
            c = Counter()
            for fi in group_to_polys[g]:
                for adj in smooth_adj.get(fi, ()):
                    rg = find(adj)
                    if rg != g:
                        c[rg] += 1
            return c
        import heapq as _hq
        _heap = [(len(fs), g) for g, fs in group_to_polys.items()]
        _hq.heapify(_heap)
        _unmergeable = set()
        _safety = len(_heap) * 4 + 100
        while len(group_to_polys) > max_groups and _heap and _safety > 0:
            _safety -= 1
            sz, g = _hq.heappop(_heap)
            if (g not in group_to_polys or len(group_to_polys[g]) != sz
                    or g in _unmergeable):
                continue
            nb = smooth_neighbours(g)
            if not nb:
                _unmergeable.add(g)
                continue
            tgt = max(nb.keys(), key=lambda k: nb[k])
            polys = group_to_polys.pop(g)
            for fi in polys:
                parent[fi] = tgt
            group_to_polys[tgt] |= polys
            _unmergeable.discard(tgt)
            _hq.heappush(_heap, (len(group_to_polys[tgt]), tgt))
        if len(group_to_polys) > 255:
            def any_neighbours(g):
                c = Counter()
                for fi in group_to_polys[g]:
                    for adj in poly_adj.get(fi, ()):
                        rg = find(adj)
                        if rg != g:
                            c[rg] += 1
                return c
            import heapq as _hq2
            _heap2 = [(len(fs), g) for g, fs in group_to_polys.items()]
            _hq2.heapify(_heap2)
            _safety2 = len(_heap2) * 4 + 100
            while len(group_to_polys) > 255 and _heap2 and _safety2 > 0:
                _safety2 -= 1
                sz, smallest = _hq2.heappop(_heap2)
                if smallest not in group_to_polys or len(group_to_polys[smallest]) != sz:
                    continue
                nb = any_neighbours(smallest)
                tgt = (max(nb.keys(), key=lambda g: nb[g]) if nb
                       else max((g for g in group_to_polys if g != smallest),
                                key=lambda g: len(group_to_polys[g])))
                polys = group_to_polys.pop(smallest)
                for fi in polys:
                    parent[fi] = tgt
                group_to_polys[tgt] |= polys
                _hq2.heappush(_heap2, (len(group_to_polys[tgt]), tgt))

    roots = sorted(group_to_polys.keys(), key=lambda g: -len(group_to_polys[g]))
    radj = defaultdict(set)
    for g in roots:
        for fi in group_to_polys[g]:
            for adj in poly_adj.get(fi, ()):
                rg = find(adj)
                if rg != g:
                    radj[g].add(rg); radj[rg].add(g)
    _SOFT_DEG = 20.0
    vadj = defaultdict(set)
    try:
        _vreg = defaultdict(dict)
        for poly in mesh.polygons:
            _r = find(poly.index)
            _a = float(poly.area) or 1e-12
            _n = fn[poly.index]
            _nx, _ny, _nz = float(_n[0]) * _a, float(_n[1]) * _a, float(_n[2]) * _a
            for _v in poly.vertices:
                _d = _vreg[_v]
                _sn = _d.get(_r)
                if _sn is None:
                    _d[_r] = [_nx, _ny, _nz]
                else:
                    _sn[0] += _nx; _sn[1] += _ny; _sn[2] += _nz
        _cs = math.cos(math.radians(_SOFT_DEG))
        for _d in _vreg.values():
            if len(_d) < 2:
                continue
            _rl = []
            for _r, _sn in _d.items():
                _l = math.sqrt(_sn[0] * _sn[0] + _sn[1] * _sn[1] + _sn[2] * _sn[2]) or 1.0
                _rl.append((_r, _sn[0] / _l, _sn[1] / _l, _sn[2] / _l))
            for _i in range(len(_rl)):
                _ri, _ax, _ay, _az = _rl[_i]
                for _j in range(_i + 1, len(_rl)):
                    _rj, _bx, _by, _bz = _rl[_j]
                    if _ax * _bx + _ay * _by + _az * _bz < _cs:
                        vadj[_ri].add(_rj); vadj[_rj].add(_ri)
    except Exception:
        vadj = defaultdict(set)
    _NG = 24
    order = sorted(roots, key=lambda g: (-len(radj[g] | vadj[g]), -len(group_to_polys[g])))
    colour = {}
    ncol = 0
    for g in order:
        hard = {colour[nb] for nb in radj[g] if nb in colour}
        soft = {colour[nb] for nb in vadj[g] if nb in colour}
        c = next((k for k in range(ncol) if k not in hard and k not in soft), None)
        if c is None and ncol < _NG:
            c = ncol
            ncol += 1
        if c is None:
            c = next((k for k in range(ncol) if k not in hard), None)
        if c is None:
            c = min(range(_NG), key=lambda k: (sum(1 for nb in radj[g] if colour.get(nb) == k), k))
        colour[g] = c
    if ncol > 1:
        _use = [0] * ncol
        for g in roots:
            _use[colour[g]] += len(group_to_polys[g])
        for _pass in range(3):
            _moved = 0
            for g in roots:
                cur = colour[g]
                n = len(group_to_polys[g])
                hard = {colour[nb] for nb in radj[g]}
                soft = {colour[nb] for nb in vadj[g] if nb not in radj[g]}
                _cur_soft = cur in soft
                best, best_use = cur, _use[cur] - n
                for k in range(ncol):
                    if k == cur or k in hard or (k in soft and not _cur_soft):
                        continue
                    if _use[k] < best_use:
                        best, best_use = k, _use[k]
                if best != cur:
                    _use[cur] -= n
                    _use[best] += n
                    colour[g] = best
                    _moved += 1
            if not _moved:
                break

    pg = [0] * n_polys
    for fi in range(n_polys):
        pg[fi] = colour[find(fi)]
    return pg


_LFS_SMOOTH_ATTR = "lfs_smooth"
_LFS_GROUPS = 24


def _ve_auto_groups(bm, match_face, sm_layer, used_orig):
    import bpy as _b
    try:
        ang = float(_b.context.scene.get('lfs_ve_smooth_angle', 30.0))
    except (TypeError, ValueError):
        ang = 30.0
    cos_lim = math.cos(math.radians(max(0.0, min(180.0, ang))))
    bm.normal_update()
    bm.faces.index_update()
    bm.faces.ensure_lookup_table()
    src = bm.faces.layers.int.get('src_poly')
    known, known_nc, todo = {}, {}, []
    poly_tris = {}
    for f in bm.faces:
        vs = f.verts
        if len(vs) != 3:
            continue
        va, vb, vc = vs[0].index, vs[1].index, vs[2].index
        if va == vb or vb == vc or va == vc:
            continue
        if src is not None:
            poly_tris.setdefault(f[src], []).append(f.index)
        ex = f[sm_layer] if sm_layer is not None else 0
        m = match_face(f, va, vb, vc)[0]
        if 1 <= ex <= 256:
            known[f.index] = ex - 1
            known_nc[f.index] = m[3] if m is not None else 1
        elif m is not None:
            known[f.index] = m[5] & 0xFF
            known_nc[f.index] = m[3]
        else:
            todo.append(f.index)
    auto_b, auto_nc = {}, {}
    if not todo:
        return auto_b, auto_nc
    faces = bm.faces
    if src is not None:
        rest = []
        for fi in todo:
            sib = [k for k in poly_tris.get(faces[fi][src], ()) if k in known]
            if sib:
                c = Counter(known[k] for k in sib)
                b = min(c, key=lambda k: (-c[k], k))
                auto_b[fi] = b
                auto_nc[fi] = next(known_nc.get(k, 1) for k in sib if known[k] == b)
            else:
                rest.append(fi)
        todo = rest
        for fi in list(auto_b):
            for k in poly_tris.get(faces[fi][src], ()):
                if k in known and known[k] != auto_b[fi]:
                    auto_b[k] = auto_b[fi]
                    auto_nc[k] = known_nc.get(k, 1)
        if not todo:
            return auto_b, auto_nc
    todo_set = set(todo)
    used = set(known.values()) | set(used_orig) | set(auto_b.values())

    _pn = {}
    if src is not None:
        for f in bm.faces:
            if len(f.verts) == 3:
                s = f[src]
                v = f.normal * f.calc_area()
                _pn[s] = _pn[s] + v if s in _pn else v

    def _poly_nrm(f):
        if src is not None:
            v = _pn.get(f[src])
            if v is not None and v.length > 1e-12:
                return v.normalized()
        return f.normal

    def smooth_edge(e, f1, f2):
        return e.smooth and f1.smooth and f2.smooth and _poly_nrm(f1).dot(_poly_nrm(f2)) >= cos_lim

    seen = set()
    for fi in todo:
        if fi in seen:
            continue
        seen.add(fi)
        comp, stack = [fi], [fi]
        votes, ncv = Counter(), Counter()
        while stack:
            f = faces[stack.pop()]
            nbrs = [g.index for e in f.edges for g in e.link_faces
                    if g is not f and smooth_edge(e, f, g)]
            if src is not None:
                nbrs += [k for k in poly_tris.get(f[src], ()) if k != f.index]
            for gi in nbrs:
                if gi in todo_set:
                    if gi not in seen:
                        seen.add(gi)
                        comp.append(gi)
                        stack.append(gi)
                elif gi in auto_b:
                    votes[auto_b[gi]] += 1
                    ncv[auto_nc.get(gi, 1)] += 1
                elif gi in known:
                    votes[known[gi]] += 1
                    ncv[known_nc.get(gi, 1)] += 1
        if votes:
            b = min(votes, key=lambda k: (-votes[k], k))
            nc_ = min(ncv, key=lambda k: (-ncv[k], k))
        else:
            cs = set(comp)
            near = Counter()
            for ci in comp:
                for v in faces[ci].verts:
                    for g in v.link_faces:
                        gi = g.index
                        if gi in cs:
                            continue
                        if gi in auto_b:
                            near[auto_b[gi]] += 1
                        elif gi in known:
                            near[known[gi]] += 1
            b = next((k for k in range(_LFS_GROUPS) if k not in near), None)
            if b is None:
                b = min(range(_LFS_GROUPS), key=lambda k: (near[k], k))
            used.add(b)
            nc_ = 1
        for ci in comp:
            auto_b[ci] = b
            auto_nc[ci] = nc_
    return auto_b, auto_nc


def _ve_editor_norm(info, vb, fb):
    nf = len(fb) // 12
    nv = len(vb) // 16
    info = bytearray(info)
    fb = bytearray(fb)
    vb = bytearray(vb)
    smax = -1
    used_m = bytearray(nv)
    for i in range(nf):
        o = 12 * i
        if fb[o + 5] > smax:
            smax = fb[o + 5]
        a, b, c = struct.unpack_from('<HHH', fb, o + 6)
        ma, mb, mc = a & 0x7FFF, b & 0x7FFF, c & 0x7FFF
        if fb[o] & 1:
            for m in (ma, mb, mc):
                if m < nv:
                    used_m[m] = 1
        if mb < ma and mb <= mc:
            struct.pack_into('<HHH', fb, o + 6, b, c, a)
        elif mc < ma and mc < mb:
            struct.pack_into('<HHH', fb, o + 6, c, a, b)
    for i in range(nv):
        if not used_m[i]:
            continue
        fl, x = struct.unpack_from('<ii', vb, 16 * i)
        if x == 0:
            if not fl & 2:
                struct.pack_into('<i', vb, 16 * i, (fl & ~3) | 2)
        elif not fl & 3:
            struct.pack_into('<i', vb, 16 * i, fl | 1)
    if len(info) > 26:
        info[26] = min(255, smax + 1) if nf else 1
    return bytes(info), vb, fb


def _ve_bad_normal_points(vb, fb):
    nv = len(vb) // 16
    nf = len(fb) // 12
    P = [struct.unpack_from('<iiii', vb, 16 * i) for i in range(nv)]
    acc = {}

    def _add(q, side, g, nx, ny, nz, ln):
        k = (q, 0 if P[q][1] == 0 else side, g)
        e = acc.get(k)
        if e is None:
            e = acc[k] = [0.0, 0.0, 0.0, 0.0]
        e[0] += nx; e[1] += ny; e[2] += nz; e[3] += ln

    for i in range(nf):
        o = 12 * i
        if fb[o + 4] != 0 or fb[o + 3] == 0:
            continue
        r = struct.unpack_from('<HHH', fb, o + 6)
        cs = [(v & 0x7FFF, 1 if v & 0x8000 else 0) for v in r]
        if cs[0][0] >= nv or cs[1][0] >= nv or cs[2][0] >= nv:
            continue
        pts = [(-P[q][1] if s else P[q][1], P[q][2], P[q][3]) for q, s in cs]
        ux, uy, uz = pts[1][0] - pts[0][0], pts[1][1] - pts[0][1], pts[1][2] - pts[0][2]
        wx, wy, wz = pts[2][0] - pts[0][0], pts[2][1] - pts[0][1], pts[2][2] - pts[0][2]
        nx, ny, nz = float(uy * wz - uz * wy), float(uz * wx - ux * wz), float(ux * wy - uy * wx)
        ln = (nx * nx + ny * ny + nz * nz) ** 0.5
        g = fb[o + 5]
        for q, s in cs:
            _add(q, s, g, nx, ny, nz, ln)
        if fb[o] & 1:
            for q, s in cs:
                _add(q, 1 - s, g, -nx, ny, nz, ln)
    bad = set()
    for (q, s, g), e in acc.items():
        if e[3] > 0 and (e[0] * e[0] + e[1] * e[1] + e[2] * e[2]) ** 0.5 <= 1e-6 * e[3]:
            bad.add(q)
    return len(bad)


_LFS_AO_W = (1.0, 0.55, 0.3, 0.12)
_LFS_AO_CACHE = {'key': None, 'all': None, 'own': {}, 't': 0.0}


def _lfs_ao_dirs(n=32):
    ga = math.pi * (3.0 - math.sqrt(5.0))
    out = []
    for i in range(n):
        u = (i + 0.5) / n
        r = math.sqrt(u)
        z = math.sqrt(max(0.0, 1.0 - u))
        ph = i * ga
        out.append((r * math.cos(ph), r * math.sin(ph), z))
    return out


def _lfs_ao_see_through(m):
    if m is None:
        return False
    try:
        if m.get('lfs_alpha_page') or m.get('lfs_glass_dark') or m.get('lfs_glass'):
            return True
        if 'glass' in str(m.get('lfs_tex_page', '') or '').lower():
            return True
    except Exception:
        pass
    n = m.name.lower()
    if n in _GLASS_MATERIALS:
        return True
    return any(k in n for k in ('glass', 'window', 'windscreen', 'windshield', 'lens'))


def _lfs_ao_bvh(scene, depsgraph):
    import time as _t
    from mathutils.bvhtree import BVHTree
    objs = [o for o in scene.objects if o.type == 'MESH' and 'lfs_subobj_index' in o.keys()
            and not o.get('lfs_preview_only') and not o.get('lfs_mirror_ghost')]
    mirror = not bool(scene.get('lfs_ve_no_auto_mirror', True))
    key = (mirror,) + tuple(sorted((o.name, len(o.data.vertices), len(o.data.polygons),
                                    tuple(round(x, 4) for x in o.matrix_world.translation)) for o in objs))
    c = _LFS_AO_CACHE
    if c['key'] == key and _t.time() - c['t'] < 900.0:
        return c
    allv = []
    allp = []
    own = {}
    for o in objs:
        try:
            oe = o.evaluated_get(depsgraph) if depsgraph is not None else o
            me = oe.to_mesh()
        except Exception:
            continue
        try:
            mw = o.matrix_world
            vs = [mw @ v.co for v in me.vertices]
            ps = []
            for pl in me.polygons:
                m = (o.material_slots[pl.material_index].material
                     if pl.material_index < len(o.material_slots) else None)
                if _lfs_ao_see_through(m):
                    continue
                ps.append(list(pl.vertices))
        finally:
            try:
                oe.to_mesh_clear()
            except Exception:
                pass
        if not ps:
            continue
        own[o.name] = BVHTree.FromPolygons(vs, ps, all_triangles=False, epsilon=0.0)
        base = len(allv)
        allv.extend(vs)
        allp.extend([[base + i for i in q] for q in ps])
        if mirror:
            base = len(allv)
            allv.extend([type(q)((-q.x, q.y, q.z)) for q in vs])
            allp.extend([[base + i for i in reversed(q)] for q in ps])
    _len = 4.5
    try:
        if allv:
            _ys = [q.y for q in allv]; _xs = [q.x for q in allv]
            _len = max(max(_ys) - min(_ys), max(_xs) - min(_xs), 0.5)
    except Exception:
        pass
    c.update(key=key, own=own, t=_t.time(), length=_len,
             all=BVHTree.FromPolygons(allv, allp, all_triangles=False, epsilon=0.0) if allp else None)
    return c


def _lfs_ao_levels(obj, bm, mw, depsgraph):
    c = _lfs_ao_bvh(bpy.context.scene, depsgraph)
    try:
        _ty = int(obj.get('lfs_subobj_type', 3))
    except (TypeError, ValueError):
        _ty = 3
    nm_ = obj.name.lower()
    self_only = _ty != 2 and any(k in nm_ for k in ('wheel', 'hub', 'tyre', 'tire', 'rim'))
    bvh = c['own'].get(obj.name) if self_only else c['all']
    if bvh is None:
        return None
    nv = len(bm.verts)
    dirs = _lfs_ao_dirs(32 if nv <= 60000 else 16)
    nmat = mw.to_3x3().inverted().transposed()
    try:
        bm.normal_update()
    except Exception:
        pass
    W = _LFS_AO_W
    try:
        _reach = float(bpy.context.scene.get('lfs_ve_corner_reach', 1.0)) * float(c.get('length', 4.5))
    except (TypeError, ValueError):
        _reach = 4.5
    out = []
    for v in bm.verts:
        n = nmat @ v.normal
        if n.length < 1e-9:
            out.append(0)
            continue
        n.normalize()
        tg = n.orthogonal()
        tg.normalize()
        bt = n.cross(tg)
        o = (mw @ v.co) + n * 0.002
        sw = 0.0
        sv = 0.0
        for dx, dy, dz in dirs:
            d = tg * dx + bt * dy + n * dz
            w = (d.z if d.z > 0.0 else 0.0) + 0.05
            sw += w
            if bvh.ray_cast(o, d, _reach)[0] is None:
                sv += w
        ao = sv / sw if sw > 0.0 else 1.0
        out.append(min(range(4), key=lambda k: abs(W[k] - ao)))
    return out


def _ve_rebuild_subobj_geometry(raw_bytes, obj, depsgraph, apply_mods, report=None):
    info = raw_bytes[:28]
    lods_count = info[3]
    p = 28 + lods_count * 4
    geo = bytearray(raw_bytes[p:p+28])
    p += 28
    orig_nv = struct.unpack_from('<H', geo, 0)[0]
    orig_nf = struct.unpack_from('<H', geo, 2)[0]
    verts_end = p + orig_nv * 16
    faces_off = verts_end
    faces_end = verts_end + orig_nf * 12
    trailing_full = raw_bytes[faces_end:]
    
    tp = 0
    pages_count = struct.unpack_from('<i', trailing_full, tp)[0]
    tp += 4 + pages_count * 24
    cutouts_count = struct.unpack_from('<i', trailing_full, tp)[0]
    tp += 4 + cutouts_count * 32
    pages_cutouts_bytes = trailing_full[:tp]
    orig_some_var = struct.unpack_from('<h', trailing_full, tp + 2)[0] if tp + 4 <= len(trailing_full) else 2

    new_map_records = _EXPORT_CACHE.get('map_records')
    if new_map_records is None:
        new_map_records = _scene_materials_to_map_records(bpy.context)
        _EXPORT_CACHE['map_records'] = new_map_records

    cut_by_name = {}
    try:
        _cc = struct.unpack_from('<i', pages_cutouts_bytes,
                                 4 + struct.unpack_from('<i', pages_cutouts_bytes, 0)[0]*24)[0]
        _coff = 4 + struct.unpack_from('<i', pages_cutouts_bytes, 0)[0]*24 + 4
        for _ci in range(_cc):
            _nm = pages_cutouts_bytes[_coff:_coff+16].split(b'\x00',1)[0].decode('latin-1','replace')
            cut_by_name.setdefault(_nm, _ci)
            _coff += 32
    except Exception:
        cut_by_name = {}

    _rt_map_names = []
    _rt_maps_count = 0
    _rt_maps_end = len(trailing_full)
    try:
        _rt_maps_count = struct.unpack_from('<H', trailing_full, tp)[0]
        for _mi in range(_rt_maps_count):
            _mo = tp + 4 + _mi * 52
            _rt_map_names.append(trailing_full[_mo:_mo+16].split(b'\x00', 1)[0]
                                 .decode('latin-1', 'replace'))
        _rt_maps_end = tp + 4 + _rt_maps_count * 52
    except Exception:
        _rt_map_names = []
    _rt_idx_by_name = {}
    for _i, _n in enumerate(_rt_map_names):
        _rt_idx_by_name.setdefault(_n, _i)
    _rt_extra_cuts = []
    _rt_extra_maps = []
    _rt_cache = {}
    _rt_cut_count0 = cutouts_count

    def _rt_map_id(mat):
        nm = mat.name
        if nm in _rt_cache:
            return _rt_cache[nm]
        idx = None
        import re as _re
        _base = _re.sub(r'\.\d{3}$', '', nm)
        _rawnm = mat.get('lfs_map_name')
        _base2 = _re.sub(r'_\d+$', '', _base)
        _cands = ((str(_rawnm),) if _rawnm else ()) + (nm, nm[:16], nm[:15], _base, _base[:16], _base[:15])
        if _base2 and _base2 != _base:
            _cands = _cands + (_base2, _base2[:16], _base2[:15])
        for cand in _cands:
            if cand in _rt_idx_by_name:
                idx = _rt_idx_by_name[cand]
                break
        if idx is None:
            try:
                r_, g_, b_ = _mat_rgb(mat)
            except Exception:
                r_, g_, b_ = 128, 128, 128
            if (r_, g_, b_) == (0, 0, 0):
                r_, g_, b_ = 8, 8, 8
            _mode = 1; _type = 7; _shine = 0x2e
            try:
                if 'lfs_rmode' in mat.keys(): _mode = int(mat['lfs_rmode']) & 0xFF
                if 'lfs_rtype' in mat.keys(): _type = int(mat['lfs_rtype']) & 0xFF
                if 'lfs_shine' in mat.keys(): _shine = int(mat['lfs_shine']) & 0xFF
            except (ValueError, TypeError):
                pass
            cn = nm.encode('latin-1', 'replace')[:15]
            crec = bytearray(cn + b'\x00' * (16 - len(cn)))
            crec += bytes([0, 0, 0, 0, 0, _mode, _type, 0])
            crec += bytes([r_ & 0xFF, g_ & 0xFF, b_ & 0xFF, _shine & 0xFF])
            crec += bytes([0x80, 0x80, 0, 0])
            ci_new = _rt_cut_count0 + len(_rt_extra_cuts)
            if ci_new >= _CUTOUT_TABLE_MAX and _LFS_OVER['on']:
                _lfs_over_note("%s: more than %d cutouts" % (obj.name, _CUTOUT_TABLE_MAX))
            elif ci_new >= _CUTOUT_TABLE_MAX:
                raise ValueError(
                    "Sub-object '%s': material '%s' needs a new cutout but the "
                    "cutout table is full (%d, editor limit ~%d). Re-use an "
                    "existing material for those faces or run Purge Unused Maps%s."
                    % (obj.name, nm, ci_new, _CUTOUT_TABLE_MAX,
                       _LFS_OVER_HINT if _LFS_OVER['export'] else ''))
            _rt_extra_cuts.append(bytes(crec))
            mrec = bytearray(_build_default_map_record(ci_new, nm, r_, g_, b_))
            struct.pack_into('<hh', mrec, 48, ci_new, ci_new)
            idx = _rt_maps_count + len(_rt_extra_maps)
            _rt_extra_maps.append(bytes(mrec))
            _rt_idx_by_name[nm] = idx
        _rt_cache[nm] = idx
        return idx

    new_maps_section = bytearray()
    new_maps_section += struct.pack('<H', len(new_map_records))
    new_maps_section += struct.pack('<h', orig_some_var)
    _map_org = _ve_export_origin(obj)
    _sf_m = float(bpy.context.scene.get('lfs_ve_scale_factor', 1.0))
    _org_fp = (int(round(_map_org.x * _sf_m * 65536.0)),
               int(round(_map_org.y * _sf_m * 65536.0)),
               int(round(_map_org.z * _sf_m * 65536.0)))
    _scratch_tables = None
    if orig_nf == 0:
        _scratch_tables = _EXPORT_CACHE.get('tables')
        if _scratch_tables is None:
            _scratch_tables = _build_texture_tables(
                _cidx_materials_list(new_map_records), _resolve_png_dir())
            _EXPORT_CACHE['tables'] = _scratch_tables
    _loc_order = None
    _loc_of = {}
    if orig_nf == 0:
        try:
            _usedc = set()
            for _p9 in obj.data.polygons:
                _mi9 = _p9.material_index
                _m9 = obj.material_slots[_mi9].material if 0 <= _mi9 < len(obj.material_slots) else None
                _c9 = int(_m9['lfs_cidx']) if (_m9 is not None and _m9.get('lfs_cidx') is not None) else 0
                _usedc.add(_c9 if 0 <= _c9 < len(new_map_records) else 0)
            if not _usedc:
                _usedc = {0}
            _loc_order = sorted(_usedc)
            _loc_of = {c_: i_ for i_, c_ in enumerate(_loc_order)}
        except Exception as _le:
            print(f"  [ve-export] {obj.name}: own map list skipped: {_le!r}")
            _loc_order = None
            _loc_of = {}
    if _loc_order is not None:
        new_maps_section = bytearray()
        new_maps_section += struct.pack('<H', len(_loc_order))
        new_maps_section += struct.pack('<h', orig_some_var)
    for _mi, rec in ([(c_, new_map_records[c_]) for c_ in _loc_order] if _loc_order is not None
                     else enumerate(new_map_records)):
        rec = bytearray(rec)
        if _org_fp != (0, 0, 0):
            _px, _py, _pz = struct.unpack_from('<iii', rec, 28)
            if _px or _py or _pz:
                struct.pack_into('<iii', rec, 28, _px - _org_fp[0],
                                 _py - _org_fp[1], _pz - _org_fp[2])
        ci = None
        if _scratch_tables is not None:
            _cidx_list = _scratch_tables[2]
            if _mi < len(_cidx_list):
                ci = _cidx_list[_mi]
        if ci is None:
            mname = rec[:16].split(b'\x00',1)[0].decode('latin-1','replace')
            ci = cut_by_name.get(mname)
            if ci is None:
                ci = cut_by_name.get(mname[:15])
        if ci is not None:
            struct.pack_into('<hh', rec, 48, ci, ci)
        new_maps_section += bytes(rec)
    if _scratch_tables is not None:
        pages_cutouts_bytes = _scratch_tables[0] + _scratch_tables[1]

    if orig_nf > 0:
        trailing = trailing_full
    else:
        trailing = pages_cutouts_bytes + bytes(new_maps_section)
    
    face_meta_lookup = _ve_decode_original_faces(raw_bytes)
    
    orig_raw_faces = []
    for fi in range(orig_nf):
        off = faces_off + fi * 12
        face_raw = raw_bytes[off:off+12]
        mirror = face_raw[0]
        if mirror == 33:
            orig_raw_faces.append((None, face_raw))
            continue
        i1 = struct.unpack_from('<h', face_raw, 6)[0]
        i2 = struct.unpack_from('<h', face_raw, 8)[0]
        i3 = struct.unpack_from('<h', face_raw, 10)[0]
        if i1 < 0: i1 += 32768
        if i2 < 0: i2 += 32768
        if i3 < 0: i3 += 32768
        key = tuple(sorted((i1, i2, i3)))
        orig_raw_faces.append((key, face_raw))

    from collections import Counter
    src_mirror_counts = Counter()
    for _key, _raw in orig_raw_faces:
        if _key is None:
            continue
        src_mirror_counts[_raw[0]] += 1
    
    default_mirror_byte = None
    if src_mirror_counts:
        total = sum(src_mirror_counts.values())
        top_val, top_count = src_mirror_counts.most_common(1)[0]
        if top_count / total >= 0.80:
            default_mirror_byte = top_val
            print(f"  [ve-export] {obj.name}: using source-majority mirror={top_val} for new faces ({top_count}/{total})")
    
    if default_mirror_byte is None:
        try:
            no_mirror_flag = bool(bpy.context.scene.get('lfs_ve_no_auto_mirror', False))
        except Exception:
            no_mirror_flag = False
        default_mirror_byte = 0 if no_mirror_flag else 1
        print(f"  [ve-export] {obj.name}: using scene-flag mirror={default_mirror_byte} for new faces")
    else:
        try:
            if 'lfs_ve_no_auto_mirror' in bpy.context.scene.keys():
                explicit = bool(bpy.context.scene['lfs_ve_no_auto_mirror'])
                forced = 0 if explicit else 1
                if forced != default_mirror_byte:
                    print(f"  [ve-export] {obj.name}: scene flag forces mirror={forced} (overriding source majority {default_mirror_byte})")
                    default_mirror_byte = forced
        except Exception:
            pass
    
    no_mirror_flag = (default_mirror_byte == 0)
    
    _apply_subsurf = True
    try:
        _apply_subsurf = bool(bpy.context.scene.get('lfs_ve_apply_subsurf', True))
    except Exception:
        pass

    def _subsurf_mods():
        return [_m for _m in obj.modifiers
                if _m.type in {'SUBSURF', 'MULTIRES'} and _m.show_viewport]

    _muted = []

    def _mute_subsurf():
        for _m in _subsurf_mods():
            _m.show_viewport = False
            _muted.append(_m)
            _EXPORT_CACHE.setdefault('muted', []).append(_m)
        if _muted:
            depsgraph.update()

    if apply_mods and not _apply_subsurf:
        _mute_subsurf()
    elif apply_mods and _apply_subsurf and _subsurf_mods():
        try:
            _ev = obj.evaluated_get(depsgraph).to_mesh(preserve_all_data_layers=False, depsgraph=depsgraph)
            _evn = len(_ev.vertices)
            obj.evaluated_get(depsgraph).to_mesh_clear()
        except Exception:
            _evn = 0
        if _evn > 32767:
            print(f"  [ve-export] {obj.name}: subsurf would make {_evn} verts "
                  f"(>32767) - auto-skipping subsurf for this sub-object. Split "
                  f"it to keep subdivision.")
            _mute_subsurf()

    me = (obj.evaluated_get(depsgraph).to_mesh(preserve_all_data_layers=False, depsgraph=depsgraph)
          if apply_mods else obj.to_mesh())

    def _restore_muted():
        if _muted:
            for _mm in _muted:
                _mm.show_viewport = True
            try:
                depsgraph.update()
            except Exception:
                pass
    
    _fast = False
    try:
        _fast = bool(bpy.context.scene.get('lfs_ve_fast_smoothing', False))
    except Exception:
        pass
    if _fast:
        pre_tri_groups = [0] * len(me.polygons)
    elif orig_nf > 0:
        pre_tri_groups = []
    else:
        _as = bool(bpy.context.scene.get('lfs_ve_auto_smooth', False))
        _sa = float(bpy.context.scene.get('lfs_ve_smooth_angle', 30.0))
        pre_tri_groups = _compute_smoothing_groups(
            me, hard_angle_deg=_sa, auto_smooth=_as)
    bm = bmesh.new()
    bm.from_mesh(me)
    
    src_poly_layer = bm.faces.layers.int.new('src_poly')
    for fi, f in enumerate(bm.faces):
        f[src_poly_layer] = fi
    
    bmesh.ops.triangulate(bm, faces=bm.faces)
    _mir_face = bm.faces.layers.int.get('lfs_mirrored') if orig_nf == 0 else None
    
    matrix_world = obj.matrix_world
    flip_y = bpy.context.scene.get('lfs_ve_flip_y_on_export', False)

    _sf = 1.0
    try:
        _sf = float(bpy.context.scene.get('lfs_ve_scale_factor', 1.0))
    except Exception:
        pass
    _origin = _ve_export_origin(obj)
    new_verts_bytes = bytearray()
    _orig_vflag = []
    _flag_by_xyz = {}
    _oidx_by_xyz = {}
    _orig_vco = []
    try:
        _vb = faces_off - orig_nv * 16
        for _i in range(orig_nv):
            _f0, _x0, _y0, _z0 = struct.unpack_from('<iiii', raw_bytes, _vb + 16 * _i)
            _orig_vflag.append(_f0)
            _flag_by_xyz.setdefault((_x0, _y0, _z0), _f0)
            _oidx_by_xyz.setdefault((_x0, _y0, _z0), _i)
            _orig_vco.append((_x0, _y0, _z0))
    except Exception:
        _orig_vflag = []; _flag_by_xyz = {}; _oidx_by_xyz = {}; _orig_vco = []
    _bl2o = []
    _new_vco = []
    _posface = {}
    _n_pos_rescued = 0
    if _orig_vco:
        try:
            for _k0, _r0 in face_meta_lookup.items():
                if max(_k0) < len(_orig_vco):
                    _posface.setdefault(
                        tuple(sorted(_orig_vco[_j] for _j in _k0)), _r0)
        except Exception:
            _posface = {}
    _flag_default = 1
    if _orig_vflag:
        try:
            _flag_default = Counter(_orig_vflag).most_common(1)[0][0]
        except Exception:
            _flag_default = 1
    _flag_kept = 0
    _ao_lv = None
    try:
        if bool(bpy.context.scene.get('lfs_ve_corner_dark', False)):
            _ao_lv = _lfs_ao_levels(obj, bm, matrix_world, depsgraph)
    except Exception as _aoe:
        print(f"  [ve-export] {obj.name}: darker hidden corners skipped: {_aoe!r}")
        _ao_lv = None
    _ao_n = [0, 0, 0, 0]
    _fs_layer = bm.faces.layers.int.get('lfs_face')
    try:
        _fs_tag = int(obj.get('lfs_face_tag', -1))
    except (TypeError, ValueError):
        _fs_tag = -1
    _fs_any = _fs_layer is not None and _fs_tag >= 0 and bool(orig_raw_faces)

    def _src_of(f_):
        if _fs_layer is None or _fs_tag < 0:
            return -1
        v_ = f_[_fs_layer]
        if v_ <= 0 or (v_ >> 16) != _fs_tag:
            return -1
        k_ = (v_ & 0xFFFF) - 1
        return k_ if 0 <= k_ < len(orig_raw_faces) else -1

    _fs_mir_pts = set()
    for _k5, _r5 in orig_raw_faces:
        if _k5 is not None and (_r5[0] & 1):
            _fs_mir_pts.update(_k5)
    _FS_SEAM = 66

    def _fs_seam(v_, vi_, p_):
        if p_ in _oidx_by_xyz:
            return False
        if vi_ < len(_orig_vco) and _orig_vco[vi_][0] == 0 and vi_ in _fs_mir_pts:
            return True
        if not _fs_any:
            return False
        for f_ in v_.link_faces:
            k_ = _src_of(f_)
            if k_ >= 0 and (orig_raw_faces[k_][1][0] & 1):
                return True
        return False

    def _fs_newflag(v_, p_):
        best = None
        for f_ in (v_.link_faces if _fs_any else ()):
            k_ = _src_of(f_)
            if k_ < 0 or orig_raw_faces[k_][0] is None:
                continue
            for oi_ in orig_raw_faces[k_][0]:
                if 0 <= oi_ < len(_orig_vco) and oi_ < len(_orig_vflag):
                    q_ = _orig_vco[oi_]
                    d_ = (q_[0] - p_[0]) ** 2 + (q_[1] - p_[1]) ** 2 + (q_[2] - p_[2]) ** 2
                    if best is None or d_ < best[0]:
                        best = (d_, _orig_vflag[oi_])
        fl_ = best[1] if best is not None else _flag_default
        if p_[0] != 0:
            fl_ &= ~2
        return fl_

    for _vi, v in enumerate(bm.verts):
        co = matrix_world @ v.co
        x = (co.x - _origin.x) * _sf
        y = ((-(co.y - _origin.y)) if flip_y else (co.y - _origin.y)) * _sf
        z = (co.z - _origin.z) * _sf
        _xi = int(round(x * FP)); _yi = int(round(y * FP)); _zi = int(round(z * FP))
        if _xi and abs(_xi) <= _FS_SEAM and _fs_seam(v, _vi, (_xi, _yi, _zi)):
            _xi = 0
        if _vi < len(_orig_vco) and _orig_vco[_vi] == (_xi, _yi, _zi):
            _bl2o.append(_vi)
        else:
            _bl2o.append(_oidx_by_xyz.get((_xi, _yi, _zi), -1))
        _new_vco.append((_xi, _yi, _zi))
        _ov5 = _bl2o[-1]
        if 0 <= _ov5 < len(_orig_vflag):
            _flag = _orig_vflag[_ov5]; _flag_kept += 1
        elif _vi < len(_orig_vflag) and len(bm.verts) == orig_nv:
            _flag = _orig_vflag[_vi]; _flag_kept += 1
        elif (_xi, _yi, _zi) in _flag_by_xyz:
            _flag = _flag_by_xyz[(_xi, _yi, _zi)]; _flag_kept += 1
        else:
            _flag = _fs_newflag(v, (_xi, _yi, _zi))
            if _ao_lv is not None and _vi < len(_ao_lv):
                _flag = (_flag & ~0xC0) | (int(_ao_lv[_vi]) << 6)
                _ao_n[int(_ao_lv[_vi])] += 1
        new_verts_bytes += struct.pack('<iiii', _flag, _xi, _yi, _zi)
    if sum(_ao_n):
        print(f"  [ve-export] {obj.name}: darker hidden corners: {_ao_n[0]} bright, {_ao_n[1]} dark, "
              f"{_ao_n[2]} very dark, {_ao_n[3]} extra dark point(s)")
    if _orig_vflag and len(bm.verts) != orig_nv:
        print(f"  [ve-export] {obj.name}: vertex shading flags kept on "
              f"{_flag_kept}/{len(bm.verts)} point(s) (new points -> {_flag_default})")
    new_nv = len(bm.verts)

    _dbl_set0 = set()
    try:
        _db0 = obj.get('lfs_dbl_b64')
        if _db0:
            import base64 as _b64d0
            _buf0 = _b64d0.b64decode(_db0)
            _dbl_set0 = {int.from_bytes(_buf0[i:i+4], 'little')
                         for i in range(0, len(_buf0), 4)}
    except Exception:
        _dbl_set0 = set()
    _dbl_vmap = {}
    if _dbl_set0:
        bm.verts.ensure_lookup_table()
        _need = []
        for _f in bm.faces:
            if _f[src_poly_layer] in _dbl_set0:
                for _v in _f.verts:
                    if _v.index not in _dbl_vmap:
                        _dbl_vmap[_v.index] = new_nv + len(_need)
                        _need.append(_v.index)
        if new_nv + len(_need) > 32700:
            print(f"  [ve-export] {obj.name}: double-siding skipped "
                  f"({new_nv}+{len(_need)} verts would exceed the limit)")
            _dbl_set0 = set(); _dbl_vmap = {}
        else:
            for _vi in _need:
                _v = bm.verts[_vi]
                co = matrix_world @ _v.co
                x = (co.x - _origin.x) * _sf
                y = ((-(co.y - _origin.y)) if flip_y else (co.y - _origin.y)) * _sf
                z = (co.z - _origin.z) * _sf
                new_verts_bytes += struct.pack('<iiii', 1,
                                               int(round(x * FP)),
                                               int(round(y * FP)),
                                               int(round(z * FP)))
            new_nv += len(_need)
            print(f"  [ve-export] {obj.name}: double-siding {len(_dbl_set0)} "
                  f"polys with {len(_need)} duplicated vert(s)")

    if new_nv > 32767:
        if apply_mods:
            obj.evaluated_get(depsgraph).to_mesh_clear()
        else:
            obj.to_mesh_clear()
        _restore_muted()
        raise ValueError(
            "Sub-object '%s' has %d vertices, over the 32767 limit per "
            "sub-object. Split it into multiple sub-objects (e.g. separate "
            "body / chassis / wheels) or decimate before exporting."
            % (obj.name, new_nv))

    _wco = [matrix_world @ v.co for v in bm.verts]
    _verts_same_order = (len(bm.verts) == orig_nv)

    new_faces_bytes = bytearray()
    new_nf = 0
    matched = 0
    unmatched = 0
    skipped_thin = 0
    _dbl_set = _dbl_set0
    try:
        _MIN_TRI_ALT = float(bpy.context.scene.get('lfs_ve_min_tri_alt', 0.00003))
    except (TypeError, ValueError):
        _MIN_TRI_ALT = 0.00003
    blender_face_keys = set()
    consumed_raw = set()
    try:
        _lods_kept = {int(x) for x in str(obj.get('lfs_subobj_lods_imported', '1')).split(',') if x.strip()}
    except (ValueError, TypeError):
        _lods_kept = {1}
    _kept_raw = []
    for _fi, (_k, _fr) in enumerate(orig_raw_faces):
        if _k is None:
            continue
        if (_fr[4] + 1) not in _lods_kept:
            continue
        if len(set(_k)) != 3 or max(_k) >= orig_nv:
            continue
        if sum(1 for _o in (6, 8, 10) if struct.unpack_from('<h', _fr, _o)[0] < 0) in (1, 2):
            continue
        _kept_raw.append(_fi)
    _auto_smooth_fresh = True
    _used_orig_bytes = set()
    try:
        _used_orig_bytes = {_r[5] for _r in face_meta_lookup.values()}
    except Exception:
        _used_orig_bytes = set()
    _free_bytes = [_b for _b in range(_LFS_GROUPS) if _b not in _used_orig_bytes]
    _fresh_byte = {}
    def _take_fresh_byte(_g):
        if _g not in _fresh_byte:
            _fresh_byte[_g] = _free_bytes.pop(0) if _free_bytes else (_g % _LFS_GROUPS)
        return _fresh_byte[_g]
    _n_untouched_winding = 0
    _grp_orig = {}
    try:
        for _f2 in bm.faces:
            if len(_f2.verts) != 3:
                continue
            _vs = [v.index for v in _f2.verts]
            if len(set(_vs)) != 3:
                continue
            _k2 = tuple(sorted(_vs))
            if _bl2o and max(_vs) < len(_bl2o):
                _o3 = [_bl2o[i] for i in _vs]
                if min(_o3) >= 0 and len(set(_o3)) == 3:
                    _k2 = tuple(sorted(_o3))
            _om = face_meta_lookup.get(_k2)
            if _om is None:
                continue
            _sp = _f2[src_poly_layer]
            if 0 <= _sp < len(pre_tri_groups):
                _grp_orig.setdefault(pre_tri_groups[_sp], Counter())[_om[5]] += 1
    except Exception:
        _grp_orig = {}
    _near = {'ready': False, 'C': None, 'M': None}

    def _mirror_for(cen):
        try:
            import numpy as _np
        except Exception:
            return default_mirror_byte
        if not _near['ready']:
            _near['ready'] = True
            cs = []; ms = []
            for _k2, _fr2 in orig_raw_faces:
                if _fr2[0] == 33 or _k2 is None:
                    continue
                if max(_k2) >= len(_orig_vco):
                    continue
                a_, b_, c_ = (_orig_vco[i_] for i_ in _k2)
                cs.append(((a_[0] + b_[0] + c_[0]) / 3.0,
                           (a_[1] + b_[1] + c_[1]) / 3.0,
                           (a_[2] + b_[2] + c_[2]) / 3.0))
                ms.append(_fr2[0])
            if cs:
                _near['C'] = _np.asarray(cs, dtype=_np.float64)
                _near['M'] = _np.asarray(ms, dtype=_np.int32)
        if _near['C'] is None:
            return default_mirror_byte
        d = ((_near['C'] - _np.asarray(cen, dtype=_np.float64)) ** 2).sum(1)
        return int(_near['M'][int(d.argmin())])

    def _match_face(face, va, vb, vc):
        key = tuple(sorted((va, vb, vc)))
        _key_o = None
        if _bl2o and max(va, vb, vc) < len(_bl2o):
            _oa, _ob, _oc = _bl2o[va], _bl2o[vb], _bl2o[vc]
            if _oa >= 0 and _ob >= 0 and _oc >= 0 and len({_oa, _ob, _oc}) == 3:
                _key_o = tuple(sorted((_oa, _ob, _oc)))
        _lk = _key_o if _key_o is not None else key
        orig = None
        orig_raw12 = None
        _rescued = False
        _spi = face[src_poly_layer]
        if 0 <= _spi < len(_kept_raw) and orig_raw_faces[_kept_raw[_spi]][0] == _lk:
            _ri = _kept_raw[_spi]
            _fr = orig_raw_faces[_ri][1]
            orig = (_fr[0], _fr[1], _fr[2], _fr[3], _fr[4], _fr[5], _ri)
            orig_raw12 = _fr
        else:
            orig = face_meta_lookup.get(_lk)
            if orig is None and _key_o is not None:
                orig = face_meta_lookup.get(key)
            if (orig is None and _posface
                    and len(_new_vco) > max(va, vb, vc)):
                orig = _posface.get(tuple(sorted((_new_vco[va], _new_vco[vb],
                                                  _new_vco[vc]))))
                if orig is not None:
                    _rescued = True
            if orig is not None and len(orig) > 6 and not _rescued:
                orig_raw12 = orig_raw_faces[orig[6]][1]
        return orig, orig_raw12, _rescued, _lk

    _FS_T = 33
    _fs_newc, _fs_piece_of, _fs_pieces, _fs_np = {}, {}, [], {}

    def _fs_isnew(f_):
        r_ = _fs_newc.get(f_.index)
        if r_ is None:
            vs_ = f_.verts
            r_ = (len(vs_) == 3 and _src_of(f_) < 0
                  and _match_face(f_, vs_[0].index, vs_[1].index, vs_[2].index)[0] is None)
            _fs_newc[f_.index] = r_
        return r_

    def _fs_table():
        if 'C' not in _fs_np:
            import numpy as _np5
            C_, N_, M_, I_ = [], [], [], []
            for k_, r_ in orig_raw_faces:
                if k_ is None or max(k_) >= len(_orig_vco) or r_[4] != 0:
                    continue
                a_, b_, c_ = (_orig_vco[i_] for i_ in k_)
                C_.append(((a_[0] + b_[0] + c_[0]) / 3.0, (a_[1] + b_[1] + c_[1]) / 3.0,
                           (a_[2] + b_[2] + c_[2]) / 3.0))
                N_.append(_rt_map_names[r_[2]] if r_[2] < len(_rt_map_names) else '')
                M_.append(r_[0]); I_.append(r_[2])
            _fs_np['np'] = _np5
            _fs_np['C'] = _np5.asarray(C_, dtype=_np5.float64).reshape(-1, 3)
            _fs_np['N'] = _np5.asarray(N_, dtype=object)
            _fs_np['M'] = _np5.asarray(M_, dtype=_np5.int64)
            _fs_np['I'] = _np5.asarray(I_, dtype=_np5.int64)
        return _fs_np

    def _fs_near(cen_, name_, side_):
        T_ = _fs_table(); np_ = T_['np']
        if len(T_['C']) == 0:
            return None
        ok_ = np_.ones(len(T_['C']), dtype=bool)
        if name_ is not None:
            m_ = T_['N'] == name_
            if m_.any():
                ok_ &= m_
        if side_:
            cx_ = T_['C'][:, 0]
            m_ = np_.where(np_.abs(cx_) > _FS_T, np_.sign(cx_), 0) == side_
            if not (ok_ & m_).any():
                return None
            ok_ &= m_
        ix_ = np_.nonzero(ok_)[0]
        d_ = ((T_['C'][ix_] - np_.asarray(cen_, dtype=np_.float64)) ** 2).sum(1)
        return int(ix_[int(d_.argmin())])

    def _fs_piece(face_, cidx_):
        pid_ = _fs_piece_of.get(face_.index)
        if pid_ is None:
            comp_, seen_, stack_ = [face_], {face_.index}, [face_]
            while stack_:
                f_ = stack_.pop()
                for v_ in f_.verts:
                    for g_ in v_.link_faces:
                        if g_.index not in seen_ and _fs_isnew(g_):
                            seen_.add(g_.index); comp_.append(g_); stack_.append(g_)
            pts_ = [_new_vco[v_.index] for f_ in comp_ for v_ in f_.verts if v_.index < len(_new_vco)]
            xs_ = [q_[0] for q_ in pts_] or [0]
            if min(xs_) < -_FS_T and max(xs_) > _FS_T:
                side_ = None
            elif min(xs_) < -_FS_T:
                side_ = -1
            elif max(xs_) > _FS_T:
                side_ = 1
            else:
                side_ = 0
            n_ = max(len(pts_), 1)
            cen_ = (sum(q_[0] for q_ in pts_) / n_, sum(q_[1] for q_ in pts_) / n_,
                    sum(q_[2] for q_ in pts_) / n_)
            pid_ = len(_fs_pieces)
            _fs_pieces.append({'side': side_, 'cen': cen_, 'res': {}})
            for f_ in comp_:
                _fs_piece_of[f_.index] = pid_
        P_ = _fs_pieces[pid_]
        name_ = _rt_map_names[cidx_] if 0 <= cidx_ < len(_rt_map_names) else None
        if name_ not in P_['res']:
            mir_, map_ = 0, cidx_
            T_ = _fs_table()
            if P_['side']:
                j_ = _fs_near(P_['cen'], name_, P_['side'])
                mir_ = int(T_['M'][j_]) & 1 if j_ is not None else 0
            if name_ is not None and _rt_map_names.count(name_) > 1:
                j_ = _fs_near(P_['cen'], name_, 0)
                if j_ is not None and T_['N'][j_] == name_:
                    map_ = int(T_['I'][j_])
            P_['res'][name_] = (mir_, map_)
        return P_['res'][name_]

    def _fs_off_side(va_, vb_, vc_, k_):
        xs_ = [_new_vco[i_][0] for i_ in (va_, vb_, vc_)]
        if min(xs_) < -_FS_T and max(xs_) > _FS_T:
            return True
        key_ = orig_raw_faces[k_][0]
        if key_ is None or max(key_) >= len(_orig_vco):
            return False
        sx_ = sum(_orig_vco[i_][0] for i_ in key_) / 3.0
        nx_ = sum(xs_) / 3.0
        return (abs(sx_) > _FS_T and abs(nx_) > _FS_T and (sx_ > 0) != (nx_ > 0))

    _sm_layer = bm.faces.layers.int.get(_LFS_SMOOTH_ATTR)
    _auto_b, _auto_nc = {}, {}
    bm.faces.index_update()
    if orig_nf > 0:
        try:
            _auto_b, _auto_nc = _ve_auto_groups(bm, _match_face, _sm_layer, _used_orig_bytes)
        except Exception:
            traceback.print_exc()
            _auto_b, _auto_nc = {}, {}

    for face in bm.faces:
        verts_in_face = list(face.verts)
        if len(verts_in_face) != 3:
            continue
        va, vb, vc = verts_in_face[0].index, verts_in_face[1].index, verts_in_face[2].index
        if va == vb or vb == vc or va == vc:
            continue

        orig, orig_raw12, _rescued_by_pos, _lk = _match_face(face, va, vb, vc)
        if _rescued_by_pos:
            _n_pos_rescued += 1

        _a, _b, _c = _wco[va], _wco[vb], _wco[vc]
        _ab = _b - _a; _ac = _c - _a
        _area2 = _ab.cross(_ac).length
        _lmax = max(_ab.length, _ac.length, (_c - _b).length)
        _alt9 = (_sf * _area2 / _lmax) if _lmax > 1e-9 else 0.0
        if orig is None and _lmax > 1e-9 and (
                _alt9 < _MIN_TRI_ALT
                or _alt9 < 0.00022
                or 0.5 * _area2 * _sf * _sf < 4.5e-8):
            skipped_thin += 1
            continue

        blender_face_keys.add(_lk)
        
        mi = face.material_index
        slot_mat = obj.material_slots[mi].material if 0 <= mi < len(obj.material_slots) else None
        cidx = int(slot_mat['lfs_cidx']) if (slot_mat is not None and slot_mat.get('lfs_cidx') is not None) else 0
        if orig_nf == 0 and _loc_order is not None:
            cidx = _loc_of.get(cidx, _loc_of.get(0, 0))
        if orig_nf > 0 and slot_mat is not None:
            cidx = _rt_map_id(slot_mat)
        
        if orig is not None:
            mirror, layout, _orig_map_id, nc, lod, smooth = orig[:6]
            if face.index in _auto_b:
                smooth = _auto_b[face.index]
            if len(orig) > 6:
                consumed_raw.add(orig[6])
            matched += 1
            if (orig_nf > 0 and slot_mat is not None and _orig_map_id != cidx
                    and 0 <= _orig_map_id < len(_rt_map_names)
                    and 0 <= cidx < len(_rt_map_names)
                    and _rt_map_names[_orig_map_id] == _rt_map_names[cidx]):
                cidx = _orig_map_id
            elif orig_nf > 0 and slot_mat is None:
                cidx = _orig_map_id
        else:
            mirror = default_mirror_byte
            layout, nc, lod = 0, 1, 0
            if _mir_face is not None and face[_mir_face]:
                mirror = 1
            _sk = _src_of(face)
            if _sk >= 0:
                _sr = orig_raw_faces[_sk][1]
                mirror, layout, nc, lod = _sr[0], _sr[1], _sr[3], _sr[4]
                if (mirror & 1) and _fs_off_side(va, vb, vc, _sk):
                    mirror &= ~1
                _smap = _sr[2]
                if orig_nf > 0 and 0 <= _smap < len(_rt_map_names) and (
                        slot_mat is None or (0 <= cidx < len(_rt_map_names)
                                             and _rt_map_names[_smap] == _rt_map_names[cidx])):
                    cidx = _smap
            elif _orig_vco and len(_new_vco) > max(va, vb, vc):
                try:
                    mirror, cidx = _fs_piece(face, cidx)
                except Exception:
                    traceback.print_exc()
                    _ca = _new_vco[va]; _cb = _new_vco[vb]; _cc2 = _new_vco[vc]
                    mirror = _mirror_for(((_ca[0] + _cb[0] + _cc2[0]) / 3.0,
                                          (_ca[1] + _cb[1] + _cc2[1]) / 3.0,
                                          (_ca[2] + _cb[2] + _cc2[2]) / 3.0))
            src_pi = face[src_poly_layer]
            if face.index in _auto_b:
                smooth = _auto_b[face.index]
                nc = _auto_nc.get(face.index, 1)
            elif 0 <= src_pi < len(pre_tri_groups):
                smooth = pre_tri_groups[src_pi] & 0xFF
                if _auto_smooth_fresh:
                    smooth = _take_fresh_byte(pre_tri_groups[src_pi])
                else:
                    _c2 = _grp_orig.get(pre_tri_groups[src_pi])
                    if _c2:
                        smooth = _c2.most_common(1)[0][0] & 0xFF
            else:
                smooth = mi & 0xFF
            unmatched += 1
        
        _how = 'file' if orig is not None else 'auto'
        if _sm_layer is not None:
            _ex = face[_sm_layer]
            if 1 <= _ex <= 256:
                smooth = (_ex - 1) & 0xFF
                _how = 'set'
        if report is not None:
            report.setdefault('tri', []).append(
                (face[src_poly_layer], smooth & 0xFF, nc & 0xFF, mirror & 0xFF, _how,
                 (face.verts[0].index, face.verts[1].index, face.verts[2].index)))

        if flip_y:
            _o1, _o2 = vc, vb
        else:
            _o1, _o2 = vb, vc
        _idx_bytes = None
        if orig_raw12 is not None and _verts_same_order:
            _r1, _r2, _r3 = struct.unpack_from('<hhh', orig_raw12, 6)
            _eff = ((_r3 & 0x7FFF, _r2 & 0x7FFF, _r1 & 0x7FFF)
                    if (_r1 < 0 or _r2 < 0 or _r3 < 0)
                    else (_r1 & 0x7FFF, _r2 & 0x7FFF, _r3 & 0x7FFF))
            _now = (va, _o1, _o2)
            if _now in (_eff, (_eff[1], _eff[2], _eff[0]), (_eff[2], _eff[0], _eff[1])):
                _idx_bytes = orig_raw12[6:12]
                _n_untouched_winding += 1
        if _idx_bytes is not None:
            new_faces_bytes += struct.pack('<BBBBBB',
                                           mirror & 0xFF, layout & 0xFF, cidx & 0xFF,
                                           nc & 0xFF, lod & 0xFF, smooth & 0xFF) + _idx_bytes
        else:
            _ab3 = orig_raw12
            if _ab3 is None:
                try:
                    _sk3 = _src_of(face)
                    if _sk3 >= 0:
                        _ab3 = orig_raw_faces[_sk3][1]
                except Exception:
                    _ab3 = None
            _allb = False
            if _ab3 is not None:
                _q1, _q2, _q3 = struct.unpack_from('<hhh', _ab3, 6)
                _allb = _q1 < 0 and _q2 < 0 and _q3 < 0
            if _allb:
                new_faces_bytes += struct.pack('<BBBBBBhhh',
                                               mirror & 0xFF, layout & 0xFF, cidx & 0xFF,
                                               nc & 0xFF, lod & 0xFF, smooth & 0xFF,
                                               -32768 + (_o2 & 0x7FFF), -32768 + (_o1 & 0x7FFF),
                                               -32768 + (va & 0x7FFF))
            else:
                new_faces_bytes += struct.pack('<BBBBBBhhh',
                                               mirror & 0xFF, layout & 0xFF, cidx & 0xFF,
                                               nc & 0xFF, lod & 0xFF, smooth & 0xFF,
                                               va & 0x7FFF, _o1 & 0x7FFF, _o2 & 0x7FFF)
        new_nf += 1
        if _dbl_vmap and face[src_poly_layer] in _dbl_set0:
            _dva = _dbl_vmap.get(va, va)
            _dv1 = _dbl_vmap.get(_o1, _o1)
            _dv2 = _dbl_vmap.get(_o2, _o2)
            new_faces_bytes += struct.pack('<BBBBBBhhh',
                                           mirror & 0xFF, layout & 0xFF, cidx & 0xFF,
                                           nc & 0xFF, lod & 0xFF, smooth & 0xFF,
                                           _dva & 0x7FFF, _dv2 & 0x7FFF, _dv1 & 0x7FFF)
            new_nf += 1

    bm.free()
    if apply_mods:
        obj.evaluated_get(depsgraph).to_mesh_clear()
    else:
        obj.to_mesh_clear()
    
    preserved = 0
    dropped_stale = 0
    _verts_unchanged = (new_nv == orig_nv)
    _o2bl = {}
    for _bi, _oi in enumerate(_bl2o):
        if _oi >= 0:
            _o2bl.setdefault(_oi, _bi)

    def _reindex(face_raw, v1, v2, v3):
        out = bytearray(face_raw)
        for _k, _v in enumerate((v1, v2, v3)):
            _nv2 = _o2bl.get(_v)
            if _nv2 is None or _nv2 >= new_nv:
                return None
            _old = struct.unpack_from('<h', face_raw, 6 + 2 * _k)[0]
            struct.pack_into('<h', out, 6 + 2 * _k, (-32768 + _nv2) if _old < 0 else _nv2)
        return bytes(out)
    try:
        _lods_in_blender = {int(x) for x in str(obj.get('lfs_subobj_lods_imported', '1')).split(',') if x.strip()}
    except (ValueError, TypeError):
        _lods_in_blender = {1}
    for fi, (key, face_raw) in enumerate(orig_raw_faces):
        mirror = face_raw[0]
        lod_byte = face_raw[4]
        i1 = struct.unpack_from('<h', face_raw, 6)[0]
        i2 = struct.unpack_from('<h', face_raw, 8)[0]
        i3 = struct.unpack_from('<h', face_raw, 10)[0]
        if mirror != 33 and ((i1 < 0) + (i2 < 0) + (i3 < 0)) in (1, 2):
            if fi in consumed_raw:
                continue
            if _verts_unchanged:
                new_faces_bytes += face_raw
                new_nf += 1
                preserved += 1
            else:
                _fr1 = _reindex(face_raw, (i1 + 32768) if i1 < 0 else i1,
                                (i2 + 32768) if i2 < 0 else i2, (i3 + 32768) if i3 < 0 else i3)
                if _fr1 is not None:
                    new_faces_bytes += _fr1
                    new_nf += 1
                    preserved += 1
                else:
                    dropped_stale += 1
            continue
        v1 = (i1 + 32768) if i1 < 0 else i1
        v2 = (i2 + 32768) if i2 < 0 else i2
        v3 = (i3 + 32768) if i3 < 0 else i3
        _in_range = (v1 < new_nv and v2 < new_nv and v3 < new_nv)

        if mirror == 33:
            _fr2 = (face_raw if (_in_range and _verts_unchanged)
                    else _reindex(face_raw, v1, v2, v3))
            if _fr2 is not None:
                new_faces_bytes += _fr2
                new_nf += 1
                preserved += 1
            else:
                dropped_stale += 1
            continue

        if fi in consumed_raw:
            continue
        if (lod_byte + 1) in _lods_in_blender:
            continue
        if lod_byte == 0:
            continue

        _fr3 = (face_raw if (_in_range and _verts_unchanged)
                else _reindex(face_raw, v1, v2, v3))
        if _fr3 is not None:
            new_faces_bytes += _fr3
            new_nf += 1
            preserved += 1
        else:
            dropped_stale += 1
    if dropped_stale:
        print(f"  [ve-export] {obj.name}: dropped {dropped_stale} preserved LOD2/3 or mirror-33 face(s) "
              f"whose original vertex indices no longer apply (vertex count {orig_nv} -> {new_nv})")
    
    try:
        _EXPORT_CACHE['thin'] = _EXPORT_CACHE.get('thin', 0) + skipped_thin
    except Exception:
        pass
    print(f"  [ve-export] {obj.name}: {matched} matched ({_n_untouched_winding} byte-verbatim), {unmatched} new, {preserved} preserved verbatim (LOD-filtered/mirror33)"
          + (f", {skipped_thin} degenerate sliver(s) dropped" if skipped_thin else ""))

    if new_nf > 65535:
        if apply_mods:
            obj.evaluated_get(depsgraph).to_mesh_clear()
        else:
            obj.to_mesh_clear()
        _restore_muted()
        raise ValueError(
            "Sub-object '%s' has %d triangles, over the 65535 limit per "
            "sub-object. Split it into more sub-objects or decimate."
            % (obj.name, new_nf))
    struct.pack_into('<H', geo, 0, new_nv)
    struct.pack_into('<H', geo, 2, new_nf)
    _rel = _ve_rel_origin(obj)
    _oy = (-_rel.y if flip_y else _rel.y)
    struct.pack_into('<i', geo, 16, int(round(_rel.x * _sf * FP)))
    struct.pack_into('<i', geo, 20, int(round(_oy * _sf * FP)))
    struct.pack_into('<i', geo, 24, int(round(_rel.z * _sf * FP)))

    if orig_nf > 0 and (_rt_extra_cuts or _rt_extra_maps):
        _pg_end = 4 + pages_count * 24
        _ct_start = _pg_end + 4
        _ct_end = _ct_start + cutouts_count * 32
        _mp_start = tp + 4
        _mp_end = _mp_start + _rt_maps_count * 52
        _nt = bytearray()
        _nt += trailing_full[:_pg_end]
        _nt += struct.pack('<i', cutouts_count + len(_rt_extra_cuts))
        _nt += trailing_full[_ct_start:_ct_end]
        for _c in _rt_extra_cuts:
            _nt += _c
        _nt += struct.pack('<H', _rt_maps_count + len(_rt_extra_maps))
        _nt += trailing_full[tp + 2:tp + 4]
        _nt += trailing_full[_mp_start:_mp_end]
        for _m in _rt_extra_maps:
            _nt += _m
        _nt += trailing_full[_rt_maps_end:]
        trailing = bytes(_nt)
        print(f"  [ve-export] {obj.name}: appended {len(_rt_extra_cuts)} new "
              f"cutout(s)/map(s) for materials absent from the imported table")

    try:
        info, new_verts_bytes, new_faces_bytes = _ve_editor_norm(info, new_verts_bytes, new_faces_bytes)
        _nb5 = _ve_bad_normal_points(new_verts_bytes, new_faces_bytes)
        if _nb5:
            _EXPORT_CACHE.setdefault('badn', []).append((obj.name, _nb5))
            print(f"  [ve-export] {obj.name}: {_nb5} point(s) get no normal in LFS (editor: bad normals)")
    except Exception:
        traceback.print_exc()
    _restore_muted()
    out = bytearray()
    out += info
    out += raw_bytes[28:28 + lods_count * 4]
    out += geo
    out += new_verts_bytes
    out += new_faces_bytes
    out += trailing
    return bytes(out)

def build_vehicle_editor_sre(context, objects, apply_mods=True):
    scene = context.scene

    hdr_b64 = scene.get('lfs_ve_header', '')
    header_bytes = base64.b64decode(hdr_b64) if hdr_b64 else bytes.fromhex('5352454f424a00fc')

    ln_b64 = scene.get('lfs_ve_layout_names_raw', '')
    layout_names_raw = base64.b64decode(ln_b64) if ln_b64 else b'\x00' * 128
    if len(layout_names_raw) < 128:
        layout_names_raw = layout_names_raw + b'\x00' * (128 - len(layout_names_raw))

    spare_b64 = scene.get('lfs_ve_spare_bytes', '')
    spare_bytes = base64.b64decode(spare_b64) if spare_b64 else b'\x00' * 128
    if len(spare_bytes) < 128:
        spare_bytes = spare_bytes + b'\x00' * (128 - len(spare_bytes))

    def _subobj_type(o):
        b = o.get('lfs_subobj_raw_b64', '')
        if b:
            try:
                return base64.b64decode(b)[1]
            except Exception:
                pass
        return o.get('lfs_subobj_type', 3)
    _phantoms = [o for o in objects if _ve_is_phantom(o)]
    if _phantoms:
        print(f"  [ve-export] leaving out {len(_phantoms)} empty record(s) an older import "
              f"made from the layout block: {', '.join(o.name for o in _phantoms)}")
        objects = [o for o in objects if not _ve_is_phantom(o)]
    objects_sorted = sorted(
        objects,
        key=lambda o: (0 if (_subobj_type(o) == 0 and o.type == 'MESH' and len(o.data.vertices) > 0) else 1,
                       o.get('lfs_subobj_index', 999))
    )

    _no_raw = [o for o in objects_sorted if not o.get('lfs_subobj_raw_b64')]
    for _o in _no_raw:
        print(f"  [ve-export] WARN: {_o.name} has no raw bytes - skipping "
              f"(re-mark it with Mark as Sub-Object to include it)")
    if _no_raw:
        objects_sorted = [o for o in objects_sorted
                          if o.get('lfs_subobj_raw_b64')]

    out = bytearray()
    out += header_bytes

    depsgraph = context.evaluated_depsgraph_get()

    global _EXPORT_CACHE
    _EXPORT_CACHE = {'no_raw': [o.name for o in _no_raw], 'stats': [0, 0],
                     'order': [o.name for o in objects_sorted]}
    for _o in objects_sorted:
        if _subobj_type(_o) == 0:
            _EXPORT_CACHE['body_obj'] = _o
            break
    else:
        if objects_sorted:
            _EXPORT_CACHE['body_obj'] = objects_sorted[0]
    try:
        return _build_vehicle_editor_sre_body(context, objects_sorted, depsgraph,
                                              apply_mods, out, layout_names_raw,
                                              spare_bytes)
    finally:
        for _mm in _EXPORT_CACHE.get('muted', []):
            try:
                _mm.show_viewport = True
            except Exception:
                pass
        _keep = {k: _EXPORT_CACHE.get(k) for k in ('stats', 'no_raw', 'thin', 'order', 'pages', 'over', 'badn',
                                                   'over_lim')}
        _EXPORT_CACHE = {k: v for k, v in _keep.items() if v is not None}


def lfs_look_export(context):
    sc = context.scene
    try:
        op = context.window_manager.operator_properties_last("export_scene.lfs_sre")
    except Exception:
        op = None

    def _g(name, default):
        try:
            return getattr(op, name) if op is not None else default
        except Exception:
            return default
    objs = [o for o in sc.objects if o.type == 'MESH' and 'lfs_subobj_index' in o.keys()]
    if not objs:
        return None, []
    sf = 1.0
    if _g('scale_mode', 'ASIS') == 'LENGTH':
        mins = [1e18] * 3; maxs = [-1e18] * 3
        for o in objs:
            for v in o.data.vertices:
                w = o.matrix_world @ v.co
                for i in range(3):
                    mins[i] = min(mins[i], w[i]); maxs[i] = max(maxs[i], w[i])
        longest = max(maxs[i] - mins[i] for i in range(3))
        if longest > 0:
            sf = float(_g('real_length', 4.5)) / longest
    settings = {
        'lfs_ve_no_auto_mirror': not bool(_g('auto_mirror', False)),
        'lfs_ve_apply_subsurf': bool(_g('apply_subsurf', True)),
        'lfs_ve_fast_smoothing': bool(_g('fast_smoothing', False)),
        'lfs_ve_auto_smooth': bool(_g('auto_smooth', False)),
        'lfs_ve_smooth_angle': float(_g('smooth_angle', 30.0)),
        'lfs_ve_uv_seam_groups': bool(_g('uv_seam_groups', True)),
        'lfs_ve_group_mode_angle': bool(_g('simple_groups', False)),
        'lfs_ve_scale_factor': float(sf),
    }
    _none = object()
    saved = {k: (sc[k] if k in sc.keys() else _none) for k in settings}
    try:
        for k, v in settings.items():
            sc[k] = v
        data = build_vehicle_editor_sre(context, objs, apply_mods=True)
        order = list(_EXPORT_CACHE.get('order') or [])
    finally:
        for k, v in saved.items():
            try:
                if v is _none:
                    if k in sc.keys():
                        del sc[k]
                else:
                    sc[k] = v
            except Exception:
                pass
    return data, order


def _ve_compact_map_table(sub_bytes, label=''):
    b = bytes(sub_bytes)
    try:
        geo = 28 + b[3] * 4
        nv, nf = struct.unpack_from('<HH', b, geo)
        fs = geo + 28 + nv * 16
        fe = fs + nf * 12
        p = fe
        pc = struct.unpack_from('<i', b, p)[0]; p += 4 + 24 * pc
        cc = struct.unpack_from('<i', b, p)[0]; p += 4 + 32 * cc
        mp = p
        mc = struct.unpack_from('<H', b, mp)[0]
        me = mp + 4 + 52 * mc
    except Exception:
        return b
    if nf == 0 or mc == 0 or me > len(b):
        return b
    used = sorted({b[fs + i * 12 + 2] for i in range(nf)})
    if used[-1] >= mc or len(used) == mc:
        return b
    remap = {old: new for new, old in enumerate(used)}
    fb = bytearray(b[fs:fe])
    for i in range(nf):
        fb[i * 12 + 2] = remap[fb[i * 12 + 2]]
    maps = b''.join(b[mp + 4 + 52 * i: mp + 4 + 52 * (i + 1)] for i in used)
    print(f"  [ve-export] {label}: map table {mc} -> {len(used)} (maps this sub-object does not use dropped)")
    return (b[:fs] + bytes(fb) + b[fe:mp] + struct.pack('<H', len(used))
            + b[mp + 2:mp + 4] + maps + b[me:])


def _ve_compact_cutout_table(sub_bytes, label=''):
    b = bytes(sub_bytes)
    try:
        geo = 28 + b[3] * 4
        nv, nf = struct.unpack_from('<HH', b, geo)
        fs = geo + 28 + nv * 16
        fe = fs + nf * 12
        p = fe
        pc = struct.unpack_from('<i', b, p)[0]; p += 4 + 24 * pc
        cs = p
        cc = struct.unpack_from('<i', b, cs)[0]
        ce = cs + 4 + 32 * cc
        mp = ce
        mc = struct.unpack_from('<H', b, mp)[0]
        me = mp + 4 + 52 * mc
    except Exception:
        return b
    if cc <= 1 or mc == 0 or me > len(b):
        return b

    used = {0}
    for i in range(mc):
        mo = mp + 4 + 52 * i
        for off in (48, 50):
            v = struct.unpack_from('<h', b, mo + off)[0]
            if v < 0 or v >= cc:
                return b
            used.add(v)
    if len(used) == cc:
        return b

    keep = sorted(used)
    remap = {old: new for new, old in enumerate(keep)}
    cuts = b''.join(b[cs + 4 + 32 * i: cs + 4 + 32 * (i + 1)] for i in keep)
    mb = bytearray(b[mp:me])
    for i in range(mc):
        o = 4 + 52 * i
        for off in (48, 50):
            v = struct.unpack_from('<h', mb, o + off)[0]
            struct.pack_into('<h', mb, o + off, remap[v])
    print(f"  [ve-export] {label}: cutout table {cc} -> {len(keep)} "
          f"(cutouts no mapping points at dropped)")
    return (b[:cs] + struct.pack('<i', len(keep)) + cuts + bytes(mb) + b[me:])


def _build_vehicle_editor_sre_body(context, objects_sorted, depsgraph, apply_mods,
                                   out, layout_names_raw, spare_bytes):
    scene = context.scene
    for idx, obj in enumerate(objects_sorted):
        _lfs_progress(i=idx)
        raw_b64 = obj.get('lfs_subobj_raw_b64', '')
        if not raw_b64:
            print(f"  [ve-export] WARN: {obj.name} has no raw bytes - skipping")
            continue
        raw_bytes = base64.b64decode(raw_b64)

        _sf_scene = 1.0
        try:
            _sf_scene = float(scene.get('lfs_ve_scale_factor', 1.0))
        except Exception:
            pass
        if ((_ve_detect_geometry_change(obj) or abs(_sf_scene - 1.0) > 1e-9)
                and not _ve_still_empty(obj, raw_bytes)):
            print(f"  [ve-export] {obj.name}: rebuilding "
                  f"({'scaling x%.4f' % _sf_scene if abs(_sf_scene - 1.0) > 1e-9 else 'geometry modified'})")
            try:
                sub_bytes = _ve_rebuild_subobj_geometry(raw_bytes, obj, depsgraph, apply_mods)
                if scene.get('lfs_ve_compact_maps', True):
                    sub_bytes = _ve_compact_map_table(sub_bytes, obj.name)
                    if scene.get('lfs_ve_compact_cutouts', True):
                        sub_bytes = _ve_compact_cutout_table(sub_bytes, obj.name)
                _ncut5 = _ve_count_cutouts(bytes(sub_bytes))
                if _ncut5 > _CUTOUT_TABLE_MAX and _LFS_OVER['on']:
                    _lfs_over_note(f"{obj.name}: {_ncut5} cutouts (the editor crashes above {_CUTOUT_TABLE_MAX})")
                elif _ncut5 > _CUTOUT_TABLE_MAX:
                    raise ValueError(
                        f"it would get {_ncut5} cutouts - the LFS editor crashes above {_CUTOUT_TABLE_MAX}. "
                        "Run Bake Textures again or Purge Unused Maps" + (_LFS_OVER_HINT if _LFS_OVER['export'] else ''))
                _nmap5 = _ve_count_maps(bytes(sub_bytes))
                if _nmap5 > _MAP_TABLE_MAX and _nmap5 > _ve_count_maps(raw_bytes) and _LFS_OVER['on']:
                    _lfs_over_note(f"{obj.name}: {_nmap5} maps (the editor crashes above {_MAP_TABLE_MAX})")
                elif _nmap5 > _MAP_TABLE_MAX and _nmap5 > _ve_count_maps(raw_bytes):
                    raise ValueError(
                        f"it would get {_nmap5} texture maps - the LFS editor crashes above {_MAP_TABLE_MAX}. "
                        "Undo the last mapping tool (Fit Maps, Auto Split...) or run Purge Unused Maps"
                        + (_LFS_OVER_HINT if _LFS_OVER['export'] else ''))
            except Exception as e:
                traceback.print_exc()
                raise RuntimeError(f"{obj.name}: {e}") from e
        else:
            sub_bytes = bytearray(raw_bytes)
            info = sub_bytes[:28]
            lods_count = info[3]
            geo_off = 28 + lods_count * 4
            _rel = _ve_rel_origin(obj)
            _fy = bool(scene.get('lfs_ve_flip_y_on_export', False))
            px = int(round(_rel.x * FP))
            py = int(round((-_rel.y if _fy else _rel.y) * FP))
            pz = int(round(_rel.z * FP))
            struct.pack_into('<i', sub_bytes, geo_off + 16, px)
            struct.pack_into('<i', sub_bytes, geo_off + 20, py)
            struct.pack_into('<i', sub_bytes, geo_off + 24, pz)
            sub_bytes = bytes(sub_bytes)
        try:
            _gi = 28 + sub_bytes[3] * 4
            _EXPORT_CACHE['stats'][0] += struct.unpack_from('<H', sub_bytes, _gi)[0]
            _EXPORT_CACHE['stats'][1] += struct.unpack_from('<H', sub_bytes, _gi + 2)[0]
        except Exception:
            pass
        try:
            _nv, _nf = struct.unpack_from('<HH', sub_bytes, _gi)
            if _nv > 32767:
                _EXPORT_CACHE.setdefault('over', []).append((obj.name, _nv))
            _pp_ = _gi + 28 + _nv * 16 + _nf * 12
            _pc = struct.unpack_from('<i', sub_bytes, _pp_)[0]
            for _k in range(max(0, min(_pc, 4096))):
                _o = _pp_ + 4 + 24 * _k
                _nm = bytes(sub_bytes[_o + 4:_o + 24]).split(b'\0')[0]
                if _nm:
                    _EXPORT_CACHE.setdefault('pages', set()).add(_nm.decode('latin-1'))
        except Exception:
            pass

        if idx == 0:
            sub_bytes = bytearray(sub_bytes)
            _info = sub_bytes[:28]
            _geo_off = 28 + _info[3] * 4
            struct.pack_into('<i', sub_bytes, _geo_off + 4, len(objects_sorted) - 1)
            sub_bytes = bytes(sub_bytes)

        out += sub_bytes

        if idx == 0:
            out += layout_names_raw
            out += spare_bytes

    return bytes(out)


_CIDX_GEOM_CACHE = {'on': False, 'd': {}, 'area': {}}


def _lfs_mat_index_array(me):
    import numpy as np
    n = len(me.polygons)
    a = np.zeros(n, np.int32)
    if n:
        at = me.attributes.get('material_index')
        if (at is not None and at.domain == 'FACE' and at.data_type == 'INT' and len(at.data) == n):
            at.data.foreach_get('value', a)
        else:
            me.polygons.foreach_get('material_index', a)
    return a


def _compute_cidx_face_geometry(context):
    from collections import defaultdict
    import mathutils as _mu
    mat_cidx = {}
    for mat in bpy.data.materials:
        ci = mat.get('lfs_cidx')
        if ci is not None:
            try: mat_cidx[mat.name] = int(ci)
            except Exception: pass

    eps = 0.05
    buckets = defaultdict(list)
    for obj in bpy.data.objects:
        if obj.type != 'MESH' or 'lfs_subobj_index' not in obj.keys():
            continue
        mw = obj.matrix_world
        _ck = None
        if _CIDX_GEOM_CACHE['on']:
            try:
                import numpy as _np, hashlib as _hl
                _me = obj.data
                _mi = _lfs_mat_index_array(_me)
                _sl = tuple((s.material.name if s.material else None) for s in obj.material_slots)
                _ck = (obj.name, _me.name, len(_me.polygons), tuple(tuple(r) for r in mw), _sl,
                       tuple(mat_cidx.get(n_) for n_ in _sl), _hl.md5(_mi.tobytes()).digest())
            except Exception:
                _ck = None
            _hit = _CIDX_GEOM_CACHE['d'].get(_ck) if _ck is not None else None
            if _hit is not None:
                for _bk, _bl in _hit:
                    buckets[_bk].extend(_bl)
                continue
        _rows = {}
        mn = mw.to_3x3()
        for poly in obj.data.polygons:
            mi = poly.material_index
            nm = (obj.material_slots[mi].material.name
                  if mi < len(obj.material_slots) and obj.material_slots[mi].material
                  else None)
            ci = mat_cidx.get(nm)
            if ci is None:
                continue
            c = mw @ poly.center
            nrm = mn @ poly.normal
            if nrm.length > 0: nrm = nrm.normalized()
            side = 'L' if c.x < -eps else ('R' if c.x > eps else 'C')
            ar = poly.area
            buckets[(ci, side)].append((c, nrm, ar))
            if _ck is not None:
                _rows.setdefault((ci, side), []).append((c, nrm, ar))
        if _ck is not None:
            _CIDX_GEOM_CACHE['d'][_ck] = list(_rows.items())

    by_cidx_side = defaultdict(dict)
    for (ci, side), faces in buckets.items():
        by_cidx_side[ci][side] = sum(f[2] for f in faces)

    def _inplane_axes(n):
        n = _mu.Vector(n)
        if n.length == 0: n = _mu.Vector((0, 0, 1))
        n = n.normalized()
        up = _mu.Vector((0, 0, 1))
        if abs(n.dot(up)) > 0.95:
            up = _mu.Vector((0, 1, 0))
        u = n.cross(up).normalized()
        v = n.cross(u).normalized()
        return u, v

    out = {}
    for ci, sides in by_cidx_side.items():
        best_side = max(sides.items(), key=lambda kv: (kv[1],
                        {'R': 2, 'L': 1, 'C': 0}.get(kv[0], 0)))[0]
        faces = buckets[(ci, best_side)]
        if not faces:
            continue
        nv = _mu.Vector((0, 0, 0))
        for c, nrm, ar in faces:
            nv += nrm * ar
        if nv.length > 0: nv = nv.normalized()
        cen = _mu.Vector((0, 0, 0)); tot = 0.0
        for c, nrm, ar in faces:
            cen += c * ar; tot += ar
        if tot > 0: cen /= tot
        u, v = _inplane_axes(nv)
        us = [c.dot(u) for c, _, _ in faces]
        vs = [c.dot(v) for c, _, _ in faces]
        w = max(max(us) - min(us), 0.05)
        h = max(max(vs) - min(vs), 0.05)
        w *= 1.08; h *= 1.08
        out[ci] = (cen.x, cen.y, cen.z, w, h, (nv.x, nv.y, nv.z))
    return out


def _build_default_map_record(cidx, name, r=128, g=128, b=128, geom=None):
    buf = bytearray()
    nm = (name or f'col_{cidx}').encode('latin-1', 'replace')[:15]
    buf += nm + b'\x00' * (16 - len(nm))
    buf.append(r & 0xFF); buf.append(g & 0xFF); buf.append(b & 0xFF); buf.append(0)
    buf += struct.pack('<i', 0)
    rot_raw = 0x168
    if geom is not None and len(geom) >= 6 and geom[5] is not None:
        try:
            _h, _p = _uvp_hp_from_normal(geom[5])
            rot_raw = _uvp_pack_rot(_h, _p, 0.0)
        except Exception:
            rot_raw = 0x168
    buf += struct.pack('<I', rot_raw & 0xFFFFFFFF)
    if geom is not None:
        cx, cy, cz, gw, gh = geom[0], geom[1], geom[2], geom[3], geom[4]
        buf += struct.pack('<iii', int(round(cx * FP)),
                                    int(round(cy * FP)),
                                    int(round(cz * FP)))
        buf += struct.pack('<ii', int(round(gw * FP)), int(round(gh * FP)))
    else:
        buf += struct.pack('<iii', 0, 0, 0)
        buf += struct.pack('<ii', int(round(0.936 * FP)), int(round(0.936 * FP)))
    buf += struct.pack('<hh', 0, 0)
    return bytes(buf)


_SUBOBJ_TYPE_DEFAULTS = {
    0:  {'flip': 1, 'sub_state': 66, 'unk3': 19, 'lods': [(0, 120)], 'cn': 0, 'some_var': 2},
    1:  {'flip': 1, 'sub_state': 66, 'unk3': 5,  'lods': [(0, 120)],            'cn': 0, 'some_var': 2},
    2:  {'flip': 3, 'sub_state': 66, 'unk3': 9,  'lods': [(0, 120)],            'cn': 0, 'some_var': 2},
    3:  {'flip': 1, 'sub_state': 66, 'unk3': 3,  'lods': [(0, 30)],             'cn': 0, 'some_var': 2},
    10: {'flip': 2, 'sub_state': 66, 'unk3': 10, 'lods': [(0, 120)],            'cn': 0, 'some_var': 2},
}


def _tex_norm(s):
    return ''.join(c.lower() for c in s if c.isalnum())


_TEX_OVERRIDES = {
    'glass':        's_glass_ALP',
    'sits_leather': 'LeathA_ALP',
    'interior':     'LeathA_ALP',
    'leather':      'LeathA_ALP',
    'seat':         'LeathA_ALP',
    'seats':        'LeathA_ALP',
    'carpet':       'Carpet',
    'floor':        'Carpet',
    'scene_-_root': 'sketchfab_body',
    'scene - root': 'sketchfab_body',
    'treebillboard': 'treebillboard_ALP',
}


def _find_png_for_material(mat_name, png_dir):
    _ov_key = mat_name.lower()
    try:
        import bpy as _bpy0
        _m0 = _bpy0.data.materials.get(mat_name)
        if _m0 is not None:
            _pg = _m0.get('lfs_tex_page')
            if _pg is not None:
                return str(_pg) or None
            if not _m0.get('lfs_baked_from'):
                _src = _m0.get('lfs_split_from')
                if _src and str(_src) != mat_name and str(_src) in _bpy0.data.materials:
                    _r = _find_png_for_material(str(_src), png_dir)
                    if _r is not None:
                        return _r
    except Exception:
        pass
    try:
        import bpy as _bpy
        _sc_ov = _bpy.context.scene.get('lfs_tex_overrides')
        if _sc_ov:
            for _k in _sc_ov.keys():
                if _k.lower() == _ov_key:
                    _v = _sc_ov[_k]
                    return _v if _v else None
    except Exception:
        pass
    for _k, _v in _TEX_OVERRIDES.items():
        if _k.lower() == _ov_key:
            return _v
    try:
        import re as _re2
        _base = _re2.sub(r'_(p\d+|left|rght|frnt|back|top|bot|u\d+|b\d+)$', '', _ov_key)
        if len(_base) >= 6:
            _tables = []
            try:
                import bpy as _bpy3
                _sc3 = _bpy3.context.scene.get('lfs_tex_overrides')
                if _sc3:
                    _tables.append({str(k).lower(): _sc3[k] for k in _sc3.keys()})
            except Exception:
                pass
            _tables.append({k.lower(): v for k, v in _TEX_OVERRIDES.items()})
            for _tb in _tables:
                for _k, _v in _tb.items():
                    if _k.startswith(_base) or (len(_k) >= 6 and _base.startswith(_k)):
                        return _v if _v else None
    except Exception:
        pass
    _norm = ''.join(c for c in _ov_key if c.isalnum())
    for _g in _MESH_GRILLE_MATERIALS:
        if _g in _norm:
            return _HONEYCOMB_STEM
    return None


_PAINT_SKIN_MATERIALS = {'varnish', 'paint', 'm1', 'skin', 'body'}

_GLASS_MATERIALS = {'glass', 'windows', 'window', 'windscreen', 'windshield'}

_GLASS_NAME_RE = re.compile(
    r'(?:^|[^a-z])(glass|window|windows|windscreen|windshield|winshield|glas)'
    r'(?:[^a-z]|$)', re.I)
_LENS_NAME_RE = re.compile(
    r'(?:^|[^a-z])(taillight|taillights|tail_light|rearlight|rearlights|'
    r'rear_light|rearlamp|tail_lamp|taillamp|lightlens|light_lens|lens|lenses|'
    r'lamp|lamps|blinker|blinkers|indicator|indicators|foglight|fog_light|'
    r'headlight|head_light|headlamp|brakelight|brake_light|reverselight|'
    r'reverse_light|lightglass|light_glass)(?:[^a-z]|$)', re.I)


def _is_seethrough_material(mat_name, mat_db_name, mat_obj=None):
    if mat_obj is not None and 'lfs_alpha' in mat_obj.keys():
        return bool(mat_obj['lfs_alpha'])
    for nm in (mat_name or '', mat_db_name or ''):
        if not nm:
            continue
        if nm.lower() in _GLASS_MATERIALS:
            return True
        if _GLASS_NAME_RE.search(nm) or _LENS_NAME_RE.search(nm):
            return True
    return False

_MESH_GRILLE_MATERIALS = {'grill', 'grille', 'mesh', 'honeycomb', 'meshgrill',
                          'grillmesh', 'frontgrill', 'lowergrill', 'uppergrill'}
_HONEYCOMB_STEM = 'honeycombgrill_ALP'


_GLASS_ALPHA_MAX = 0.6
_GLASS_TRANSMISSION_MIN = 0.4


def _mat_shader_info(mat):
    r = g = b = 204
    alpha = 1.0
    transmission = 0.0
    try:
        if mat and mat.use_nodes and mat.node_tree:
            bsdf = None
            for n in mat.node_tree.nodes:
                if n.type == 'BSDF_PRINCIPLED':
                    bsdf = n
                    break
            if bsdf is not None:
                col = bsdf.inputs.get('Base Color')
                if col is not None:
                    c = col.default_value
                    r, g, b = (_srgb_from_linear(c[0]), _srgb_from_linear(c[1]),
                               _srgb_from_linear(c[2]))
                a = bsdf.inputs.get('Alpha')
                if a is not None:
                    alpha = float(a.default_value)
                t = bsdf.inputs.get('Transmission Weight') or bsdf.inputs.get('Transmission')
                if t is not None:
                    transmission = float(t.default_value)
                return (r, g, b), alpha, transmission
        if mat is not None:
            c = mat.diffuse_color
            r, g, b = int(c[0]*255), int(c[1]*255), int(c[2]*255)
            alpha = float(c[3]) if len(c) > 3 else 1.0
    except Exception:
        pass
    return (r, g, b), alpha, transmission


def _srgb_from_linear(c):
    if c <= 0.0031308:
        s = 12.92 * c
    else:
        s = 1.055 * (c ** (1.0 / 2.4)) - 0.055
    return max(0, min(255, int(round(s * 255))))


_MAT_RGB_IMG_CACHE = {}


def _lfs_socket_rgb(sock, stack=(), depth=0):
    try:
        if sock is None or depth > 12:
            return None
        if not sock.is_linked:
            v = sock.default_value
            try:
                return (float(v[0]), float(v[1]), float(v[2]))
            except TypeError:
                return (float(v), float(v), float(v))
        lk = sock.links[0]
        n = lk.from_node
        if n.type == 'REROUTE':
            return _lfs_socket_rgb(n.inputs[0], stack, depth + 1)
        if n.type == 'RGB':
            v = n.outputs[0].default_value
            return (float(v[0]), float(v[1]), float(v[2]))
        if n.type == 'GROUP_INPUT':
            if not stack:
                return None
            gnode = stack[-1]
            gs = next((s for s in gnode.inputs if s.identifier == lk.from_socket.identifier), None)
            if gs is None:
                gs = next((s for s in gnode.inputs if s.name == lk.from_socket.name), None)
            return _lfs_socket_rgb(gs, stack[:-1], depth + 1)
        if n.type == 'GROUP' and n.node_tree is not None:
            out = next((x for x in n.node_tree.nodes if x.type == 'GROUP_OUTPUT' and x.is_active_output), None) \
                or next((x for x in n.node_tree.nodes if x.type == 'GROUP_OUTPUT'), None)
            if out is None:
                return None
            si = next((s for s in out.inputs if s.identifier == lk.from_socket.identifier), None)
            if si is None:
                si = next((s for s in out.inputs if s.name == lk.from_socket.name), None)
            return _lfs_socket_rgb(si, tuple(stack) + (n,), depth + 1)
        if n.type in ('MIX_RGB', 'MIX'):
            ins = [s for s in n.inputs if s.enabled]
            fac = next((s for s in ins if s.name in ('Fac', 'Factor')), None)
            cols = [s for s in ins if s.type == 'RGBA']
            if len(cols) >= 2:
                a = _lfs_socket_rgb(cols[0], stack, depth + 1)
                b = _lfs_socket_rgb(cols[1], stack, depth + 1)
                f = 0.5
                if fac is not None and not fac.is_linked:
                    try:
                        f = float(fac.default_value if not hasattr(fac.default_value, '__len__') else fac.default_value[0])
                    except Exception:
                        f = 0.5
                if a is None:
                    return b
                if b is None:
                    return a
                f = max(0.0, min(1.0, f))
                return tuple(a[i] * (1.0 - f) + b[i] * f for i in range(3))
            return None
        if n.type == 'VALTORGB':
            els = list(n.color_ramp.elements)
            if els:
                return tuple(sum(e.color[i] for e in els) / len(els) for i in range(3))
            return None
        if n.type in ('BSDF_PRINCIPLED', 'BSDF_DIFFUSE'):
            return _lfs_socket_rgb(n.inputs.get('Base Color') or n.inputs.get('Color'), stack, depth + 1)
        if n.type == 'MIX_SHADER':
            ss = [s for s in n.inputs if s.type == 'SHADER']
            for s in ss[::-1]:
                v = _lfs_socket_rgb(s, stack, depth + 1)
                if v is not None:
                    return v
            return None
        return None
    except Exception:
        return None


def _lfs_mat_node_rgb(mat):
    try:
        if mat is None or not mat.use_nodes or not mat.node_tree:
            return None
        if _lfs_base_color_image(mat) is not None:
            return None
        nt = mat.node_tree
        out = next((x for x in nt.nodes if x.type == 'OUTPUT_MATERIAL' and x.is_active_output), None) \
            or next((x for x in nt.nodes if x.type == 'OUTPUT_MATERIAL'), None)
        if out is None or not out.inputs['Surface'].is_linked:
            return None
        v = _lfs_socket_rgb(out.inputs['Surface'])
        if v is None:
            return None
        return (_srgb_from_linear(v[0]), _srgb_from_linear(v[1]), _srgb_from_linear(v[2]))
    except Exception:
        return None


def _mat_rgb(mat):
    if mat is None:
        return (128, 128, 128)
    try:
        if mat.use_nodes and mat.node_tree:
            for n in mat.node_tree.nodes:
                if n.type == 'BSDF_PRINCIPLED':
                    col = n.inputs.get('Base Color')
                    if col is not None:
                        if col.links:
                            _img = _lfs_base_color_image(mat)
                            if _img is not None:
                                _key = (_img.name, tuple(_img.size))
                                if _key not in _MAT_RGB_IMG_CACHE:
                                    _MAT_RGB_IMG_CACHE[_key] = _lfs_image_avg_rgb(_img)
                                _avg = _MAT_RGB_IMG_CACHE[_key]
                                if _avg:
                                    return tuple(int(round(v)) for v in _avg)
                        if col.links:
                            _nv = _lfs_socket_rgb(col)
                            if _nv is not None:
                                return (_srgb_from_linear(_nv[0]), _srgb_from_linear(_nv[1]),
                                        _srgb_from_linear(_nv[2]))
                        c = col.default_value
                        return (_srgb_from_linear(c[0]),
                                _srgb_from_linear(c[1]),
                                _srgb_from_linear(c[2]))
                    break
            else:
                _nv = _lfs_mat_node_rgb(mat)
                if _nv is not None:
                    return _nv
        c = mat.diffuse_color
        return (int(round(c[0]*255)), int(round(c[1]*255)), int(round(c[2]*255)))
    except Exception:
        return (128, 128, 128)


_LFS_SEEN_CACHE = {}


def _lfs_seen_area_by_material(meshes, n=128):
    import time
    from mathutils import Vector
    from mathutils.bvhtree import BVHTree
    meshes = [o for o in meshes if o.type == 'MESH' and not o.get('lfs_preview_only')
              and not o.get('lfs_mirror_ghost')]
    key = tuple(sorted((o.name, len(o.data.vertices), len(o.data.polygons),
                        tuple(round(x, 4) for x in o.matrix_world.translation)) for o in meshes))
    hit = _LFS_SEEN_CACHE.get('k')
    if hit is not None and hit[0] == key and time.time() - hit[1] < 60.0:
        return hit[2]
    import numpy as _np
    verts = []; polys = []; pm = []
    _sc = _CIDX_GEOM_CACHE.get('seen') if _CIDX_GEOM_CACHE.get('on') else None
    for o in meshes:
        me = o.data; mw = o.matrix_world; sl = o.material_slots
        b = len(verts)
        _sk = None
        if _sc is not None:
            _sk = (o.name, me.name, len(me.vertices), len(me.polygons), tuple(tuple(r) for r in mw),
                   tuple((s.material.name if s.material else '') for s in sl),
                   __import__('hashlib').md5(_lfs_mat_index_array(me).tobytes()).digest())
        _e = _sc.get(_sk) if _sk is not None else None
        if _e is None:
            _vl = [mw @ v.co for v in me.vertices]
            _np_ = len(me.polygons)
            _lt = _np.zeros(_np_, _np.int32)
            _lv = _np.zeros(len(me.loops), _np.int32)
            _ls = _np.zeros(_np_, _np.int32)
            if _np_:
                me.polygons.foreach_get('loop_total', _lt)
                me.polygons.foreach_get('loop_start', _ls)
                me.loops.foreach_get('vertex_index', _lv)
            _mi = _lfs_mat_index_array(me)
            _ok = _lt >= 3
            _names = [((sl[k].material.name if sl[k].material else '') if k < len(sl) else '')
                      for k in range(max(len(sl), int(_mi.max()) + 1 if _np_ else 0))]
            _pmo = [_names[k] if 0 <= k < len(_names) else '' for k in _mi[_ok].tolist()]
            if _np_ and bool((_lt[_ok] == 3).all()):
                _ix = (_ls[_ok][:, None] + _np.arange(3)[None, :])
                _local = ('tri', _lv[_ix])
            else:
                _local = ('poly', [_lv[s_:s_ + n_] for s_, n_ in zip(_ls[_ok].tolist(), _lt[_ok].tolist())])
            _e = (_vl, _local, _pmo)
            if _sk is not None:
                _sc[_sk] = _e
        _vl, _local, _pmo = _e
        verts.extend(_vl)
        if _local[0] == 'tri':
            polys.extend((_local[1] + b).tolist())
        else:
            polys.extend((a_ + b).tolist() for a_ in _local[1])
        pm.extend(_pmo)
    out = {}
    if polys:
        bvh = BVHTree.FromPolygons(verts, polys, all_triangles=False)
        lo = [min(v[i] for v in verts) for i in range(3)]
        hi = [max(v[i] for v in verts) for i in range(3)]
        for ax, sg in ((2, 1), (0, 1), (0, -1), (1, 1), (1, -1)):
            a1, a2 = [i for i in range(3) if i != ax]
            s1 = (hi[a1] - lo[a1]) / n; s2 = (hi[a2] - lo[a2]) / n
            if s1 <= 0 or s2 <= 0:
                continue
            d = Vector((0.0, 0.0, 0.0)); d[ax] = -float(sg)
            org = Vector((0.0, 0.0, 0.0)); org[ax] = (hi[ax] + 1.0) if sg > 0 else (lo[ax] - 1.0)
            cell = s1 * s2
            for i in range(n):
                org[a1] = lo[a1] + (i + 0.5) * s1
                for j in range(n):
                    org[a2] = lo[a2] + (j + 0.5) * s2
                    h = bvh.ray_cast(org, d)
                    if h[0] is not None:
                        k = pm[h[2]]
                        out[k] = out.get(k, 0.0) + cell
    _LFS_SEEN_CACHE['k'] = (key, time.time(), out)
    return out


def _auto_classify_materials(mat_infos, glass_mode='AUTO', seen_fn=None):
    paint = set()
    glass = set()

    def _is_near_black(rgb):
        return max(rgb) <= 25

    def _chroma(rgb):
        return max(rgb) - min(rgb)

    total_area = sum(mi.get('area', 0.0) for mi in mat_infos) or 1.0
    if glass_mode != 'NONE':
        for mi in mat_infos:
            nm = mi['name'].lower()
            if (nm in _GLASS_MATERIALS
                    or mi.get('alpha', 1.0) < _GLASS_ALPHA_MAX
                    or mi.get('transmission', 0.0) >= _GLASS_TRANSMISSION_MIN):
                glass.add(nm)
        if glass_mode == 'AUTO':
            _NOT_GLASS_HINTS = ('black', 'under', 'bottom', 'shadow', 'dark', 'chassis', 'base',
                                'plastic', 'rubber', 'tyre', 'tire', 'wheel',
                                'trim', 'carbon', 'leather', 'seat', 'dash',
                                'metal', 'chrome', 'brake', 'grille', 'grill',
                                'floor', 'carpet', 'vinyl', 'paint',
                                'body', 'panel', 'interior')
            def _name_blocks_glass(nm):
                return any(h in nm for h in _NOT_GLASS_HINTS)
            black_big = [mi for mi in mat_infos
                         if _is_near_black(mi.get('rgb', (0, 0, 0)))
                         and mi.get('area', 0.0) / total_area >= 0.08
                         and not _name_blocks_glass(mi['name'].lower())
                         and (mi.get('zrel') is None or mi['zrel'] >= 0.45)
                         and (mi.get('nz') is None or mi['nz'] > -0.3)]
            if black_big:
                bb = max(black_big, key=lambda mi: mi.get('area', 0.0))
                glass.add(bb['name'].lower())

    for mi in mat_infos:
        if mi['name'].lower() in _PAINT_SKIN_MATERIALS:
            paint.add(mi['name'].lower())
    if not paint:
        cand = [mi for mi in mat_infos
                if mi['name'].lower() not in glass
                and not _is_near_black(mi.get('rgb', (0, 0, 0)))]
        if cand:
            def _paint_hint(nm):
                return ('paint' in nm or 'lakier' in nm or nm.endswith('lak')
                        or '_lak' in nm or 'lak_' in nm or 'karos' in nm
                        or 'carross' in nm or 'bodycol' in nm or 'body_col' in nm
                        or 'cabin' in nm or 'shell' in nm or 'exterior' in nm
                        or 'carbody' in nm or 'bodywork' in nm)

            def _never_paint(nm):
                return any(h in nm for h in ('chassis', 'underbody', 'undercarr', 'engine',
                                             'suspens', 'interior', 'wheel', 'tyre', 'tire',
                                             'rim', 'glass', 'window', 'seat', 'dash', 'trim',
                                             'light', 'lamp', 'exhaust',
                                             'inside', 'inner', 'innen', 'cockpit', 'console',
                                             'floor', 'carpet', 'headlin', 'steer', 'pedal',
                                             'gauge', 'needle', 'logo', 'badge', 'emblem',
                                             'licen', 'numberplate', 'number plate', 'number_plate'))
            _cand2 = [mi for mi in cand if not _never_paint(mi['name'].lower())]
            if _cand2:
                cand = _cand2

            def _score(mi):
                a = mi.get('area_seen', mi.get('area', 0.0))
                s = a * (1.3 if _chroma(mi.get('rgb', (0, 0, 0))) >= 30 else 1.0)
                if mi.get('textured'):
                    s *= 0.5
                return s
            hinted = [mi for mi in cand if _paint_hint(mi['name'].lower())]
            if not hinted:
                def _paint_hint2(nm):
                    return (('body' in nm and 'underbody' not in nm)
                            or 'main colo' in nm or 'maincolo' in nm or 'main_colo' in nm
                            or 'carcol' in nm or 'car_col' in nm or 'car col' in nm
                            or 'kaporta' in nm or 'karoser' in nm)
                hinted = [mi for mi in cand if _paint_hint2(mi['name'].lower())]
            _pool = hinted or cand
            if len(_pool) > 1 and seen_fn is not None:
                try:
                    _seen = seen_fn() or {}
                except Exception as _se:
                    print(f"  [auto-setup] the outside check was skipped: {_se!r}")
                    _seen = {}
                if any(_seen.get(mi.get('bname', mi['name']), 0.0) > 0 for mi in _pool):
                    for mi in _pool:
                        mi['area_seen'] = _seen.get(mi.get('bname', mi['name']), 0.0)
            best = max(_pool, key=_score)
            if best.get('area', 0.0) > 0:
                paint.add(best['name'].lower())
    return paint, glass


def _lfs_area_by_material(meshes, area_by=None):
    import numpy as np
    area_by = {} if area_by is None else area_by
    for o in meshes:
        me = o.data
        n = len(me.polygons)
        if n == 0:
            continue
        slots = o.material_slots
        names = []
        slot_name = np.full(max(1, len(slots)) + 1, -1, np.int64)
        for i, sl in enumerate(slots):
            if sl.material:
                nm = sl.material.name
                if nm not in names:
                    names.append(nm)
                slot_name[i] = names.index(nm)
        mi = _lfs_mat_index_array(me)
        _ak = (o.name, me.name, n) if _CIDX_GEOM_CACHE['on'] else None
        ar = _CIDX_GEOM_CACHE['area'].get(_ak) if _ak is not None else None
        if ar is None:
            ar = np.empty(n, np.float32)
            me.polygons.foreach_get('area', ar)
            if _ak is not None:
                _CIDX_GEOM_CACHE['area'][_ak] = ar
        mi = np.where((mi >= 0) & (mi < len(slots)), mi, len(slot_name) - 1)
        nid = slot_name[mi]
        ok = nid >= 0
        if not ok.any() or not names:
            continue
        ar64 = ar.astype(np.float64)
        for k, nm in enumerate(names):
            sel = nid == k
            if sel.any():
                seq = np.concatenate(([area_by.get(nm, 0.0)], ar64[sel]))
                area_by[nm] = float(np.add.accumulate(seq)[-1])
    return area_by


def _auto_detect_from_scene(mat_names, glass_mode='AUTO'):
    import bpy, re as _re
    area_by = {}
    meshes = [o for o in bpy.data.objects
              if o.type == 'MESH' and 'lfs_subobj_index' in o.keys()]
    if not meshes:
        meshes = [o for o in bpy.data.objects if o.type == 'MESH'
                  and not o.get('lfs_preview_only')]
    _lfs_area_by_material(meshes, area_by)

    def _resolve(name):
        if name in bpy.data.materials:
            return bpy.data.materials[name]
        for mat in bpy.data.materials:
            if _re.sub(r'[._]\d+$', '', mat.name) == name:
                return mat
        return None

    infos = []
    for nm in mat_names:
        mat = _resolve(nm)
        rgb, alpha, transmission = _mat_shader_info(mat) if mat else ((204, 204, 204), 1.0, 0.0)
        area = 0.0
        if mat is not None:
            area = area_by.get(mat.name, 0.0)
        if area == 0.0:
            area = area_by.get(nm, 0.0)
        infos.append({'name': nm, 'bname': mat.name if mat is not None else nm,
                      'rgb': rgb, 'alpha': alpha,
                      'transmission': transmission, 'area': area,
                      'textured': bool(mat is not None and _lfs_base_color_image(mat) is not None)})
    paint, glass = _auto_classify_materials(infos, glass_mode=glass_mode,
                                           seen_fn=lambda: _lfs_seen_area_by_material(meshes))
    for nm in mat_names:
        mat = _resolve(nm)
        if mat is None:
            continue
        low = nm.lower()
        g = mat.get('lfs_glass')
        if g is not None:
            (glass.add if bool(g) else glass.discard)(low)
        pnt = mat.get('lfs_paint')
        if pnt is not None:
            (paint.add if bool(pnt) else paint.discard)(low)
    return paint, glass


_LFS_PNG_CACHE = {}
_LFS_TEX_ENUM_ITEMS = []
_LFS_SOFT_HINTS = ('leath', 'seat', 'sits', 'alcant', 'suede', 'cloth', 'fabric')
_LFS_STOCK_SOFT_PAGE = 'LeathA_ALP'
_LFS_INT_HINTS = ('interior', 'int_', 'dash', 'seat', 'cockpit', 'console', 'cabin')


def _lfs_png_stems():
    import os, time
    d = _resolve_png_dir()
    now = time.time()
    c = _LFS_PNG_CACHE
    if c.get('dir') == d and now - c.get('t', 0.0) < 4.0:
        return c['stems']
    stems = []
    try:
        for fn in os.listdir(d):
            if fn.lower().endswith('.png') and len(fn) - 4 <= 19:
                stems.append(fn[:-4])
    except Exception:
        pass
    stems.sort(key=str.lower)
    c.update(dir=d, t=now, stems=stems)
    return stems


def _lfs_base_color_image(mat):
    try:
        if not (mat and mat.use_nodes and mat.node_tree):
            return None
        for n in mat.node_tree.nodes:
            if n.type == 'BSDF_PRINCIPLED':
                col = n.inputs.get('Base Color')
                if col and col.links:
                    s = col.links[0].from_node
                    if s.type == 'TEX_IMAGE' and s.image:
                        return s.image
                break
    except Exception:
        pass
    return None


def _lfs_image_avg_rgb(img):
    try:
        import numpy as np
        if img is None:
            return None
        if min(img.size) == 0:
            try:
                img.reload()
            except Exception:
                pass
        if min(img.size) == 0:
            return None
        ch = int(img.channels)
        arr = np.empty(img.size[0] * img.size[1] * ch, dtype=np.float32)
        img.pixels.foreach_get(arr)
        arr = arr.reshape(-1, ch)
        if arr.shape[0] > 262144:
            arr = arr[::max(1, arr.shape[0] // 262144)]
        rgb = arr[:, :3]
        if ch >= 4:
            a = arr[:, 3:4]
            w = float(a.sum())
            mean = (rgb * a).sum(axis=0) / w if w > 0 else rgb.mean(axis=0)
        else:
            mean = rgb.mean(axis=0)
        if not getattr(img, 'is_float', False):
            return tuple(int(round(max(0.0, min(1.0, float(v))) * 255)) for v in mean)
        return tuple(_srgb_from_linear(float(v)) for v in mean)
    except Exception:
        return None


def _lfs_is_soft_name(name):
    n = ''.join(c for c in str(name).lower() if c.isalnum())
    return any(h in n for h in _LFS_SOFT_HINTS)


def _lfs_plain_rgb(mat):
    rgb = mat.get('lfs_tex_tint_rgb')
    if rgb is not None:
        try:
            return tuple(float(v) for v in list(rgb)[:3])
        except Exception:
            pass
    try:
        for n in mat.node_tree.nodes:
            if n.type == 'BSDF_PRINCIPLED':
                c = n.inputs['Base Color'].default_value

                def _s(v):
                    v = max(0.0, min(1.0, float(v)))
                    return 255.0 * (12.92 * v if v <= 0.0031308 else 1.055 * v ** (1 / 2.4) - 0.055)
                return (_s(c[0]), _s(c[1]), _s(c[2]))
    except Exception:
        pass
    return None


def _lfs_set_tex_page(mat, page, tint=True, tint_rgb=None, auto=False):
    if page is None:
        for k in ('lfs_tex_page', 'lfs_tex_tint', 'lfs_tex_tint_rgb', 'lfs_tex_auto'):
            if k in mat.keys():
                del mat[k]
        return
    mat['lfs_tex_page'] = str(page)
    mat['lfs_tex_tint'] = bool(tint)
    if tint_rgb is not None:
        mat['lfs_tex_tint_rgb'] = [int(v) for v in tint_rgb[:3]]
    elif 'lfs_tex_tint_rgb' in mat.keys():
        del mat['lfs_tex_tint_rgb']
    if auto:
        mat['lfs_tex_auto'] = True
    elif 'lfs_tex_auto' in mat.keys():
        del mat['lfs_tex_auto']


def _lfs_soft_fits(rgb, png_dir):
    try:
        if rgb is None:
            return True
        L = _lfs_page_avg_lin(_LFS_STOCK_SOFT_PAGE, png_dir) if png_dir else None
        if not L:
            L = 0.17
        k = 1.0 / max(0.12, L ** 0.5)
        return max(float(v) for v in list(rgb)[:3]) * k <= 255.0 * 1.15
    except Exception:
        return True


def _lfs_apply_tex_page_group(root_name, page, tint=True, auto=False):
    n = 0
    root = bpy.data.materials.get(root_name)
    tint_rgb = None
    if page and tint and root is not None:
        img = _lfs_base_color_image(root)
        if img is not None:
            tint_rgb = _lfs_image_avg_rgb(img)
    for m in bpy.data.materials:
        if m.get('lfs_baked_from'):
            continue
        if m.name == root_name or str(m.get('lfs_split_from', '')) == root_name:
            _lfs_set_tex_page(m, page, tint, tint_rgb, auto)
            n += 1
    return n


def _lfs_tex_tint_for(mat):
    try:
        m = mat
        for _ in range(3):
            if m is None:
                return None
            if m.get('lfs_tex_tint'):
                tr = m.get('lfs_tex_tint_rgb')
                if tr is not None and len(tr) >= 3:
                    t = (int(tr[0]), int(tr[1]), int(tr[2]))
                else:
                    t = tuple(_mat_rgb(m))
                t = tuple(max(0, min(255, v)) for v in t)
                return (8, 8, 8) if t == (0, 0, 0) else t
            if 'lfs_tex_page' in m.keys():
                return None
            src = m.get('lfs_split_from') or m.get('lfs_baked_from')
            m = bpy.data.materials.get(str(src)) if src else None
    except Exception:
        pass
    return None


_LFS_AUTO_BASE_KEYS = ('lfs_tex_page', 'lfs_tex_tint', 'lfs_tex_tint_rgb', 'lfs_tex_auto',
                       'lfs_fit_base', 'lfs_tile_size', 'lfs_auto_map')


def _lfs_record_cidx(objs):
    for o in objs:
        for s in o.material_slots:
            m = s.material
            if (m is None or m.get('lfs_auto_made') or m.get('lfs_baked_from') or m.get('lfs_fit_left')
                    or m.get('lfs_split_from') or m.get('lfs_cidx') is None):
                continue
            try:
                m['lfs_cidx_orig'] = int(m['lfs_cidx'])
            except (TypeError, ValueError):
                pass


def _lfs_restore_cidx():
    want, claimed = {}, set()
    for m in sorted(bpy.data.materials, key=lambda x: x.name):
        if m.get('lfs_cidx_orig') is None or m.get('lfs_auto_made'):
            continue
        try:
            c = int(m['lfs_cidx_orig'])
        except (TypeError, ValueError):
            continue
        if c in claimed:
            continue
        want[m.name] = c
        claimed.add(c)
    if not want:
        return 0
    n = 0
    mx = max(claimed)
    for m in bpy.data.materials:
        try:
            mx = max(mx, int(m.get('lfs_cidx', 0) or 0))
        except (TypeError, ValueError):
            pass
    for m in sorted(bpy.data.materials, key=lambda x: x.name):
        if m.name in want:
            if m.get('lfs_cidx') != want[m.name]:
                m['lfs_cidx'] = want[m.name]
                n += 1
            continue
        try:
            c = int(m.get('lfs_cidx')) if m.get('lfs_cidx') is not None else None
        except (TypeError, ValueError):
            c = None
        if c is not None and c in claimed:
            mx += 1
            m['lfs_cidx'] = mx
            n += 1
    return n


def _lfs_undo_auto(objs):
    import bpy
    n_faces = 0
    auto = [m for m in bpy.data.materials
            if m.get('lfs_auto_made') or m.get('lfs_baked_from') or m.get('lfs_fit_left')
            or (m.get('lfs_split_from') and m.get('lfs_tex_auto'))]
    auto_names = {m.name for m in auto}
    for o in objs:
        me = o.data
        back = {}
        for si, sl in enumerate(o.material_slots):
            m = sl.material
            if m is None or m.name not in auto_names:
                continue
            base = str(m.get('lfs_baked_from') or m.get('lfs_fit_left') or m.get('lfs_split_from') or '')
            _hops = 0
            while base in auto_names and _hops < 6:
                bm_ = bpy.data.materials[base]
                nb = str(bm_.get('lfs_baked_from') or bm_.get('lfs_fit_left') or bm_.get('lfs_split_from') or '')
                if not nb:
                    break
                base = nb; _hops += 1
            if not base or base not in bpy.data.materials or base in auto_names:
                continue
            tgt = next((k for k, s2 in enumerate(o.material_slots)
                        if s2.material and s2.material.name == base), None)
            if tgt is None:
                me.materials.append(bpy.data.materials[base]); tgt = len(me.materials) - 1
            back[si] = tgt
        if back:
            for p in me.polygons:
                if p.material_index in back:
                    p.material_index = back[p.material_index]; n_faces += 1
    n_rm = 0
    for m in auto:
        try:
            bpy.data.materials.remove(m); n_rm += 1
        except Exception:
            pass
    for m in bpy.data.materials:
        if m.get('lfs_tex_auto') or m.get('lfs_fit_base') or m.get('lfs_auto_map') or m.get('lfs_tile_size'):
            if m.get('lfs_auto_map'):
                for k in ('lfs_map_rot', 'lfs_map_pos', 'lfs_map_wh', 'lfs_cutout_rect'):
                    if k in m.keys():
                        del m[k]
            if m.get('lfs_fit_base'):
                for k in ('lfs_map_rot', 'lfs_map_pos', 'lfs_map_wh', 'lfs_cutout_rect'):
                    if k in m.keys():
                        del m[k]
            if m.get('lfs_tex_auto'):
                for k in ('lfs_tex_page', 'lfs_tex_tint', 'lfs_tex_tint_rgb', 'lfs_tex_auto'):
                    if k in m.keys():
                        del m[k]
            for k in ('lfs_fit_base', 'lfs_tile_size', 'lfs_auto_map'):
                if k in m.keys():
                    del m[k]
    for o in objs:
        me = o.data
        src_uv = o.get('lfs_bake_src_uv')
        if src_uv and src_uv in me.uv_layers:
            me.uv_layers[src_uv].active = True
        _lb = me.uv_layers.get('LFS_BAKE')
        if _lb is not None and len(me.uv_layers) > 1:
            try:
                me.uv_layers.remove(_lb)
            except Exception:
                pass
    return n_rm, n_faces


class LFS_OT_ResetTextures(Operator):
    """Undo Bake Textures for LFS: the faces get the model's own materials
    back and the materials the bake made are removed. Your choices in the LFS Texture per
    Material panel are kept"""
    bl_idname = "lfs.reset_textures"
    bl_label = "Undo Bake"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        objs = [o for o in context.scene.objects if o.type == 'MESH' and 'lfs_subobj_index' in o.keys()]
        if not objs:
            self.report({'ERROR'}, "No marked sub-objects.")
            return {'CANCELLED'}
        n_rm, n_f = _lfs_undo_auto(objs)
        try:
            _lfs_restore_cidx()
        except Exception as _ce:
            print(f"  [undo bake] map numbers: {_ce!r}")
        try:
            bpy.ops.lfs.purge_unused_maps(also_unused_zero_face_mats=True)
        except Exception:
            pass
        try:
            _lfs_enforce_m1()
        except Exception:
            pass
        try:
            _need = set()
            for o in objs:
                if _lfs_is_imported(o):
                    continue
                for i in {p.material_index for p in o.data.polygons}:
                    _m6 = o.material_slots[i].material if i < len(o.material_slots) else None
                    if _m6 is not None and _m6.get('lfs_cidx') is None:
                        _need.add(_m6.name)
            if _need:
                _lfs_assign_cidx(sorted(_need))
        except Exception as _ce:
            print(f"  [undo bake] map numbers: {_ce!r}")
        _tag_redraw(context)
        self.report({'INFO'}, f"Reset: {n_rm} generated material(s) removed, {n_f} face(s) back on their originals."
                    + (" The LFS look (Material Preview) catches up in a few seconds."
                       if context.scene.get('lfs_look_attached') else ''))
        return {'FINISHED'}


def _lfs_uv_span(objs, mat):
    import numpy as np
    lo = np.array([9e9, 9e9]); hi = np.array([-9e9, -9e9])
    for o in objs:
        me = o.data
        si = [i for i, sl in enumerate(o.material_slots) if sl.material == mat]
        if not si or not me.uv_layers:
            continue
        uvn = o.get('lfs_bake_src_uv')
        if not uvn or uvn not in me.uv_layers:
            cands = [l for l in me.uv_layers if l.name != 'LFS_BAKE']
            if not cands:
                continue
            uvn = next((l for l in cands if l.active_render), cands[0]).name
        uvd = me.uv_layers[uvn].data
        sel = set(si)
        for p in me.polygons:
            if p.material_index not in sel:
                continue
            for li in p.loop_indices:
                uv = uvd[li].uv
                lo = np.minimum(lo, (uv[0], uv[1])); hi = np.maximum(hi, (uv[0], uv[1]))
    if hi[0] < lo[0]:
        return 0.0
    return float(max(hi[0] - lo[0], hi[1] - lo[1]))


_LFS_IMG_EXTS = ('.png', '.jpg', '.jpeg', '.tga', '.bmp', '.tif', '.tiff', '.dds', '.webp', '.exr', '.hdr')


def _lfs_face_detail(me, uv_name, faces, src):
    import numpy as np
    n = len(faces)
    if n == 0:
        return np.zeros(0), np.zeros((0, 3))
    uv = np.empty(len(me.loops) * 2, np.float32)
    me.uv_layers[uv_name].data.foreach_get('uv', uv)
    uv = uv.reshape(-1, 2)
    ls = np.empty(len(me.polygons), np.int32); me.polygons.foreach_get('loop_start', ls)
    lt = np.empty(len(me.polygons), np.int32); me.polygons.foreach_get('loop_total', lt)
    H, W = src.shape[0], src.shape[1]
    rgb = src[..., :3]
    kk = 16
    B = np.array([(1.0 - a / kk - b / kk, a / kk, b / kk) for a in range(kk + 1) for b in range(kk + 1 - a)])
    std = np.zeros(n); mu = np.zeros((n, 3))
    for k, fi in enumerate(faces):
        q = uv[ls[fi]:ls[fi] + lt[fi]].astype(np.float64)
        if len(q) < 3:
            continue
        c = q.mean(axis=0)
        q = c + 0.92 * (q - c)
        px = q[:, 0] * W - 0.5; py = q[:, 1] * H - 0.5
        x0 = int(np.floor(px.min())); x1 = int(np.ceil(px.max()))
        y0 = int(np.floor(py.min())); y1 = int(np.ceil(py.max()))
        vals = None
        if (x1 - x0 + 1) * (y1 - y0 + 1) <= 262144:
            gx, gy = np.meshgrid(np.arange(x0, x1 + 1, dtype=np.float64), np.arange(y0, y1 + 1, dtype=np.float64))
            inside = np.zeros(gx.shape, bool)
            for j in range(1, len(q) - 1):
                ax, ay = px[0], py[0]; bx, by = px[j], py[j]; cx, cy = px[j + 1], py[j + 1]
                det = (bx - ax) * (cy - ay) - (cx - ax) * (by - ay)
                if abs(det) < 1e-12:
                    continue
                l1 = ((gx - ax) * (cy - ay) - (cx - ax) * (gy - ay)) / det
                l2 = ((bx - ax) * (gy - ay) - (gx - ax) * (by - ay)) / det
                inside |= (l1 >= 0) & (l2 >= 0) & (l1 + l2 <= 1)
            if inside.any():
                vals = rgb[gy[inside].astype(np.int64) % H, gx[inside].astype(np.int64) % W]
        if vals is None:
            pts = np.concatenate([B @ np.stack([q[0], q[j], q[j + 1]]) for j in range(1, len(q) - 1)])
            vals = _bake_sample(src, pts[:, 0], pts[:, 1])[:, :3]
        mu[k] = vals.mean(axis=0) * 255.0
        std[k] = float(vals.std(axis=0).max()) * 255.0
    return std, mu


def _lfs_colour_outliers(mu, w, K=4):
    import numpy as np
    n = len(mu)
    if n < 8:
        return np.zeros(n, bool)
    K = min(K, n)
    w = np.asarray(w, np.float64)
    cent = [mu[int(np.argmax(w))]]
    for _k in range(1, K):
        d = np.min([((mu - c) ** 2).sum(axis=1) for c in cent], axis=0)
        cent.append(mu[int(np.argmax(d))])
    cent = np.array(cent, np.float64)
    lab = np.zeros(n, int)
    for _it in range(15):
        d = ((mu[:, None, :] - cent[None, :, :]) ** 2).sum(axis=2)
        lab = d.argmin(axis=1)
        for k in range(K):
            s = lab == k
            if s.any():
                cent[k] = (mu[s] * w[s, None]).sum(axis=0) / w[s].sum()
    dist = np.sqrt(((mu - cent[lab]) ** 2).mean(axis=1))
    out = dist > _LFS_DETAIL_DEV
    share = np.array([w[lab == k].sum() for k in range(K)]) / max(w.sum(), 1e-12)
    big = int(np.argmax(share))
    for k in range(K):
        if 0 < share[k] < 0.03 and np.abs(cent[k] - cent[big]).max() > 40:
            out |= lab == k
    return out


def _lfs_grow_detail(me, faces, sel, std, rings=3):
    idx = {fi: k for k, fi in enumerate(faces)}
    ek = {}
    for k, fi in enumerate(faces):
        for e in me.polygons[fi].edge_keys:
            ek.setdefault(e, []).append(k)
    sel = list(sel)
    front = [k for k, s in enumerate(sel) if s]
    for _r in range(rings):
        nxt = []
        for k in front:
            for e in me.polygons[faces[k]].edge_keys:
                for k2 in ek.get(e, ()):
                    if not sel[k2] and std[k2] > _LFS_DETAIL_GROW:
                        sel[k2] = True
                        nxt.append(k2)
        if not nxt:
            break
        front = nxt
    return sel


def _lfs_tri_cells(X, Y, wu, hu):
    import numpy as np
    m = np.zeros((hu, wu), dtype=bool)
    if len(X) == 0:
        return m
    x0 = np.clip(np.floor(X.min(axis=1)).astype(np.int64), 0, wu - 1)
    x1 = np.clip(np.floor(X.max(axis=1)).astype(np.int64), 0, wu - 1)
    y0 = np.clip(np.floor(Y.min(axis=1)).astype(np.int64), 0, hu - 1)
    y1 = np.clip(np.floor(Y.max(axis=1)).astype(np.int64), 0, hu - 1)
    small = ((x1 - x0) <= 1) & ((y1 - y0) <= 1)
    for dy in (0, 1):
        for dx in (0, 1):
            s = small & (y0 + dy <= y1) & (x0 + dx <= x1)
            m[y0[s] + dy, x0[s] + dx] = True
    for k in np.nonzero(~small)[0]:
        jj, ii = np.meshgrid(np.arange(x0[k], x1[k] + 1, dtype=np.float64),
                             np.arange(y0[k], y1[k] + 1, dtype=np.float64))
        ok = np.ones(jj.shape, dtype=bool)
        px = X[k]; py = Y[k]
        for e in range(3):
            ax_, ay_ = px[e], py[e]
            bx_, by_ = px[(e + 1) % 3], py[(e + 1) % 3]
            nx_, ny_ = -(by_ - ay_), (bx_ - ax_)
            if nx_ == 0.0 and ny_ == 0.0:
                continue
            tp = nx_ * px + ny_ * py
            tmin, tmax = tp.min(), tp.max()
            base = nx_ * jj + ny_ * ii
            cmin = base + min(0.0, nx_) + min(0.0, ny_)
            cmax = base + max(0.0, nx_) + max(0.0, ny_)
            ok &= ~((cmax < tmin) | (cmin > tmax))
        m[ii[ok].astype(np.int64), jj[ok].astype(np.int64)] = True
    return m


def _lfs_dilate1(m):
    out = m.copy()
    out[1:, :] |= m[:-1, :]
    out[:-1, :] |= m[1:, :]
    o2 = out.copy()
    o2[:, 1:] |= out[:, :-1]
    o2[:, :-1] |= out[:, 1:]
    return o2


def _lfs_free_spots(occ, m):
    import numpy as np
    H, W = occ.shape
    h, w = m.shape
    if h > H or w > W:
        return None
    if not occ.any():
        return np.ones((H - h + 1, W - w + 1), dtype=bool)
    sh = (H + h, W + w)
    F = np.fft.rfft2(occ.astype(np.float64), s=sh)
    K = np.fft.rfft2(m[::-1, ::-1].astype(np.float64), s=sh)
    c = np.fft.irfft2(F * K, s=sh)
    return c[h - 1:H, w - 1:W] < 0.5


def _lfs_piece_views(me, nmat, mw, keys, dirs, n_dirs, cover=0.42, rest=0.10, most=4):
    import numpy as np
    nf = len(me.polygons)
    if nf == 0 or not keys:
        return {}
    nr = np.empty(nf * 3, np.float64)
    me.polygons.foreach_get('normal', nr)
    N = np.array(nmat, dtype=np.float64)
    nr = nr.reshape(-1, 3) @ N.T
    ln = np.linalg.norm(nr, axis=1)
    ln[ln == 0] = 1.0
    nr /= ln[:, None]
    ar = np.empty(nf, np.float64)
    me.polygons.foreach_get('area', ar)
    D = np.array([tuple(dirs[i]) for i in range(n_dirs)], dtype=np.float64)
    dots = nr @ D.T
    edge_faces = {}
    for f in keys:
        for ek in me.polygons[f].edge_keys:
            edge_faces.setdefault(ek, []).append(f)
    out = {}
    seen = set()
    for f0, k0 in keys.items():
        if f0 in seen:
            continue
        comp = []
        stack = [f0]
        seen.add(f0)
        while stack:
            f = stack.pop()
            comp.append(f)
            for ek in me.polygons[f].edge_keys:
                for g in edge_faces.get(ek, ()):
                    if g not in seen and keys.get(g) == k0:
                        seen.add(g)
                        stack.append(g)
        ids = np.array(comp, dtype=np.int64)
        a = ar[ids]
        dt = dots[ids]
        tot = float(a.sum()) or 1.0
        left = np.ones(len(ids), dtype=bool)
        chosen = []
        while left.any() and len(chosen) < most:
            if chosen and float(a[left].sum()) < rest * tot:
                break
            cov = (((dt >= cover) & left[:, None]) * a[:, None]).sum(axis=0)
            k = int(np.argmax(cov))
            if cov[k] <= 0.0:
                break
            chosen.append(k)
            left &= ~(dt[:, k] >= cover)
        if not chosen:
            chosen = [int(np.argmax((np.maximum(dt, 0.0) * a[:, None]).sum(axis=0)))]
        sub = dt[:, chosen]
        pick = np.array(chosen, dtype=np.int64)[np.argmax(sub, axis=1)]
        away = sub.max(axis=1) < 0.0
        if away.any() and float(a[away].sum()) >= 0.15 * tot:
            pick[away] = np.argmax(dt[away], axis=1)
        for j, f in enumerate(comp):
            out[f] = int(pick[j])
    return out


def _lfs_cluster_area(c):
    try:
        _sc = abs(c['obj'].matrix_world.to_3x3().determinant()) ** (2.0 / 3.0)
        return float(sum(c['obj'].data.polygons[f].area for f in c['faces'])) * _sc
    except Exception:
        return 1.0


def _lfs_shape_pack(items, max_pages, G=128, fail=None):
    import numpy as np
    order = sorted(range(len(items)),
                   key=lambda k: (-items[k][1].shape[0] * items[k][1].shape[1],
                                  -int(items[k][1].sum()), k))
    occ = []
    occd = []
    place = {}
    for k in order:
        key, m = items[k]
        hu, wu = m.shape
        if hu > G or wu > G:
            if fail is not None:
                fail.append(key)
            return None
        spot = None
        for pg in range(len(occ)):
            fr = _lfs_free_spots(occd[pg], m)
            if fr is None:
                if fail is not None:
                    fail.append(key)
                return None
            ys, xs = np.nonzero(fr)
            if len(ys):
                spot = (pg, int(xs[0]), int(ys[0]))
                break
        if spot is None:
            if len(occ) >= max_pages:
                if fail is not None:
                    fail.append(key)
                return None
            occ.append(np.zeros((G, G), dtype=bool))
            occd.append(np.zeros((G, G), dtype=bool))
            spot = (len(occ) - 1, 0, 0)
        pg, x0, y0 = spot
        occ[pg][y0:y0 + hu, x0:x0 + wu] |= m
        occd[pg] = _lfs_dilate1(occ[pg])
        place[key] = (pg, x0, y0, wu, hu)
    return place, len(occ)


def _lfs_piece_mask(c, S):
    import numpy as np
    pr = c.get('prio', 1.0)
    wu = max(1, int(math.ceil(c['w'] * pr / S)) + 1)
    hu = max(1, int(math.ceil(c['hgt'] * pr / S)) + 1)
    if wu > 128 or hu > 128:
        return None
    T = c.get('_tri2')
    if T is None or not len(T):
        return np.ones((hu, wu), dtype=bool)
    Sc = S / pr
    mx = 0.5 * (wu - c['w'] / Sc)
    my = 0.5 * (hu - c['hgt'] / Sc)
    return _lfs_tri_cells(T[:, :, 0] / Sc + mx, T[:, :, 1] / Sc + my, wu, hu)


_LFS_PLANE_CELL = 0.01


def _lfs_plane_cells(c, U, V):
    import numpy as np
    mw = c['obj'].matrix_world
    me = c['obj'].data
    out = set()
    k_ = 1.0 / _LFS_PLANE_CELL
    for fi in c['faces']:
        pts = [mw @ me.vertices[vi].co for vi in me.polygons[fi].vertices]
        P = [(q.dot(U) * k_, q.dot(V) * k_) for q in pts]
        for k in range(1, len(P) - 1):
            ax = np.array((P[0][0], P[k][0], P[k + 1][0]))
            ay = np.array((P[0][1], P[k][1], P[k + 1][1]))
            out.add(int(np.floor(ax.mean())) * 1048576 + int(np.floor(ay.mean())))
            x0, x1 = int(np.floor(ax.min())), int(np.floor(ax.max()))
            y0, y1 = int(np.floor(ay.min())), int(np.floor(ay.max()))
            if x1 == x0 and y1 == y0:
                continue
            if (x1 - x0 + 1) * (y1 - y0 + 1) > 250000:
                continue
            X, Y = np.meshgrid(np.arange(x0, x1 + 1) + 0.5, np.arange(y0, y1 + 1) + 0.5)
            det = (ax[1] - ax[0]) * (ay[2] - ay[0]) - (ax[2] - ax[0]) * (ay[1] - ay[0])
            if abs(det) < 1e-12:
                continue
            l1 = ((X - ax[0]) * (ay[2] - ay[0]) - (ax[2] - ax[0]) * (Y - ay[0])) / det
            l2 = ((ax[1] - ax[0]) * (Y - ay[0]) - (X - ax[0]) * (ay[1] - ay[0])) / det
            ins = (l1 >= 0) & (l2 >= 0) & (l1 + l2 <= 1)
            if ins.any():
                xs = (X[ins] - 0.5).astype(np.int64); ys = (Y[ins] - 0.5).astype(np.int64)
                out.update((xs * 1048576 + ys).tolist())
    return out


def _lfs_merge_min_waste(clusters, cap, dirs, near=8, coarse=False):
    import heapq
    from mathutils import Vector
    frames = {}
    for c in clusters:
        di = c['dir']
        if di not in frames:
            d = dirs[di]
            _h, _p = _uvp_hp_from_normal((d.x, d.y, d.z))
            U, V, _N = (Vector(x) for x in _uvp_frame(_h, _p, 0.0))
            frames[di] = (U, V)
        U, V = frames[di]
        mw = c['obj'].matrix_world; me = c['obj'].data
        us = []; vs = []
        for fi in c['faces']:
            for vi in me.polygons[fi].vertices:
                q = mw @ me.vertices[vi].co
                us.append(q.dot(U)); vs.append(q.dot(V))
        c['_bb'] = [min(us), max(us), min(vs), max(vs)]
        c['_k'] = ((c['obj'].name, c['mat'], di) if coarse else
                   (c['obj'].name, c['mat'], di, bool(c.get('fine')), bool(c.get('lens'))))
        c['_cells'] = _lfs_plane_cells(c, U, V)
        c['_ver'] = 0; c['_alive'] = True

    def _area(b):
        return max(1e-4, b[1] - b[0]) * max(1e-4, b[3] - b[2])

    def _union(a, b):
        return [min(a[0], b[0]), max(a[1], b[1]), min(a[2], b[2]), max(a[3], b[3])]

    def _cen(b):
        return (0.5 * (b[0] + b[1]), 0.5 * (b[2] + b[3]))
    by_key = {}
    for i, c in enumerate(clusters):
        by_key.setdefault(c['_k'], []).append(i)
    heap = []

    def _push(i, cands):
        ci = clusters[i]
        for j in cands:
            cj = clusters[j]
            if j == i or not cj['_alive']:
                continue
            _pi7 = ci.get('prio', 1.0); _pj7 = cj.get('prio', 1.0); _P7 = max(_pi7, _pj7)
            w = (_area(_union(ci['_bb'], cj['_bb'])) * _P7 * _P7 - _area(ci['_bb']) * _pi7 * _pi7
                 - _area(cj['_bb']) * _pj7 * _pj7)
            _ov7 = len(ci['_cells'] & cj['_cells'])
            if _ov7 >= 3 and _ov7 >= 0.1 * min(len(ci['_cells']), len(cj['_cells'])):
                w += 50.0 * _ov7 * _LFS_PLANE_CELL * _LFS_PLANE_CELL * _P7 * _P7
            heapq.heappush(heap, (w, i, j, ci['_ver'], cj['_ver']))

    def _nearest(i, ids):
        ci = _cen(clusters[i]['_bb'])
        return sorted((j for j in ids if j != i and clusters[j]['_alive']),
                      key=lambda j: (_cen(clusters[j]['_bb'])[0] - ci[0]) ** 2
                      + (_cen(clusters[j]['_bb'])[1] - ci[1]) ** 2)[:near]
    for ids in by_key.values():
        if len(ids) > 1:
            for i in ids:
                _push(i, _nearest(i, ids))
    alive = len(clusters)
    while alive > cap and heap:
        w, i, j, vi, vj = heapq.heappop(heap)
        ci, cj = clusters[i], clusters[j]
        if not (ci['_alive'] and cj['_alive']) or ci['_ver'] != vi or cj['_ver'] != vj:
            continue
        ci['faces'].extend(cj['faces'])
        ci['_bb'] = _union(ci['_bb'], cj['_bb'])
        ci['_cells'] = ci['_cells'] | cj['_cells']
        ci['alpha'] = bool(ci['alpha'] or cj['alpha'])
        ci['prio'] = max(ci.get('prio', 1.0), cj.get('prio', 1.0))
        ci['_ver'] += 1
        cj['_alive'] = False
        alive -= 1
        _push(i, _nearest(i, by_key[ci['_k']]))
    out = [c for c in clusters if c['_alive']]
    for c in out:
        for k in ('_bb', '_k', '_ver', '_alive', '_cells'):
            c.pop(k, None)
    return out


_LFS_DETAIL_MIN = 12.0
_LFS_DETAIL_GROW = 5.0
_LFS_DETAIL_DEV = 28.0


def _lfs_steer_offset(objs, steer):
    from mathutils import Vector
    if steer is None or not objs:
        return None
    pts = [o.matrix_world @ Vector(c) for o in objs for c in o.bound_box]
    sp = [steer.matrix_world @ Vector(c) for c in steer.bound_box]
    y0, y1 = min(p.y for p in pts), max(p.y for p in pts)
    if y1 - y0 < 0.5:
        return None
    sy = (min(p.y for p in sp) + max(p.y for p in sp)) / 2
    return (sy - (y0 + y1) / 2) / (y1 - y0)


_LFS_FRONT_WORDS = ('headlight', 'head_light', 'head light', 'headlamp', 'head_lamp', 'head lamp',
                    'frontlight', 'front_light', 'grill', 'radiator', 'bumperf', 'bumper_f', 'bumper f',
                    'bonnet', 'hood', 'windshield', 'windscreen', 'splitter', 'front', 'foglight',
                    'fog_light', 'fog light', 'drl')
_LFS_REAR_WORDS = ('taillight', 'tail_light', 'tail light', 'taillamp', 'tail_lamp', 'tail lamp',
                   'rearlight', 'rear_light', 'brakelight', 'brake_light', 'brake light', 'reverse',
                   'bumperr', 'bumper_r', 'bumper r', 'trunk', 'boot', 'tailgate', 'exhaust', 'muffler',
                   'diffuser', 'spoiler', 'rear', 'back')
_LFS_NOT_FACING = ('rearview', 'rear_view', 'rear view', 'backfac', 'backrest', 'back_rest', 'background',
                   'backplate', 'backing', 'feedback', 'front_seat', 'frontseat', 'rear_seat', 'rearseat',
                   'back_seat', 'backseat', 'seat')


def _lfs_front_cue(name):
    n = name.lower()
    if any(w in n for w in _LFS_NOT_FACING):
        return 0
    f = any(w in n for w in _LFS_FRONT_WORDS)
    r = any(w in n for w in _LFS_REAR_WORDS)
    return 1 if (f and not r) else (-1 if (r and not f) else 0)


_LFS_WHEEL_POS_RE = re.compile(r'(?<![a-z])(fl|fr|rl|rr|bl|br)(_?w|_?wheel|_?tyre|_?tire|_?rim)?(?![a-z])')


def _lfs_wheel_end(name):
    n = name.lower()
    m = _LFS_WHEEL_POS_RE.search(n)
    if not m:
        return 0
    if not (m.group(2) or re.fullmatch(r'(fl|fr|rl|rr|bl|br)(\.\d+)?', n.strip())
            or any(w in n for w in ('wheel', 'tyre', 'tire', 'rim', 'brake', 'disc', 'calip', 'hub'))):
        return 0
    return 1 if m.group(1) in ('fl', 'fr') else -1


def _lfs_front_hint(meshes):
    import numpy as np
    from mathutils import Vector
    pts = [o.matrix_world @ Vector(c) for o in meshes for c in o.bound_box]
    if not pts:
        return 0, ''
    y0 = min(p.y for p in pts); y1 = max(p.y for p in pts)
    L = y1 - y0
    if L < 0.5:
        return 0, ''
    yc = (y0 + y1) / 2
    acc = {1: [0.0, 0.0], -1: [0.0, 0.0]}
    red = [0.0, 0.0]
    gl_y = []; gl_a = []
    whl = {1: [0.0, 0.0], -1: [0.0, 0.0]}
    total = 0.0
    for o in meshes:
        me = o.data
        n = len(me.polygons)
        if n == 0:
            continue
        mw = o.matrix_world
        ar = np.empty(n, np.float32); me.polygons.foreach_get('area', ar)
        ce = np.empty(n * 3, np.float32); me.polygons.foreach_get('center', ce)
        ce = ce.reshape(-1, 3)
        M = np.array(mw)
        wy = ce @ M[1, :3] + M[1, 3]
        sc = max(abs(mw.to_scale()[k]) for k in range(3)) or 1.0
        ar = ar.astype(np.float64) * sc * sc
        mi = np.empty(n, np.int32); me.polygons.foreach_get('material_index', mi)
        total += float(ar.sum())
        oc = _lfs_front_cue(o.name)
        _we = _lfs_wheel_end(o.name)
        if _we:
            whl[_we][0] += float(ar.sum()); whl[_we][1] += float((ar * wy).sum())
        slots = o.material_slots
        for si in np.unique(mi):
            sel = mi == si
            m = slots[si].material if 0 <= si < len(slots) else None
            cue = _lfs_front_cue(m.name) if m is not None else 0
            if cue == 0:
                cue = oc
            a = float(ar[sel].sum())
            if a <= 0:
                continue
            ay = float((ar[sel] * wy[sel]).sum())
            if cue:
                acc[cue][0] += a; acc[cue][1] += ay
            if m is not None:
                rgb, alpha, _tr = _mat_shader_info(m)
                if rgb[0] >= 150 and rgb[1] <= 80 and rgb[2] <= 80:
                    red[0] += a; red[1] += ay
                _gn = (m.name + ' ' + o.name).lower()
                if (any(w in _gn for w in ('glass', 'window', 'windscreen', 'windshield'))
                        and not any(w in _gn for w in ('light', 'lamp', 'lens', 'mirror', 'fiber', 'fibre'))):
                    gl_y.append(wy[sel].astype(np.float64)); gl_a.append(ar[sel])
    (af, afy), (ar_, ary) = acc[1], acc[-1]
    d = None
    if af > 0 and ar_ > 0:
        d = afy / af - ary / ar_
    elif af > 0:
        d = afy / af - yc
    elif ar_ > 0:
        d = yc - ary / ar_
    if d is not None and abs(d) >= 0.15 * L:
        return (1 if d > 0 else -1), 'names', bool(af > 0 and ar_ > 0 and abs(d) >= 0.3 * L)
    if whl[1][0] > 0 and whl[-1][0] > 0:
        dw = whl[1][1] / whl[1][0] - whl[-1][1] / whl[-1][0]
        if abs(dw) >= 0.3 * L:
            return (1 if dw > 0 else -1), 'wheel names', True
    if total > 0 and 0 < red[0] <= 0.05 * total:
        ry = red[1] / red[0]
        if abs(ry - yc) >= 0.3 * L:
            return (1 if ry < yc else -1), 'red lights'
    if gl_y:
        gy_ = np.concatenate(gl_y); ga_ = np.concatenate(gl_a)
        A_ = float(ga_.sum())
        if A_ > 0:
            gy = float((ga_ * gy_).sum()) / A_
            s_ = 1 if gy > yc else -1
            o_ = np.argsort(s_ * gy_, kind='stable')
            k_ = int(np.searchsorted(np.cumsum(ga_[o_]) / A_, 0.10))
            near = float(gy_[o_][min(k_, len(o_) - 1)])
            if abs(gy - yc) >= 0.15 * L and s_ * (near - yc) >= 0.05 * L:
                return s_, 'windows'
    return 0, ''


def _lfs_face_plus_y(objs, steer_name, hint=(0, '')):
    import bpy, math
    from mathutils import Matrix
    st = bpy.data.objects.get(steer_name) if steer_name else None
    off = _lfs_steer_offset(objs, st)
    _over = bool(off is not None and 0.05 < abs(off) < 0.15 and hint and len(hint) > 2 and hint[2]
                 and hint[0] and (off > 0) != (hint[0] > 0))
    if _over:
        print(f"  [auto-setup] the names at both ends win over the steering wheel {abs(off) * 100:.0f} % "
              f"off the middle (front at {'+' if hint[0] > 0 else '-'}Y)")
    if off is not None and abs(off) > 0.05 and not _over:
        if off > -0.05:
            return False
        why = f"the steering wheel sat {abs(off) * 100:.0f} % behind the middle"
    elif hint and hint[0] == -1:
        why = ("its head and tail lights (by name) said its front was at -Y" if hint[1] == 'names'
               else ("its wheels' names (FL, FR / RL, RR) said its front was at -Y" if hint[1] == 'wheel names'
                     else ("its windows (the cab) sat at -Y" if hint[1] == 'windows'
                           else "its red tail lights sat at +Y")))
        if _over:
            why += f" (they win over its steering wheel, {abs(off) * 100:.0f} % off the middle)"
    else:
        return False
    rot = Matrix.Rotation(math.radians(180), 4, 'Z')
    for o in objs:
        o.matrix_world = rot @ o.matrix_world
    print(f"  [auto-setup] {why} - turned the car to face +Y")
    return True


def _lfs_find_missing_images(objs):
    import bpy, os, re as _re
    imgs, seen = [], set()
    for ob in objs:
        for sl in ob.material_slots:
            m = sl.material
            if m is None or m.name in seen or not m.node_tree:
                continue
            seen.add(m.name)
            for n in m.node_tree.nodes:
                im = getattr(n, 'image', None) if n.type == 'TEX_IMAGE' else None
                if (im is None or im in imgs or im.packed_file is not None
                        or im.source not in ('FILE', 'TILED') or not im.filepath):
                    continue
                try:
                    if os.path.isfile(bpy.path.abspath(im.filepath)):
                        continue
                except Exception:
                    pass
                imgs.append(im)
    if not imgs:
        return [], []
    if not bpy.data.filepath:
        return [], [im.name for im in imgs]
    bd = os.path.dirname(bpy.path.abspath(bpy.data.filepath))
    index = {}

    def _take(d):
        sub = []
        try:
            for e in os.scandir(d):
                try:
                    if e.is_file():
                        st, ex = os.path.splitext(e.name)
                        if ex.lower() in _LFS_IMG_EXTS:
                            index.setdefault(e.name.lower(), e.path)
                            index.setdefault('stem:' + st.lower(), e.path)
                    elif e.is_dir() and not e.name.startswith('.'):
                        sub.append(e.path)
                except OSError:
                    pass
        except OSError:
            pass
        return sub
    level = [bd]
    for _depth in range(4):
        nxt = []
        for d in level:
            nxt += _take(d)
            if len(index) > 40000:
                break
        level = nxt[:400]
    par = os.path.dirname(bd)
    if par and par != bd:
        _take(par)
    found, missing = [], []
    for im in imgs:
        bn = _re.split(r'[\\/]', im.filepath)[-1]
        path = index.get(bn.lower()) or index.get('stem:' + os.path.splitext(bn)[0].lower())
        if not path:
            missing.append(im.name)
            continue
        try:
            im.filepath = path
            im.reload()
            found.append((im.name, path))
            print(f"  [textures] {im.name}: found at {path}")
        except Exception as e:
            missing.append(im.name)
            print(f"  [textures] {im.name}: {path} did not load: {e}")
    return found, missing


def _lfs_missing_note(found, missing):
    import os
    s = ''
    if found:
        dirs = sorted({os.path.dirname(p) for _n, p in found})
        s += (f"Found {len(found)} texture(s) that were not where the .blend said, in "
              f"{dirs[0]}{' and %d more folder(s)' % (len(dirs) - 1) if len(dirs) > 1 else ''}. ")
    if missing:
        s += (f"{len(missing)} texture(s) are missing ({', '.join(missing[:3])}"
              f"{'...' if len(missing) > 3 else ''}): those parts get a plain colour - "
              f"File > External Data > Find Missing Files, then run it again. ")
    return s.strip()


def _lfs_autolink_missing_textures(objs, png_dir):
    import bpy, os
    exts = ('.png', '.jpg', '.jpeg', '.tga', '.bmp', '.dds', '.tif', '.tiff')
    dirs = []
    if bpy.data.filepath:
        bd = os.path.dirname(bpy.data.filepath)
        dirs += [bd, os.path.join(bd, 'textures'), os.path.join(bd, 'Textures'),
                 os.path.join(bd, 'tex'), os.path.join(bd, 'maps')]
    dirs.append(png_dir)
    index = {}
    for d in dirs:
        try:
            for fn in os.listdir(d):
                st, ex = os.path.splitext(fn)
                if ex.lower() in exts:
                    index.setdefault(st.lower(), os.path.join(d, fn))
        except Exception:
            pass
    if not index:
        return []
    done = []
    seen = set()
    for ob in objs:
        for sl in ob.material_slots:
            m = sl.material
            if m is None or m.name in seen or m.get('lfs_baked_from') or m.get('lfs_split_from'):
                continue
            seen.add(m.name)
            if _lfs_base_color_image(m) is not None or m.get('lfs_tex_page') is not None:
                continue
            base = m.name
            for suf in ('.mat', '_mat', '.material'):
                if base.lower().endswith(suf):
                    base = base[:-len(suf)]
                    break
            path = index.get(base.lower()) or index.get(m.name.lower())
            if not path:
                continue
            try:
                img = next((i for i in bpy.data.images
                            if i.filepath and os.path.normcase(bpy.path.abspath(i.filepath)) == os.path.normcase(path)), None)
                if img is None:
                    img = bpy.data.images.load(path)
                if min(img.size) == 0:
                    img.reload()
                if min(img.size) == 0:
                    continue
                m.use_nodes = True
                nt = m.node_tree
                bsdf = next((n for n in nt.nodes if n.type == 'BSDF_PRINCIPLED'), None)
                if bsdf is None:
                    continue
                tex = nt.nodes.new('ShaderNodeTexImage')
                tex.image = img
                tex.location = (bsdf.location.x - 340, bsdf.location.y)
                for l in list(bsdf.inputs['Base Color'].links):
                    nt.links.remove(l)
                nt.links.new(tex.outputs['Color'], bsdf.inputs['Base Color'])
                m['lfs_autolinked_tex'] = os.path.basename(path)
                done.append((m.name, os.path.basename(path)))
                print(f"  [bake] {m.name}: no texture in Blender -> linked {path}")
            except Exception as e:
                print(f"  [bake] {m.name}: could not link {path}: {e}")
    return done


def _lfs_uv_density(objs, mat, uv_name_of):
    import numpy as np
    wa = 0.0; ua = 0.0
    for o in objs:
        me = o.data
        uvn = uv_name_of.get(o.name) if isinstance(uv_name_of, dict) else None
        if uvn is None:
            cands = [l for l in me.uv_layers if l.name != 'LFS_BAKE']
            if not cands:
                continue
            uvn = next((l for l in cands if l.active_render), cands[0]).name
        if uvn not in me.uv_layers:
            continue
        sidx = [i for i, sl in enumerate(o.material_slots) if sl.material == mat]
        if not sidx:
            continue
        uvd = me.uv_layers[uvn].data
        sc = o.matrix_world.to_scale()
        s2 = abs(sc.x * sc.y)
        for p in me.polygons:
            if p.material_index not in sidx:
                continue
            wa += p.area * s2
            li = list(p.loop_indices)
            a = 0.0
            u0 = uvd[li[0]].uv
            for k in range(1, len(li) - 1):
                u1 = uvd[li[k]].uv; u2 = uvd[li[k + 1]].uv
                a += 0.5 * abs((u1.x - u0.x) * (u2.y - u0.y) - (u2.x - u0.x) * (u1.y - u0.y))
            ua += a
    if wa <= 0 or ua <= 1e-9:
        return None
    return float((wa / ua) ** 0.5)


def _lfs_relief_page(arr, fld, faces):
    import numpy as np
    from mathutils import Vector
    Ph, Pw = arr.shape[0], arr.shape[1]
    done = np.zeros((Ph, Pw), bool)
    n = 0
    for o, fis, uvn in faces:
        me = o.data
        uvl = me.uv_layers.get(uvn) if uvn else None
        if uvl is None:
            continue
        uvl = uvl.data
        mw = o.matrix_world
        nmat = mw.to_3x3().inverted().transposed()
        for fi in fis:
            poly = me.polygons[fi]
            lv = list(poly.loop_indices)
            vv = list(poly.vertices)
            nw = nmat @ poly.normal
            if nw.length < 1e-12:
                continue
            nw.normalize()
            for k in range(1, len(vv) - 1):
                tri = (0, k, k + 1)
                P = [mw @ me.vertices[vv[t_]].co for t_ in tri]
                suv = [uvl[lv[t_]].uv for t_ in tri]
                us = [float(q[0]) for q in suv]
                vs_ = [float(q[1]) for q in suv]
                ou = np.floor(min(us)); ov = np.floor(min(vs_))
                ax = np.array([(u_ - ou) * Pw for u_ in us])
                ay = np.array([(v_ - ov) * Ph for v_ in vs_])
                if ax.max() > Pw + 1 or ay.max() > Ph + 1:
                    continue
                x0 = max(int(np.floor(ax.min())), 0); x1 = min(int(np.ceil(ax.max())), Pw - 1)
                y0 = max(int(np.floor(ay.min())), 0); y1 = min(int(np.ceil(ay.max())), Ph - 1)
                if x1 < x0 or y1 < y0:
                    continue
                gx, gy = np.meshgrid(np.arange(x0, x1 + 1) + 0.5, np.arange(y0, y1 + 1) + 0.5)
                det = (ax[1] - ax[0]) * (ay[2] - ay[0]) - (ax[2] - ax[0]) * (ay[1] - ay[0])
                if abs(det) < 1e-9:
                    continue
                l1 = ((gx - ax[0]) * (ay[2] - ay[0]) - (ax[2] - ax[0]) * (gy - ay[0])) / det
                l2 = ((ax[1] - ax[0]) * (gy - ay[0]) - (gx - ax[0]) * (ay[1] - ay[0])) / det
                l0 = 1.0 - l1 - l2
                ins = (l0 >= -0.01) & (l1 >= -0.01) & (l2 >= -0.01)
                yy, xx = np.nonzero(ins)
                if not len(yy):
                    continue
                ys = yy + y0
                xs = xx + x0
                free = ~done[ys, xs]
                if not free.any():
                    continue
                ys = ys[free]
                xs = xs[free]
                su = (xs + 0.5) / Pw
                sv = (ys + 0.5) / Ph
                col = arr[ys, xs].copy()
                suv_ = [Vector((us[i] - ou, vs_[i] - ov)) for i in range(3)]
                if _lfs_relief_apply(col, fld, su, sv, P, suv_, nw):
                    arr[ys, xs] = col
                    done[ys, xs] = True
                    n += len(ys)
    return n


def _lfs_export_image_as_page(img, png_dir, max_px=1024, shade_mat=None, relief_faces=None):
    import os, math, shutil, tempfile
    stem0 = os.path.splitext(bpy.path.basename(img.filepath) or img.name)[0]
    stem0 = ''.join(ch for ch in stem0 if ch.isalnum() or ch in '_-')[:19] or 'tile'
    tpath = None
    try:
        if min(img.size) == 0:
            img.reload()
        if min(img.size) == 0:
            return None, 0
        _w, _h = int(img.size[0]), int(img.size[1])
        _side = 2 ** int(round(math.log2(max(_w, _h))))
        _side = max(16, min(int(max_px), _side))
        dst = os.path.join(png_dir, stem0 + '.png')
        src = ''
        if img.filepath and img.packed_file is None:
            src = os.path.normcase(os.path.abspath(bpy.path.abspath(img.filepath)))
        if (src and src == os.path.normcase(os.path.abspath(dst)) and os.path.isfile(dst)
                and (_w, _h) == (_side, _side) and shade_mat is None):
            return stem0, _side * _side
        tmp = img.copy()
        if min(tmp.size) == 0:
            bpy.data.images.remove(tmp)
            return None, 0
        if (_w, _h) != (_side, _side):
            tmp.scale(_side, _side)
        if shade_mat is not None:
            try:
                import numpy as np
                _w2, _h2 = int(tmp.size[0]), int(tmp.size[1])
                _a = np.empty(_w2 * _h2 * 4, np.float32)
                tmp.pixels.foreach_get(_a)
                _a = _a.reshape(_h2, _w2, 4)
                _rf9 = _lfs_relief_field(shade_mat) if relief_faces else None
                _a = _lfs_nshade(shade_mat, _a, hi_lines=_rf9 is None)
                if _rf9 is not None:
                    _n9 = _lfs_relief_page(_a, _rf9, relief_faces)
                    print(f"  [bake] {stem0}: {_n9} texel(s) of the model's own page with its bumps lit by LFS's sky")
                tmp.pixels.foreach_set(np.ascontiguousarray(_a).ravel())
            except Exception as _ne:
                print(f"  [bake] {stem0}: the normal-map bumps were skipped: {_ne!r}")
        fd, tpath = tempfile.mkstemp(suffix='.png')
        os.close(fd)
        tmp.filepath_raw = tpath
        tmp.file_format = 'PNG'
        tmp.save()
        bpy.data.images.remove(tmp)
        with open(tpath, 'rb') as fh:
            data = fh.read()
        for k in range(1, 100):
            stem = stem0 if k == 1 else stem0[:18 - len(str(k))] + '_' + str(k)
            page = os.path.join(png_dir, stem + '.png')
            if not os.path.exists(page):
                shutil.copyfile(tpath, page)
                return stem, _side * _side
            with open(page, 'rb') as fh:
                if fh.read() == data:
                    return stem, _side * _side
        return None, 0
    except Exception as e:
        print(f"  [bake] could not write page {stem0}: {e}")
        return None, 0
    finally:
        if tpath:
            try:
                os.remove(tpath)
            except OSError:
                pass


def _bake_own_prefix(scene, stem0, png_dir, own_pages):
    import os, glob
    own = str(scene.get('lfs_bake_prefix', '') or '')
    if own:
        return own
    mine = {s.lower() for s in own_pages}

    def taken(pre):
        for f in glob.glob(os.path.join(glob.escape(png_dir), glob.escape(pre) + '_bk*.png')):
            if os.path.splitext(os.path.basename(f))[0].lower() not in mine:
                return True
        return False
    cand = stem0
    for k in range(2, 100):
        if not taken(cand):
            break
        cand = stem0[:11 - len(str(k))] + str(k)
    scene['lfs_bake_prefix'] = cand
    return cand


def _lfs_tex_status(mat):
    if mat is None:
        return ('?', 'QUESTION', False)
    pg = mat.get('lfs_tex_page')
    if pg is not None:
        pg = str(pg)
        if pg == '':
            return ('colour', 'COLOR', True)
        return (pg, 'TEXTURE', True)
    if mat.get('lfs_baked_from'):
        return ('baked', 'RENDER_STILL', False)
    if _lfs_base_color_image(mat) is not None and not mat.get('lfs_split_from'):
        return ('bake', 'RENDER_STILL', False)
    try:
        st = _find_png_for_material(mat.name, _resolve_png_dir())
    except Exception:
        st = None
    if st:
        return (st, 'LINKED', False)
    return ('colour', 'COLOR', False)


def _lfs_material_face_counts(objs):
    import numpy as np
    counts = {}
    for o in objs:
        me = o.data
        n = len(me.polygons)
        if n == 0 or not o.material_slots:
            continue
        idx = _lfs_mat_index_array(me)
        bc = np.bincount(np.clip(idx, 0, len(o.material_slots) - 1),
                         minlength=len(o.material_slots))
        for si, sl in enumerate(o.material_slots):
            if sl.material is not None and bc[si]:
                counts[sl.material.name] = counts.get(sl.material.name, 0) + int(bc[si])
    return counts


def _build_texture_tables(materials, png_dir, auto_paint=None, auto_glass=None):
    pages = [None]
    page_for_stem = {}
    skin_stems = set()
    cutouts = [{'name': 'unnamed', 'page': 0, 'rgb': (255, 255, 255),
                'flags': bytes([0, 0, 0, 0, 0]), 'shine': 0}]
    cut_index = []
    if auto_paint is None and auto_glass is None:
        try:
            _gm = 'AUTO'
            try:
                import bpy as _bpy
                _gm = _bpy.context.scene.get('lfs_automap_glass_mode', 'AUTO')
            except Exception:
                pass
            auto_paint, auto_glass = _auto_detect_from_scene(
                [(e[2] if len(e) > 2 and e[2] else e[0]) for e in materials], glass_mode=_gm)
        except Exception as _e:
            print(f"  [automap] auto-detect skipped: {_e}")
            auto_paint, auto_glass = set(), set()
    _paint_set = set(_PAINT_SKIN_MATERIALS) | set(auto_paint or ())
    _glass_set = set(_GLASS_MATERIALS) | set(auto_glass or ())
    print(f"  [automap] paint={sorted(_paint_set & {e[0].lower() for e in materials})} "
          f"glass={sorted(_glass_set & {e[0].lower() for e in materials})}")
    _seen_cut_names = {'unnamed'}
    _tex_cut_seen = {}
    for _entry in materials:
        mat_name, rgb = _entry[0], _entry[1]
        _mat_db = _entry[2] if len(_entry) > 2 and _entry[2] else mat_name
        _cut_nm = mat_name[:15]
        if _cut_nm in _seen_cut_names:
            _k = 2
            while True:
                _sfx = '~%d' % _k
                _cand = mat_name[:15 - len(_sfx)] + _sfx
                if _cand not in _seen_cut_names:
                    _cut_nm = _cand
                    break
                _k += 1
        _seen_cut_names.add(_cut_nm)
        stem = _find_png_for_material(mat_name, png_dir)
        if stem is None and _mat_db != mat_name:
            stem = _find_png_for_material(_mat_db, png_dir)
        if stem is None and (mat_name.lower() in _glass_set
                             or (_mat_db or '').lower() in _glass_set):
            stem = 's_glass_ALP'
        if stem:
            if stem not in page_for_stem:
                pages.append(stem)
                page_for_stem[stem] = len(pages) - 1
            pidx = page_for_stem[stem]
            _stem_l = (stem or '').lower()
            _alpha_stems = ('honeycombgrill', 'treebillboard', 'billboard',
                            'foliage', 'leaf', 'leaves', 'fence', 'grate')
            _mdb_obj = None
            try:
                import bpy as _b5
                _mdb_obj = _b5.data.materials.get(_mat_db) or _b5.data.materials.get(mat_name)
            except Exception:
                pass
            _baked_alpha = bool(_mdb_obj is not None and _mdb_obj.get('lfs_alpha_page'))
            _is_skin = bool(_mdb_obj is not None and _mdb_obj.get('lfs_skin_page'))
            if _is_skin:
                skin_stems.add(stem)
            _is_alpha_tex = (_baked_alpha
                             or mat_name.lower() in _glass_set
                             or (_mat_db or '').lower() in _glass_set
                             or _is_seethrough_material(mat_name, _mat_db, _mdb_obj)
                             or any(s in _stem_l for s in _alpha_stems))
            _tshine = 0
            _is_real_glass = (mat_name.lower() in _glass_set or (_mat_db or '').lower() in _glass_set
                              or _is_seethrough_material(mat_name, _mat_db, _mdb_obj)
                              or _stem_l.startswith('s_glass'))
            if _is_alpha_tex and not _is_real_glass and not _baked_alpha:
                _tflags = bytes([0, 2, 1, 7, 0])
            elif _is_alpha_tex:
                _tflags = bytes([0, 2, 1, 2, 0])
            elif 'leath' in _stem_l:
                _tflags = bytes([0, 0, 2, 2, 0])
                _tshine = 0x37
            elif 'carpet' in _stem_l:
                _tflags = bytes([0, 0, 0, 0, 0])
            else:
                if 'lum' in _stem_l or 'light' in _stem_l:
                    _tflags = bytes([0, 0, 1, 1, 0])
                    _tshine = 0x37
                elif 'chb' in _stem_l or 'chrom' in _stem_l:
                    _tflags = bytes([0, 0, 1, 7, 0])
                    _tshine = 0x28
                elif 'tire' in _stem_l or 'tyre' in _stem_l or 'p4b' in _stem_l:
                    _tflags = bytes([0, 0, 1, 6, 0])
                    _tshine = 0
                else:
                    _tflags = bytes([0, 0, 1, 7, 0])
                    _tshine = 0x2e
            try:
                if (not _is_alpha_tex and not _is_skin and _mdb_obj is not None
                        and (_mdb_obj.get('lfs_baked_from') or _mdb_obj.get('lfs_fit_base')
                             or _mdb_obj.get('lfs_detail_bake') or _mdb_obj.get('lfs_fit_left'))):
                    _tflags = bytes([0, 0, 0, 0, 0])
                    _tshine = 0
            except Exception:
                pass
            try:
                import bpy as _b3
                _m3 = _b3.data.materials.get(_mat_db) or _b3.data.materials.get(mat_name)
                if _m3 is not None:
                    if 'lfs_shine' in _m3.keys():
                        _tshine = int(_m3['lfs_shine']) & 0xFF
                    if 'lfs_rtype' in _m3.keys():
                        _tfb = bytearray(_tflags)
                        _tfb[3] = int(_m3['lfs_rtype']) & 0xFF
                        _tflags = bytes(_tfb)
                    if 'lfs_rmode' in _m3.keys():
                        _tfb = bytearray(_tflags)
                        _tfb[2] = int(_m3['lfs_rmode']) & 0xFF
                        _tflags = bytes(_tfb)
            except Exception:
                pass
            _crect = None
            try:
                import bpy as _bpy2
                _mm = _bpy2.data.materials.get(_mat_db) or _bpy2.data.materials.get(mat_name)
                _cr = _mm.get('lfs_cutout_rect') if _mm else None
                if _cr is not None and len(_cr) == 4:
                    _crect = bytes(max(0, min(255, int(round(v)))) for v in _cr)
            except Exception:
                pass
            _crgb = (25, 25, 25) if (_is_alpha_tex and _is_real_glass and not _baked_alpha) else (255, 255, 255)
            try:
                if _mdb_obj is not None and _mdb_obj.get('lfs_refl_rgb') is not None:
                    _crgb = tuple(max(0, min(255, int(v))) for v in list(_mdb_obj['lfs_refl_rgb'])[:3])
            except (TypeError, ValueError):
                pass
            if _is_skin:
                _tflags = bytes([0, 0, 1, 1, 0]); _crgb = (255, 255, 255); _tshine = 0
            _ckey = (pidx, bytes(_tflags), tuple(_crgb), int(_tshine), bytes(_crect) if _crect else None)
            _shared = _tex_cut_seen.get(_ckey)
            if _shared is not None:
                cut_index.append(_shared)
                continue
            cutouts.append({'name': _cut_nm, 'page': pidx,
                            'rgb': _crgb, 'flags': _tflags,
                            'shine': _tshine, 'rect': _crect})
            _tex_cut_seen[_ckey] = len(cutouts) - 1
        else:
            _is_paint = (mat_name.lower() in _paint_set or (_mat_db or '').lower() in _paint_set)
            cut_rgb = (255, 255, 255)
            try:
                import bpy as _b6
                _m6 = _b6.data.materials.get(_mat_db) or _b6.data.materials.get(mat_name)
                if _m6 is not None and _m6.get('lfs_refl_rgb') is not None:
                    cut_rgb = tuple(max(8, min(255, int(v))) for v in list(_m6['lfs_refl_rgb'])[:3])
            except Exception:
                pass
            _ml = mat_name.lower()
            _cshine = 0
            if not _is_paint:
                if ('chrom' in _ml or 'metal' in _ml or 'alu' in _ml
                        or _ml.endswith('chr') or '_chr_' in _ml):
                    _cshine = 0x28
                elif ('leath' in _ml or 'sits' in _ml or 'seat' in _ml
                        or 'beige' in _ml or 'suede' in _ml):
                    _cshine = 0x37
                elif ('rubber' in _ml or 'tyre' in _ml or 'tire' in _ml
                        or 'gum' in _ml):
                    _cshine = 0
                elif ('plastic' in _ml or 'plstc' in _ml or 'grey' in _ml
                        or 'black' in _ml or 'white' in _ml or 'xtex' in _ml):
                    _cshine = 0x2e
            if _is_paint:
                _ctype = 1
            elif 'chrom' in _ml or 'chr' == _ml[-3:] or 'metal' in _ml or 'alu' in _ml:
                _ctype = 3
            elif 'rubber' in _ml or 'tyre' in _ml or 'tire' in _ml or 'gum' in _ml:
                _ctype = 6
            else:
                _ctype = 7
            _cflags = bytes([0, 0, 1, _ctype, 0])
            try:
                import bpy as _b4
                _m4 = _b4.data.materials.get(_mat_db) or _b4.data.materials.get(mat_name)
                if _m4 is not None:
                    if 'lfs_shine' in _m4.keys():
                        _cshine = int(_m4['lfs_shine']) & 0xFF
                    _cfb = bytearray(_cflags)
                    if 'lfs_rmode' in _m4.keys():
                        _cfb[2] = int(_m4['lfs_rmode']) & 0xFF
                    if 'lfs_rtype' in _m4.keys():
                        _cfb[3] = int(_m4['lfs_rtype']) & 0xFF
                    _cflags = bytes(_cfb)
            except Exception:
                pass
            cutouts.append({'name': _cut_nm, 'page': 0,
                            'rgb': cut_rgb, 'flags': _cflags,
                            'shine': _cshine})
        cut_index.append(len(cutouts) - 1)

    if len(cutouts) > _CIDX_MAX and _LFS_OVER['on']:
        _lfs_over_note("%d cutouts (the editor crashes above ~%d)" % (len(cutouts), _CUTOUT_TABLE_MAX))
    elif len(cutouts) > _CIDX_MAX:
        raise ValueError(
            "%d cutouts (one per material with an lfs_cidx) - the LFS editor "
            "crashes above ~%d. Merge materials or run Purge Unused Maps%s."
            % (len(cutouts), _CUTOUT_TABLE_MAX, _LFS_OVER_HINT if _LFS_OVER['export'] else ''))
    if len(pages) > 255:
        raise ValueError("%d texture pages - the cutout page index is a byte (max 255)." % len(pages))

    pbuf = bytearray(struct.pack('<i', len(pages)))
    for stem in pages:
        pbuf += struct.pack('<i', 1 if (stem and stem in skin_stems) else 0)
        nm = (stem or '').encode('latin-1', 'replace')[:19]
        pbuf += nm + b'\x00' * (20 - len(nm))
    cbuf = bytearray(struct.pack('<i', len(cutouts)))
    for c in cutouts:
        nm = c['name'].encode('latin-1', 'replace')[:16]
        cbuf += nm + b'\x00' * (16 - len(nm))
        cbuf += bytes([0, 0])
        cbuf += bytes([c['page'] & 0xFF])
        cbuf += c['flags']
        cbuf += bytes([c['rgb'][0] & 0xFF, c['rgb'][1] & 0xFF, c['rgb'][2] & 0xFF])
        cbuf += bytes([c.get('shine', 0) & 0xFF])
        cbuf += (c.get('rect') or bytes([0x80, 0x80, 0, 0]))
    return bytes(pbuf), bytes(cbuf), cut_index


def _png_prefs():
    try:
        import bpy
        for name, ad in bpy.context.preferences.addons.items():
            if 'lfs_sre' in name and ad.preferences is not None and hasattr(ad.preferences, 'png_dir'):
                return ad.preferences
    except Exception:
        pass
    return None


def _resolve_png_dir():
    try:
        import bpy
        for name, ad in bpy.context.preferences.addons.items():
            if 'lfs_sre' in name:
                p = getattr(ad.preferences, 'png_dir', None)
                if p:
                    return bpy.path.abspath(p)
    except Exception:
        pass
    try:
        import bpy as _b, os as _os
        _d = _b.context.scene.get('lfs_png_dir')
        if _d and _os.path.isdir(str(_d)):
            return str(_d)
    except Exception:
        pass
    return ""


_CUTOUT_TABLE_MAX = 238
_MAP_TABLE_MAX = 236
_CIDX_MAX = 4000


def _lfs_live_material_names():
    import bpy
    live = set()
    for o in bpy.data.objects:
        if o.users == 0:
            continue
        for sl in o.material_slots:
            if sl.material is not None:
                live.add(sl.material.name)
    return live


def _lfs_map_rgb(mat, png_dir):
    rgb = _mat_rgb(mat)
    try:
        stem = _find_png_for_material(mat.name, png_dir)
    except Exception:
        stem = None
    if not stem or str(stem).lower().startswith('s_'):
        return rgb
    tint = _lfs_tex_tint_for(mat)
    if tint is not None:
        L = _lfs_page_avg_lin(stem, png_dir)
        k = (1.0 / max(0.12, L ** 0.5)) if L else 1.0
        return tuple(max(8, min(255, int(round(v * k)))) for v in tint[:3])
    if mat.get('lfs_glass_dark'):
        return (64, 64, 64)
    if mat.get('lfs_baked_from') or _lfs_base_color_image(mat) is not None:
        return (255, 255, 255)
    return rgb


_LFS_PAGE_LIN = {}


def _lfs_page_avg_lin(stem, png_dir):
    import bpy, os
    if not stem or not png_dir:
        return None
    key = (str(png_dir), str(stem).lower())
    if key in _LFS_PAGE_LIN:
        return _LFS_PAGE_LIN[key]
    val = None
    img = None
    try:
        want = (str(stem) + '.png').lower()
        path = next((os.path.join(png_dir, f) for f in os.listdir(png_dir) if f.lower() == want), None)
        if path:
            import numpy as np
            img = bpy.data.images.load(path, check_existing=False)
            a = _bake_read_image(img, max_size=128)[..., :3]
            if not getattr(img, 'is_float', False):
                a = np.where(a <= 0.04045, a / 12.92, ((a + 0.055) / 1.055) ** 2.4)
            val = float(a.mean())
    except Exception:
        val = None
    finally:
        if img is not None:
            try:
                bpy.data.images.remove(img)
            except Exception:
                pass
    _LFS_PAGE_LIN[key] = val
    return val


def _lfs_pick_cidx_materials():
    import bpy, re as _re
    used_mats = set()
    for obj in bpy.data.objects:
        if obj.type != 'MESH' or 'lfs_subobj_index' not in obj.keys():
            continue
        import numpy as _np
        _npoly = len(obj.data.polygons)
        used_slot_indices = set()
        if _npoly:
            _mi = _lfs_mat_index_array(obj.data)
            used_slot_indices = set(int(x) for x in _np.unique(_mi))
        for si in used_slot_indices:
            if si < len(obj.material_slots):
                slot = obj.material_slots[si]
                if slot.material is not None:
                    used_mats.add(slot.material.name)
    candidates_by_cidx = {}
    bad = []
    _live = _lfs_live_material_names()
    try:
        _pick_png_dir = _resolve_png_dir()
    except Exception:
        _pick_png_dir = ''
    for mat in bpy.data.materials:
        cidx = mat.get('lfs_cidx')
        if cidx is None or mat.name not in _live:
            continue
        try:
            ci = int(cidx)
        except (ValueError, TypeError):
            continue
        if ci < 0 or ci > _CIDX_MAX:
            bad.append("%s=%d" % (mat.name, ci))
            continue
        r, g, b = _lfs_map_rgb(mat, _pick_png_dir)
        is_used = mat.name in used_mats
        candidates_by_cidx.setdefault(ci, []).append((is_used, mat.name, r, g, b))
    if bad:
        raise ValueError(("lfs_cidx must be 0..%d: " % _CIDX_MAX)
                         + ", ".join(bad[:8]))
    by_cidx = {}
    for ci, cands in candidates_by_cidx.items():
        cands.sort(key=lambda c: (not c[0], len(c[1]), c[1]))
        is_used, nm, r, g, b = cands[0]
        by_cidx[ci] = [nm, r, g, b, nm]
    if by_cidx and max(by_cidx) + 1 > _CIDX_MAX + 1 and _LFS_OVER['on']:
        _lfs_over_note("%d maps (the editor crashes above ~%d)" % (max(by_cidx) + 1, _MAP_TABLE_MAX))
    elif by_cidx and max(by_cidx) + 1 > _CIDX_MAX + 1:
        raise ValueError(
            "Map table too long: %d entries (the LFS editor crashes above ~%d). "
            "Run Purge Unused Maps, or re-run Bake Textures (it keeps the map "
            "count under the limit)%s." % (max(by_cidx) + 1, _MAP_TABLE_MAX,
                                           _LFS_OVER_HINT if _LFS_OVER['export'] else ''))
    for ci in sorted(by_cidx):
        m = bpy.data.materials.get(by_cidx[ci][4])
        raw = m.get('lfs_map_name') if m is not None else None
        if raw:
            by_cidx[ci][0] = str(raw)
    seen15 = set()
    for ci in sorted(by_cidx):
        nm = by_cidx[ci][0]
        n15 = nm[:15]
        if n15 in seen15:
            k = 2
            while True:
                sfx = '~%d' % k
                cand = nm[:15 - len(sfx)] + sfx
                if cand not in seen15:
                    break
                k += 1
            by_cidx[ci][0] = cand
            n15 = cand
        seen15.add(n15)
    return {ci: tuple(v) for ci, v in by_cidx.items()}


def _lfs_assign_cidx(names, paint_names=()):
    import bpy
    used = {}
    _live = _lfs_live_material_names()
    for m in bpy.data.materials:
        ci = m.get('lfs_cidx')
        if ci is None or m.name not in _live:
            continue
        try:
            used[int(ci)] = m.name
        except (ValueError, TypeError):
            pass
    nxt = 2
    assigned = 0
    for nm in names:
        m = bpy.data.materials.get(nm)
        if m is None or m.get('lfs_cidx') is not None:
            continue
        if nm in paint_names and 1 not in used:
            m['lfs_cidx'] = 1; used[1] = nm; assigned += 1
            continue
        while nxt in used:
            nxt += 1
        if nxt > _CIDX_MAX:
            raise ValueError("Map limit (%d) reached - merge materials before marking." % _CIDX_MAX)
        m['lfs_cidx'] = nxt; used[nxt] = nm; assigned += 1
    return assigned


def _lfs_enforce_m1(paint_names=None):
    import bpy
    marked = [ob for ob in bpy.data.objects if ob.type == 'MESH' and 'lfs_subobj_index' in ob.keys()]
    if any(int(ob.get('lfs_subobj_original_nf', 0) or 0) > 0 for ob in marked):
        return None
    if paint_names is None:
        try:
            paint_names, _g = _auto_detect_from_scene(
                [m.name for m in bpy.data.materials],
                glass_mode=bpy.context.scene.get('lfs_automap_glass_mode', 'AUTO'))
        except Exception:
            paint_names = set()
    cands = [m for m in bpy.data.materials
             if not m.get('lfs_split_from') and not m.get('lfs_baked_from')
             and m.get('lfs_paint') is not False
             and (m.get('lfs_paint') or m.name.lower() in paint_names
                  or m.name.lower() in _PAINT_SKIN_MATERIALS)]
    try:
        _fc = _lfs_material_face_counts([ob for ob in bpy.data.objects if ob.type == 'MESH' and ob.users > 0
                                         and not ob.get('lfs_preview_only')])
        cands = [m for m in cands if _fc.get(m.name)]
    except Exception:
        pass
    cands.sort(key=lambda m: (not bool(m.get('lfs_paint')),
                              m.name.lower() not in _PAINT_SKIN_MATERIALS,
                              str(m.get('lfs_cidx', '')) != '1', m.name))
    paint = cands[0] if cands else None
    for m in bpy.data.materials:
        if m.get('lfs_m1_auto') and m is not paint:
            for k in ('lfs_map_name', 'lfs_m1_auto'):
                if k in m.keys():
                    del m[k]
    if paint is None:
        return None
    old = paint.get('lfs_cidx')
    try:
        old = int(old) if old is not None else None
    except (ValueError, TypeError):
        old = None
    if old != 1:
        for m in bpy.data.materials:
            if m is paint or m.get('lfs_cidx') is None:
                continue
            try:
                if int(m['lfs_cidx']) == 1:
                    if old is not None:
                        m['lfs_cidx'] = old
                    else:
                        del m['lfs_cidx']
            except (ValueError, TypeError):
                pass
        paint['lfs_cidx'] = 1
    if str(paint.get('lfs_map_name', '')) != 'm1':
        paint['lfs_map_name'] = 'm1'
        paint['lfs_m1_auto'] = True
    return paint


def _cidx_materials_list(map_records):
    by_cidx = _lfs_pick_cidx_materials()
    out = []
    for ci in range(len(map_records)):
        v = by_cidx.get(ci)
        if v is None:
            out.append((f'col_{ci}', (128, 128, 128), None))
        else:
            out.append((v[0], (v[1], v[2], v[3]), v[4]))
    return out


def _build_min_subobj_raw(name, sub_type, position, map_records, lod_distance=None, tex_materials=None, png_dir=None):
    d = _SUBOBJ_TYPE_DEFAULTS.get(sub_type, _SUBOBJ_TYPE_DEFAULTS[3])
    
    buf = bytearray()
    buf.append(15)
    buf.append(sub_type)
    buf.append(d['flip'])
    buf.append(len(d['lods']))
    nm = (name or 'subobj').encode('latin-1', 'replace')[:20]
    buf += nm + b'\x00' * (20 - len(nm))
    buf.append(d['sub_state'])
    buf.append(0)
    buf.append(d['unk3'])
    buf.append(0)
    
    for unk, dist in d['lods']:
        buf += struct.pack('<HH', unk, dist)
    
    buf += struct.pack('<H', 0)
    buf += struct.pack('<H', 0)
    buf += struct.pack('<i', d['cn'])
    buf += struct.pack('<hhh', 0, 0, 0)
    buf += struct.pack('<h', 0)
    px, py, pz = position
    buf += struct.pack('<iii',
                       int(round(px * FP)),
                       int(round(py * FP)),
                       int(round(pz * FP)))
    

    cut_index = None
    if tex_materials:
        pages_b, cutouts_b, cut_index = _build_texture_tables(tex_materials, png_dir)
        buf += pages_b
        buf += cutouts_b
    else:
        buf += struct.pack('<i', 1)
        buf += struct.pack('<i', 0)
        buf += b'unnamed' + b'\x00' * 13
        buf += struct.pack('<i', 1)
        buf += b'unnamed' + b'\x00' * 9
        buf += bytes([0, 0])
        buf += struct.pack('<h', 0)
        buf += bytes([0, 0, 0, 0])
        buf += bytes([0xFF, 0xFF, 0xFF])
        buf += bytes([0, 0x80, 0x80, 0, 0])

    buf += struct.pack('<H', len(map_records))
    buf += struct.pack('<h', d['some_var'])
    for mi, rec in enumerate(map_records):
        rec = bytearray(rec)
        if cut_index is not None and mi < len(cut_index):
            ci = cut_index[mi]
            struct.pack_into('<hh', rec, 48, ci, ci)
        buf += bytes(rec)

    return bytes(buf)


def _scene_materials_to_map_records(context):
    try:
        _lfs_enforce_m1()
    except Exception as _e:
        print(f"  [maps] m1 rule skipped: {_e}")
    by_cidx = {}
    for ci, (name, r, g, b, mat_db) in _lfs_pick_cidx_materials().items():
        if ci == 1:
            try:
                import bpy as _b76
                _m76 = _b76.data.materials.get(mat_db) if mat_db else None
            except Exception:
                _m76 = None
            if not (_m76 is not None and (_m76.get('lfs_baked_from') or str(_m76.get('lfs_tex_page') or ''))):
                r, g, b = 76, 76, 76
        by_cidx[ci] = (name, r, g, b, mat_db)

    if not by_cidx:
        for i, name in enumerate(_DEFAULT_SLOT_TABLE):
            by_cidx[i] = (name, 128, 128, 128, None)
    
    planar_by_cidx = {}
    try:
        pm_b64 = context.scene.get('lfs_planar_maps_b64')
        if pm_b64:
            import base64 as _b64
            blob = _b64.b64decode(pm_b64)
            stride = 2 + 52
            for k in range(len(blob) // stride):
                o = k * stride
                pci = struct.unpack_from('<H', blob, o)[0]
                planar_by_cidx[pci] = blob[o+2:o+stride]
            for pci in planar_by_cidx:
                by_cidx.setdefault(pci, (f'island_{pci}', 128, 128, 128, None))
    except Exception as _e:
        print(f"  [planar] skipped planar-map merge: {_e}")

    _DETAIL_AREA_MAX = 0.5
    try:
        _cidx_geom = _compute_cidx_face_geometry(context)
    except Exception as _ge:
        print(f"  [map-face] geometry calc skipped: {_ge}")
        _cidx_geom = {}

    def _geom_for(ci):
        g = _cidx_geom.get(ci)
        if g is None:
            return None
        if g[3] * g[4] > _DETAIL_AREA_MAX:
            return None
        return g

    _GLASS_AT_EXPORT = set(_GLASS_MATERIALS)
    try:
        _sc_ov2 = context.scene.get('lfs_tex_overrides')
        if _sc_ov2:
            for _k2 in _sc_ov2.keys():
                _v2 = str(_sc_ov2[_k2]).lower()
                if 'glass' in _v2 or _v2.startswith('s_'):
                    _GLASS_AT_EXPORT.add(_k2.lower())
    except Exception:
        pass
    try:
        _ap2, _ag2 = _auto_detect_from_scene(
            [m.name for m in bpy.data.materials if m.get('lfs_cidx') is not None])
        _GLASS_AT_EXPORT |= {n.lower() for n in (_ag2 or ())}
    except Exception:
        pass
    max_cidx = max(by_cidx.keys())
    records = []
    for ci in range(max_cidx + 1):
        if ci in planar_by_cidx:
            records.append(planar_by_cidx[ci])
        elif ci in by_cidx:
            name, r, g, b, mat_db = by_cidx[ci]
            if name.lower() in _GLASS_AT_EXPORT:
                r, g, b = 25, 25, 25
            if (r, g, b) == (0, 0, 0):
                r, g, b = 8, 8, 8
            rec = bytearray(_build_default_map_record(ci, name, r, g, b,
                                                      geom=_geom_for(ci)))
            _m = bpy.data.materials.get(mat_db) if mat_db else None
            if _m is not None and _m.get('lfs_map_rot') is not None:
                try:
                    _msf = float(bpy.context.scene.get('lfs_ve_scale_factor', 1.0)) or 1.0
                    struct.pack_into('<I', rec, 24, int(_m['lfs_map_rot']) & 0xffffffff)
                    _mp = _m.get('lfs_map_pos')
                    if _mp is not None and len(_mp) == 3:
                        struct.pack_into('<iii', rec, 28,
                                         *(int(round(float(v)*_msf*65536.0)) for v in _mp))
                    _wh = _m.get('lfs_map_wh')
                    if _wh is not None and len(_wh) == 2:
                        struct.pack_into('<ii', rec, 40,
                                         *(int(round(float(v)*_msf*65536.0)) for v in _wh))
                except Exception as _oe:
                    print(f"  [map-over] {mat_db}: {_oe}")
            records.append(bytes(rec))
        else:
            records.append(_build_default_map_record(ci, f'col_{ci}', 128, 128, 128,
                                                     geom=_geom_for(ci)))
    if planar_by_cidx:
        print(f"  [planar] merged {len(planar_by_cidx)} fitted planar map(s) into export")
    return records


def _setup_vehicle_editor_scene(scene, top_name='new_model'):
    scene['lfs_is_vehicle_editor'] = True
    scene['lfs_ve_top_name'] = top_name
    header = bytes.fromhex('5352454f424a00fc')
    scene['lfs_ve_header'] = base64.b64encode(header).decode('ascii')
    scene['lfs_ve_layout_names_raw'] = base64.b64encode(b'\x00' * 128).decode('ascii')
    scene['lfs_ve_spare_bytes'] = base64.b64encode(b'\x00' * 128).decode('ascii')


class LFS_OT_CreateEmptySre(Operator):
    '''Set up the scene so it can export to SRE without an imported file.
    
    Initializes scene-level metadata AND creates 6 empty placeholder sub-objects
    (wheel, steering, interior, plate, wing, mirror) that LFS requires. After
    this, mark your main body mesh as sub-object type 0, optionally add geometry
    to the placeholders, then export.
    '''
    bl_idname = 'lfs.create_empty_sre'
    bl_label = 'Initialize SRE Scene'
    bl_options = {'REGISTER', 'UNDO'}
    top_name: StringProperty(name='Top Name', default='new_model')
    create_placeholders: BoolProperty(
        name='Create Required Placeholders',
        default=True,
        description='Auto-create empty wheel/steering/interior/plate/wing/mirror sub-objects (LFS requires these)',
    )

    def execute(self, context):
        scene = context.scene
        if any(_lfs_is_imported(o) for o in scene.objects
               if o.type == 'MESH' and 'lfs_subobj_index' in o.keys()):
            self.report({'ERROR'}, "This scene has a car imported from an .sre - it is set up already. "
                                   "Init Scene is for building a car from scratch.")
            return {'CANCELLED'}
        _setup_vehicle_editor_scene(scene, self.top_name)
        
        cidx_to_name = {i: n for i, n in enumerate(_DEFAULT_SLOT_TABLE)}
        for mat in bpy.data.materials:
            if mat.get('lfs_cidx') is not None:
                continue
            cidx = auto_cidx_for_material(mat.name, cidx_to_name)
            if cidx >= 0:
                mat['lfs_cidx'] = cidx
        
        created_count = 0
        if self.create_placeholders:
            try:
                map_records = _scene_materials_to_map_records(context)
            except ValueError as _ce:
                self.report({'ERROR'}, str(_ce))
                return {'CANCELLED'}
            
            existing_indices = {0}
            for o in bpy.data.objects:
                if o.type == 'MESH' and 'lfs_subobj_index' in o.keys():
                    try:
                        existing_indices.add(int(o['lfs_subobj_index']))
                    except (ValueError, TypeError):
                        pass
            
            placeholders = [
                ('LFS_wheel',     2, (-0.4, 0.4, 0.3)),
                ('LFS_steering',  2, (-0.4, 0.5, 1.0)),
                ('LFS_interior',  3, (0.0, 0.0, 0.0)),
                ('LFS_plate',     3, (0.0, -1.6, 0.1)),
                ('LFS_wing',      3, (0.0, -1.5, 1.5)),
                ('LFS_mirror',    10, (0.0, 0.0, 1.0)),
            ]
            
            for name, sub_type, location in placeholders:
                if bpy.data.objects.get(name) is not None:
                    continue
                
                me = bpy.data.meshes.new(name)
                obj = bpy.data.objects.new(name, me)
                obj.location = location
                context.collection.objects.link(obj)
                
                next_idx = 1
                while next_idx in existing_indices:
                    next_idx += 1
                existing_indices.add(next_idx)
                
                obj['lfs_subobj_index'] = next_idx
                obj['lfs_subobj_type'] = sub_type
                obj['lfs_subobj_rotate'] = (0.0, 0.0, 0.0)
                obj['lfs_subobj_original_nv'] = 0
                obj['lfs_subobj_original_nf'] = 0
                
                raw = _build_min_subobj_raw(name[:20], sub_type, location, map_records, tex_materials=_cidx_materials_list(map_records), png_dir=_resolve_png_dir())
                obj['lfs_subobj_raw_b64'] = base64.b64encode(raw).decode('ascii')
                
                obj.hide_set(True)
                obj.hide_render = True
                
                created_count += 1
        
        _tag_redraw(context)
        
        msg = f'Scene initialized as vehicle-editor SRE'
        if created_count:
            msg += f' (auto-created {created_count} placeholder sub-objects: wheel, steering, interior, plate, wing, mirror)'
        msg += '. Now mark your main body mesh as sub-object type 0.'
        self.report({'INFO'}, msg)
        return {'FINISHED'}


def _lfs_shown(o, vl, look=False):
    try:
        if vl.objects.get(o.name) is None:
            return False
        if o.hide_viewport:
            return False
        if look:
            return True
        return bool(o.visible_get(view_layer=vl))
    except Exception:
        return True


_LFS_LOD_RE = re.compile(r'(?i)(?:^|[_\-\s.])lod[_\-\s]?(\d)(?=$|[_\-\s.])')
_LFS_RES_RE = re.compile(r'(?i)(?:^|[_\-\s.])(hi|high|mid|medium|lo|low)(?:[_\-\s]?(?:res|poly|detail))?(?=$|[_\-\s.\d])')
_LFS_RES_LEVEL = {'hi': 0, 'high': 0, 'mid': 1, 'medium': 1, 'lo': 2, 'low': 2}


def _lfs_lod_level(o):
    for nm in [o.name] + [c.name for c in o.users_collection]:
        m = _LFS_LOD_RE.search(nm)
        if m:
            return int(m.group(1))
        m = _LFS_RES_RE.search(nm)
        if m:
            return _LFS_RES_LEVEL[m.group(1).lower()]
    return None


def _lfs_lod_pick(meshes):
    lv = {o.name: _lfs_lod_level(o) for o in meshes}
    levels = {v for v in lv.values() if v is not None}
    if len(levels) < 2:
        return list(meshes), []
    best = min(levels)
    kept = [o for o in meshes if lv[o.name] is None or lv[o.name] == best]
    return kept, [o for o in meshes if lv[o.name] is not None and lv[o.name] != best]


def _lfs_unit_fix(meshes):
    import math
    from mathutils import Vector, Matrix

    def _box(objs):
        lo = [1e30] * 3
        hi = [-1e30] * 3
        for o in objs:
            mw = o.matrix_world
            for c in o.bound_box:
                q = mw @ Vector(c)
                lo = [min(a, b) for a, b in zip(lo, q)]
                hi = [max(a, b) for a, b in zip(hi, q)]
        return [b - a for a, b in zip(lo, hi)] if hi[0] >= lo[0] else [0.0, 0.0, 0.0]
    core = []
    for o in meshes:
        e = _box([o])
        if len(o.data.polygons) > 8 and max(e) > 0 and min(e) >= 0.02 * max(e):
            core.append(o)
    core = core or list(meshes)
    L = max(_box(core))
    if L <= 0.0:
        return 1.0, L, ''
    if not 0.2 <= L <= 100.0:
        cands = [10.0 ** k for k in range(-4, 5)] + [0.0254, 0.3048]
        f = min(cands, key=lambda c: abs(math.log(L * c / 4.5)))
        roots = []
        for o in meshes:
            r = o
            while r.parent is not None:
                r = r.parent
            if r not in roots:
                roots.append(r)
        S = Matrix.Scale(f, 4)
        for r in roots:
            r.matrix_world = S @ r.matrix_world
        return f, L, 'world'
    if L > 15.0:
        D = 0.0
        for o in core:
            e = sorted(_box([o]))
            if e[2] > 0.0 and e[1] >= 0.88 * e[2] and e[0] <= 0.5 * e[1] and 2.0 < e[2] < 0.3 * L:
                D = max(D, e[2])
        if D > 0.0:
            f = min([10.0 ** k for k in range(-4, 1)], key=lambda c: abs(math.log(D * c / 0.65)))
            if f < 1.0:
                roots = []
                for o in meshes:
                    r = o
                    while r.parent is not None:
                        r = r.parent
                    if r not in roots:
                        roots.append(r)
                S = Matrix.Scale(f, 4)
                for r in roots:
                    r.matrix_world = S @ r.matrix_world
                return f, L, 'world'
    big = max(core, key=lambda o: len(o.data.polygons))
    Lb = max(_box([big]))
    if 0.0 < Lb < 0.5 and Lb < 0.05 * L:
        return 1.0, Lb, 'mixed'
    return 1.0, L, ''


_LFS_MERGE_LIMIT = 200


def _lfs_merge_lookalike_materials(objs, limit=_LFS_MERGE_LIMIT):
    mats = []
    for o in objs:
        for s in o.material_slots:
            if s.material and s.material not in mats:
                mats.append(s.material)
    if len(mats) <= limit:
        return len(mats), len(mats)

    def role(m):
        n = m.name.lower()
        return (any(h in n for h in ('glass', 'window', 'lens', 'gls', 'transp')), 'paint' in n,
                any(h in n for h in ('light', 'lamp')), 'chrome' in n,
                any(h in n for h in ('leather', 'seat', 'alcantara', 'fabric', 'cloth')), 'steer' in n,
                any(h in n for h in ('tyre', 'tire', 'rim', 'wheel')))
    info = {}
    for m in mats:
        img = _lfs_base_color_image(m)
        rgb, alpha, trans = _mat_shader_info(m)
        info[m.name] = (img.name if img is not None else None, tuple(int(c) for c in rgb),
                        round(float(alpha), 2), round(float(trans), 2), role(m))
    n_after = len(mats)
    for step in (1, 8, 16, 32):
        rep_ = {}
        remap = {}
        for m in mats:
            img, rgb, alpha, trans, rl = info[m.name]
            k = (img, None if img else tuple(c // step for c in rgb), alpha, trans, rl)
            if k in rep_:
                remap[m.name] = rep_[k]
            else:
                rep_[k] = m
        n_after = len(rep_)
        if n_after <= limit or step == 32:
            for o in objs:
                for s in o.material_slots:
                    if s.material and s.material.name in remap:
                        s.material = remap[s.material.name]
            break
    return len(mats), n_after


def _lfs_stand_up(meshes):
    import re as _re
    import numpy as np
    from mathutils import Vector, Matrix

    def _is_wheel(n):
        n = n.lower()
        if 'steer' in n or any(h in n for h in ('arch', 'well', 'house')):
            return False
        return 'wheel' in n or 'tyre' in n or 'tire' in n or bool(_re.search(r'(?<![a-z])rim', n))

    def _is_glass(o):
        ms = [s.material.name.lower() for s in o.material_slots if s.material]
        if not ms:
            return False
        nm = o.name.lower()
        if any(h in nm for h in ('light', 'lamp', 'lens', 'marker', 'mirror', 'indicator', 'reflector')):
            return False
        return all(any(h in (nm + ' ' + m) for h in ('glass', 'window', 'windshield', 'windscreen'))
                   for m in ms)
    pts = []
    wheels = []
    glass = []
    for o in meshes:
        mw = o.matrix_world
        bb = np.array([tuple(mw @ Vector(c)) for c in o.bound_box])
        pts.append(bb)
        if _is_wheel(o.name):
            wheels.append(bb)
        elif _is_glass(o):
            glass.append(bb)
    if not pts:
        return ''
    P = np.concatenate(pts)
    lo, hi = P.min(axis=0), P.max(axis=0)
    ext = hi - lo
    la = int(np.argmax(ext))
    if la == 1 or ext[la] <= 0 or ext[la] <= 1.2 * max(ext[k] for k in range(3) if k != la):
        return ''
    c = (lo + hi) / 2.0
    cands = [k for k in range(3) if k != la]
    h = None
    up = 0.0
    guess = False
    wc = None
    if wheels:
        W = np.concatenate(wheels)
        wc = W.mean(axis=0)
        vote = {k: 0.0 for k in cands}
        for bb in wheels:
            e = bb.max(axis=0) - bb.min(axis=0)
            s = np.sort(e)
            k = int(np.argmin(e))
            if (k in vote and s[2] >= 0.04 * ext[la] and s[1] >= 0.75 * s[2] and s[0] <= 0.7 * s[1]):
                vote[k] += float(s[2])
        tot = sum(vote.values())
        if tot > 0:
            kw = max(vote, key=vote.get)
            if vote[kw] >= 0.75 * tot:
                h = [k for k in cands if k != kw][0]
        if h is None:
            off = {k: abs(wc[k] - c[k]) / max(ext[k], 1e-9) for k in cands}
            ko = max(off, key=off.get)
            if off[ko] >= 0.08 and off[ko] >= 1.5 * min(off.values()):
                h = ko
    gc = None
    if glass:
        G = np.concatenate(glass)
        gc = G.mean(axis=0)
        if h is None:
            off = {k: abs(gc[k] - c[k]) / max(ext[k], 1e-9) for k in cands}
            ko = max(off, key=off.get)
            if off[ko] >= 0.08 and off[ko] >= 1.5 * min(off.values()):
                h = ko
    if h is None:
        guess = True
        h = 2 if 2 in cands else min(cands, key=lambda k: ext[k])
    if wc is not None and abs(wc[h] - c[h]) >= 0.06 * ext[h]:
        up = 1.0 if wc[h] < c[h] else -1.0
    elif gc is not None and abs(gc[h] - c[h]) >= 0.06 * ext[h]:
        up = 1.0 if gc[h] > c[h] else -1.0
    else:
        up = 1.0
        guess = guess or h != 2
    w = [k for k in cands if k != h][0]
    rows = np.zeros((3, 3))
    rows[0, w] = 1.0
    rows[1, la] = 1.0
    rows[2, h] = up
    if np.linalg.det(rows) < 0:
        rows[0, w] = -1.0
    nc = rows @ c
    tr = (-nc[0], -nc[1], -(nc[2] - ext[h] / 2.0))
    M = Matrix([list(rows[0]) + [tr[0]], list(rows[1]) + [tr[1]], list(rows[2]) + [tr[2]],
                [0.0, 0.0, 0.0, 1.0]])
    roots = []
    for o in meshes:
        r = o
        while r.parent is not None:
            r = r.parent
        if r not in roots:
            roots.append(r)
    for r in roots:
        r.matrix_world = M @ r.matrix_world
    kind = 'end' if la == 2 else ('x' if (h == 2 and up > 0) else 'x_side')
    return kind + ('?' if guess else '')


_LFS_NAME_LOOKS = {
    'glass':      ((16, 20, 22), 0.35, 0.0, 0.05),
    'lens':       ((235, 235, 235), 0.25, 0.0, 0.05),
    'tyre':       ((22, 22, 22), 1.0, 0.0, 0.9),
    'rim':        ((170, 172, 175), 1.0, 1.0, 0.3),
    'brake':      ((90, 90, 92), 1.0, 1.0, 0.5),
    'metal':      ((140, 142, 145), 1.0, 1.0, 0.4),
    'chrome':     ((220, 222, 225), 1.0, 1.0, 0.1),
    'carbon':     ((28, 28, 30), 1.0, 0.0, 0.3),
    'interior':   ((38, 38, 40), 1.0, 0.0, 0.8),
    'steering':   ((30, 30, 30), 1.0, 0.0, 0.7),
    'light':      ((200, 200, 200), 1.0, 0.5, 0.2),
    'black plastic': ((18, 18, 18), 1.0, 0.0, 0.6),
    'chassis':    ((45, 45, 47), 1.0, 0.0, 0.8),
    'plain':      ((128, 128, 128), 1.0, 0.0, 0.5),
}


def _lfs_role_from_name(name):
    n = name.lower().replace('-', '_')

    def has(*ws):
        return any(w in n for w in ws)
    if has('mirror_center', 'mirror_centre', 'mirrorglass', 'mirror_glass', 'mirror glass', 'mirror_left',
           'mirror_right', 'mirror_face'):
        return 'chrome'
    if has('caliper', 'brakerotor', 'rotoredge', 'brake', 'rotor'):
        return 'brake'
    if has('tyre', 'tire', 'sidewall', 'tread'):
        return 'tyre'
    if (has('gls_clear', 'gls_colo', 'gls_ml', 'lens', 'reflector')
            or (has('light', 'lamp') and has('glass', 'gls', 'clear'))):
        return 'lens'
    if (has('gls', 'windshield', 'windscreen', 'limotint', 'glassinner', 'glass_inner')
            or (has('glass', 'window') and not has('fiber', 'fibre', 'frame', 'trim', 'seal', 'surround',
                                                    'switch', 'regulator', 'black'))):
        return 'glass'
    if has('steer'):
        return 'steering'
    if (re.search(r'(?<![a-z])rim', n) or has('wheel', 'center_cap', 'centre_cap', 'hubcap')) \
            and not has('arch', 'well', 'house'):
        return 'rim'
    if has('carbon'):
        return 'carbon'
    if has('chrome', 'badge', 'emblem', 'logo', 'gold', 'brass', 'bronze', 'titanium'):
        return 'chrome'
    if has('paintedmetal', 'painted_metal', 'gunmetal', 'alumin', 'steel', 'metal', 'exhaust', 'muffler',
           'radiator', 'screw', 'bolt', 'anodized', 'weld', 'rollcage', 'roll_cage'):
        return 'metal'
    if has('interior', 'seat', 'leather', 'alcantara', 'fabric', 'cloth', 'felt', 'carpet', 'stitch',
           'dash', 'headlin', 'doorcard', 'door_card', 'cockpit', 'console', 'gauge', 'needle', 'screen',
           'pedal', 'belt'):
        return 'interior'
    if has('light', 'lamp', 'indicator', 'blinker', 'drl'):
        return 'light'
    if has('rubber', 'plastic', 'black', 'grille', 'grill', 'mesh', 'vent', 'wiper', 'seal', 'trim',
           'frame', 'label', 'nylon', 'backfacing'):
        return 'black plastic'
    if has('chassis', 'underbody', 'under_body', 'undercarriage', 'floor', 'engine', 'suspens', 'axle',
           'subframe', 'diffuser', 'fluid', 'tank', 'battery'):
        return 'chassis'
    return None


def _lfs_name_materials(meshes):
    import bpy
    bare = [o for o in meshes if not any(s.material for s in o.material_slots)]
    _has_own = len(bare) < len(meshes)
    if not bare:
        return {}
    done = {}
    seen_me = set()
    for o in bare:
        me = o.data
        if me.name in seen_me:
            continue
        seen_me.add(me.name)
        role = _lfs_role_from_name(o.name + ' ' + me.name)
        if role is None and _has_own:
            role = 'plain'
        if role is None:
            m = bpy.data.materials.get('m1') or bpy.data.materials.new('m1')
            if m.get('lfs_cidx') is None:
                m['lfs_cidx'] = 1
            key = 'paint'
        else:
            key = role
            m = bpy.data.materials.get('auto ' + role)
            if m is None:
                m = bpy.data.materials.new('auto ' + role)
                (sr, sg, sb), a, met, rough = _LFS_NAME_LOOKS[role]
                lin = [((c / 255.0 + 0.055) / 1.055) ** 2.4 if c / 255.0 > 0.04045 else c / 255.0 / 12.92
                       for c in (sr, sg, sb)]
                try:
                    if m.node_tree is None:
                        m.use_nodes = True
                    b = next((n for n in m.node_tree.nodes if n.type == 'BSDF_PRINCIPLED'), None)
                    if b is not None:
                        b.inputs['Base Color'].default_value = (lin[0], lin[1], lin[2], 1.0)
                        b.inputs['Metallic'].default_value = met
                        b.inputs['Roughness'].default_value = rough
                        b.inputs['Alpha'].default_value = a
                except Exception as _ne:
                    print(f"  [auto-setup] {m.name}: node set-up skipped: {_ne!r}")
                m.diffuse_color = (sr / 255.0, sg / 255.0, sb / 255.0, a)
                if a < 1.0:
                    for _at, _v in (('surface_render_method', 'BLENDED'), ('blend_method', 'BLEND')):
                        try:
                            setattr(m, _at, _v)
                            break
                        except Exception:
                            pass
                m['lfs_auto_material'] = role
        if len(me.materials) == 0:
            me.materials.append(m)
        else:
            for i in range(len(me.materials)):
                if me.materials[i] is None:
                    me.materials[i] = m
        done[key] = done.get(key, 0) + 1
    return done


def _lfs_backdrop_objects(meshes):
    from mathutils import Vector

    def _ext(objs):
        pts = [o.matrix_world @ Vector(c) for o in objs for c in o.bound_box]
        if not pts:
            return [0.0, 0.0, 0.0]
        return [max(q[i] for q in pts) - min(q[i] for q in pts) for i in range(3)]
    size = {o.name: _ext([o]) for o in meshes}
    cand = [o for o in meshes if max(size[o.name]) >= 6.0]
    if not cand:
        return []
    rest = [o for o in meshes if o not in cand]
    if not rest:
        return []
    box = {}
    for o in rest:
        pts = [o.matrix_world @ Vector(c) for c in o.bound_box]
        box[o.name] = ([min(q[i] for q in pts) - 0.05 for i in range(3)],
                       [max(q[i] for q in pts) + 0.05 for i in range(3)])
    root = {o.name: o.name for o in rest}

    def _find(n):
        while root[n] != n:
            root[n] = root[root[n]]
            n = root[n]
        return n
    names = [o.name for o in rest]
    for i_, a in enumerate(names):
        la, ha = box[a]
        for b in names[i_ + 1:]:
            lb, hb = box[b]
            if all(la[k] <= hb[k] and lb[k] <= ha[k] for k in range(3)):
                ra, rb = _find(a), _find(b)
                if ra != rb:
                    root[ra] = rb
    faces = {}
    for o in rest:
        r_ = _find(o.name)
        faces[r_] = faces.get(r_, 0) + len(o.data.polygons)
    core_root = max(faces, key=faces.get)
    core = [o for o in rest if _find(o.name) == core_root]
    R = max(_ext(core))
    if R <= 0.0:
        return []
    _cl = [min(box[o.name][0][k] + 0.05 for o in core) for k in range(3)]
    _ch = [max(box[o.name][1][k] - 0.05 for o in core) for k in range(3)]
    _ce = [b - a for a, b in zip(_cl, _ch)]
    _core_ok = max(_ce) >= 1.0
    _core_faces = sum(len(o.data.polygons) for o in core)
    out = []
    for o in cand:
        d = size[o.name]; L = max(d)
        flat = min(d) < 0.02 * L or len(o.data.polygons) <= 8
        if flat and L > 1.5 * R:
            out.append(o)
            continue
        if not _core_ok:
            continue
        if L > 3.0 * R and d[0] >= 2.0 * _ce[0] and d[1] >= 2.0 * _ce[1]:
            out.append(o)
            continue
        pts = [o.matrix_world @ Vector(c) for c in o.bound_box]
        lo = [min(q[i] for q in pts) for i in range(3)]
        hi = [max(q[i] for q in pts) for i in range(3)]
        if (d[0] >= 1.5 * _ce[0] and d[1] >= 1.5 * _ce[1]
                and (lo[2] + hi[2]) / 2 < _cl[2] + 0.25 * _ce[2]):
            out.append(o)
        elif (not all(lo[k] <= _ch[k] + 0.05 and _cl[k] - 0.05 <= hi[k] for k in range(3))
              and len(o.data.polygons) <= 4 * _core_faces):
            out.append(o)
    return out


def _lfs_tidy_parts(scene, vl, part_names, anc_names):
    import bpy
    from mathutils import Matrix
    try:
        vl.update()
    except Exception:
        pass
    n_p = 0
    for nm in part_names:
        o = bpy.data.objects.get(nm)
        if o is None or o.parent is None:
            continue
        mw = o.matrix_world.copy()
        res = None
        m2 = mw
        try:
            loc, rot, sca = mw.decompose()
            m2 = Matrix.LocRotScale(loc, rot, sca)
            res = m2.inverted() @ mw
        except Exception:
            res = None; m2 = mw
        o.parent = None
        o.matrix_parent_inverse = Matrix.Identity(4)
        if res is not None and any(abs(res[i][j] - (1.0 if i == j else 0.0)) > 1e-6
                                   for i in range(4) for j in range(4)):
            if o.data.users > 1:
                o.data = o.data.copy()
            o.data.transform(res)
            o.data.update()
        o.matrix_world = m2
        n_p += 1
    if n_p:
        try:
            vl.update()
        except Exception:
            pass

    def _keeps(e, depth=0):
        if depth > 64:
            return True
        for ch in e.children:
            if scene not in ch.users_scene:
                continue
            if ch.type != 'EMPTY' or ch.instance_type != 'NONE' or _keeps(ch, depth + 1):
                return True
        return False
    left = []
    for nm in anc_names:
        e = bpy.data.objects.get(nm)
        if (e is None or e.type != 'EMPTY' or e.instance_type != 'NONE' or e.library is not None
                or 'lfs_subobj_index' in e.keys() or _keeps(e)):
            continue
        if scene not in e.users_scene:
            continue
        left.append(e)
    def _desc(e, depth=0):
        if depth > 64:
            return
        for ch in e.children:
            if scene in ch.users_scene and ch.type == 'EMPTY' and ch not in left:
                left.append(ch)
                _desc(ch, depth + 1)
    for e in list(left):
        _desc(e)
    n_e = 0
    if left:
        coll = bpy.data.collections.get('Auto Setup leftovers')
        if coll is None or coll.library is not None:
            coll = bpy.data.collections.new('Auto Setup leftovers')
        if coll.name not in scene.collection.children.keys():
            scene.collection.children.link(coll)
        for e in left:
            if coll not in e.users_collection:
                coll.objects.link(e)
            for c in list(e.users_collection):
                if c is not coll:
                    try:
                        c.objects.unlink(e)
                    except Exception:
                        pass
            n_e += 1
        try:
            lc = vl.layer_collection.children.get(coll.name)
            if lc is not None:
                lc.exclude = True
        except Exception:
            pass
    return n_p, n_e


def _lfs_restore_copies(scene, meshes, depsgraph):
    import bpy, re
    from mathutils import Matrix
    in_scene = set(scene.objects)
    mset = set(meshes)

    def base(n):
        return re.sub(r'[\s._\-]*\d+$', '', n.lower()).strip()

    def mesh_desc(e, depth=0):
        out = []
        if depth > 32:
            return out
        for ch in e.children:
            if ch not in in_scene:
                continue
            if ch.type == 'MESH' and ch in mset:
                out.append(ch)
            out += mesh_desc(ch, depth + 1)
        return out
    empties = [o for o in scene.objects if o.type == 'EMPTY' and o.instance_type == 'NONE' and o.library is None]
    new, notes = [], []
    for e in empties:
        if any(ch in in_scene for ch in e.children):
            continue
        b = base(e.name)
        if len(b) < 2:
            continue
        srcs = []
        for s_ in empties:
            if s_ is e or s_.parent != e.parent or base(s_.name) != b:
                continue
            ds = mesh_desc(s_)
            if ds:
                srcs.append((s_, ds))
        if not srcs:
            continue
        src, ds = next(((s_, d_) for s_, d_ in srcs if s_.name.lower() == b), None) or \
            max(srcs, key=lambda sd: len(sd[1]))
        if len(ds) > 60:
            continue
        M = e.matrix_world @ src.matrix_world.inverted_safe()
        if max(abs(M[i][j] - (1.0 if i == j else 0.0)) for i in range(4) for j in range(4)) < 1e-6:
            continue
        k = 0
        for d in ds:
            try:
                me = bpy.data.meshes.new_from_object(d.evaluated_get(depsgraph), preserve_all_data_layers=True,
                                                     depsgraph=depsgraph)
            except Exception:
                me = d.data.copy()
            W = M @ d.matrix_world
            me.transform(W)
            if W.to_3x3().determinant() < 0.0:
                try:
                    me.flip_normals()
                except Exception:
                    import bmesh
                    bm = bmesh.new(); bm.from_mesh(me)
                    bmesh.ops.reverse_faces(bm, faces=bm.faces[:])
                    bm.to_mesh(me); bm.free()
            me.update()
            ob = bpy.data.objects.new((d.name + '_' + e.name)[:63], me)
            for c in (d.users_collection or [scene.collection]):
                try:
                    c.objects.link(ob)
                except Exception:
                    pass
            ob.parent = e
            ob.matrix_parent_inverse = e.matrix_world.inverted_safe()
            ob.matrix_basis = Matrix.Identity(4)
            for i, sl in enumerate(d.material_slots):
                if i < len(ob.material_slots) and sl.material is not None and ob.material_slots[i].material != sl.material:
                    ob.material_slots[i].link = 'OBJECT'
                    ob.material_slots[i].material = sl.material
            ob['lfs_copy_of'] = d.name
            new.append(ob)
            k += 1
        if k:
            notes.append((e.name, src.name, k))
    return new, notes


def _lfs_half_model(scene, vl, groups, depsgraph):
    import bpy
    import numpy as np
    from mathutils import Matrix
    info = {}
    for g, ns in groups.items():
        for nm in ns:
            o = bpy.data.objects.get(nm)
            if o is None or o.type != 'MESH' or nm in info:
                continue
            try:
                ev = o.evaluated_get(depsgraph)
                me = ev.to_mesh()
                n = len(me.vertices)
                if n == 0:
                    ev.to_mesh_clear()
                    continue
                co = np.empty(n * 3, np.float64)
                me.vertices.foreach_get('co', co)
                ar = np.empty(len(me.polygons), np.float64)
                me.polygons.foreach_get('area', ar)
                ev.to_mesh_clear()
            except Exception:
                continue
            Mw = np.array(o.matrix_world, dtype=np.float64)
            w = co.reshape(-1, 3) @ Mw[:3, :3].T + Mw[:3, 3]
            sca = abs(np.linalg.det(Mw[:3, :3])) ** (2.0 / 3.0)
            info[nm] = dict(o=o, g=g, lo=w.min(0), hi=w.max(0), nf=len(ar), area=float(ar.sum()) * sca,
                            mods=bool(o.modifiers))
    if len(info) < 3:
        return None
    lo = np.min([v['lo'] for v in info.values()], axis=0)
    hi = np.max([v['hi'] for v in info.values()], axis=0)
    W = float(hi[0] - lo[0])
    if W <= 0.0:
        return None
    m = 0.5 * float(hi[0] + lo[0])
    outside = [nm for nm, v in info.items() if v['g'] in ('BODY', 'GLASSTRIM')]
    body_area = sum(info[n_]['area'] for n_ in outside) or 1.0
    halves = {-1: [], 1: []}
    for nm in outside:
        v = info[nm]
        x0, x1 = float(v['lo'][0]), float(v['hi'][0])
        if x1 - x0 < 0.15 * W:
            continue
        if abs(x1 - m) < 0.06 * W and x0 < m - 0.25 * W:
            halves[-1].append((x1, v['area']))
        elif abs(x0 - m) < 0.06 * W and x1 > m + 0.25 * W:
            halves[1].append((x0, v['area']))
    area = {k_: sum(h[1] for h in halves[k_]) for k_ in (-1, 1)}
    side = -1 if area[-1] >= area[1] else 1
    if area[side] < 0.25 * body_area or area[-side] > 0.2 * area[side]:
        return None
    es = sorted(halves[side])
    tot = sum(e_[1] for e_ in es)
    acc = 0.0
    xc = es[-1][0]
    for e_ in es:
        acc += e_[1]
        if acc >= 0.5 * tot:
            xc = e_[0]
            break
    dx = -float(xc)
    if abs(dx) > 1e-7:
        T = Matrix.Translation((dx, 0.0, 0.0))
        roots = []
        for v in info.values():
            r = v['o']
            while r.parent is not None:
                r = r.parent
            if r not in roots:
                roots.append(r)
        for r in roots:
            r.matrix_world = T @ r.matrix_world
        for v in info.values():
            v['lo'] = v['lo'] + np.array([dx, 0.0, 0.0])
            v['hi'] = v['hi'] + np.array([dx, 0.0, 0.0])
        try:
            vl.update()
        except Exception:
            pass
    tol = 0.01 * W
    tw = max(0.02, 0.02 * W)

    def _twin(nm):
        a_ = info[nm]
        for on, b_ in info.items():
            if on == nm:
                continue
            if not (0.8 <= (b_['nf'] + 1.0) / (a_['nf'] + 1.0) <= 1.25):
                continue
            if (abs(b_['lo'][0] + a_['hi'][0]) < tw and abs(b_['hi'][0] + a_['lo'][0]) < tw
                    and abs(b_['lo'][1] - a_['lo'][1]) < tw and abs(b_['hi'][1] - a_['hi'][1]) < tw
                    and abs(b_['lo'][2] - a_['lo'][2]) < tw and abs(b_['hi'][2] - a_['hi'][2]) < tw):
                return True
        return False

    def _on(v_, sd):
        return (v_['hi'][0] <= tol and v_['lo'][0] < -tol) if sd < 0 else (v_['lo'][0] >= -tol and v_['hi'][0] > tol)
    marked = []
    for nm, v in info.items():
        if v['mods'] or v['g'] == 'STEERING':
            continue
        if v['g'] in ('BODY', 'GLASSTRIM'):
            ok = _on(v, side)
        elif v['g'] == 'WHEELS':
            ok = _on(v, -1) or _on(v, 1)
        elif v['g'] == 'INTERIOR':
            ok = _on(v, side) and (v['hi'][0] < -0.25 * W if side < 0 else v['lo'][0] > 0.25 * W)
        else:
            ok = False
        if ok and not _twin(nm):
            marked.append(nm)
    snapped = 0
    snap = max(0.002, 0.005 * W)
    for nm in marked:
        o = info[nm]['o']
        me = o.data
        if me.users > 1:
            o.data = me = me.copy()
        n = len(me.vertices)
        co = np.empty(n * 3, np.float64)
        me.vertices.foreach_get('co', co)
        co = co.reshape(-1, 3)
        Mw = np.array(o.matrix_world, dtype=np.float64)
        A = Mw[:3, :3]
        t = Mw[:3, 3]
        w = co @ A.T + t
        sel = np.abs(w[:, 0]) < snap
        if sel.any():
            w[sel, 0] = 0.0
            try:
                co2 = (w - t) @ np.linalg.inv(A).T
                co[sel] = co2[sel]
                me.vertices.foreach_set('co', co.ravel())
                snapped += int(sel.sum())
            except np.linalg.LinAlgError:
                pass
        at = me.attributes.get('lfs_mirrored')
        if at is not None and (at.domain != 'FACE' or at.data_type != 'INT'):
            me.attributes.remove(at)
            at = None
        if at is None:
            at = me.attributes.new('lfs_mirrored', 'INT', 'FACE')
        at.data.foreach_set('value', [1] * len(me.polygons))
        me.update()
    return {'side': side, 'shift': dx, 'snapped': snapped, 'marked': marked}


class LFS_OT_AutoSetup(Operator):
    """Sort a model from another format into the parts LFS needs: its meshes are
    grouped by name and material into body, interior, wheels and steering wheel, and each
    group is joined and marked as an LFS part. It also finds textures that are not where the
    .blend says, and turns a car that faces backwards round (LFS's forward is +Y)"""
    bl_idname = "lfs.auto_setup"
    bl_label = "Auto Setup"
    bl_options = {'REGISTER', 'UNDO'}

    split_by_material: BoolProperty(
        name="Sort by material names too",
        description="Also sort faces by the name of their material (leather, seat, dash: "
                    "interior; rim, tyre, brake: wheels; steering: steering wheel) - for a "
                    "model made of one mesh, or with parts that have no useful names",
        default=True,
    )

    def execute(self, context):
        import bmesh
        scene = context.scene
        vl = context.view_layer

        meshes = [o for o in scene.objects if o.type == 'MESH'
                  and not o.get('lfs_preview_only')]
        if not meshes:
            self.report({'ERROR'}, "No meshes in scene.")
            return {'CANCELLED'}
        if any(o.get('lfs_subobj_raw_b64') and int(o.get('lfs_subobj_original_nf', 0) or 0) > 0
               for o in meshes):
            self.report({'INFO'}, "This car came from an .sre and is set up already - edit it and "
                                  "export. To add a part, use Join Selected Into... (SRE Sub-Objects). "
                                  "Auto Setup is for models from other formats (FBX, OBJ...).")
            return {'CANCELLED'}
        _look_on = bool(scene.get('lfs_look_attached'))
        _shown = [o for o in meshes if _lfs_shown(o, vl, _look_on)]
        _hidden_out = [o for o in meshes if o not in _shown]
        if not _shown:
            self.report({'ERROR'}, f"None of the {len(meshes)} meshes is shown: switch on their collections "
                                   "(the tick box in the Outliner) and show the objects that belong to the "
                                   "car, then run Auto Setup again.")
            return {'CANCELLED'}
        meshes = _shown
        if _hidden_out:
            print(f"  [auto-setup] left out {len(_hidden_out)} hidden or switched-off mesh(es): "
                  + ", ".join(o.name for o in _hidden_out[:12]))
        meshes, _lod_out = _lfs_lod_pick(meshes)
        if _lod_out:
            print(f"  [auto-setup] left out {len(_lod_out)} less detailed copies: "
                  + ", ".join(o.name for o in _lod_out[:12]))
        _copies = []
        try:
            _new9, _copies = _lfs_restore_copies(scene, meshes, context.evaluated_depsgraph_get())
            if _new9:
                meshes = list(meshes) + _new9
                try:
                    vl.update()
                except Exception:
                    pass
                print("  [auto-setup] empty copies (3ds Max) filled: "
                      + ", ".join(f"{e_} <- {s_} ({k_})" for e_, s_, k_ in _copies))
        except Exception as _rce:
            import traceback as _tb8
            _tb8.print_exc()
            print(f"  [auto-setup] filling the empty copies skipped: {_rce!r}")
            _copies = []
        _n_faces = sum(len(o.data.polygons) for o in meshes)
        _unit_f, _unit_L, _unit_how = 1.0, 0.0, ''
        try:
            _unit_f, _unit_L, _unit_how = _lfs_unit_fix(meshes)
            if _unit_f != 1.0:
                try:
                    vl.update()
                except Exception:
                    pass
                print(f"  [auto-setup] scaled x{_unit_f:g}: {_unit_L:.3g} m before")
            elif _unit_how == 'mixed':
                print(f"  [auto-setup] units mixed up: the body is {_unit_L:.3g} m, far apart parts")
        except Exception as _ue:
            print(f"  [auto-setup] size check skipped: {_ue!r}")
        _backdrop = _lfs_backdrop_objects(meshes)
        if _backdrop:
            meshes = [o for o in meshes if o not in _backdrop]
            print("  [auto-setup] left out (a floor or a studio panel): " + ", ".join(o.name for o in _backdrop))
        _stood = ''
        try:
            _stood = _lfs_stand_up(meshes)
            if _stood:
                try:
                    vl.update()
                except Exception:
                    pass
                print(f"  [auto-setup] the car lay wrong ({_stood}) - turned it: length along Y, top up, on the ground")
        except Exception as _se:
            print(f"  [auto-setup] upright check skipped: {_se!r}")
        _named = {}
        try:
            _named = _lfs_name_materials(meshes)
            if _named:
                print("  [auto-setup] meshes with no material, by name: "
                      + ", ".join(f"{k} {v}" for k, v in sorted(_named.items(), key=lambda kv: -kv[1])))
        except Exception as _nm:
            print(f"  [auto-setup] naming materials skipped: {_nm!r}")
        _front = (0, '')
        try:
            _front = _lfs_front_hint(meshes)
            if _front[0]:
                print(f"  [auto-setup] front at {'+' if _front[0] > 0 else '-'}Y by {_front[1]}")
        except Exception as _fe:
            print(f"  [auto-setup] front check skipped: {_fe!r}")
        _found_tex, _missing_tex = _lfs_find_missing_images(meshes)
        for _m9 in bpy.data.materials:
            if 'lfs_cidx_orig' in _m9.keys():
                del _m9['lfs_cidx_orig']

        _TR = str.maketrans('çğıöşüäéèêáàíóú', 'cgiosuaeeeaaiou')

        def _words(n):
            return set(w for w in re.split(r'[^a-z0-9]+', n.translate(_TR)) if w)

        def cat(name):
            n = name.lower().translate(_TR)
            _w = _words(n)
            if any(k in n for k in ('steer', 'driving_wheel', 'driving wheel',
                                    'rulek', 'volant', 'lenkrad', 'direksiyon', 'kierownic', 'stuurwiel')):
                return 'STEERING'
            if (any(k in n for k in ('jant', 'lastik', 'teker', 'felge', 'reifen', 'rueda', 'llanta',
                                     'neumatic', 'pneu', 'ruota', 'cerchio', 'opona', 'velg'))
                    and not any(k in n for k in ('bandeja',))) or _w & {'roue', 'rad', 'kolo', 'gomma', 'wiel'}:
                return 'WHEELS'
            if (any(k in n for k in ('koltuk', 'konsol', 'gosterge', 'torpido', 'vites', 'el-freni', 'emniyet',
                                     'sitz', 'armaturen', 'innen', 'asiento', 'tablero', 'siege', 'tableau',
                                     'sedile', 'cruscotto', 'fotel', 'deska', 'banco', 'painel', 'bedal',
                                     'kokpit', 'interieur', 'innenraum', 'dashboard'))
                    or _w & {'ic', 'interno', 'interni', 'wnetrze', 'zetel', 'stoel'}):
                return 'INTERIOR'
            if re.match(r'^(fl|fr|rl|rr)(w|wheel|_wheel)?(\.\d+)?$', n.strip()):
                return 'WHEELS'
            if 'wheel' in n or 'tyre' in n or 'tire' in n or re.search(r'(?<![a-z])rim', n):
                return 'WHEELS'
            if any(k in n for k in ('interior', 'dash', 'seat', 'cockpit',
                                    'pedal', 'btn', 'button', 'lcd',
                                    'gauge', 'console', 'shifter')) \
                    or re.search(r'(?<![a-z])int(?![a-z])', n):
                return 'INTERIOR'
            return 'BODY'

        def mat_cat(name):
            n = name.lower()
            n = n.translate(_TR)
            if re.search(r'steer|volant|lenkrad|direksiyon|kierownic', n):
                return 'STEERING'
            if any(k in n for k in ('light', 'lamp', 'glass', 'lens', 'paint')):
                return 'BODY'
            if re.search(r'(?<![a-z])rim|tyre|tire|wheel|brake|calip|rotor|hubcap|jant|lastik|teker|felge|'
                         r'reifen|llanta|neumatic|pneu', n):
                return 'WHEELS'
            if re.search(r'interior|leather|seat|dash|carpet|fabric|alcantara|cloth|'
                         r'stitch|gauge|speaker|pedal|console|cockpit|cabin|upholst|'
                         r'suede|headlin|instrument|(?<![a-z])int(?![a-z])|koltuk|konsol|deri|kumas|'
                         r'gosterge|torpido|leder|sitz|cuero|asiento|cuir|siege|pelle|sedile|skora|fotel|'
                         r'(?<![a-z])ic(?![a-z])', n.replace('cabine', '').replace('kabine', '')):
                return 'INTERIOR'
            return 'BODY'

        def keep_faces(me, mask):
            bm = bmesh.new()
            bm.from_mesh(me)
            dead = [f for f, k in zip(bm.faces, mask) if not k]
            if dead:
                bmesh.ops.delete(bm, geom=dead, context='FACES')
            bm.to_mesh(me)
            bm.free()
            me.update()

        groups = {'BODY': [], 'INTERIOR': [], 'WHEELS': [], 'STEERING': [],
                  'GLASSTRIM': []}
        def cat_obj(o):
            c_ = cat(o.name)
            q_ = o.parent
            _hops = 0
            while c_ == 'BODY' and q_ is not None and _hops < 8:
                c_ = cat(q_.name)
                q_ = q_.parent; _hops += 1
            return c_
        for o in meshes:
            groups[cat_obj(o)].append(o.name)
        _big = max(meshes, key=lambda o: o.dimensions.length)
        for g in ('INTERIOR', 'WHEELS', 'STEERING', 'GLASSTRIM'):
            if _big.name in groups[g]:
                groups[g].remove(_big.name); groups['BODY'].append(_big.name)

        _dg = context.evaluated_depsgraph_get()

        kept = []
        for nm in list(groups['BODY']):
            o = bpy.data.objects[nm]
            if o is _big or re.match(r'^(body|glasstrim)\d*(\.\d+)?$', nm.lower()):
                continue
            try:
                t = int(o.get('lfs_subobj_type', 0)) if 'lfs_subobj_index' in o.keys() else 0
            except Exception:
                t = 0
            if t == 0:
                continue
            groups['BODY'].remove(nm)
            if t == 2:
                groups['STEERING'].append(nm)
            else:
                kept.append((nm, t))

        _split_log = []
        _shell_mat = None
        try:
            _sa = {}
            for _p in _big.data.polygons:
                if _p.material_index < len(_big.material_slots):
                    _sm = _big.material_slots[_p.material_index].material
                    if _sm is not None:
                        _sa[_sm.name] = _sa.get(_sm.name, 0.0) + _p.area
            if _sa:
                _shell_mat = max(_sa, key=_sa.get)
        except Exception:
            _shell_mat = None
        if self.split_by_material:
            for nm in list(groups['BODY']):
                o = bpy.data.objects.get(nm)
                if o is None or o.type != 'MESH' or not o.data.polygons:
                    continue
                slot_cat = [('BODY' if sl.material.name == _shell_mat else mat_cat(sl.material.name))
                            if sl.material else 'BODY'
                            for sl in o.material_slots]
                if all(c == 'BODY' for c in slot_cat):
                    continue
                if o.modifiers:
                    try:
                        _me = bpy.data.meshes.new_from_object(
                            o.evaluated_get(_dg), preserve_all_data_layers=True, depsgraph=_dg)
                        _me.name = o.data.name + '_baked'
                        o.data = _me
                        o.modifiers.clear()
                    except Exception as _be:
                        print(f"  [auto-setup] {o.name}: modifier bake skipped: {_be}")
                        continue
                me = o.data
                ns = len(slot_cat)
                fcat = [slot_cat[p.material_index] if p.material_index < ns else 'BODY'
                        for p in me.polygons]
                present = set(fcat)
                if present == {'BODY'}:
                    continue
                if 'BODY' not in present and len(groups['BODY']) == 1:
                    continue
                if me.users > 1:
                    me = o.data = me.copy()
                moved = []
                for g in ('INTERIOR', 'WHEELS', 'STEERING'):
                    if g not in present:
                        continue
                    no = o.copy()
                    no.data = me.copy()
                    no.name = f"{o.name}_{g.lower()}"
                    for coll in o.users_collection:
                        coll.objects.link(no)
                    for k in list(no.keys()):
                        if k.startswith('lfs_subobj'):
                            del no[k]
                    keep_faces(no.data, [c == g for c in fcat])
                    groups[g].append(no.name)
                    moved.append(f"{fcat.count(g)} faces -> {g}")
                if 'BODY' in present:
                    keep_faces(me, [c == 'BODY' for c in fcat])
                else:
                    groups['BODY'].remove(nm)
                    bpy.data.objects.remove(o)
                _split_log.append(f"{nm}: " + ", ".join(moved))
                print(f"  [auto-setup] split by material {_split_log[-1]}")
        if _split_log:
            try:
                vl.update()
            except Exception:
                pass

        _dg = context.evaluated_depsgraph_get()
        def _ev_nv(name):
            try:
                _o = bpy.data.objects[name]
                _me = _o.evaluated_get(_dg).to_mesh()
                _n = len(_me.vertices)
                _o.evaluated_get(_dg).to_mesh_clear()
                return _n
            except Exception:
                return len(bpy.data.objects[name].data.vertices)
        if sum(_ev_nv(nm) for nm in groups['BODY']) > 32767:
            _trim_hints = ('light', 'lamp', 'glass', 'window', 'grill', 'wing',
                           'spoiler', 'exhaust', 'mirror', 'trim', 'rubber',
                           'chrome', 'badge', 'logo')
            for nm in list(groups['BODY']):
                if any(h in nm.lower() for h in _trim_hints):
                    groups['BODY'].remove(nm)
                    groups['GLASSTRIM'].append(nm)

        _half = None
        try:
            try:
                vl.update()
            except Exception:
                pass
            _half = _lfs_half_model(scene, vl, groups, context.evaluated_depsgraph_get())
            if _half:
                print(f"  [auto-setup] half model ({'left' if _half['side'] < 0 else 'right'} side): moved "
                      f"{_half['shift'] * 1000:+.1f} mm across, {_half['snapped']} point(s) put on the centre "
                      f"line, {len(_half['marked'])} piece(s) for LFS to mirror: " + ", ".join(_half['marked'][:14]))
        except Exception as _hme:
            import traceback as _tb9
            _tb9.print_exc()
            print(f"  [auto-setup] half model check skipped: {_hme!r}")
            _half = None
        for o in [x for x in scene.objects if x.type == 'MESH']:
            for k in list(o.keys()):
                if k.startswith('lfs_subobj'):
                    del o[k]

        try:
            if context.mode != 'OBJECT':
                bpy.ops.object.mode_set(mode='OBJECT')
        except Exception:
            pass

        def join(names, result_name):
            def _live():
                return {x.name for x in vl.objects if x is not None}
            names = [n for n in names if n in bpy.data.objects]
            _live_names = _live()
            if any(n not in _live_names for n in names):
                try:
                    vl.update()
                except Exception:
                    pass
                _live_names = _live()
                for n in [x for x in names if x not in _live_names]:
                    ob = bpy.data.objects[n]
                    if not ob.users_collection:
                        scene.collection.objects.link(ob)
                try:
                    vl.update()
                except Exception:
                    pass
                _live_names = _live()
                _lost = [n for n in names if n not in _live_names]
                if _lost:
                    print(f"  [auto-setup] WARN: not in the view layer, skipped: {_lost[:4]}")
            names = [n for n in names if n in _live_names]
            if not names:
                return None
            objs = [bpy.data.objects[n] for n in names]
            for o in objs:
                if o.modifiers:
                    try:
                        _ev = o.evaluated_get(_dg)
                        _me = bpy.data.meshes.new_from_object(
                            _ev, preserve_all_data_layers=True, depsgraph=_dg)
                        _me.name = o.data.name + '_baked'
                        o.data = _me
                        o.modifiers.clear()
                    except Exception as _be:
                        print(f"  [auto-setup] {o.name}: modifier bake skipped: {_be}")
            for x in vl.objects:
                if x is not None:
                    x.select_set(False)
            vl.objects.active = objs[0]
            for o in objs:
                o.select_set(True)
            if len(objs) > 1:
                try:
                    with context.temp_override(active_object=objs[0],
                                               selected_objects=objs,
                                               selected_editable_objects=objs):
                        bpy.ops.object.join()
                except Exception:
                    bpy.ops.object.join()
            j = vl.objects.active
            j.name = result_name
            return j.name

        made = []
        _anc9 = set()
        for _g9 in list(groups.values()):
            for _n9 in _g9:
                _q9 = bpy.data.objects.get(_n9)
                _q9 = _q9.parent if _q9 is not None else None
                _h9 = 0
                while _q9 is not None and _h9 < 64:
                    _anc9.add(_q9.name)
                    _q9 = _q9.parent; _h9 += 1
        plan = [('BODY', 0), ('INTERIOR', 3), ('STEERING', 2), ('WHEELS', 3),
                ('GLASSTRIM', 3)]
        for _kn, _kt in kept:
            groups[_kn] = [_kn]
            plan.append((_kn, _kt))
        for gname, gtype in plan:
            if not groups[gname]:
                continue
            chunks = _autosetup_chunk_group(groups[gname], _dg)
            for k, names in enumerate(chunks):
                cname = gname if k == 0 else f"{gname}{k + 1}"
                rn = join(names, cname)
                if rn is None:
                    continue
                made.append((rn, gtype if k == 0 else (3 if gtype == 0 else gtype)))
            if len(chunks) > 1:
                self.report({'WARNING'},
                            f"{gname} was over the LFS limits - split into {len(chunks)} sub-objects.")
        _unpar, _tidy = 0, 0
        try:
            _unpar, _tidy = _lfs_tidy_parts(scene, vl, [rn for rn, _t in made], _anc9)
            if _unpar or _tidy:
                print(f"  [auto-setup] {_unpar} part(s) out from under the model's empties, {_tidy} empty "
                      f"object(s) with nothing left under them -> collection 'Auto Setup leftovers' (off)")
        except Exception as _tde:
            print(f"  [auto-setup] tidying the outliner skipped: {_tde!r}")
        _turned = False
        _facing_unknown = False
        try:
            _parts = [bpy.data.objects[rn] for rn, _t in made if rn in bpy.data.objects]
            _stn = next((rn for rn, _t in made if _t == 2), None)
            _turned = _lfs_face_plus_y(_parts, _stn, _front)
            _off0 = _lfs_steer_offset(_parts, bpy.data.objects.get(_stn) if _stn else None)
            _facing_unknown = not _turned and not (_front and _front[0]) and (_off0 is None or abs(_off0) <= 0.05)
        except Exception as _te:
            print(f"  [auto-setup] facing check skipped: {_te}")

        _merged = (0, 0)
        try:
            _merged = _lfs_merge_lookalike_materials([bpy.data.objects[rn] for rn, _t in made
                                                      if rn in bpy.data.objects])
            if _merged[0] != _merged[1]:
                print(f"  [auto-setup] {_merged[0]} materials -> {_merged[1]} (look-alikes made one)")
        except Exception as _mg:
            print(f"  [auto-setup] material merge skipped: {_mg!r}")
        names = []
        _made_names = {rn for rn, _t in made}
        for o in bpy.data.objects:
            if o.type != 'MESH' or o.get('lfs_preview_only'):
                continue
            if _made_names and o.name not in _made_names:
                continue
            for s in o.material_slots:
                if s.material and s.material.name not in names:
                    names.append(s.material.name)
        paint = [n for n in names if any(p in n.lower()
                 for p in ('paint', 'varnish', 'body', 'm1'))]
        ordered = paint + sorted(n for n in names if n not in paint)
        try:
            _lfs_assign_cidx(ordered, paint_names=set(paint[:1]))
        except ValueError as _ce:
            self.report({'ERROR'}, str(_ce))
            return {'CANCELLED'}
        try:
            _pm = _lfs_enforce_m1()
            if _pm is not None:
                print(f"  [auto-setup] paint = {_pm.name} -> m1")
        except Exception as _e:
            print(f"  [auto-setup] m1 rule skipped: {_e}")

        scene['lfs_ve_no_auto_mirror'] = True
        if not scene.get('lfs_is_vehicle_editor'):
            _setup_vehicle_editor_scene(scene)
        try:
            map_records = _scene_materials_to_map_records(context)
            _cidx_materials_list(map_records)
        except ValueError as _ce:
            self.report({'ERROR'}, str(_ce))
            return {'CANCELLED'}
        next_idx = 0
        for rn, gtype in made:
            obj = bpy.data.objects[rn]
            for k in list(obj.keys()):
                if k.startswith('lfs_subobj'):
                    del obj[k]
            obj['lfs_subobj_index'] = next_idx
            obj['lfs_subobj_type'] = gtype
            obj['lfs_subobj_rotate'] = (0.0, 0.0, 0.0)
            obj['lfs_subobj_original_nv'] = 0
            obj['lfs_subobj_original_nf'] = 0
            position = (obj.location.x, obj.location.y, obj.location.z)
            raw = _build_min_subobj_raw(
                obj.name[:20], gtype, position, map_records,
                tex_materials=_cidx_materials_list(map_records),
                png_dir=_resolve_png_dir())
            obj['lfs_subobj_raw_b64'] = base64.b64encode(raw).decode('ascii')
            if not obj.data.materials:
                m1 = bpy.data.materials.get('m1') or bpy.data.materials.new('m1')
                if m1.get('lfs_cidx') is None:
                    m1['lfs_cidx'] = 1
                obj.data.materials.append(m1)
            next_idx += 1

        _kind = {0: 'body', 2: 'steering wheel', 3: 'part'}
        summary = ", ".join(f"{rn} ({_kind.get(t, 'type %d' % t)})" for rn, t in made)
        msg = f"Auto Setup made {len(made)} LFS part(s): {summary}."
        if _backdrop:
            _bn = ", ".join(o.name for o in _backdrop[:3]) + (" ..." if len(_backdrop) > 3 else "")
            msg += (f" Left out {len(_backdrop)} object(s) that look like a floor, a studio panel or scenery "
                    f"({_bn}) - mark them by hand if they belong to the car.")
        if _stood:
            if _stood.startswith('end'):
                msg += " Stood the car up: it came in on its nose or tail (the file's axes were not converted)."
            elif _stood.startswith('x_side'):
                msg += " Turned the car upright with its length along Y: it came in on its side (the file's axes)."
            else:
                msg += " Turned the car a quarter turn: its length lay along X, LFS's length is along Y."
            if _stood.endswith('?'):
                msg += (" It has no wheels or windows that show which side is up: if it is upside down, "
                        "turn it over and run Auto Setup again.")
        if _named and any(k != 'paint' for k in _named):
            _nn = sum(_named.values())
            _nl = ", ".join(f"{k} {v}" for k, v in sorted(_named.items(), key=lambda kv: -kv[1]) if k != 'paint')
            _nl += ("; the rest paint" if 'paint' in _named else "")
            msg += (f" {_nn} mesh(es) had no material: gave them one by their names ({_nl}) - "
                    f"change any that are wrong in the Material tab ('auto ...' materials) and run Bake.")
        if _turned:
            msg += " Turned the car round to face +Y, LFS's forward (Rotate 180 turns it back)."
        elif _facing_unknown:
            msg += (" Nothing told its front from its back (no steering wheel, no head or tail lights by name): "
                    "LFS's forward is +Y - if it faces the other way, press Rotate 180.")
        if _unit_how == 'mixed':
            msg += (f" The parts are far too small for how far apart they sit (the body is {_unit_L:.2g} m): "
                    f"the model's units are mixed up - import it again with other scale settings, or "
                    f"give the parts their real size, then run it again.")
        elif _unit_f != 1.0:
            msg += (f" Scaled the car x{_unit_f:g}: it was {_unit_L:.2g} m long (its units were not "
                    f"metres).")
        if _hidden_out:
            msg += (f" Left out {len(_hidden_out)} mesh(es) that are hidden or in switched-off collections - "
                    f"show them and run it again if they belong to the car.")
        if _lod_out:
            msg += f" Left out {len(_lod_out)} less detailed copies (LOD) of the car's meshes."
        if _copies:
            msg += (f" Filled {len(_copies)} empty copies from 3ds Max with the pieces they copy ("
                    + ", ".join(f"{e_} from {s_}" for e_, s_, k_ in _copies[:4])
                    + (" ..." if len(_copies) > 4 else "") + ").")
        if _half:
            msg += (f" Its outside is one half of the car ({'left' if _half['side'] < 0 else 'right'} side): LFS mirrors "
                    f"{len(_half['marked'])} piece(s) to the other side, the centre line on the car's middle"
                    + (f" (moved {abs(_half['shift']) * 1000:.0f} mm)" if abs(_half['shift']) >= 0.0005 else "") + ".")
        if _merged[0] != _merged[1]:
            msg += (f" Made its {_merged[0]} materials into {_merged[1]}: the ones that look the same are one now "
                    f"(LFS has room for 236 maps).")
        if _n_faces > 300000:
            msg += (f" The car has {_n_faces:,} faces - LFS cars usually have under 100,000: Bake takes long "
                    f"and LFS runs slowly. A less detailed version (LOD) or Decimate helps.")
        _tn = _lfs_missing_note(_found_tex, _missing_tex)
        if _tn:
            msg += " " + _tn
        if _unpar or _tidy:
            msg += (f" The parts are at the top of the Outliner now" + (f" (they were under the model's empties)"
                    if _unpar else "") + (f"; the {_tidy} empty object(s) their meshes hung under are in the "
                    f"collection 'Auto Setup leftovers', switched off" if _tidy else "") + ".")
        msg += " Next: Bake Textures for LFS."
        if _split_log:
            print("  [auto-setup] split by material: " + "; ".join(_split_log))
        self.report({'WARNING'} if (_missing_tex or _unit_how == 'mixed') else {'INFO'}, msg)
        return {'FINISHED'}


class LFS_OT_MakeSubObj(Operator):
    '''Turn the selected mesh(es) into LFS sub-objects so they can be exported.
    
    Each selected mesh becomes its own sub-object with the chosen type.
    Type 0 = main body, 3 = most parts (detail, interior, wheels), 2 = steering wheel,
    10 = rear-view mirror.
    '''
    bl_idname = 'lfs.make_subobj'
    bl_label = 'Mark as Sub-Object'
    bl_options = {'REGISTER', 'UNDO'}
    sub_type: EnumProperty(
        name='Sub-Object Type',
        items=[
            ('0', 'Main Body (type 0)', 'The main body - only one allowed per file'),
            ('1', 'Generic (type 1)', 'Generic sub-object'),
            ('2', 'Steering wheel (type 2)', 'The steering wheel'),
            ('3', 'Detail (type 3)', 'Most parts: trim, interior, wheels, number plate, wing...'),
            ('10', 'Mirror (type 10)', 'The interior rear-view mirror'),
        ],
        default='3',
    )

    def execute(self, context):
        if not context.scene.get('lfs_is_vehicle_editor'):
            _setup_vehicle_editor_scene(context.scene)
        
        selected = [o for o in context.selected_objects if o.type == 'MESH'
                    and not o.get('lfs_preview_only')]
        if not selected:
            self.report({'ERROR'}, 'Select one or more meshes first.')
            return {'CANCELLED'}
        
        existing_indices = set()
        for o in bpy.data.objects:
            if o.type == 'MESH' and 'lfs_subobj_index' in o.keys():
                try:
                    existing_indices.add(int(o['lfs_subobj_index']))
                except (ValueError, TypeError):
                    pass
        next_idx = 0
        while next_idx in existing_indices:
            next_idx += 1
        
        try:
            map_records = _scene_materials_to_map_records(context)
            _build_texture_tables(_cidx_materials_list(map_records), _resolve_png_dir())
        except ValueError as _ce:
            self.report({'ERROR'}, str(_ce))
            return {'CANCELLED'}

        sub_type_int = int(self.sub_type)
        count = 0
        for obj in selected:
            if 'lfs_subobj_index' in obj.keys():
                continue
            
            obj['lfs_subobj_index'] = next_idx
            obj['lfs_subobj_type'] = sub_type_int
            obj['lfs_subobj_rotate'] = (0.0, 0.0, 0.0)
            obj['lfs_subobj_original_nv'] = 0
            obj['lfs_subobj_original_nf'] = 0
            
            position = (obj.location.x, obj.location.y, obj.location.z)
            raw = _build_min_subobj_raw(obj.name[:20], sub_type_int, position, map_records, tex_materials=_cidx_materials_list(map_records), png_dir=_resolve_png_dir())
            obj['lfs_subobj_raw_b64'] = base64.b64encode(raw).decode('ascii')
            
            if not obj.data.materials:
                m1 = bpy.data.materials.get('m1') or bpy.data.materials.new('m1')
                if m1.get('lfs_cidx') is None:
                    m1['lfs_cidx'] = 1
                obj.data.materials.append(m1)
            
            count += 1
            next_idx += 1
            while next_idx in existing_indices:
                next_idx += 1
        
        _tag_redraw(context)
        self.report({'INFO'},
            f'Marked {count} mesh(es) as sub-objects (type {sub_type_int}).')
        return {'FINISHED'}


_LFS_PROGRESS = [False]
_LFS_LAST_REPORT = ['']


def _lfs_progress(i=None, n=None, end=False):
    try:
        wm = bpy.context.window_manager
        if end:
            if _LFS_PROGRESS[0]:
                wm.progress_end()
            _LFS_PROGRESS[0] = False
        elif n is not None:
            wm.progress_begin(0, max(1, int(n)))
            _LFS_PROGRESS[0] = True
        elif i is not None and _LFS_PROGRESS[0]:
            wm.progress_update(int(i))
    except Exception:
        pass


def _lfs_other_copies():
    own = __package__ or ''
    if not own:
        return []
    out = []
    try:
        for name in bpy.context.preferences.addons.keys():
            base = name.split('.')[-1]
            if name != own and base.startswith(('lfs_sre_exporter', 'lfs_sre_importer',
                                                'io_import_lfs_sre', 'lfs_sre_tools')):
                out.append(base)
    except Exception:
        pass
    return sorted(set(out))


def _lfs_addon_version():
    import sys as _sys
    m = _sys.modules.get(__package__) if __package__ else _sys.modules.get(__name__)
    v = None
    try:
        import addon_utils
        v = addon_utils.module_bl_info(m).get('version') if m is not None else None
    except Exception:
        v = None
    if not v:
        bi = getattr(m, 'bl_info', None) or globals().get('bl_info') or {}
        v = bi.get('version')
    return '.'.join(str(x) for x in v) if v else '?'


class LFS_OT_CopyBugReport(Operator):
    """Copy what is needed to look into a problem - versions, settings, the scene in short and
    the last messages - to paste where you ask for help (no file paths: your user name stays out)"""
    bl_idname = "lfs.copy_bug_report"
    bl_label = "Copy Bug Report"

    def execute(self, context):
        import os, platform
        home = os.path.expanduser('~')

        def clean(s):
            s = str(s)
            if home and len(home) > 3:
                i = s.lower().find(home.lower())
                while i >= 0:
                    s = s[:i] + '~' + s[i + len(home):]
                    i = s.lower().find(home.lower())
            return s

        pkg = __package__ or __name__
        kind = 'extension' if pkg.startswith('bl_ext.') else ('add-on' if __package__ else 'single-file add-on')
        L = [f"LFS SRE Tools {_lfs_addon_version()} ({kind}) - bug report"]
        try:
            L.append(f"Blender {bpy.app.version_string} ({bpy.app.build_hash.decode(errors='replace')[:12]}) - "
                     f"{platform.platform()}")
        except Exception:
            pass
        try:
            import gpu
            L.append("GPU: " + gpu.platform.renderer_get())
        except Exception:
            pass
        dups = _lfs_other_copies()
        L.append("Other LFS add-ons on: " + (", ".join(dups) if dups else "none"))
        sc = context.scene
        try:
            pp = _png_prefs()
            pd = _resolve_png_dir() or ''
            how = ('set in preferences' if (pp is not None and getattr(pp, 'png_dir', ''))
                   else 'found by the import' if sc.get('lfs_png_dir') else 'not set')
            if pd and os.path.isdir(pd):
                n = len([f for f in os.listdir(pd) if f.lower().endswith('.png')])
                L.append(f"Texture folder: {how}, ...{os.sep}{os.sep.join(pd.rstrip(os.sep).split(os.sep)[-2:])} "
                         f"({n} .png)")
            else:
                L.append(f"Texture folder: {how}" + (", not found" if pd else ""))
            if pp is not None:
                L.append("LFS look: " + ", ".join(f"{k}={getattr(pp, k)}" for k in
                                                  ('look_on_import', 'look_live', 'look_show')
                                                  if hasattr(pp, k)))
        except Exception as e:
            L.append(f"Texture folder: ? ({e})")
        try:
            ve = [o for o in sc.objects if o.type == 'MESH' and 'lfs_subobj_index' in o.keys()]
            nf = sum(len(o.data.polygons) for o in ve)
            def _tp(o):
                b = o.get('lfs_subobj_raw_b64', '')
                try:
                    return base64.b64decode(b)[1] if b else o.get('lfs_subobj_type', 3)
                except Exception:
                    return o.get('lfs_subobj_type', 3)
            nb = sum(1 for o in ve if _tp(o) == 0)
            src = sc.get('lfs_last_import_path')
            L.append(f"Scene: {len(ve)} sub-object(s), {nf} faces, {nb} body"
                     + (f", imported from {os.path.basename(str(src))}" if src else ", not imported")
                     + (", LFS look built" if sc.get('lfs_look_scene') else ""))
            L.append(f"Smooth angle: {sc.get('lfs_ve_smooth_angle', 30.0)}  mode: {context.mode}")
        except Exception as e:
            L.append(f"Scene: ? ({e})")
        lines = []
        try:
            before = {tx.name for tx in bpy.data.texts}
            bpy.ops.ui.reports_to_textblock()
            tx = next((tx for tx in bpy.data.texts if tx.name not in before), None) \
                or bpy.data.texts.get('Recent Reports')
            if tx is not None:
                lines = [ln.body for ln in tx.lines if ln.body.strip()][-30:]
                if tx.name not in before:
                    bpy.data.texts.remove(tx)
        except Exception:
            pass
        L.append("Last messages:" if lines else "Last messages: none")
        L += ["  " + ln for ln in lines]
        text = clean("\n".join(L))
        _LFS_LAST_REPORT[0] = text
        try:
            context.window_manager.clipboard = text
        except Exception:
            pass
        print(text)
        self.report({'INFO'}, "Bug report copied - paste it where you ask for help")
        return {'FINISHED'}


def _ve_export_notes(sre_path):
    import os
    notes = []
    pages = sorted(_EXPORT_CACHE.get('pages') or ())
    pd = _resolve_png_dir() or ''
    if pages and pd and os.path.isdir(pd):
        have = {f.lower() for f in os.listdir(pd)}
        miss = [pg for pg in pages if not pg.lower().startswith('s_') and (pg + '.png').lower() not in have
                and pg.lower() not in have]
        _skd = os.path.join(os.path.dirname(os.path.normpath(pd)), 'skins')
        try:
            _sk = {f.lower() for f in os.listdir(_skd)} if os.path.isdir(_skd) else set()
        except OSError:
            _sk = set()
        miss = [pg for pg in miss if (pg + '.jpg').lower() not in _sk and (pg + '.png').lower() not in _sk]
        if miss:
            notes.append(f"{len(miss)} texture page(s) are not in your texture folder: "
                         + ", ".join(miss[:4]) + (", ..." if len(miss) > 4 else "")
                         + " - the editor shows them blank")
    for nm, nv in (_EXPORT_CACHE.get('over') or [])[:3]:
        notes.append(f"'{nm}' has {nv} points, more than the 32767 LFS reads (it came like this from the file)")
    for nm, nb in (_EXPORT_CACHE.get('badn') or [])[:3]:
        notes.append(f"'{nm}': {nb} point(s) get no normal (the editor says bad normals) - usually triangles "
                     "standing on the centre line of a mirrored part, whose mirror copy faces the other way: delete them")
    hint = ''
    if os.path.basename(os.path.dirname(os.path.abspath(sre_path))).lower() != '3dob':
        hint = "saved outside a data\\3dob folder - the vehicle editor lists cars from there"
    return notes, hint


class LFS_OT_ExportSRE(Operator, ExportHelper):
    """Export the current scene to a vehicle-editor SRE file"""
    bl_idname = "export_scene.lfs_sre"
    bl_label = "Export LFS SRE"
    filename_ext = ".sre"
    filter_glob: StringProperty(default="*.sre", options={'HIDDEN'})
    use_selection: BoolProperty(
        name="Selected Only",
        description="Export only selected sub-objects. OFF = export ALL "
                    "sub-objects in the scene (recommended).",
        default=False)
    auto_mirror: BoolProperty(
        name="Auto-Mirror (half model)",
        description="ON: your mesh is HALF the car and LFS mirrors it to the "
                    "other side (doubles the in-game geometry). OFF: your mesh "
                    "is the FULL car already, exported as-is. Leave OFF for "
                    "complete/symmetric models - ON can overflow the 32767 "
                    "vertex limit.",
        default=False)
    recalc_normals: BoolProperty(
        name="Recalc normals (leave OFF)",
        description="OFF (default): preserve the model's original normals exactly "
                    "- this is almost always what you want and matches Blender. "
                    "ON: force-recalculate outward, which can flip interiors/"
                    "wheels the wrong way. Only enable for models with genuinely "
                    "broken normals.",
        default=False)
    scale_mode: EnumProperty(
        name="Size",
        description="How to size the model in LFS (LFS uses metres)",
        items=[
            ('ASIS', "As-is (Blender units = metres)",
             "Export at the model's current Blender size"),
            ('LENGTH', "Fit to real length",
             "Scale the whole model so its longest axis = the length you enter"),
        ],
        default='ASIS')
    real_length: FloatProperty(
        name="Real length (m)",
        description="Target real-world length in metres for the longest axis "
                    "(e.g. 4.83 for an Opel Insignia). Used when Size = Fit to "
                    "real length.",
        default=4.5, min=0.1, max=100.0)
    simple_groups: BoolProperty(
        name="Simple groups (1 per panel)",
        description="Parts made in Blender: build the groups from the UV islands, then fold "
                    "small islands (mouldings, strips) into the panel they border most, down "
                    "to ~24 panels - one group per panel like a hand-made LFS car. Ignores "
                    "the sharp edges of the model (noise on PBR / game rips)",
        default=False)
    uv_seam_groups: BoolProperty(
        name="Panel seams from UV islands",
        description="Parts made in Blender: also treat UV-island boundaries as hard panel "
                    "seams. Essential for PBR/game models whose "
                    "panel gaps are painted in the normal map instead of "
                    "modelled - without it whole car sides fuse into one "
                    "group. Turn OFF only if UV seams create unwanted hard "
                    "edges on smooth surfaces.",
        default=True)
    auto_smooth: BoolProperty(
        name="Re-derive groups by angle",
        description="Parts made in Blender: also put a hard edge where faces bend more than "
                    "the Smooth angle, on top of the sharp edges you marked. Leave OFF when "
                    "you marked the hard edges yourself (Auto Smooth Groups or by hand) - "
                    "then the export is exactly what you see. A part with no sharp edges "
                    "marked is split by the angle anyway.\n\n"
                    "Imported parts are not changed by this: their faces keep their groups, "
                    "and new or edited faces always follow the sharp edges and the Smooth angle",
        default=False)
    smooth_angle: FloatProperty(
        name="Smooth angle",
        description="Faces that meet at more than this angle get a hard edge. Decides which "
                    "new or edited faces of an imported part shade into the faces around them, "
                    "and the groups of a part made in Blender that has no sharp edges marked "
                    "(or with Re-derive groups by angle). Lower = crisper (try 20 for sharp "
                    "bodywork), higher = softer (45-60 for rounded shapes); 30 is Blender's "
                    "default",
        default=30.0, min=1.0, max=180.0)
    fast_smoothing: BoolProperty(
        name="Fast (no groups)",
        description="Parts made in Blender: skip the smoothing groups - much faster export for "
                    "dense/environment meshes (trees, billboards, terrain). "
                    "Leave OFF for vehicles where you want crisp panel shading.",
        default=False)
    over_limits: BoolProperty(
        name="Export past LFS's limits",
        description="OFF: the export stops when a part is past what the LFS editor can load - "
                    "more than 236 maps or 238 cutouts (the editor crashes). ON: the file is "
                    "written anyway and the report lists what is past the limits. The .sre "
                    "format's own limits (32767 points and 65535 triangles in one part, 255 maps) "
                    "can never be passed",
        default=False)
    corner_dark: BoolProperty(
        name="Darker hidden corners",
        description="LFS lights every point with the whole sky (it has no ambient occlusion): the footwells, "
                    "under the dash, vents and the gaps round the seats come out as bright as the roof. ON: "
                    "each new point gets LFS's own ambient darkness (bright / dark / very dark / extra dark) "
                    "from how much sky it sees past the car's parts. Points from an LFS file keep theirs. "
                    "TEST: the darkness levels are not checked in the editor yet - off by default",
        default=False, options={'SKIP_SAVE'})
    apply_subsurf: BoolProperty(
        name="Apply Subdivision",
        description="ON: bake Subdivision-Surface modifiers into the export "
                    "(higher poly, smoother). OFF: export the base cage instead "
                    "(keeps subsurf in Blender for preview only). Turn OFF if a "
                    "sub-object exceeds the 32767 vertex limit.",
        default=True)

    def draw(self, context):
        layout = self.layout
        layout.prop(self, "use_selection")
        layout.prop(self, "auto_mirror")
        layout.prop(self, "apply_subsurf")
        layout.prop(self, "corner_dark")
        box = layout.box()
        box.label(text="Smoothing groups", icon='MOD_SMOOTH')
        box.prop(self, "smooth_angle")
        col = box.column(align=True)
        col.label(text="Only for parts made in Blender:")
        sub = col.column(align=True)
        sub.enabled = not self.fast_smoothing
        sub.prop(self, "simple_groups")
        sub.prop(self, "uv_seam_groups")
        sub.prop(self, "auto_smooth")
        col.prop(self, "fast_smoothing")
        layout.prop(self, "recalc_normals")
        layout.separator()
        layout.prop(self, "scale_mode")
        if self.scale_mode == 'LENGTH':
            layout.prop(self, "real_length")
        layout.prop(self, "over_limits")
        n = len([o for o in context.scene.objects
                 if o.type == 'MESH' and 'lfs_subobj_index' in o.keys()])
        layout.label(text=str(n) + " sub-object(s) in scene", icon='OBJECT_DATA')

    def invoke(self, context, event):
        try:
            self.smooth_angle = float(context.scene.get('lfs_ve_smooth_angle', self.smooth_angle))
        except (TypeError, ValueError):
            pass
        try:
            import os as _os
            if not self.filepath:
                _p = context.scene.get('lfs_last_export_path') or context.scene.get('lfs_last_import_path')
                if _p and _os.path.isdir(_os.path.dirname(str(_p))):
                    self.filepath = str(_p)
        except Exception:
            pass
        return ExportHelper.invoke(self, context, event)

    def execute(self, context):
        _LFS_OVER['on'] = bool(self.over_limits)
        _LFS_OVER['export'] = True
        try:
            return self._execute_export(context)
        finally:
            _LFS_OVER['on'] = False
            _LFS_OVER['export'] = False

    def _execute_export(self, context):
        context.scene['lfs_ve_no_auto_mirror'] = (not self.auto_mirror)
        context.scene['lfs_ve_apply_subsurf'] = self.apply_subsurf
        context.scene['lfs_ve_corner_dark'] = bool(self.corner_dark)
        _LFS_AO_CACHE['key'] = None
        context.scene['lfs_ve_fast_smoothing'] = self.fast_smoothing
        context.scene['lfs_ve_auto_smooth'] = self.auto_smooth
        context.scene['lfs_ve_smooth_angle'] = float(self.smooth_angle)
        context.scene['lfs_ve_uv_seam_groups'] = self.uv_seam_groups
        context.scene['lfs_ve_group_mode_angle'] = self.simple_groups
        scale_factor = 1.0
        if self.scale_mode == 'LENGTH':
            mins = [1e18] * 3; maxs = [-1e18] * 3
            for o in context.scene.objects:
                if o.type != 'MESH' or 'lfs_subobj_index' not in o.keys():
                    continue
                for v in o.data.vertices:
                    w = o.matrix_world @ v.co
                    for i in range(3):
                        mins[i] = min(mins[i], w[i]); maxs[i] = max(maxs[i], w[i])
            longest = max(maxs[i] - mins[i] for i in range(3))
            if longest > 0:
                scale_factor = self.real_length / longest
        context.scene['lfs_ve_scale_factor'] = scale_factor

        objects = (context.selected_objects if self.use_selection
                  else context.scene.objects)
        objects = [o for o in objects if o.type == 'MESH']
        ve_objects = [o for o in objects if 'lfs_subobj_index' in o.keys()]

        if not ve_objects:
            self.report({'ERROR'},
                "No vehicle-editor sub-objects in scene. Import an SRE first.")
            return {'CANCELLED'}

        if self.recalc_normals:
            import bmesh as _bm
            for _o in ve_objects:
                try:
                    _b = _bm.new(); _b.from_mesh(_o.data)
                    _bm.ops.recalc_face_normals(_b, faces=_b.faces)
                    _b.to_mesh(_o.data); _b.free(); _o.data.update()
                except Exception:
                    pass


        def _so_type(o):
            b = o.get('lfs_subobj_raw_b64')
            if b:
                try:
                    import base64 as _b64
                    return _b64.b64decode(b)[1]
                except Exception:
                    pass
            return o.get('lfs_subobj_type', 3)
        type0 = [o for o in ve_objects if _so_type(o) == 0 and not _ve_is_phantom(o)]
        if len(type0) > 1:
            names = ", ".join(o.name for o in type0)
            self.report({'WARNING'},
                "Multiple type-0 (main body) sub-objects: " + names +
                ". LFS wants exactly one - set the others to Interior/Detail "
                "(type 3) or Steering (type 2), or they may not show.")

        print(f"[ve-export] Exporting {len(ve_objects)} sub-objects")
        _lfs_progress(n=len(ve_objects))
        try:
            sre_bytes = build_vehicle_editor_sre(context, ve_objects, apply_mods=True)
        except Exception as e:
            self.report({'ERROR'}, f"Export failed: {e}")
            traceback.print_exc()
            return {'CANCELLED'}
        finally:
            _lfs_progress(end=True)

        import os as _os, shutil as _sh
        _bak = ''
        if _os.path.isfile(self.filepath):
            try:
                _bak = self.filepath + '.bak'
                _sh.copy2(self.filepath, _bak)
            except Exception as _e:
                _bak = ''
                self.report({'WARNING'}, f"Could not keep the old file as .bak: {_e}")
        Path(self.filepath).write_bytes(sre_bytes)
        try:
            context.scene['lfs_last_export_path'] = self.filepath
        except Exception:
            pass
        name = Path(self.filepath).stem[:20]
        _st = _EXPORT_CACHE.get('stats') or [0, 0]
        _skipped = _EXPORT_CACHE.get('no_raw') or []
        total_v, total_f = int(_st[0]), int(_st[1])
        if _skipped:
            self.report({'WARNING'},
                "Skipped (not marked as sub-object): " + ", ".join(_skipped)
                + " - use Mark as Sub-Object and export again.")
        _thin = int(_EXPORT_CACHE.get('thin') or 0)
        if _thin:
            self.report({'WARNING'},
                "%d sliver or tiny triangle(s) the LFS editor calls too thin / too small were dropped "
                "(under 0.22 mm high or 0.045 mm2)." % _thin)
        _over = list(_EXPORT_CACHE.get('over_lim') or [])
        if _over:
            self.report({'WARNING'},
                "Written past LFS's limits: " + "; ".join(_over[:6])
                + " - the LFS editor may crash on this car.")
        _msg = ("\u2713 " + name + ".sre - " + str(len(ve_objects) - len(_skipped)) + " sub-objs, "
                + str(total_v) + "v " + str(total_f) + "f" + (" (old file kept as .bak)" if _bak else ""))
        try:
            _notes, _hint = _ve_export_notes(self.filepath)
        except Exception:
            _notes, _hint = [], ''
        if _notes:
            self.report({'WARNING'}, _msg + ". " + "; ".join(_notes + ([_hint] if _hint else [])))
        else:
            self.report({'INFO'}, _msg + (". " + _hint if _hint else ""))
        return {'FINISHED'}


class LFS_OT_AutoMapMaterials(Operator):
    """Give every material the LFS map with the most similar name"""
    bl_idname = "lfs.auto_map_materials"
    bl_label = "Auto-Map Materials"
    bl_options = {'REGISTER', 'UNDO'}
    overwrite: BoolProperty(name="Overwrite Existing", default=False)

    def execute(self, context):
        cidx_to_name = _get_scene_map_names(context)
        if not cidx_to_name:
            self.report({'WARNING'},
                "No map names available. Import an SRE first.")
            return {'CANCELLED'}

        used_mats = set()
        for o in context.scene.objects:
            if o.type == 'MESH':
                for s in o.material_slots:
                    if s.material:
                        used_mats.add(s.material)

        matched = 0
        unmatched = []
        for mat in used_mats:
            if not self.overwrite and mat.get('lfs_cidx') is not None:
                continue
            cidx = auto_cidx_for_material(mat.name, cidx_to_name)
            if cidx >= 0:
                mat['lfs_cidx'] = cidx
                matched += 1
            else:
                unmatched.append(mat.name)

        _tag_redraw(context)

        msg = "Auto-mapped " + str(matched) + " material(s)"
        if unmatched:
            msg += "; " + str(len(unmatched)) + " unmatched"
        self.report({'INFO'}, msg)
        return {'FINISHED'}


class LFS_OT_ClearMaterialCidx(Operator):
    """Take the map choice off this material (it goes back to automatic)"""
    bl_idname = "lfs.clear_material_cidx"
    bl_label = "Clear Map Choice"
    bl_options = {'REGISTER', 'UNDO'}
    material_name: StringProperty()

    def execute(self, context):
        mat = bpy.data.materials.get(self.material_name)
        if mat and 'lfs_cidx' in mat:
            del mat['lfs_cidx']
        _tag_redraw(context)
        return {'FINISHED'}


class LFS_OT_ClearAllMaterialCidx(Operator):
    """Take the map choice off every material"""
    bl_idname = "lfs.clear_all_material_cidx"
    bl_label = "Clear All Map Choices"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        count = 0
        for mat in bpy.data.materials:
            if 'lfs_cidx' in mat:
                del mat['lfs_cidx']
                count += 1
        _tag_redraw(context)
        self.report({'INFO'}, "Took the map choice off " + str(count) + " material(s)")
        return {'FINISHED'}


class LFS_OT_JoinToSubObj(Operator):
    """Join the selected new meshes INTO the sub-object you pick, so they export with it.
    Meshes that are not sub-objects are not exported - this is the way to add a part
    to an imported car. Their materials keep working: a new material exports as a colour"""
    bl_idname = "lfs.join_to_subobj"
    bl_label = "Join Selected Into Sub-Object"
    bl_options = {'REGISTER', 'UNDO'}
    bl_property = "target_subobj"

    def _enum_items(self, context):
        items = []
        for o in context.scene.objects:
            if o.type == 'MESH' and 'lfs_subobj_index' in o.keys():
                idx = o.get('lfs_subobj_index', 999)
                v = len(o.data.vertices)
                f = len(o.data.polygons)
                label = f"{idx}: {o.name}  ({v}v {f}f)"
                items.append((o.name, label, ''))
        if not items:
            items = [('__none__', '(no sub-objects in scene)', '')]
        return items

    target_subobj: EnumProperty(items=_enum_items, name="Join Into")

    def execute(self, context):
        target_name = self.target_subobj
        if target_name == '__none__':
            self.report({'ERROR'}, "No sub-objects available to join into")
            return {'CANCELLED'}
        
        target = bpy.data.objects.get(target_name)
        if not target or 'lfs_subobj_index' not in target.keys():
            self.report({'ERROR'}, f"Target '{target_name}' is not a sub-object")
            return {'CANCELLED'}
        
        sources = [o for o in context.selected_objects
                   if o.type == 'MESH'
                   and o.name != target_name
                   and 'lfs_subobj_index' not in o.keys()]
        
        if not sources:
            self.report({'WARNING'},
                "No new (non-sub-object) meshes selected. Select your added objects first.")
            return {'CANCELLED'}
        
        bpy.ops.object.select_all(action='DESELECT')
        for s in sources:
            s.select_set(True)
        target.select_set(True)
        context.view_layer.objects.active = target
        
        try:
            bpy.ops.object.join()
        except Exception as e:
            self.report({'ERROR'}, f"Join failed: {e}")
            return {'CANCELLED'}
        
        new_v = len(target.data.vertices)
        new_f = len(target.data.polygons)
        orig_f = target.get('lfs_subobj_original_nf', 0)
        
        _tag_redraw(context)
        
        self.report({'INFO'},
            f"Joined {len(sources)} obj(s) into '{target_name}' "
            f"(now {new_v}v {new_f}f, was {orig_f}f - will rebuild on export)")
        return {'FINISHED'}

    def invoke(self, context, event):
        non_subobj_selected = [o for o in context.selected_objects
                               if o.type == 'MESH' and 'lfs_subobj_index' not in o.keys()]
        if not non_subobj_selected:
            self.report({'WARNING'},
                "Select one or more new meshes (without lfs_subobj_index) first, "
                "then click this button to pick which sub-object to join them into.")
            return {'CANCELLED'}
        
        context.window_manager.invoke_search_popup(self)
        return {'RUNNING_MODAL'}


class LFS_OT_PickCidxMenu(Operator):
    """Pick the LFS map this material uses"""
    bl_idname = "lfs.pick_cidx_menu"
    bl_label = "Pick Map"
    bl_options = {'REGISTER', 'UNDO'}
    bl_property = "cidx_choice"
    material_name: StringProperty()

    def _enum_items(self, context):
        cidx_to_name = _get_scene_map_names(context)
        if not cidx_to_name:
            return [('0', '0: (no maps loaded)', '')]
        items = []
        for ci in sorted(cidx_to_name.keys()):
            items.append((str(ci), str(ci) + ': ' + cidx_to_name[ci], ''))
        return items

    cidx_choice: EnumProperty(items=_enum_items)

    def execute(self, context):
        mat = bpy.data.materials.get(self.material_name)
        if mat:
            mat['lfs_cidx'] = int(self.cidx_choice)
        _tag_redraw(context)
        return {'FINISHED'}

    def invoke(self, context, event):
        context.window_manager.invoke_search_popup(self)
        return {'RUNNING_MODAL'}


class LFS_OT_FitMaps(Operator):
    """Fit map gizmos to the parts they cover. For every NON-DEFAULT map of
    each marked sub-object: cluster its faces into separate parts (connected
    pieces merged by proximity), give EACH part its own map record aligned
    to the part's surface (position at the part, facing its normal, sized
    a bit larger than the mesh), appending extra mappings + per-part
    materials as needed. Skin-default maps are left alone.
    Uses the CONFIRMED rotation encoding (see top of file)."""
    bl_idname = "lfs.fit_maps"
    bl_label = "Fit Maps to Parts"
    bl_options = {'REGISTER', 'UNDO'}

    pad: FloatProperty(name="Padding", description="Size multiplier over the part",
                       default=1.15, min=1.0, max=2.0)
    merge_dist: FloatProperty(name="Merge distance (m)",
                              description="Connected pieces closer than this "
                                          "count as one part",
                              default=0.3, min=0.01, max=2.0)

    def execute(self, context):
        import base64, struct as _st, math
        from mathutils import Vector

        def enc_h(deg):
            d = ((deg + 180.0) % 360.0) - 180.0
            q = int(round(d * 4))
            if q < 0: q += 2048
            return q & 2047

        def enc_p(deg):
            q = int(round(deg * 4))
            if q < 0: q += 1024
            return q & 1023

        FP_ = 65536.0
        total_new = 0
        total_fit = 0
        _fm_all = [x for x in bpy.data.objects if x.type == 'MESH' and 'lfs_subobj_raw_b64' in x.keys()]
        if _fm_all and all(_lfs_is_imported(x) for x in _fm_all):
            self.report({'ERROR'}, "Fit Maps is for parts made in Blender - an imported car keeps its own "
                                   "maps (re-fitting them took the body past the editor's map limit).")
            return {'CANCELLED'}
        for o in [x for x in _fm_all if not _lfs_is_imported(x)]:
            me = o.data
            mw = o.matrix_world
            mn = mw.to_3x3()
            raw = bytearray(base64.b64decode(o['lfs_subobj_raw_b64']))
            lods = raw[3]; geo = 28 + lods*4
            nv = _st.unpack_from('<H', raw, geo)[0]
            nf = _st.unpack_from('<H', raw, geo+2)[0]
            tp = geo + 28 + nv*16 + nf*12
            pg = _st.unpack_from('<i', raw, tp)[0]; tp += 4 + pg*24
            co = _st.unpack_from('<i', raw, tp)[0]; tp += 4 + co*32
            cnt_pos = tp
            nm = _st.unpack_from('<H', raw, tp)[0]; tp += 4
            maps_end = tp + nm*52

            slot_ci = {}
            for si, s in enumerate(o.material_slots):
                if s.material and s.material.get('lfs_cidx') is not None:
                    slot_ci[si] = int(s.material['lfs_cidx'])
            by_ci = {}
            for poly in me.polygons:
                ci = slot_ci.get(poly.material_index)
                if ci is not None:
                    by_ci.setdefault(ci, []).append(poly.index)

            new_records = []
            new_assign = []
            for mi in range(nm):
                mo = tp + mi*52
                r_raw = _st.unpack_from('<I', raw, mo+24)[0]
                px, py, pz = _st.unpack_from('<iii', raw, mo+28)
                if r_raw == 360 and px == 0 and py == 0 and pz == 0:
                    continue
                polys = by_ci.get(mi)
                if not polys:
                    continue
                vert_owner = {}
                parent = {p: p for p in polys}
                def find(x):
                    while parent[x] != x:
                        parent[x] = parent[parent[x]]
                        x = parent[x]
                    return x
                for p in polys:
                    for v in me.polygons[p].vertices:
                        if v in vert_owner:
                            ra, rb = find(vert_owner[v]), find(p)
                            if ra != rb:
                                parent[ra] = rb
                        else:
                            vert_owner[v] = p
                comps = {}
                for p in polys:
                    comps.setdefault(find(p), []).append(p)
                comp_list = []
                for cpolys in comps.values():
                    cen = Vector((0, 0, 0)); area = 0.0
                    for p in cpolys:
                        pl = me.polygons[p]
                        cen += (mw @ pl.center) * pl.area
                        area += pl.area
                    if area > 0: cen /= area
                    comp_list.append({'polys': cpolys, 'cen': cen, 'area': area})
                merged = []
                for cmp_ in sorted(comp_list, key=lambda c: -c['area']):
                    tgt = None
                    for g in merged:
                        if (g['cen'] - cmp_['cen']).length < self.merge_dist:
                            tgt = g; break
                    if tgt is None:
                        merged.append(dict(cmp_))
                    else:
                        tot = tgt['area'] + cmp_['area']
                        if tot > 0:
                            tgt['cen'] = (tgt['cen']*tgt['area'] + cmp_['cen']*cmp_['area']) / tot
                        tgt['polys'] = tgt['polys'] + cmp_['polys']
                        tgt['area'] = tot
                merged.sort(key=lambda c: -c['area'])

                src_rec = bytes(raw[mo:mo+52])
                base_name = src_rec[:16].split(b'\x00', 1)[0].decode('latin-1')
                for k, cl in enumerate(merged):
                    navg = Vector((0, 0, 0)); area = 0.0
                    cen = Vector((0, 0, 0))
                    for p in cl['polys']:
                        pl = me.polygons[p]
                        n = (mn @ pl.normal)
                        navg += n * pl.area
                        cen += (mw @ pl.center) * pl.area
                        area += pl.area
                    cen /= max(area, 1e-9)
                    coher = navg.length / max(area, 1e-9)
                    if coher > 0.3:
                        n = navg.normalized()
                        p_deg = math.degrees(math.asin(-max(-1.0, min(1.0, n.z))))
                        h_deg = (math.degrees(math.atan2(n.x, -n.y))
                                 if (abs(n.x) + abs(n.y)) > 1e-6 else 0.0)
                    elif coher > 0.03:
                        nn = navg.normalized()
                        cards = [(Vector((0, 1, 0)), 180.0, 0.0),
                                 (Vector((0, -1, 0)), 0.0, 0.0),
                                 (Vector((1, 0, 0)), 90.0, 0.0),
                                 (Vector((-1, 0, 0)), -90.0, 0.0),
                                 (Vector((0, 0, 1)), 0.0, -90.0),
                                 (Vector((0, 0, -1)), 0.0, 90.0)]
                        best = max(cards, key=lambda c: nn.dot(c[0]))
                        n, h_deg, p_deg = best[0], best[1], best[2]
                    else:
                        n = Vector((0, 0, 1)); p_deg = 90.0; h_deg = 0.0
                    up = Vector((0, 0, 1)) if abs(n.z) < 0.95 else Vector((0, 1, 0))
                    u = n.cross(up).normalized()
                    v = n.cross(u).normalized()
                    umin = vmin = 1e9; umax = vmax = -1e9
                    for p in cl['polys']:
                        for vi in me.polygons[p].vertices:
                            w = (mw @ me.vertices[vi].co) - cen
                            uu = w.dot(u); vv = w.dot(v)
                            umin = min(umin, uu); umax = max(umax, uu)
                            vmin = min(vmin, vv); vmax = max(vmax, vv)
                    W = max(umax - umin, 0.03) * self.pad
                    H = max(vmax - vmin, 0.03) * self.pad
                    rec = bytearray(src_rec)
                    if k > 0:
                        nm_new = (base_name[:14] + str(k + 1)).encode('latin-1')[:15]
                        rec[0:16] = nm_new + b'\x00' * (16 - len(nm_new))
                    _st.pack_into('<I', rec, 24, enc_h(h_deg) | (enc_p(p_deg) << 11))
                    _st.pack_into('<iii', rec, 28, int(round(cen.x*FP_)),
                                  int(round(cen.y*FP_)), int(round(cen.z*FP_)))
                    _st.pack_into('<ii', rec, 40, int(round(W*FP_)), int(round(H*FP_)))
                    if k == 0:
                        raw[mo:mo+52] = rec
                        total_fit += 1
                    else:
                        new_ci = nm + len(new_records)
                        if new_ci > 255:
                            self.report({'WARNING'}, f"{o.name}: map limit reached")
                            break
                        new_records.append(bytes(rec))
                        new_assign.append((cl['polys'], me.polygons[cl['polys'][0]].material_index, new_ci))

            if new_records:
                for polys, src_slot, new_ci in new_assign:
                    src_mat = o.material_slots[src_slot].material
                    mat2 = src_mat.copy()
                    mat2['lfs_split_from'] = src_mat.get('lfs_split_from', src_mat.name)
                    mat2['lfs_cidx'] = new_ci
                    me.materials.append(mat2)
                    new_slot = len(me.materials) - 1
                    for p in polys:
                        me.polygons[p].material_index = new_slot
                me.update()
                raw2 = bytes(raw[:maps_end]) + b''.join(new_records) + bytes(raw[maps_end:])
                raw = bytearray(raw2)
                _st.pack_into('<H', raw, cnt_pos, nm + len(new_records))
                if len(me.polygons) == nf:
                    fbase = 28 + lods*4 + 28 + nv*16
                    for polys, _src_slot, new_ci in new_assign:
                        for p in polys:
                            raw[fbase + p*12 + 2] = new_ci
                total_new += len(new_records)
            o['lfs_subobj_raw_b64'] = base64.b64encode(bytes(raw)).decode('ascii')

        self.report({'INFO'},
                    f"Fitted {total_fit} map(s), created {total_new} new part mapping(s).")
        return {'FINISHED'}


class LFS_OT_SplitMapDirections(Operator):
    """The active material: faces looking up, forward, to the side... each
    get their own map, so a leather or dash texture does not smear over curves"""
    bl_idname = "lfs.split_map_directions"
    bl_label = "Split Map by Direction"
    bl_options = {'REGISTER', 'UNDO'}

    pad: FloatProperty(name="Padding", default=1.15, min=1.0, max=2.0)
    min_share: FloatProperty(
        name="Min bucket share",
        description="Directions holding less than this share of the "
                    "material's area merge into the dominant direction",
        default=0.05, min=0.0, max=0.5)
    fit_to_part: BoolProperty(
        name="Fit size to part",
        description="Stretch each mapping over its faces (for skins/decals). "
                    "OFF = small fixed-size mapping, right for REPEATING "
                    "textures like leather - the texture tiles, the mapping "
                    "size just sets the tile scale",
        default=False)
    map_size: FloatProperty(
        name="Tile size (m)",
        description="Mapping W/H when not fitting to the part - smaller = "
                    "texture repeats finer",
        default=0.45, min=0.05, max=4.0)

    @classmethod
    def poll(cls, context):
        o = context.active_object
        return (o is not None and o.type == 'MESH'
                and 'lfs_subobj_raw_b64' in o.keys()
                and o.active_material is not None
                and o.active_material.get('lfs_cidx') is not None)

    def execute(self, context):
        import base64, struct as _st
        from mathutils import Vector

        def enc_h(deg):
            d = ((deg + 180.0) % 360.0) - 180.0
            q = int(round(d * 4))
            if q < 0: q += 2048
            return q & 2047

        def enc_p(deg):
            q = int(round(deg * 4))
            if q < 0: q += 1024
            return q & 1023

        FP_ = 65536.0
        o = context.active_object
        me = o.data
        mw = o.matrix_world
        mn = mw.to_3x3()
        src_mat = o.active_material
        src_ci = int(src_mat['lfs_cidx'])

        raw = bytearray(base64.b64decode(o['lfs_subobj_raw_b64']))
        lods = raw[3]; geo = 28 + lods*4
        nv = _st.unpack_from('<H', raw, geo)[0]
        nf = _st.unpack_from('<H', raw, geo+2)[0]
        scratch = (nf == 0)
        if not scratch:
            tp = geo + 28 + nv*16 + nf*12
            pg = _st.unpack_from('<i', raw, tp)[0]; tp += 4 + pg*24
            co = _st.unpack_from('<i', raw, tp)[0]; tp += 4 + co*32
            cnt_pos = tp
            nm = _st.unpack_from('<H', raw, tp)[0]; tp += 4
            maps_end = tp + nm*52
            if src_ci >= nm:
                self.report({'ERROR'}, "Material's cidx has no map record.")
                return {'CANCELLED'}
            src_rec = bytes(raw[tp + src_ci*52: tp + (src_ci+1)*52])
            base_name = src_rec[:16].split(b'\x00', 1)[0].decode('latin-1')
        else:
            src_rec = None
            base_name = src_mat.name

        slots = {si for si, s in enumerate(o.material_slots)
                 if s.material == src_mat}
        cards = [(Vector((0, 0, 1)), 0.0, -90.0, 'top'),
                 (Vector((0, 0, -1)), 0.0, 90.0, 'bot'),
                 (Vector((0, 1, 0)), 180.0, 0.0, 'frnt'),
                 (Vector((0, -1, 0)), 0.0, 0.0, 'back'),
                 (Vector((1, 0, 0)), 90.0, 0.0, 'rght'),
                 (Vector((-1, 0, 0)), -90.0, 0.0, 'left')]
        buckets = {i: [] for i in range(6)}
        areas = {i: 0.0 for i in range(6)}
        for poly in me.polygons:
            if poly.material_index not in slots:
                continue
            n = (mn @ poly.normal)
            k = max(range(6), key=lambda i: n.dot(cards[i][0]))
            buckets[k].append(poly.index)
            areas[k] += poly.area
        total = sum(areas.values())
        if total <= 0:
            self.report({'ERROR'}, "No faces use the active material.")
            return {'CANCELLED'}
        order = sorted(range(6), key=lambda i: -areas[i])
        main = order[0]
        keep = [i for i in order
                if buckets[i] and areas[i] >= total * self.min_share]
        if main not in keep:
            keep = [main] + keep
        for i in range(6):
            if i not in keep and buckets[i]:
                buckets[main].extend(buckets[i])
                areas[main] += areas[i]
                buckets[i] = []

        def fit_vals(polys, axis):
            cen = Vector((0, 0, 0)); ar = 0.0
            for p_ in polys:
                pl = me.polygons[p_]
                cen += (mw @ pl.center) * pl.area
                ar += pl.area
            cen /= max(ar, 1e-9)
            n = axis
            up = Vector((0, 0, 1)) if abs(n.z) < 0.95 else Vector((0, 1, 0))
            u = n.cross(up).normalized()
            v = n.cross(u).normalized()
            if self.fit_to_part:
                umin = vmin = 1e9; umax = vmax = -1e9
                for p_ in polys:
                    for vi in me.polygons[p_].vertices:
                        w = (mw @ me.vertices[vi].co) - cen
                        uu = w.dot(u); vv = w.dot(v)
                        umin = min(umin, uu); umax = max(umax, uu)
                        vmin = min(vmin, vv); vmax = max(vmax, vv)
                W = max(umax - umin, 0.03) * self.pad
                H = max(vmax - vmin, 0.03) * self.pad
            else:
                W = H = self.map_size
            return cen, W, H

        def fit_into(rec, polys, h_deg, p_deg, axis):
            cen, W, H = fit_vals(polys, axis)
            _st.pack_into('<I', rec, 24, enc_h(h_deg) | (enc_p(p_deg) << 11))
            _st.pack_into('<iii', rec, 28, int(round(cen.x*FP_)),
                          int(round(cen.y*FP_)), int(round(cen.z*FP_)))
            _st.pack_into('<ii', rec, 40, int(round(W*FP_)), int(round(H*FP_)))

        if scratch:
            def set_props(mat, polys, h_deg, p_deg, axis):
                cen, W, H = fit_vals(polys, axis)
                mat['lfs_map_rot'] = enc_h(h_deg) | (enc_p(p_deg) << 11)
                mat['lfs_map_pos'] = [cen.x, cen.y, cen.z]
                mat['lfs_map_wh'] = [W, H]
            set_props(src_mat, buckets[main],
                      cards[main][1], cards[main][2], cards[main][0])
            made = [cards[main][3]]
            next_ci = 0
            for m_ in bpy.data.materials:
                try:
                    next_ci = max(next_ci, int(m_.get('lfs_cidx', -1)))
                except (ValueError, TypeError):
                    pass
            for i in keep:
                if i == main or not buckets[i]:
                    continue
                next_ci += 1
                if next_ci > _CIDX_MAX:
                    self.report({'WARNING'}, "Map limit reached.")
                    break
                sfx = cards[i][3]
                mat2 = src_mat.copy()
                mat2['lfs_split_from'] = src_mat.get('lfs_split_from', src_mat.name)
                mat2.name = src_mat.name[:14 - len(sfx)] + '_' + sfx
                mat2['lfs_cidx'] = next_ci
                set_props(mat2, buckets[i],
                          cards[i][1], cards[i][2], cards[i][0])
                me.materials.append(mat2)
                new_slot = len(me.materials) - 1
                for p_ in buckets[i]:
                    me.polygons[p_].material_index = new_slot
                made.append(sfx)
            me.update()
            self.report({'INFO'},
                        f"{src_mat.name}: split into {len(made)} direction "
                        "mapping(s): " + ", ".join(made))
            return {'FINISHED'}

        mo = tp + src_ci*52
        rec0 = bytearray(src_rec)
        fit_into(rec0, buckets[main], cards[main][1], cards[main][2], cards[main][0])
        raw[mo:mo+52] = rec0

        new_records = []
        assigns = []
        made = [cards[main][3]]
        for i in keep:
            if i == main or not buckets[i]:
                continue
            new_ci = nm + len(new_records)
            if new_ci > 255:
                self.report({'WARNING'}, "Map limit (255) reached.")
                break
            rec = bytearray(src_rec)
            sfx = cards[i][3]
            nm_new = (base_name[:14 - len(sfx)] + '_' + sfx).encode('latin-1')[:15]
            rec[0:16] = nm_new + b'\x00' * (16 - len(nm_new))
            fit_into(rec, buckets[i], cards[i][1], cards[i][2], cards[i][0])
            new_records.append(bytes(rec))
            assigns.append((list(buckets[i]), new_ci))
            mat2 = src_mat.copy()
            mat2['lfs_split_from'] = src_mat.get('lfs_split_from', src_mat.name)
            mat2['lfs_cidx'] = new_ci
            me.materials.append(mat2)
            new_slot = len(me.materials) - 1
            for p_ in buckets[i]:
                me.polygons[p_].material_index = new_slot
            made.append(sfx)
        if new_records:
            raw2 = bytes(raw[:maps_end]) + b''.join(new_records) + bytes(raw[maps_end:])
            raw = bytearray(raw2)
            _st.pack_into('<H', raw, cnt_pos, nm + len(new_records))
        if len(me.polygons) == nf:
            fbase = geo + 28 + nv*16
            for polys, ci in assigns:
                for p_ in polys:
                    raw[fbase + p_*12 + 2] = ci
        me.update()
        o['lfs_subobj_raw_b64'] = base64.b64encode(bytes(raw)).decode('ascii')
        self.report({'INFO'},
                    f"{src_mat.name}: split into {len(made)} direction mapping(s): "
                    + ", ".join(made))
        return {'FINISHED'}


class LFS_OT_FitUVMaps(Operator):
    """Fit LFS planar Maps + clipped cutouts to the ACTIVE material's real
    UV layout (supersedes Bake UV->Planar Maps).

    Per UV island: fits position / heading / pitch / ROLL / W / H from the
    island's world-space UVs, bisecting
    curved islands until each part is planar enough. When the island sits
    inside 0..1 UV, a CUTOUT is clipped to the island's UV bbox (the
    editor's pos/size clip) so an atlas texture shows the RIGHT sub-region;
    islands spanning past 0..1 keep the whole page and tile.
    SCRATCH sub-objects only (imported raw tables are preserved verbatim -
    use Fit Maps / Split Map for those)."""
    bl_idname = "lfs.fit_uv_maps"
    bl_label = "Fit UV Maps (atlas)"
    bl_options = {'REGISTER', 'UNDO'}

    u_sign: bpy.props.IntProperty(name="U sign", default=1, min=-1, max=1)
    v_sign: bpy.props.IntProperty(name="V sign", default=1, min=-1, max=1)
    swap_uv: BoolProperty(name="Swap U/V", default=False)
    rms_tol: FloatProperty(name="Fit tolerance (UV rms)", default=0.008,
                           min=0.002, max=0.2)
    fallback_rms: FloatProperty(
        name="Fallback ceiling (UV rms)", default=0.2, min=0.02, max=1.0,
        description="Curved parts that cannot hit the fit tolerance still "
                    "get their best-effort map if under this - far better "
                    "than inheriting the dominant island's map")
    max_parts: bpy.props.IntProperty(name="Max parts per material",
                                     default=24, min=1, max=64)
    min_faces: bpy.props.IntProperty(name="Min faces per part", default=4,
                                     min=1, max=64)
    min_island_faces: bpy.props.IntProperty(
        name="Skip islands smaller than", default=3, min=1, max=200,
        description="Tiny islands stay on the base material")
    uv_name: StringProperty(name="UV layer", default="",
                            description="UV layer to fit (empty = active)")
    parts_per_island: bpy.props.IntProperty(
        name="Max parts per island", default=0, min=0, max=64,
        description="Bisection cap for ONE curved island (0 = Max parts)")
    whole_island: BoolProperty(
        name="Whole-island verdict", default=False,
        description="An island whose fitted (planar) parts cover less than the "
                    "share below is rejected entirely - a seat is either textured "
                    "or plain, never a patchwork")
    island_min_ok: FloatProperty(name="Min fitted share", default=0.6, min=0.1, max=1.0)
    quiet: BoolProperty(options={'HIDDEN', 'SKIP_SAVE'}, default=False)

    @classmethod
    def poll(cls, context):
        o = context.active_object
        return (o is not None and o.type == 'MESH' and o.data.uv_layers
                and o.active_material is not None)

    def execute(self, context):
        import numpy as np
        o = context.active_object
        me = o.data
        src_mat = o.active_material
        if int(o.get('lfs_subobj_original_nf', 0) or 0) > 0:
            self.report({'ERROR'},
                "Imported sub-object: its map table exports verbatim. "
                "Split Map by Direction or Pro-Map Material work on one of its materials.")
            return {'CANCELLED'}
        mw = o.matrix_world.copy()
        mn = mw.to_3x3().inverted_safe().transposed()

        slots = {si for si, s in enumerate(o.material_slots)
                 if s.material == src_mat}
        subset = {p.index for p in me.polygons if p.material_index in slots}
        if not subset:
            self.report({'ERROR'}, "No faces use the active material.")
            return {'CANCELLED'}

        bm = bmesh.new()
        bm.from_mesh(me)
        bm.faces.ensure_lookup_table()
        uvl = (bm.loops.layers.uv.get(self.uv_name) if self.uv_name else None) \
            or bm.loops.layers.uv.active
        islands = _uvp_islands(bm, uvl, subset)

        def face_entry(f):
            pts = []; uvs = []
            for l in f.loops:
                w = mw @ l.vert.co
                pts.append((w.x, w.y, w.z))
                uv = l[uvl].uv
                uvs.append((uv.x, uv.y))
            n = (mn @ f.normal)
            ln = n.length or 1.0
            return {'pts': pts, 'uvs': uvs,
                    'n': (n.x/ln, n.y/ln, n.z/ln),
                    'a': f.calc_area(), 'id': f.index}

        parts = []
        raw_parts = []
        n_skip_small = n_rej = n_fb = 0
        rej_ids = []
        for isl in islands:
            if len(isl) < self.min_island_faces:
                n_skip_small += 1
                continue
            entries = [face_entry(f) for f in isl]
            _fits = _uvp_fit_faces(
                entries, self.u_sign, self.v_sign, self.swap_uv,
                rms_tol=self.rms_tol, min_faces=self.min_faces,
                max_parts=(self.parts_per_island or self.max_parts))
            if self.whole_island:
                _area_of = {e['id']: e['a'] for e in entries}
                _a_all = sum(_area_of.values()) or 1e-12
                _a_ok = sum(_area_of[i] for fit, ids in _fits
                            if fit.get('ok') and (fit.get('rms') or 9.0) <= self.rms_tol
                            for i in ids)
                if _a_ok / _a_all < self.island_min_ok:
                    n_rej += 1
                    rej_ids.extend(e['id'] for e in entries)
                    continue
            for fit, ids in _fits:
                if not fit.get('ok'):
                    if (fit.get('h') is not None
                            and (fit.get('rms') or 9.0) <= self.fallback_rms):
                        n_fb += 1
                    else:
                        n_rej += 1
                        rej_ids.extend(ids)
                        continue
                idset = set(ids)
                raw_parts.append((fit, list(ids),
                                  [e for e in entries if e['id'] in idset]))
        bm.free()

        import math as _math
        def _bkey(f):
            return (int(round(f['h'] / 20.0)), int(round(f['p'] / 20.0)),
                    int(round((f.get('r') or 0.0) / 20.0)),
                    int(round(_math.log2(max(f['W'], 1e-6)) * 2)),
                    int(round(_math.log2(max(f['H'], 1e-6)) * 2)))
        used_m = [False] * len(raw_parts)
        order = sorted(range(len(raw_parts)),
                       key=lambda i: -len(raw_parts[i][1]))
        for i in order:
            if used_m[i]:
                continue
            used_m[i] = True
            cur_fit, cur_ids, cur_ent = raw_parts[i]
            if cur_fit.get('h') is None:
                continue
            for j in order:
                if used_m[j] or raw_parts[j][0].get('h') is None:
                    continue
                if _bkey(raw_parts[j][0]) != _bkey(cur_fit):
                    continue
                ent2 = cur_ent + raw_parts[j][2]
                pts = [p_ for e in ent2 for p_ in e['pts']]
                uvs = [t_ for e in ent2 for t_ in e['uvs']]
                an = [0.0, 0.0, 0.0]
                for e in ent2:
                    for k2 in range(3):
                        an[k2] += e['n'][k2] * e['a']
                f2 = _uvp_fit_island(pts, uvs, tuple(an), self.u_sign,
                                     self.v_sign, self.swap_uv)
                lim = max(self.rms_tol, cur_fit.get('rms') or 0.0,
                          raw_parts[j][0].get('rms') or 0.0)
                if f2.get('h') is not None and (f2.get('rms') or 9.0) <= lim:
                    used_m[j] = True
                    cur_fit = f2
                    cur_ids = cur_ids + raw_parts[j][1]
                    cur_ent = ent2
            T = np.array([t_ for e in cur_ent for t_ in e['uvs']])
            u0, v0 = float(T[:, 0].min()), float(T[:, 1].min())
            u1, v1 = float(T[:, 0].max()), float(T[:, 1].max())
            inside = (-0.002 <= u0 and u1 <= 1.002
                      and -0.002 <= v0 and v1 <= 1.002)
            box = (max(0.0, u0), max(0.0, v0),
                   min(1.0, u1), min(1.0, v1)) if inside else None
            parts.append((cur_fit, cur_ids, box, sum(e['a'] for e in cur_ent)))

        if not parts:
            if self.quiet:
                print(f"  [fit] {o.name}/{src_mat.name}: no UV island can be fitted ({n_rej} degenerate or "
                      f"palette island(s)) - the steps below map them")
                return {'CANCELLED'}
            self.report({'ERROR'},
                f"No usable UV islands ({n_rej} rejected - degenerate/"
                "palette UVs cannot be planar-fitted).")
            return {'CANCELLED'}
        parts.sort(key=lambda p: -p[3])
        for _f, _ids, _b, _a in parts[self.max_parts:]:
            rej_ids.extend(_ids)
        parts = parts[:self.max_parts]

        def apply(mat, fit, box):
            h, p, r = fit['h'], fit['p'], fit['r']
            W, H = fit['W'], fit['H']
            px, py, pz = fit['pos']
            if box:
                u0, v0, u1, v1 = box
                U, V, _N = _uvp_frame(h, p, r)
                du = ((u0 + u1) / 2.0 - 0.5) * W
                dv = ((v0 + v1) / 2.0 - 0.5) * H
                px += du * U[0] + dv * V[0]
                py += du * U[1] + dv * V[1]
                pz += du * U[2] + dv * V[2]
                W *= max(u1 - u0, 1.0 / 128.0)
                H *= max(v1 - v0, 1.0 / 128.0)
                mat['lfs_cutout_rect'] = [
                    max(1, round((u1 - u0) * 128)),
                    max(1, round((v1 - v0) * 128)),
                    round(u0 * 128), round(v0 * 128)]
            elif 'lfs_cutout_rect' in mat.keys():
                del mat['lfs_cutout_rect']
            _raw = _uvp_pack_rot(h, p, r)
            if _raw >= 2**31:
                _raw -= 2**32
            mat['lfs_map_rot'] = _raw
            mat['lfs_map_pos'] = [px, py, pz]
            mat['lfs_map_wh'] = [W, H]

        fit0, ids0, box0 = parts[0][:3]
        apply(src_mat, fit0, box0)

        next_ci = 0
        for m_ in bpy.data.materials:
            try:
                next_ci = max(next_ci, int(m_.get('lfs_cidx', -1)))
            except (ValueError, TypeError):
                pass
        made = 1
        for k, (fit, ids, box, _area) in enumerate(parts[1:], start=1):
            next_ci += 1
            if next_ci > _CIDX_MAX:
                self.report({'WARNING'}, "Map limit reached.")
                break
            sfx = 'u%d' % k
            mat2 = src_mat.copy()
            mat2['lfs_split_from'] = src_mat.get('lfs_split_from', src_mat.name)
            mat2.name = src_mat.name[:14 - len(sfx)] + '_' + sfx
            mat2['lfs_cidx'] = next_ci
            apply(mat2, fit, box)
            me.materials.append(mat2)
            new_slot = len(me.materials) - 1
            for fid in ids:
                me.polygons[fid].material_index = new_slot
            made += 1
        me.update()
        o['lfs_fit_rejected'] = rej_ids
        o['lfs_fit_base_faces'] = list(ids0)
        self.report({'INFO'},
            f"{src_mat.name}: {made} fitted map(s) from {len(islands)} "
            f"island(s), {n_fb} best-effort part(s) ({n_rej} unfittable "
            f"part(s) left on base, {n_skip_small} tiny island(s) skipped)")
        return {'FINISHED'}

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self)


def _lfs_drop_unused_slots(o):
    me = o.data
    n = len(o.material_slots)
    if me is None or n <= 1:
        return 0
    import numpy as np
    mi = _lfs_mat_index_array(me)
    used = set(np.unique(mi).tolist()) if len(mi) else set()
    drop = [i for i in range(n) if i not in used]
    if len(drop) == n:
        drop = drop[1:]
    for i in reversed(drop):
        me.materials.pop(index=i)
    return len(drop)


def _lfs_idp_copy(v):
    try:
        if hasattr(v, 'to_dict'):
            return v.to_dict()
        if hasattr(v, 'to_list'):
            return v.to_list()
    except Exception:
        pass
    return v


class LFS_OT_PurgeUnusedMaps(Operator):
    """Remove the LFS maps no face uses any more (left over from earlier
    bakes and splits), number the rest again and update the parts. Parts imported from an
    .sre are not touched"""
    bl_idname = "lfs.purge_unused_maps"
    bl_label = "Purge Unused Maps"
    bl_options = {'REGISTER', 'UNDO'}

    also_unused_zero_face_mats: BoolProperty(
        name="Delete dead materials from blend",
        description="Remove the unused materials entirely (not just from the export)",
        default=True)

    def execute(self, context):
        sc = context.scene
        ve_objs = [o for o in sc.objects if o.type == 'MESH'
                   and 'lfs_subobj_index' in o.keys()]
        scratch = [o for o in ve_objs if not _lfs_is_imported(o)]
        if not scratch:
            self.report({'ERROR'}, "No scratch sub-objects in scene.")
            return {'CANCELLED'}
        used = set()
        for o in ve_objs:
            me = o.data
            slot_ci = []
            for s in o.material_slots:
                m = s.material
                ci = None
                if m is not None:
                    try:
                        ci = int(m.get('lfs_cidx'))
                    except (TypeError, ValueError):
                        ci = None
                slot_ci.append(ci)
            for p in me.polygons:
                if p.material_index < len(slot_ci):
                    ci = slot_ci[p.material_index]
                    if ci is not None:
                        used.add(ci)
        _refd = set()
        for m in bpy.data.materials:
            for k in ('lfs_split_from', 'lfs_baked_from', 'lfs_fit_left'):
                v = m.get(k)
                if v:
                    _refd.add(str(v))
        keep_mats = []
        dead_mats = []
        for m in bpy.data.materials:
            ci = m.get('lfs_cidx')
            if ci is None:
                continue
            try:
                ci = int(ci)
            except (TypeError, ValueError):
                continue
            if ci in used:
                keep_mats.append(m)
            elif m.name in _refd or m.get('lfs_fit_base') or m.get('lfs_tile_size'):
                del m['lfs_cidx']
            else:
                dead_mats.append(m)
        keep_mats.sort(key=lambda m: int(m['lfs_cidx']))
        remap = {}
        nxt = 1 if any(int(m['lfs_cidx']) == 1 for m in keep_mats) else 2
        for m in keep_mats:
            old = int(m['lfs_cidx'])
            if old not in remap:
                remap[old] = nxt
                nxt += 1
            m['lfs_cidx'] = remap[old]
        ov = sc.get('lfs_tex_overrides')
        dead_names = {m.name.lower() for m in dead_mats}
        if ov is not None:
            new_ov = {k: ov[k] for k in ov.keys()
                      if k.lower() not in dead_names}
            sc['lfs_tex_overrides'] = new_ov
        n_dead = len(dead_mats)
        if self.also_unused_zero_face_mats:
            for m in dead_mats:
                try:
                    bpy.data.materials.remove(m)
                except Exception:
                    pass
        for o in ve_objs:
            try:
                _lfs_drop_unused_slots(o)
            except Exception as _e:
                print(f"  [purge] {o.name}: slots not tidied ({_e!r})")
        _remark_failed = []
        _CIDX_GEOM_CACHE['on'] = True
        _CIDX_GEOM_CACHE['d'].clear(); _CIDX_GEOM_CACHE['area'].clear()
        _CIDX_GEOM_CACHE['seen'] = {}
        try:
            self._remark(context, sc, scratch, _remark_failed)
        finally:
            _CIDX_GEOM_CACHE['on'] = False
            _CIDX_GEOM_CACHE['d'].clear(); _CIDX_GEOM_CACHE['area'].clear()
            _CIDX_GEOM_CACHE['seen'] = {}
        for _msg in _remark_failed:
            self.report({'WARNING'}, _msg)
        self.report({'INFO'},
            f"Purged {n_dead} unused material(s); {len(remap)} map slot(s) "
            f"remain (cidx 1..{nxt-1}). Re-marked {len(scratch)} sub-object(s) "
            "- just export now.")
        return {'FINISHED'}

    def _remark(self, context, sc, scratch, _remark_failed):
        for o in scratch:
            idx = int(o.get('lfs_subobj_index', 0))
            styp = str(o.get('lfs_subobj_type', 3))
            if styp not in ('0', '1', '2', '3', '10'):
                continue
            _saved = {k: _lfs_idp_copy(o[k]) for k in o.keys() if k.startswith('lfs_subobj')}
            for k in _saved:
                del o[k]
            _hid = False
            try:
                _hid = bool(o.hide_get(view_layer=context.view_layer))
                if _hid:
                    o.hide_set(False, view_layer=context.view_layer)
            except Exception:
                _hid = False
            for oo in sc.objects:
                try:
                    oo.select_set(False)
                except Exception:
                    pass
            o.select_set(True)
            context.view_layer.objects.active = o
            try:
                bpy.ops.lfs.make_subobj(sub_type=styp)
                o['lfs_subobj_index'] = idx
            except Exception as _e:
                for k, v in _saved.items():
                    o[k] = v
                _remark_failed.append(f"{o.name}: {str(_e).replace('Error: ', '').strip()}")
            finally:
                if _hid:
                    try:
                        o.select_set(False)
                        o.hide_set(True, view_layer=context.view_layer)
                    except Exception:
                        pass


class LFS_OT_FillPanelGaps(Operator):
    """Give every OPEN panel edge an inward dark flange so shut lines
    (trunk/bumper/hood/door gaps) read as dark seams instead of see-
    through holes. Separate archviz panels have real gaps between them;
    LFS single-sided rendering shows the void. Each boundary vert gets
    one inner copy offset along the averaged inward normal; boundary
    edges become dark quads. Small shells (badges, letters) skipped."""
    bl_idname = "lfs.fill_panel_gaps"
    bl_label = "Fill Panel Gaps (flanges)"
    bl_options = {'REGISTER', 'UNDO'}

    depth: FloatProperty(name="Flange depth (m)", default=0.035,
                         min=0.005, max=0.2)
    min_edge: FloatProperty(name="Skip edges shorter than (m)",
                            default=0.012, min=0.0, max=0.2)
    min_shell: FloatProperty(name="Skip shells smaller than (m)",
                             default=0.15, min=0.0, max=2.0,
                             description="Bounding-diagonal threshold - "
                             "badges and letters keep no flange")

    @classmethod
    def poll(cls, context):
        o = context.active_object
        return o is not None and o.type == 'MESH'

    def execute(self, context):
        import bmesh
        from collections import defaultdict
        from mathutils import Vector
        o = context.active_object
        me = o.data
        gm = bpy.data.materials.get('xtex_black')
        if gm is None:
            gm = bpy.data.materials.new('xtex_black')
            gm.diffuse_color = (0, 0, 0, 1)
            nxt = 0
            for m_ in bpy.data.materials:
                try: nxt = max(nxt, int(m_.get('lfs_cidx', -1)))
                except Exception: pass
            gm['lfs_cidx'] = nxt + 1
        slot = None
        for i, ms in enumerate(me.materials):
            if ms == gm: slot = i
        if slot is None:
            me.materials.append(gm); slot = len(me.materials) - 1

        bm = bmesh.new(); bm.from_mesh(me)
        bm.verts.ensure_lookup_table(); bm.faces.ensure_lookup_table()
        parent = list(range(len(bm.verts)))
        def find(a):
            while parent[a] != a:
                parent[a] = parent[parent[a]]; a = parent[a]
            return a
        for e in bm.edges:
            a, b = find(e.verts[0].index), find(e.verts[1].index)
            if a != b: parent[a] = b
        lo = {}; hi = {}
        for v in bm.verts:
            r = find(v.index); c = v.co
            if r not in lo:
                lo[r] = Vector(c); hi[r] = Vector(c)
            else:
                lo[r].x = min(lo[r].x, c.x); lo[r].y = min(lo[r].y, c.y); lo[r].z = min(lo[r].z, c.z)
                hi[r].x = max(hi[r].x, c.x); hi[r].y = max(hi[r].y, c.y); hi[r].z = max(hi[r].z, c.z)
        big = {r for r in lo if (hi[r] - lo[r]).length >= self.min_shell}

        scale = (o.matrix_world.to_3x3() @ Vector((1, 0, 0))).length or 1.0
        depth_l = self.depth / scale
        min_edge_l = self.min_edge / scale
        bedges = [e for e in bm.edges if len(e.link_faces) == 1
                  and e.calc_length() >= min_edge_l
                  and find(e.verts[0].index) in big]
        acc = defaultdict(Vector); cnt = defaultdict(int)
        for e in bedges:
            n = e.link_faces[0].normal
            for v in e.verts:
                acc[v.index] += n; cnt[v.index] += 1
        _cos = {vi: bm.verts[vi].co.copy() for vi in acc}
        inner = {}
        for vi, n in acc.items():
            if n.length < 1e-9: continue
            inner[vi] = bm.verts.new(_cos[vi] - n.normalized() * depth_l)
        made = 0
        for e in bedges:
            v1, v2 = e.verts
            i1 = inner.get(v1.index); i2 = inner.get(v2.index)
            if i1 is None or i2 is None: continue
            f = e.link_faces[0]
            try:
                nf = bm.faces.new((v1, v2, i2, i1))
            except ValueError:
                continue
            out = (v1.co + v2.co) * 0.5 - f.calc_center_median()
            if out.length > 1e-9 and nf.normal.dot(out) < 0:
                nf.normal_flip()
            nf.material_index = slot
            nf.smooth = False
            made += 1
        bm.to_mesh(me); bm.free(); me.update()
        self.report({'INFO'},
            f"{o.name}: {made} flange face(s) on {len(bedges)} open edge(s) "
            f"(depth {self.depth:.3f} m). Re-mark before export.")
        return {'FINISHED'}

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self)


class LFS_OT_MarkDoubleSided(Operator):
    """Find faces seen from both sides (one-sheet seat backs, hood
    undersides, glass) and mark them: the export gives them a back face (no extra points).
    LFS draws a face from one side only"""
    bl_idname = "lfs.mark_double_sided"
    bl_label = "Mark Double-Sided (both-sides-visible)"
    bl_options = {'REGISTER', 'UNDO'}

    min_free: FloatProperty(name="Min open space each side (m)",
                            default=0.25, min=0.05, max=2.0)

    @classmethod
    def poll(cls, context):
        return any(o.type == 'MESH' and 'lfs_subobj_index' in o.keys()
                   for o in bpy.data.objects)

    def execute(self, context):
        import base64 as _b64e
        from mathutils.bvhtree import BVHTree
        from mathutils import Vector
        sc = context.scene
        marked_objs = [x for x in bpy.data.objects
                       if x.type == 'MESH' and 'lfs_subobj_index' in x.keys()]
        _glass_names = set(_GLASS_MATERIALS)
        try:
            _sc_ov = sc.get('lfs_tex_overrides')
            if _sc_ov:
                for _k in _sc_ov.keys():
                    _v = str(_sc_ov[_k]).lower()
                    if 'glass' in _v or _v.startswith('s_'):
                        _glass_names.add(_k.lower())
        except Exception:
            pass
        try:
            _ap, _ag = _auto_detect_from_scene(
                [m.name for m in bpy.data.materials if m.get('lfs_cidx') is not None])
            _glass_names |= {n.lower() for n in (_ag or ())}
        except Exception:
            pass
        _vs = []; _ps = []; _base = 0
        for oo in marked_objs:
            mw = oo.matrix_world
            _sg = [(s.material is not None
                    and s.material.name.lower() in _glass_names)
                   for s in oo.material_slots]
            _vs.extend([tuple(mw @ v.co) for v in oo.data.vertices])
            _ps.extend([tuple(_base + vi for vi in p.vertices)
                        for p in oo.data.polygons
                        if not (p.material_index < len(_sg) and _sg[p.material_index])])
            _base += len(oo.data.vertices)
        try:
            bvh = BVHTree.FromPolygons(_vs, _ps)
        except Exception:
            self.report({'ERROR'}, "BVH build failed")
            return {'CANCELLED'}
        _EPS = 0.008; _FAR = 8.0
        def free(origin, d):
            hit = bvh.ray_cast(origin + d * _EPS, d, _FAR)
            return (hit[3] + _EPS) if hit[0] is not None else _FAR
        rep = []
        for o in marked_objs:
            b64 = o.get('lfs_subobj_raw_b64')
            if b64:
                import base64 as _bd, struct as _st2
                raw = _bd.b64decode(b64)
                if _st2.unpack_from('<H', raw, 28 + raw[3]*4 + 2)[0] > 0:
                    continue
            me = o.data
            mw = o.matrix_world
            nmw = mw.to_3x3()
            cand = []
            for p in me.polygons:
                c = mw @ p.center
                n = (nmw @ p.normal)
                if n.length < 1e-9:
                    continue
                n.normalize()
                ff = free(c, n); fb = free(c, -n)
                m = min(ff, fb)
                if m >= self.min_free:
                    cand.append((m, p.index, len(p.vertices) - 2))
            cur_tris = sum(len(p.vertices) - 2 for p in me.polygons)
            budget = max(0, 64500 - cur_tris)
            cand.sort(key=lambda t: -t[0])
            chosen = []; used = 0
            for m, pi, ntris in cand:
                if used + ntris > budget:
                    continue
                chosen.append(pi); used += ntris
            buf = b''.join(int(pi).to_bytes(4, 'little') for pi in chosen)
            o['lfs_dbl_b64'] = _b64e.b64encode(buf).decode('ascii')
            rep.append(f"{o.name}: {len(chosen)}/{len(cand)} faces (+{used} tris)")
        self.report({'INFO'}, "Double-sided marks: " + "; ".join(rep) if rep
                    else "Nothing marked")
        return {'FINISHED'}

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self)


class LFS_OT_ProMapMaterial(Operator):
    """The active material, mapped like a hand-made LFS interior: small
    repeating maps lined up with each part's own surface (a seat back gets its rake)"""
    bl_idname = "lfs.pro_map_material"
    bl_label = "Pro-Map Material (small aligned tiles)"
    bl_options = {'REGISTER', 'UNDO'}

    tile: FloatProperty(name="Tile size (m)", default=0.09,
                        min=0.02, max=1.0)
    merge_dist: FloatProperty(name="Merge distance (m)", default=0.3,
                              min=0.01, max=2.0)
    coherence: FloatProperty(
        name="Coherence", default=0.25, min=0.05, max=0.9,
        description="Parts whose normals agree above this get ONE aligned "
                    "mapping; curvier parts sub-split by direction")
    min_share: FloatProperty(name="Min direction share", default=0.08,
                             min=0.0, max=0.5)

    @classmethod
    def poll(cls, context):
        o = context.active_object
        return (o is not None and o.type == 'MESH'
                and 'lfs_subobj_raw_b64' in o.keys()
                and o.active_material is not None
                and o.active_material.get('lfs_cidx') is not None)

    def execute(self, context):
        import base64, struct as _st, math
        from mathutils import Vector

        def enc_h(deg):
            d = ((deg + 180.0) % 360.0) - 180.0
            q = int(round(d * 4))
            if q < 0: q += 2048
            return q & 2047

        def enc_p(deg):
            q = int(round(deg * 4))
            if q < 0: q += 1024
            return q & 1023

        FP_ = 65536.0
        o = context.active_object
        me = o.data
        mw = o.matrix_world
        mn = mw.to_3x3()
        src_mat = o.active_material
        src_ci = int(src_mat['lfs_cidx'])

        raw = bytearray(base64.b64decode(o['lfs_subobj_raw_b64']))
        lods = raw[3]; geo = 28 + lods*4
        nv = _st.unpack_from('<H', raw, geo)[0]
        nf = _st.unpack_from('<H', raw, geo+2)[0]
        scratch = (nf == 0)
        if not scratch:
            tp = geo + 28 + nv*16 + nf*12
            pg = _st.unpack_from('<i', raw, tp)[0]; tp += 4 + pg*24
            co = _st.unpack_from('<i', raw, tp)[0]; tp += 4 + co*32
            cnt_pos = tp
            nm = _st.unpack_from('<H', raw, tp)[0]; tp += 4
            maps_end = tp + nm*52
            if src_ci >= nm:
                self.report({'ERROR'}, "Material's cidx has no map record.")
                return {'CANCELLED'}
            src_rec = bytes(raw[tp + src_ci*52: tp + (src_ci+1)*52])
            base_name = src_rec[:16].split(b'\x00', 1)[0].decode('latin-1')
        else:
            src_rec = None
            base_name = src_mat.name

        slots = {si for si, s in enumerate(o.material_slots)
                 if s.material == src_mat}
        polys = [p.index for p in me.polygons if p.material_index in slots]
        if not polys:
            self.report({'ERROR'}, "No faces use the active material.")
            return {'CANCELLED'}

        parent = {p: p for p in polys}

        def find(x):
            while parent[x] != x:
                parent[x] = parent[parent[x]]
                x = parent[x]
            return x
        vert_owner = {}
        for p in polys:
            for v in me.polygons[p].vertices:
                if v in vert_owner:
                    ra, rb = find(vert_owner[v]), find(p)
                    if ra != rb:
                        parent[ra] = rb
                else:
                    vert_owner[v] = p
        comps = {}
        for p in polys:
            comps.setdefault(find(p), []).append(p)
        comp_list = []
        for cpolys in comps.values():
            cen = Vector((0, 0, 0)); area = 0.0
            for p in cpolys:
                pl = me.polygons[p]
                cen += (mw @ pl.center) * pl.area
                area += pl.area
            if area > 0:
                cen /= area
            comp_list.append({'polys': cpolys, 'cen': cen, 'area': area})
        merged = []
        for cmp_ in sorted(comp_list, key=lambda c: -c['area']):
            tgt = None
            for g in merged:
                if (g['cen'] - cmp_['cen']).length < self.merge_dist:
                    tgt = g; break
            if tgt is None:
                merged.append(dict(cmp_))
            else:
                tot = tgt['area'] + cmp_['area']
                if tot > 0:
                    tgt['cen'] = (tgt['cen']*tgt['area'] + cmp_['cen']*cmp_['area']) / tot
                tgt['polys'] = tgt['polys'] + cmp_['polys']
                tgt['area'] = tot

        def aligned_hp(plist):
            navg = Vector((0, 0, 0)); ar = 0.0
            cen = Vector((0, 0, 0))
            for p in plist:
                pl = me.polygons[p]
                navg += (mn @ pl.normal) * pl.area
                cen += (mw @ pl.center) * pl.area
                ar += pl.area
            cen /= max(ar, 1e-9)
            coher = navg.length / max(ar, 1e-9)
            if navg.length > 1e-9:
                n = navg.normalized()
                p_deg = math.degrees(math.asin(-max(-1.0, min(1.0, n.z))))
                h_deg = (math.degrees(math.atan2(n.x, -n.y))
                         if (abs(n.x) + abs(n.y)) > 1e-6 else 0.0)
            else:
                p_deg, h_deg = -90.0, 0.0
            return h_deg, p_deg, cen, coher, ar

        CARDS = [Vector((0, 0, 1)), Vector((0, 0, -1)), Vector((0, 1, 0)),
                 Vector((0, -1, 0)), Vector((1, 0, 0)), Vector((-1, 0, 0))]
        final = []
        for g in sorted(merged, key=lambda c: -c['area']):
            h, p_, cen, coher, ar = aligned_hp(g['polys'])
            if coher >= self.coherence:
                final.append((g['polys'], h, p_, cen))
            else:
                buckets = {i: [] for i in range(6)}
                areas = {i: 0.0 for i in range(6)}
                for p in g['polys']:
                    nrm = mn @ me.polygons[p].normal
                    k = max(range(6), key=lambda i: nrm.dot(CARDS[i]))
                    buckets[k].append(p)
                    areas[k] += me.polygons[p].area
                order = sorted(range(6), key=lambda i: -areas[i])
                main = order[0]
                for i in order[1:]:
                    if buckets[i] and areas[i] < g['area'] * self.min_share:
                        buckets[main].extend(buckets[i]); buckets[i] = []
                for i in order:
                    if not buckets[i]:
                        continue
                    h, p_, cen, _, _ = aligned_hp(buckets[i])
                    final.append((buckets[i], h, p_, cen))
        if not final:
            self.report({'ERROR'}, "Nothing to map.")
            return {'CANCELLED'}

        TOL = 0.09
        merged_final = []
        used = [False] * len(final)
        for i in range(len(final)):
            if used[i]:
                continue
            pi, hi, pti, ci_ = final[i]
            twin = None
            if abs(ci_.x) > 0.06:
                for j in range(i + 1, len(final)):
                    if used[j]:
                        continue
                    pj, hj, ptj, cj_ = final[j]
                    if (abs(ci_.x + cj_.x) < TOL
                            and abs(ci_.y - cj_.y) < TOL
                            and abs(ci_.z - cj_.z) < TOL
                            and abs(((hi + hj + 180.0) % 360.0) - 180.0) < 25.0
                            and abs(pti - ptj) < 12.0):
                        twin = j
                        break
            if twin is not None:
                used[twin] = True
                pj, hj, ptj, cj_ = final[twin]
                keep = final[i] if ci_.x <= 0 else final[twin]
                merged_final.append((list(pi) + list(pj),
                                     keep[1], keep[2], keep[3]))
            else:
                merged_final.append((list(pi), hi, pti, ci_))
            used[i] = True
        final = merged_final

        T = int(round(self.tile * FP_))

        def fill(rec, h, p_, cen):
            _st.pack_into('<I', rec, 24, enc_h(h) | (enc_p(p_) << 11))
            _st.pack_into('<iii', rec, 28, int(round(cen.x*FP_)),
                          int(round(cen.y*FP_)), int(round(cen.z*FP_)))
            _st.pack_into('<ii', rec, 40, T, T)

        made = 0
        if scratch:
            plist, h, p_, cen = final[0]
            src_mat['lfs_map_rot'] = enc_h(h) | (enc_p(p_) << 11)
            src_mat['lfs_map_pos'] = [cen.x, cen.y, cen.z]
            src_mat['lfs_map_wh'] = [self.tile, self.tile]
            next_ci = 0
            for m_ in bpy.data.materials:
                try:
                    next_ci = max(next_ci, int(m_.get('lfs_cidx', -1)))
                except (ValueError, TypeError):
                    pass
            made = 1
            for plist, h, p_, cen in final[1:]:
                next_ci += 1
                if next_ci > _CIDX_MAX:
                    self.report({'WARNING'}, "Map limit reached.")
                    break
                mat2 = src_mat.copy()
                mat2['lfs_split_from'] = src_mat.get('lfs_split_from', src_mat.name)
                mat2.name = (src_mat.name[:11] + '_p' + str(made + 1))[:15]
                mat2['lfs_cidx'] = next_ci
                mat2['lfs_map_rot'] = enc_h(h) | (enc_p(p_) << 11)
                mat2['lfs_map_pos'] = [cen.x, cen.y, cen.z]
                mat2['lfs_map_wh'] = [self.tile, self.tile]
                me.materials.append(mat2)
                ns = len(me.materials) - 1
                for p in plist:
                    me.polygons[p].material_index = ns
                made += 1
            me.update()
        else:
            plist, h, p_, cen = final[0]
            rec0 = bytearray(src_rec)
            fill(rec0, h, p_, cen)
            raw[tp + src_ci*52: tp + (src_ci+1)*52] = rec0
            made = 1
            new_records = []
            assigns = []
            for plist, h, p_, cen in final[1:]:
                new_ci = nm + len(new_records)
                if new_ci > 255:
                    self.report({'WARNING'}, "Map limit (255) reached.")
                    break
                rec = bytearray(src_rec)
                nm_new = (base_name[:12] + '_p' + str(made + 1)).encode('latin-1')[:15]
                rec[0:16] = nm_new + b'\x00' * (16 - len(nm_new))
                fill(rec, h, p_, cen)
                new_records.append(bytes(rec))
                assigns.append((list(plist), new_ci))
                mat2 = src_mat.copy()
                mat2['lfs_split_from'] = src_mat.get('lfs_split_from', src_mat.name)
                mat2['lfs_cidx'] = new_ci
                me.materials.append(mat2)
                ns = len(me.materials) - 1
                for p in plist:
                    me.polygons[p].material_index = ns
                made += 1
            if new_records:
                raw2 = bytes(raw[:maps_end]) + b''.join(new_records) + bytes(raw[maps_end:])
                raw = bytearray(raw2)
                _st.pack_into('<H', raw, cnt_pos, nm + len(new_records))
            if len(me.polygons) == nf:
                fbase = geo + 28 + nv*16
                for plist, ci in assigns:
                    for p in plist:
                        raw[fbase + p*12 + 2] = ci
            me.update()
            o['lfs_subobj_raw_b64'] = base64.b64encode(bytes(raw)).decode('ascii')
        self.report({'INFO'},
                    f"{src_mat.name}: {made} aligned tile mapping(s), "
                    f"tile {self.tile:.2f}m")
        return {'FINISHED'}


class LFS_OT_FixInsideOut(Operator):
    """Turn round closed shells whose faces point inwards: LFS shows only
    the front of a face, so they are invisible there (Blender shows both sides). Open
    sheets and parts imported from an .sre are left alone"""
    bl_idname = "lfs.fix_inside_out"
    bl_label = "Fix Inside-Out Shells"
    bl_options = {'REGISTER', 'UNDO'}

    min_vol: FloatProperty(
        name="Min volume (m3)",
        description="Shells with |signed volume| below this are treated as "
                    "open sheets and left untouched",
        default=0.0001, min=0.0, max=1.0)

    @classmethod
    def poll(cls, context):
        return any(o.type == 'MESH' and 'lfs_subobj_index' in o.keys()
                   for o in bpy.data.objects)

    def execute(self, context):
        import bmesh, base64, struct as _st
        from collections import defaultdict
        from mathutils.bvhtree import BVHTree
        report = []
        total = 0
        marked = [x for x in bpy.data.objects
                  if x.type == 'MESH' and 'lfs_subobj_index' in x.keys()]
        _glass_names = set(_GLASS_MATERIALS)
        try:
            _sc_ov = context.scene.get('lfs_tex_overrides')
            if _sc_ov:
                for _k in _sc_ov.keys():
                    _v = str(_sc_ov[_k]).lower()
                    if 'glass' in _v or _v.startswith('s_'):
                        _glass_names.add(_k.lower())
        except Exception:
            pass
        try:
            _ap, _ag = _auto_detect_from_scene(
                [m.name for m in bpy.data.materials if m.get('lfs_cidx') is not None])
            _glass_names |= {n.lower() for n in (_ag or ())}
        except Exception:
            pass
        _vs = []; _ps = []; _base = 0
        for oo in marked:
            mw = oo.matrix_world
            _slot_glass = [(s.material is not None
                            and s.material.name.lower() in _glass_names)
                           for s in oo.material_slots]
            _vs.extend([tuple(mw @ v.co) for v in oo.data.vertices])
            _ps.extend([tuple(_base + vi for vi in p.vertices)
                        for p in oo.data.polygons
                        if not (p.material_index < len(_slot_glass)
                                and _slot_glass[p.material_index])])
            _base += len(oo.data.vertices)
        try:
            _bvh = BVHTree.FromPolygons(_vs, _ps)
        except Exception:
            _bvh = None

        _EPS = 0.008
        _FAR = 8.0

        def _free(origin, direction):
            if _bvh is None:
                return _FAR
            hit = _bvh.ray_cast(origin + direction * _EPS, direction, _FAR)
            return (hit[3] + _EPS) if hit[0] is not None else _FAR

        for o in marked:
            b64 = o.get('lfs_subobj_raw_b64')
            if b64:
                raw = base64.b64decode(b64)
                geo = 28 + raw[3]*4
                if _st.unpack_from('<H', raw, geo+2)[0] > 0:
                    continue
            me = o.data
            bm = bmesh.new()
            bm.from_mesh(me)
            bm.verts.ensure_lookup_table()
            bm.faces.ensure_lookup_table()
            before = {f.index: (f.verts[0].index, f.verts[1].index)
                      for f in bm.faces}
            bmesh.ops.recalc_face_normals(bm, faces=bm.faces[:])
            flipped = sum(1 for f in bm.faces
                          if before.get(f.index) is not None
                          and (f.verts[0].index, f.verts[1].index) != before[f.index])
            parent = list(range(len(bm.verts)))

            def find(a):
                while parent[a] != a:
                    parent[a] = parent[parent[a]]
                    a = parent[a]
                return a
            for e in bm.edges:
                a, b = find(e.verts[0].index), find(e.verts[1].index)
                if a != b:
                    parent[a] = b
            comp_faces = defaultdict(list)
            for f in bm.faces:
                comp_faces[find(f.verts[0].index)].append(f)
            mw = o.matrix_world
            nmw = mw.to_3x3()
            for c, fs in comp_faces.items():
                fs_sorted = sorted(fs, key=lambda f: -f.calc_area())
                samples = fs_sorted[:max(1, min(60, len(fs_sorted)))]
                front = back = 0.0
                for f in samples:
                    a = f.calc_area()
                    fc = mw @ f.calc_center_median()
                    fn = (nmw @ f.normal)
                    if fn.length < 1e-9:
                        continue
                    fn.normalize()
                    front += _free(fc, fn) * a
                    back += _free(fc, -fn) * a
                if back > front * 1.2 and back > front + 0.01:
                    for f in fs:
                        f.normal_flip()
                    flipped += len(fs)
            if flipped:
                src = None
                if bool(getattr(me, 'has_custom_normals', False)):
                    src = o.copy(); src.data = me.copy()
                    context.collection.objects.link(src)
                bm.to_mesh(me)
                me.update()
                if src is not None:
                    try:
                        mod = o.modifiers.new('nrm', 'DATA_TRANSFER')
                        mod.object = src
                        mod.use_loop_data = True
                        mod.data_types_loops = {'CUSTOM_NORMAL'}
                        mod.loop_mapping = 'POLYINTERP_NEAREST'
                        prev = context.view_layer.objects.active
                        context.view_layer.objects.active = o
                        bpy.ops.object.modifier_apply(modifier='nrm')
                        context.view_layer.objects.active = prev
                    except Exception as _ne:
                        self.report({'WARNING'}, f"{o.name}: normal restore failed: {_ne}")
                    finally:
                        bpy.data.objects.remove(src, do_unlink=True)
                report.append(f"{o.name}: {flipped}")
                total += flipped
            bm.free()
        if total:
            self.report({'INFO'},
                        f"Flipped {total} inside-out face(s): " + ", ".join(report))
        else:
            self.report({'INFO'}, "No inside-out shells found.")
        return {'FINISHED'}


def _lfs_shows_texture(m):
    try:
        if m.get('lfs_tile_size') or str(m.get('lfs_tex_page') or ''):
            return True
        if _lfs_base_color_image(m) is not None:
            return True
        return bool(_find_png_for_material(m.name, ''))
    except Exception:
        return True


class LFS_OT_AutoSplitMaps(Operator):
    """Give every big repeating material its own map per direction its
    faces look (top, front, side...), so its texture does not stretch over curves. Every
    part except the body (the body is for skins). Safe to run again"""
    bl_idname = "lfs.auto_split_maps"
    bl_label = "Auto Split All Maps"
    bl_options = {'REGISTER', 'UNDO'}

    map_size: FloatProperty(name="Tile size (m)", default=0.45,
                            min=0.05, max=4.0)
    soft_tile: FloatProperty(name="Leather / cloth tile (m)", default=0.09,
                             min=0.02, max=2.0,
                             description="Tile scale for leather, seats, alcantara, cloth")
    carpet_tile: FloatProperty(name="Carpet / roof tile (m)", default=0.12,
                               min=0.02, max=2.0)
    min_share: FloatProperty(name="Min bucket share", default=0.05,
                             min=0.0, max=0.5)
    min_area: FloatProperty(
        name="Min area (m2)",
        description="Materials covering less than this are left alone",
        default=0.15, min=0.0, max=10.0)
    include_body: BoolProperty(
        name="Include body (type 0)",
        description="Also split the body sub-object's tiling maps "
                    "(normally OFF - the body is skinned, not tiled)",
        default=False)

    @classmethod
    def poll(cls, context):
        return any(o.type == 'MESH' and 'lfs_subobj_raw_b64' in o.keys()
                   for o in bpy.data.objects)

    def execute(self, context):
        import base64, struct as _st
        done = []
        prev_active = context.view_layer.objects.active
        try:
            _ap_split, _ag_split = _auto_detect_from_scene(
                [m.name for m in bpy.data.materials],
                glass_mode=context.scene.get('lfs_automap_glass_mode', 'AUTO'))
        except Exception:
            _ap_split, _ag_split = set(), set()
        _marked = [x for x in bpy.data.objects if x.type == 'MESH' and 'lfs_subobj_index' in x.keys()]

        def _maps_used():
            try:
                fc = _lfs_material_face_counts(_marked)
                return len({int(bpy.data.materials[n]['lfs_cidx']) for n in fc
                            if bpy.data.materials[n].get('lfs_cidx') is not None})
            except Exception:
                return 0
        def _maps_on(o_):
            try:
                fc = _lfs_material_face_counts([o_])
                return len({int(bpy.data.materials[n]['lfs_cidx']) for n in fc
                            if bpy.data.materials[n].get('lfs_cidx') is not None})
            except Exception:
                return 0
        _nmaps = _maps_used()
        _stop = False
        _split_on = {}
        for o in [x for x in bpy.data.objects
                  if x.type == 'MESH' and 'lfs_subobj_raw_b64' in x.keys()]:
            if _stop:
                break
            raw = base64.b64decode(o['lfs_subobj_raw_b64'])
            if raw[1] == 0 and not self.include_body:
                continue
            lods = raw[3]; geo = 28 + lods*4
            nv = _st.unpack_from('<H', raw, geo)[0]
            nf = _st.unpack_from('<H', raw, geo+2)[0]
            scratch = (nf == 0)
            if scratch:
                _nmaps = _maps_on(o)
            default_ci = set()
            maps_tp = None
            if not scratch:
                tp = geo + 28 + nv*16 + nf*12
                pg = _st.unpack_from('<i', raw, tp)[0]; tp += 4 + pg*24
                co = _st.unpack_from('<i', raw, tp)[0]; tp += 4 + co*32
                nm = _st.unpack_from('<H', raw, tp)[0]; tp += 4
                maps_tp = tp
                for i in range(nm):
                    mo = tp + i*52
                    r_raw = _st.unpack_from('<I', raw, mo+24)[0]
                    px, py, pz = _st.unpack_from('<iii', raw, mo+28)
                    if r_raw == 360 and px == 0 and py == 0 and pz == 0:
                        default_ci.add(i)
            me = o.data
            if scratch and _split_on:
                _used_si = {p.material_index for p in me.polygons}
                for _si, _s in enumerate(o.material_slots):
                    _m = _s.material
                    if _m is None or _si not in _used_si or _split_on.get(_m.name) in (None, o.name):
                        continue
                    if not _find_png_for_material(_m.name, '') and _lfs_base_color_image(_m) is None:
                        continue
                    _nci = 0
                    for _mm in bpy.data.materials:
                        try:
                            _nci = max(_nci, int(_mm.get('lfs_cidx', -1)))
                        except (TypeError, ValueError):
                            pass
                    if _nci + 1 > _CIDX_MAX:
                        break
                    _cp = _m.copy()
                    for _k in ('lfs_map_rot', 'lfs_map_pos', 'lfs_map_wh', 'lfs_cutout_rect', 'lfs_auto_map'):
                        if _k in _cp.keys():
                            del _cp[_k]
                    _cp['lfs_split_from'] = _m.get('lfs_split_from', _m.name)
                    _cp['lfs_auto_made'] = True
                    _cp['lfs_cidx'] = _nci + 1
                    _cp.name = (_m.name[:11] + '_' + o.name[:3]).lower()
                    _s.material = _cp
            slot_ci = {}
            for si, s in enumerate(o.material_slots):
                if s.material and s.material.get('lfs_cidx') is not None:
                    slot_ci[si] = int(s.material['lfs_cidx'])
            area_ci = {}
            slot_of = {}
            for p in me.polygons:
                ci = slot_ci.get(p.material_index)
                if ci is not None:
                    area_ci[ci] = area_ci.get(ci, 0.0) + p.area
                    slot_of.setdefault(ci, p.material_index)
            if scratch:
                def _ok(ci):
                    m = o.material_slots[slot_of[ci]].material
                    if m.get('lfs_map_rot') is not None:
                        return False
                    if ci == 1:
                        return False
                    _ml = m.name.lower()
                    if (_ml in _ap_split or _ml in _ag_split or _ml in _PAINT_SKIN_MATERIALS
                            or m.get('lfs_paint') or m.get('lfs_glass')):
                        return False
                    if m.get('lfs_fit_base'):
                        return False
                    if m.get('lfs_tex_page') is not None and str(m.get('lfs_tex_page')) == '':
                        return False
                    if not _lfs_shows_texture(m):
                        return False
                    nl = ''.join(c for c in m.name.lower() if c.isalnum())
                    return not any(g in nl for g in
                                   ('glass', 'window', 'windscreen',
                                    'windshield'))
                targets = sorted([ci for ci in area_ci
                                  if area_ci[ci] >= self.min_area
                                  and ci in slot_of and _ok(ci)],
                                 key=lambda c: -area_ci[c])
            else:
                targets = sorted([ci for ci in default_ci
                                  if area_ci.get(ci, 0.0) >= self.min_area
                                  and ci in slot_of],
                                 key=lambda c: -area_ci[c])
            if not targets:
                continue
            context.view_layer.objects.active = o
            _SOFT = ('leath', 'seat', 'sits', 'alcant', 'suede', 'cloth', 'fabric')
            _CARP = ('carpet', 'floor', 'roof', 'interior')
            for ci in targets:
                o.active_material_index = slot_of[ci]
                mname = o.material_slots[slot_of[ci]].material.name
                sem = mname.lower()
                if maps_tp is not None:
                    sem = bytes(raw[maps_tp + ci*52: maps_tp + ci*52 + 16]) \
                        .split(b'\0')[0].decode('latin-1').lower()
                _pgs = str(o.material_slots[slot_of[ci]].material.get('lfs_tex_page') or '').lower()
                _own_tile = o.material_slots[slot_of[ci]].material.get('lfs_tile_size')
                if _nmaps + 6 > _MAP_TABLE_MAX:
                    _left9 = [o.material_slots[slot_of[c_]].material.name for c_ in targets
                              if c_ in slot_of and o.material_slots[slot_of[c_]].material is not None]
                    _left9 = _left9[_left9.index(mname):] if mname in _left9 else _left9
                    self.report({'WARNING'}, f"{o.name}: its map list is nearly full ({_nmaps} of "
                                             f"{_MAP_TABLE_MAX}) - not split: " + ", ".join(_left9[:6]))
                    if not scratch:
                        _stop = True
                    break
                _pro_ok = _nmaps < 150
                try:
                    if _own_tile:
                        if float(_own_tile) < 0.25 and _pro_ok:
                            bpy.ops.lfs.pro_map_material(tile=float(_own_tile))
                        else:
                            bpy.ops.lfs.split_map_directions(
                                map_size=float(_own_tile), min_share=self.min_share)
                    elif any(h in sem for h in _SOFT) or 'leath' in _pgs:
                        if _pro_ok:
                            bpy.ops.lfs.pro_map_material(tile=self.soft_tile)
                        else:
                            bpy.ops.lfs.split_map_directions(
                                map_size=self.soft_tile, min_share=self.min_share)
                    elif any(h in sem for h in _CARP) or 'carpet' in _pgs:
                        if _pro_ok:
                            bpy.ops.lfs.pro_map_material(tile=self.carpet_tile)
                        else:
                            bpy.ops.lfs.split_map_directions(
                                map_size=self.carpet_tile, min_share=self.min_share)
                    else:
                        bpy.ops.lfs.split_map_directions(
                            map_size=self.map_size, min_share=self.min_share)
                    done.append(f"{o.name}:{mname}")
                    _split_on[mname] = o.name
                    _nmaps = _maps_on(o) if scratch else _maps_used()
                except Exception as e:
                    self.report({'WARNING'}, f"{o.name}/{mname}: {e}")
        context.view_layer.objects.active = prev_active
        if done:
            self.report({'INFO'},
                        f"Auto-split {len(done)} material(s): " + ", ".join(done))
        else:
            self.report({'INFO'}, "Nothing to split (all maps already set up).")
        return {'FINISHED'}


class LFS_OT_RotateCar180(Operator):
    """Rotate ALL marked sub-objects 180 degrees around the world Z axis.
    Use when the exported car faces backwards in LFS. Pivot positions
    (object origins) rotate along with the geometry."""
    bl_idname = "lfs.rotate_car_180"
    bl_label = "Rotate Car 180"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        import math, base64, struct as _st
        from mathutils import Matrix
        rot = Matrix.Rotation(math.radians(180), 4, 'Z')
        n = 0
        n_maps = 0
        for o in bpy.data.objects:
            if o.type == 'MESH' and 'lfs_subobj_index' in o.keys():
                o.matrix_world = rot @ o.matrix_world
                n += 1
                b64 = o.get('lfs_subobj_raw_b64')
                if not b64:
                    continue
                raw = bytearray(base64.b64decode(b64))
                try:
                    lods = raw[3]
                    geo = 28 + lods*4
                    nv = _st.unpack_from('<H', raw, geo)[0]
                    nf = _st.unpack_from('<H', raw, geo+2)[0]
                    tp = geo + 28 + nv*16 + nf*12
                    pg = _st.unpack_from('<i', raw, tp)[0]; tp += 4 + pg*24
                    co = _st.unpack_from('<i', raw, tp)[0]; tp += 4 + co*32
                    nm = _st.unpack_from('<H', raw, tp)[0]; tp += 4
                    for mi in range(nm):
                        mo = tp + mi*52
                        r_raw = _st.unpack_from('<I', raw, mo+24)[0]
                        px, py, pz = _st.unpack_from('<iii', raw, mo+28)
                        if r_raw == 360 and px == 0 and py == 0 and pz == 0:
                            continue
                        hq = r_raw & 2047
                        h_deg = (hq - 2048 if hq > 720 else hq) / 4.0
                        d = ((h_deg + 180.0 + 180.0) % 360.0) - 180.0
                        q = int(round(d * 4))
                        if q < 0:
                            q += 2048
                        _st.pack_into('<I', raw, mo+24,
                                      (r_raw & ~2047) | (q & 2047))
                        _st.pack_into('<iii', raw, mo+28, -px, -py, pz)
                        n_maps += 1
                    o['lfs_subobj_raw_b64'] = base64.b64encode(bytes(raw)).decode('ascii')
                except Exception as e:
                    print(f"  [rotate180] map table skipped on {o.name}: {e}")
        self.report({'INFO'},
                    f"Rotated {n} sub-object(s) 180 deg ({n_maps} map gizmo(s) followed).")
        return {'FINISHED'}


class LFS_OT_PrepSteering(Operator):
    """Make the active object an LFS steering wheel: lays it flat, facing
    up (LFS turns it onto the column) and puts its origin at the rim centre, the point LFS
    turns it around"""
    bl_idname = "lfs.prep_steering"
    bl_label = "Prep Steering Wheel"
    bl_options = {'REGISTER', 'UNDO'}

    clock_deg: FloatProperty(
        name="Spin (deg)",
        description="Extra rotation around the wheel axis after levelling, "
                    "to clock the spokes (e.g. 12 o'clock forward)",
        default=0.0, min=-180.0, max=180.0)

    @classmethod
    def poll(cls, context):
        o = context.active_object
        return o is not None and o.type == 'MESH'

    def execute(self, context):
        import numpy as np, math
        from mathutils import Vector, Matrix
        o = context.active_object
        me = o.data
        mw = o.matrix_world.copy()

        for v in me.vertices:
            v.co = mw @ v.co
        o.matrix_world = Matrix.Identity(4)

        V = np.array([list(v.co) for v in me.vertices])
        c0 = V.mean(axis=0)
        U = V - c0
        _, _, vt = np.linalg.svd(U, full_matrices=False)
        n = vt[2]
        if n[1] > 0 or (abs(n[1]) < 1e-6 and n[2] < 0):
            n = -n
        R = Vector(n.tolist()).normalized().rotation_difference(
            Vector((0, 0, 1))).to_matrix().to_4x4()
        T = Matrix.Translation(Vector(c0.tolist()))
        xf = T @ R @ T.inverted()
        for v in me.vertices:
            v.co = xf @ v.co
        V = np.array([list(v.co) for v in me.vertices])
        c1 = V.mean(axis=0)
        r = np.sqrt((V[:, 0]-c1[0])**2 + (V[:, 1]-c1[1])**2)
        rim = V[r >= 0.85 * r.max()]
        rc = rim.mean(axis=0)
        _, _, vt2 = np.linalg.svd(rim - rc, full_matrices=False)
        n2 = vt2[2]
        if n2[2] < 0: n2 = -n2
        R2 = Vector(n2.tolist()).normalized().rotation_difference(
            Vector((0, 0, 1))).to_matrix().to_4x4()
        T2 = Matrix.Translation(Vector(rc.tolist()))
        xf2 = T2 @ R2 @ T2.inverted()
        for v in me.vertices:
            v.co = xf2 @ v.co
        V = np.array([list(v.co) for v in me.vertices])
        r = np.sqrt((V[:, 0]-V[:,0].mean())**2 + (V[:, 1]-V[:,1].mean())**2)
        rim = V[r >= 0.85 * r.max()]
        c = Vector(rim.mean(axis=0).tolist())
        spin = Matrix.Rotation(math.radians(self.clock_deg), 4, 'Z')
        for v in me.vertices:
            v.co = spin @ (v.co - c)
        o.location = c
        me.update()
        self.report({'INFO'},
                    f"Steering prepped: flat, pivot at ({c.x:.2f}, {c.y:.2f}, {c.z:.2f})")
        return {'FINISHED'}


class LFS_OT_SpinSteering(Operator):
    """Turn the active object round its own Z axis (to line the spokes up
    after Prep Steering)"""
    bl_idname = "lfs.spin_steering"
    bl_label = "Spin Steering"
    bl_options = {'REGISTER', 'UNDO'}

    angle_deg: FloatProperty(name="Angle (deg)", default=90.0,
                             min=-180.0, max=180.0)

    @classmethod
    def poll(cls, context):
        o = context.active_object
        return o is not None and o.type == 'MESH'

    def execute(self, context):
        import math
        from mathutils import Matrix
        o = context.active_object
        spin = Matrix.Rotation(math.radians(self.angle_deg), 4, 'Z')
        for v in o.data.vertices:
            v.co = spin @ v.co
        o.data.update()
        self.report({'INFO'}, f"Spun {self.angle_deg:.0f} degrees.")
        return {'FINISHED'}


class LFS_OT_AutoSmoothGroups(Operator):
    """Mark hard edges by angle so the smoothing groups are VISIBLE in Blender
    before you export.

    Edit Mode  -> works on the selected faces only (the part you just added).
    Object Mode-> works on every selected mesh object.

    The exporter treats authored sharp edges as the source of truth, so what
    you see in the viewport is what LFS gets. Re-run with a different angle
    any time: it clears and re-marks only inside the scope you ran it on.
    """
    bl_idname = 'lfs.auto_smooth_groups'
    bl_label = 'Auto Smooth Groups'
    bl_options = {'REGISTER', 'UNDO'}

    angle: FloatProperty(
        name='Angle',
        description='Hard edge where faces bend more than this. Lower = more '
                    'groups / crisper creases; higher = fewer / softer',
        default=30.0, min=1.0, max=180.0)
    selected_only: BoolProperty(
        name='Selected faces only',
        description='Edit Mode: only touch selected faces. Off = whole mesh',
        default=True)
    shade_smooth: BoolProperty(
        name='Shade smooth',
        description='Also set the faces to smooth shading so the result is '
                    'visible immediately',
        default=True)
    keep_existing: BoolProperty(
        name='Keep edges I marked by hand',
        description='ON (default): only ADD hard edges - anything you marked '
                    'sharp yourself is left alone, however shallow it is. '
                    'OFF: the angle decides every edge in scope, so your own '
                    'marks below the angle get cleared',
        default=True)

    def execute(self, context):
        import bmesh, math
        cos_t = math.cos(math.radians(self.angle))
        edit = (context.mode == 'EDIT_MESH')
        if edit:
            objs = [context.edit_object] if context.edit_object else []
        else:
            objs = [o for o in context.selected_objects if o.type == 'MESH']
        if not objs:
            self.report({'WARNING'}, 'Select a mesh first')
            return {'CANCELLED'}

        marked = cleared = scoped = kept = 0
        for o in objs:
            me = o.data
            if edit:
                bm = bmesh.from_edit_mesh(me)
            else:
                bm = bmesh.new(); bm.from_mesh(me)
            use_sel = self.selected_only and edit
            for f in bm.faces:
                if use_sel and not f.select:
                    continue
                scoped += 1
                if self.shade_smooth:
                    f.smooth = True
            for e in bm.edges:
                lf = e.link_faces
                if len(lf) != 2:
                    continue
                if use_sel and not (lf[0].select and lf[1].select):
                    continue
                n1, n2 = lf[0].normal, lf[1].normal
                d = n1.x*n2.x + n1.y*n2.y + n1.z*n2.z
                want = (d < cos_t)
                if want:
                    if e.smooth:
                        marked += 1
                    e.smooth = False
                elif not self.keep_existing:
                    if not e.smooth:
                        cleared += 1
                    e.smooth = True
                elif not e.smooth:
                    kept += 1
            if edit:
                bmesh.update_edit_mesh(me)
            else:
                bm.to_mesh(me); bm.free(); me.update()

        try:
            context.scene['lfs_ve_smooth_angle'] = float(self.angle)
        except Exception:
            pass
        if scoped == 0:
            self.report({'WARNING'}, 'No faces in scope - select some faces')
            return {'CANCELLED'}
        self.report({'INFO'},
                    'Auto smooth @%.0f deg: %d hard edge(s) added, %d kept as '
                    'you marked them, %d cleared, %d face(s)'
                    % (self.angle, marked, kept, cleared, scoped))
        return {'FINISHED'}


class LFS_OT_FindBadTris(Operator):
    """Find the broken triangles that came in WITH the .sre file.

    Two kinds, both authored into the source model, not made by the importer:
      DEGENERATE - two corners on the same point (zero area). Invisible, but
        they carry smoothing/map data and confuse edge tools. Always safe to
        delete.
      SPIKES - very long, very thin triangles (a 1.35 m x few-mm sliver across
        the cabin is what reads as "stretched" in LFS). These have real area,
        so they are NOT deleted automatically: they are selected for you to
        weld or collapse by hand.

    Runs on every selected mesh, or on all sub-objects if nothing is selected.
    """
    bl_idname = 'lfs.find_bad_tris'
    bl_label = 'Find Bad Triangles'
    bl_options = {'REGISTER', 'UNDO'}

    ratio: FloatProperty(
        name='Thinness',
        description='Longest edge divided by height. 50 = fifty times longer '
                    'than it is wide. Lower catches more',
        default=50.0, min=2.0, max=10000.0)
    min_length: FloatProperty(
        name='Min length (m)',
        description='Only flag thin triangles at least this long - short thin '
                    'ones are usually legitimate trim strips',
        default=0.3, min=0.0, max=10.0)
    delete_degenerate: BoolProperty(
        name='Delete zero-area ones',
        description='Remove triangles whose corners collapse to a point or a '
                    'line. Always safe - they render as nothing',
        default=True)

    def execute(self, context):
        import bmesh
        objs = [o for o in context.selected_objects
                if o.type == 'MESH' and len(o.data.polygons)]
        if not objs:
            objs = [o for o in context.scene.objects
                    if o.type == 'MESH' and len(o.data.polygons)
                    and 'lfs_subobj_index' in o.keys()]
        if not objs:
            self.report({'WARNING'}, 'No mesh to check')
            return {'CANCELLED'}
        if context.mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')

        tot_deg = tot_spike = 0
        worst = 0.0
        per_obj = []
        for o in objs:
            me = o.data
            bm = bmesh.new(); bm.from_mesh(me)
            dead = []; spikes = []
            for f in bm.faces:
                vs = [v.index for v in f.verts]
                if len(vs) != 3:
                    continue
                if len(set(vs)) != 3 or f.calc_area() <= 1e-12:
                    dead.append(f); continue
                e = [(f.verts[0].co - f.verts[1].co).length,
                     (f.verts[1].co - f.verts[2].co).length,
                     (f.verts[2].co - f.verts[0].co).length]
                L = max(e)
                alt = 2.0 * f.calc_area() / L if L > 0 else 0.0
                if alt <= 0:
                    dead.append(f); continue
                if (L / alt) >= self.ratio and L >= self.min_length:
                    spikes.append((f, L))
            nd = len(dead); ns = len(spikes)
            if self.delete_degenerate and dead:
                bmesh.ops.delete(bm, geom=dead, context='FACES')
            for f in bm.faces:
                f.select_set(False)
            for f, L in spikes:
                if f.is_valid:
                    f.select_set(True)
                    worst = max(worst, L)
            bm.to_mesh(me); bm.free(); me.update()
            tot_deg += nd; tot_spike += ns
            if nd or ns:
                per_obj.append('%s: %d zero-area, %d spike(s)' % (o.name, nd, ns))

        for line in per_obj:
            print('  [lfs-badtris] ' + line)
        self.report({'INFO'},
                    'Bad tris: %d zero-area %s, %d spike(s) selected'
                    '%s' % (tot_deg,
                            'deleted' if self.delete_degenerate else 'found',
                            tot_spike,
                            (' (longest %.2f m)' % worst) if worst else ''))
        return {'FINISHED'}


class VIEW3D_PT_LFS_SRE_Export(Panel):
    bl_label = "LFS SRE"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "LFS"

    def draw(self, context):
        layout = self.layout
        scene = context.scene
        _dups = _lfs_other_copies()
        if _dups:
            _db = layout.box()
            _db.alert = True
            _db.label(text="Another LFS SRE add-on is on:", icon='ERROR')
            for _d in _dups[:3]:
                _db.label(text="    " + _d)
            _db.label(text="Turn it off: Preferences > Add-ons")

        ve_objs = [o for o in scene.objects
                   if o.type == 'MESH' and 'lfs_subobj_index' in o.keys()]
        new_meshes = [o for o in scene.objects
                      if o.type == 'MESH' and 'lfs_subobj_index' not in o.keys()
                      and not o.get('lfs_preview_only')]

        def _tp(o):
            b = o.get('lfs_subobj_raw_b64')
            if b:
                try:
                    import base64
                    return base64.b64decode(b)[1]
                except Exception:
                    pass
            return o.get('lfs_subobj_type', 3)

        n_body = sum(1 for o in ve_objs if _tp(o) == 0)

        _imported = any(_lfs_is_imported(o) for o in ve_objs)
        if not _imported:
            cap = layout.column(align=True); cap.scale_y = 0.75
            cap.label(text="A model from FBX, OBJ, a .blend:", icon='INFO')
            top = layout.column(align=True)
            top.scale_y = 1.6
            top.operator("lfs.auto_setup", text="1   Auto Setup", icon='SHADERFX')
            top.operator("lfs.bake_textures", text="2   Bake Textures for LFS", icon='TEXTURE')
            rr = layout.row(align=True); rr.scale_y = 0.9
            rr.operator("lfs.reset_textures", text="Undo Bake", icon='LOOP_BACK')
            cap = layout.column(align=True); cap.scale_y = 0.75
            cap.label(text="3   Export to LFS (below)")
        import os as _os
        if not _os.path.isdir(_resolve_png_dir() or ''):
            _pp = _png_prefs()
            if _pp is not None:
                _pb = layout.box()
                _pb.label(text="Texture folder (your LFS data\\png):", icon='FILE_FOLDER')
                _pb.prop(_pp, "png_dir", text="")

        box = layout.box()
        if not ve_objs:
            box.label(text="No sub-objects yet.", icon='INFO')
            box.label(text="Import an .sre, or Auto Setup a model.")
        else:
            row = box.row()
            row.label(text=f"{len(ve_objs)} sub-objects", icon='OBJECT_DATA')
            if n_body == 1:
                row.label(text="Body OK", icon='CHECKMARK')
            elif n_body == 0:
                row.label(text="No Body!", icon='ERROR')
            else:
                row.label(text=f"{n_body} Bodies!", icon='ERROR')
            if new_meshes:
                box.label(text=f"{len(new_meshes)} mesh(es) not marked",
                          icon='ERROR')
            if not _imported:
                try:
                    _off = _lfs_steer_offset(ve_objs, next((o for o in ve_objs if _tp(o) == 2), None))
                except Exception:
                    _off = None
                if _off is not None and _off < -0.05:
                    _fb = box.column(align=True)
                    _fb.alert = True
                    _fb.label(text="Faces backwards for LFS", icon='ERROR')
                    _fb.operator("lfs.rotate_car_180", text="Rotate 180", icon='FILE_REFRESH')

        exp = layout.column(align=True)
        exp.scale_y = 1.4
        exp.enabled = bool(ve_objs) and n_body == 1
        exp.operator("export_scene.lfs_sre", text="Export to LFS", icon='EXPORT')
        if ve_objs and n_body != 1:
            layout.label(text="Fix the Body count to enable export.",
                         icon='INFO')

        row = layout.row(align=True)
        row.operator("lfs.find_bad_tris", text="Find Bad Triangles", icon='ERROR')
        row.operator("lfs.rotate_car_180", text="Rotate 180", icon='FILE_REFRESH')
        if ve_objs:
            _ms_on = bool(scene.get(_MS_KEY))
            layout.operator("lfs.mirror_side", icon='MOD_MIRROR', depress=_ms_on,
                            text="Mirrored Side: shown" if _ms_on else "Show Mirrored Side")
        if scene.get('lfs_ve_flip_y_on_export', False):
            fr = layout.row(align=True)
            fr.alert = True
            fr.operator("lfs.toggle_flip_y", text="Global Y-flip: ON (mirrors the car)",
                        icon='FILE_REFRESH')
        cap = layout.column(align=True); cap.scale_y = 0.75
        cap.label(text="Parts, types, Dish, smoothing groups:", icon='INFO')
        cap.label(text="    the SRE Sub-Objects panel.")
        layout.operator("lfs.copy_bug_report", icon='COPYDOWN')


class VIEW3D_PT_LFS_SRE_Other(Panel):
    """Tools for models from other formats (FBX, OBJ...)"""
    bl_label = "Models from other formats"
    bl_parent_id = "VIEW3D_PT_LFS_SRE_Export"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "LFS"
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        layout = self.layout
        col = layout.column(align=True)
        col.operator("lfs.make_subobj", text="Mark Selected Part(s)", icon='ADD')
        r = col.row(align=True)
        r.operator("lfs.prep_steering", text="Prep Steering", icon='PROP_CON')
        r.operator("lfs.spin_steering", text="Spin", icon='FORCE_MAGNETIC')
        col = layout.column(align=True)
        col.label(text="Mesh repair")
        col.operator("lfs.weld_panel_gaps", text="Weld Panel Gaps", icon='AUTOMERGE_ON')
        col.operator("lfs.mark_double_sided", text="Mark Double-Sided", icon='MOD_MIRROR')
        col.operator("lfs.fix_inside_out", text="Fix Inside-Out Shells", icon='NORMALS_FACE')
        col = layout.column(align=True)
        col.label(text="Texture maps")
        col.operator("lfs.purge_unused_maps", text="Purge Unused Maps", icon='TRASH')
        col.operator("lfs.set_tex_page", text="Set Texture by Name...", icon='TEXTURE')
        col.operator("lfs.set_tile_size", text="Set Tile Size (leather...)", icon='FULLSCREEN_ENTER')
        col.operator("lfs.auto_split_maps", text="Auto Split All Maps", icon='MOD_EXPLODE')
        col.operator("lfs.split_map_directions", text="Split Map by Direction", icon='CUBE')
        col.operator("lfs.pro_map_material", text="Pro-Map Material", icon='MOD_MESHDEFORM')


class VIEW3D_PT_LFS_SRE_Materials(Panel):
    """Which LFS map (the editor's map number) every material uses"""
    bl_label = "LFS Map per Material"
    bl_idname = "VIEW3D_PT_lfs_sre_materials"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "LFS"
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        layout = self.layout
        cidx_to_name = _get_scene_map_names(context)
        n_slots = (max(cidx_to_name.keys()) + 1) if cidx_to_name else 0

        row = layout.row(align=True)
        op1 = row.operator("lfs.auto_map_materials", text="Auto Assign", icon='AUTO')
        op1.overwrite = False
        op2 = row.operator("lfs.auto_map_materials", text="Reassign All", icon='AUTO')
        op2.overwrite = True
        layout.operator("lfs.clear_all_material_cidx", text="Clear All", icon='X')
        
        obj = context.active_object
        if obj and obj.type == 'MESH' and obj.data.uv_layers:
            layout.separator(factor=0.4)
            layout.operator("lfs.bake_texture_to_palette",
                            text="Texture to Face Colours", icon='TEXTURE')

        if not cidx_to_name:
            layout.label(text="Import an .sre to see its maps here.", icon='INFO')
            return

        layout.separator(factor=0.3)

        used = {}
        for obj in context.scene.objects:
            if obj.type != 'MESH' or obj.hide_get():
                continue
            for face in obj.data.polygons:
                if 0 <= face.material_index < len(obj.material_slots):
                    m = obj.material_slots[face.material_index].material
                    if m:
                        used[m.name] = used.get(m.name, 0) + 1
        used_sorted = sorted(used.items(), key=lambda x: -x[1])

        if not used_sorted:
            layout.label(text="No materials in scene")
            return

        bad = []
        for mat_name, count in used_sorted:
            mat = bpy.data.materials.get(mat_name)
            if mat:
                cidx = mat.get('lfs_cidx')
                if cidx is not None and (cidx < 0 or cidx >= n_slots):
                    bad.append((mat, count, cidx))
        if bad:
            wb = layout.box()
            wb.alert = True
            wb.label(text=str(len(bad)) + " material(s): no such map", icon='ERROR')
            wc = wb.column(align=True)
            wc.scale_y = 0.85
            for m, c, ci in bad:
                wr = wc.row(align=True)
                wr.label(text="  " + m.name[:18] + ": cidx=" + str(ci))
                clr = wr.operator("lfs.clear_material_cidx", text="Fix", icon='X')
                clr.material_name = m.name
            layout.separator(factor=0.3)

        cidx_total = Counter()
        for mat_name, count in used_sorted:
            mat = bpy.data.materials.get(mat_name)
            if mat:
                stored = mat.get('lfs_cidx')
                if stored is not None and 0 <= stored < n_slots:
                    c = stored
                else:
                    c = auto_cidx_for_material(mat.name, cidx_to_name)
                    if c < 0:
                        c = 0
                cidx_total[c] += count
        box = layout.box()
        box.label(text="Faces per map (" + str(len(used_sorted)) + " materials):")
        col = box.column(align=True)
        col.scale_y = 0.75
        for ci in sorted(cidx_to_name.keys()):
            cnt = cidx_total.get(ci, 0)
            row = col.row(align=True)
            icon = 'RADIOBUT_ON' if cnt > 0 else 'RADIOBUT_OFF'
            row.label(text="  " + str(ci) + " (" + cidx_to_name[ci] + "): " + str(cnt), icon=icon)

        layout.separator(factor=0.3)

        box = layout.box()
        box.label(text="Materials (click to change):")
        for mat_name, count in used_sorted:
            mat = bpy.data.materials.get(mat_name)
            if not mat:
                continue
            row = box.row(align=True)
            stored = mat.get('lfs_cidx')
            if stored is not None:
                current = stored
            else:
                current = auto_cidx_for_material(mat.name, cidx_to_name)
                if current < 0:
                    current = 0
            is_oob = current < 0 or current >= n_slots
            slot_n = 'OOB' if is_oob else cidx_to_name.get(current, '?')
            is_manual = stored is not None

            disp_name = mat.name[:16] if len(mat.name) <= 16 else mat.name[:14] + ".."
            row.label(text=disp_name + "(" + str(count) + ")")
            sub = row.row(align=True)
            sub.alert = is_oob
            picker = sub.operator("lfs.pick_cidx_menu",
                                  text=str(current) + ":" + slot_n[:9],
                                  icon='ERROR' if is_oob else 'DOWNARROW_HLT')
            picker.material_name = mat.name
            if is_manual:
                clr = row.operator("lfs.clear_material_cidx", text="", icon='X')
                clr.material_name = mat.name


class LFS_OT_PickTexPageMenu(Operator):
    """Choose the texture this material gets in LFS: one of the texture
    pages in your data\\png folder, a plain colour, or automatic (its own picture baked
    when it has one)"""
    bl_idname = "lfs.pick_tex_page_menu"
    bl_label = "Pick Texture Page"
    bl_options = {'REGISTER', 'UNDO'}
    bl_property = "page"
    material_name: StringProperty()

    def _items(self, context):
        global _LFS_TEX_ENUM_ITEMS
        items = [('__AUTO__', "(automatic: bake if it has an image, else colour)", ''),
                 ('__NONE__', "(colour only - no texture)", '')]
        items += [(s, s, '') for s in _lfs_png_stems()]
        _LFS_TEX_ENUM_ITEMS = items
        return items

    page: EnumProperty(items=_items)

    def execute(self, context):
        if self.page == '__AUTO__':
            n = _lfs_apply_tex_page_group(self.material_name, None)
        elif self.page == '__NONE__':
            n = _lfs_apply_tex_page_group(self.material_name, '', tint=False)
        else:
            n = _lfs_apply_tex_page_group(self.material_name, self.page, tint=True)
        _tag_redraw(context)
        self.report({'INFO'}, f"{self.material_name}: {n} material(s) set - re-run Bake (if used), then Export")
        return {'FINISHED'}

    def invoke(self, context, event):
        context.window_manager.invoke_search_popup(self)
        return {'RUNNING_MODAL'}


class LFS_OT_SetTexPage(Operator):
    """Give every material whose name contains a word the same LFS texture
    (e.g. 'plas' -> LeathA_ALP, tinted with each part's colour). Choose '(colour only)' to
    take a texture off"""
    bl_idname = "lfs.set_tex_page"
    bl_label = "Set Texture by Name"
    bl_options = {'REGISTER', 'UNDO'}

    name_filter: StringProperty(name="Material name contains", default="plas")

    def _items(self, context):
        global _LFS_TEX_ENUM_ITEMS
        items = [('__NONE__', "(colour only - no texture)", ''),
                 ('__AUTO__', "(automatic: bake if it has an image)", '')]
        items += [(s, s, '') for s in _lfs_png_stems()]
        _LFS_TEX_ENUM_ITEMS = items
        return items

    page: EnumProperty(name="Texture page", items=_items)
    tint: BoolProperty(name="Tint with the part's colour", default=True,
                       description="Cutout colour = material colour (image average for "
                                   "textured materials). OFF = white = the page's own colour")
    tile: FloatProperty(name="Tile size (m, 0 = keep)", default=0.0, min=0.0, max=4.0,
                        description="Also set the map W/H of already split maps that match")

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self, width=360)

    def execute(self, context):
        f = self.name_filter.lower().strip()
        if not f:
            self.report({'ERROR'}, "Type part of a material name.")
            return {'CANCELLED'}
        roots = set()
        for m in bpy.data.materials:
            if m.get('lfs_baked_from'):
                continue
            if f in m.name.lower() or f in str(m.get('lfs_split_from', '')).lower():
                roots.add(str(m.get('lfs_split_from') or m.name))
        n = 0
        for r in sorted(roots):
            if self.page == '__AUTO__':
                n += _lfs_apply_tex_page_group(r, None)
            elif self.page == '__NONE__':
                n += _lfs_apply_tex_page_group(r, '', tint=False)
            else:
                n += _lfs_apply_tex_page_group(r, self.page, tint=self.tint)
        nt = 0
        if self.tile > 0:
            for m in bpy.data.materials:
                if m.get('lfs_map_rot') is None or m.get('lfs_baked_from'):
                    continue
                if f in m.name.lower() or f in str(m.get('lfs_split_from', '')).lower():
                    m['lfs_map_wh'] = [float(self.tile), float(self.tile)]
                    nt += 1
            for m in bpy.data.materials:
                if not m.get('lfs_baked_from') and (f in m.name.lower() or f in str(m.get('lfs_split_from', '')).lower()):
                    m['lfs_tile_size'] = float(self.tile)
        _tag_redraw(context)
        what = {'__AUTO__': 'automatic', '__NONE__': 'colour only'}.get(self.page, self.page)
        self.report({'INFO'}, f"'{f}': {n} material(s) -> {what}"
                              + (f", tile {self.tile:.3f} m on {nt} map(s)" if nt else '')
                              + " - re-run Bake (if used), then Export")
        return {'FINISHED'} if n else {'CANCELLED'}


class LFS_OT_ClearTexPage(Operator):
    """Back to automatic for this material (for all of them when no name
    is given)"""
    bl_idname = "lfs.clear_tex_page"
    bl_label = "Clear Texture Choice"
    bl_options = {'REGISTER', 'UNDO'}
    material_name: StringProperty()

    def execute(self, context):
        if self.material_name:
            n = _lfs_apply_tex_page_group(self.material_name, None)
        else:
            n = 0
            for m in bpy.data.materials:
                if 'lfs_tex_page' in m.keys():
                    _lfs_set_tex_page(m, None); n += 1
        _tag_redraw(context)
        self.report({'INFO'}, f"{n} material(s) back to automatic")
        return {'FINISHED'}


class LFS_OT_FacesTexture(Operator):
    """The selected faces get this LFS texture - a copy of their material just for them, tinted
    with their own colour. Run Bake Textures for LFS again afterwards"""
    bl_idname = "lfs.faces_texture"
    bl_label = "Texture for Selected Faces"
    bl_options = {'REGISTER', 'UNDO'}

    choice: EnumProperty(name="Texture", items=[
        ('LEATHER', "LFS leather", "LFS's leather page (LeathA_ALP), tinted with the faces' own colour"),
        ('CARPET', "LFS carpet", "LFS's carpet page, tinted with the faces' own colour"),
        ('PLAIN', "Plain colour", "The faces' own colour, no texture"),
        ('BAKE', "Bake", "Painted from the model's own texture"),
        ('BAKE_HI', "Bake sharper", "Painted from the model's own texture with twice the pixels"),
        ('AUTO', "Automatic", "Back to their own material - the bake decides")], default='LEATHER')

    @classmethod
    def poll(cls, context):
        return context.mode == 'EDIT_MESH' and context.edit_object is not None

    def execute(self, context):
        import bmesh
        sfx = {'LEATHER': 'lea', 'CARPET': 'car', 'PLAIN': 'col', 'BAKE': 'bk', 'BAKE_HI': 'bk2'}
        carpet = next((st for st in _lfs_png_stems() if 'carpet' in st.lower()), None)
        n_f = 0; made = []
        for o in [ob for ob in context.objects_in_mode if ob.type == 'MESH']:
            me = o.data
            bm = bmesh.from_edit_mesh(me)
            bm.faces.ensure_lookup_table()
            sel = [f for f in bm.faces if f.select]
            if not sel:
                continue
            uvl = bm.loops.layers.uv.get(str(o.get('lfs_bake_src_uv') or '')) or bm.loops.layers.uv.active
            by_slot = {}
            for f in sel:
                by_slot.setdefault(f.material_index, []).append(f)
            for si, fs in by_slot.items():
                base = o.material_slots[si].material if si < len(o.material_slots) else None
                if base is None:
                    continue
                root = bpy.data.materials.get(str(base.get('lfs_user_from') or '')) or base
                if self.choice == 'AUTO':
                    target = root
                else:
                    tname = f"{root.name[:40]}_{sfx[self.choice]}"
                    target = bpy.data.materials.get(tname)
                    if target is None or str(target.get('lfs_user_from') or '') != root.name:
                        target = root.copy()
                        target.name = tname
                        for k in [k for k in target.keys() if k.startswith('lfs_')]:
                            if k not in ('lfs_glass', 'lfs_alpha'):
                                del target[k]
                        target['lfs_user_from'] = root.name
                        target['lfs_user_choice'] = self.choice
                        rgb = (128, 128, 128)
                        try:
                            img = _lfs_base_color_image(root)
                            if img is not None and uvl is not None and min(img.size) > 0:
                                import numpy as np
                                a = _bake_read_image(img, max_size=256)
                                H, W = a.shape[0], a.shape[1]
                                uv = np.array([(l[uvl].uv[0] % 1.0, l[uvl].uv[1] % 1.0)
                                               for f in fs[:4000] for l in f.loops])
                                xi = np.clip((uv[:, 0] * W).astype(np.int64), 0, W - 1)
                                yi = np.clip((uv[:, 1] * H).astype(np.int64), 0, H - 1)
                                c = a[yi, xi, :3].mean(axis=0)
                                rgb = tuple(int(round(max(0.0, min(1.0, float(v))) * 255)) for v in c)
                            else:
                                rgb = tuple(int(v) for v in _mat_rgb(root))
                        except Exception:
                            pass
                        if self.choice == 'LEATHER':
                            _lfs_set_tex_page(target, _LFS_STOCK_SOFT_PAGE, tint=True, tint_rgb=rgb)
                        elif self.choice == 'CARPET':
                            _lfs_set_tex_page(target, carpet or _LFS_STOCK_SOFT_PAGE, tint=True, tint_rgb=rgb)
                        elif self.choice == 'PLAIN':
                            try:
                                lin = tuple((c_ / 255.0) / 12.92 if c_ <= 10 else (((c_ / 255.0) + 0.055) / 1.055) ** 2.4
                                            for c_ in rgb)
                                for n_ in target.node_tree.nodes:
                                    if n_.type == 'BSDF_PRINCIPLED':
                                        inp = n_.inputs['Base Color']
                                        for lk in list(inp.links):
                                            target.node_tree.links.remove(lk)
                                        inp.default_value = (lin[0], lin[1], lin[2], 1.0)
                                target.diffuse_color = (lin[0], lin[1], lin[2], 1.0)
                            except Exception:
                                pass
                            _lfs_set_tex_page(target, '', tint=False)
                        elif self.choice == 'BAKE_HI':
                            target['lfs_bake_prio'] = 2.0
                        made.append(target.name)
                ti = next((k for k, sl in enumerate(o.material_slots) if sl.material is target), None)
                if ti is None:
                    o.data.materials.append(target)
                    ti = len(o.material_slots) - 1
                for f in fs:
                    f.material_index = ti
                n_f += len(fs)
            bmesh.update_edit_mesh(me)
        if made:
            try:
                _lfs_assign_cidx(made)
            except Exception as _ce:
                self.report({'WARNING'}, str(_ce))
        if not n_f:
            self.report({'WARNING'}, "No faces selected.")
            return {'CANCELLED'}
        _tag_redraw(context)
        what = {'LEATHER': 'LFS leather', 'CARPET': 'LFS carpet', 'PLAIN': 'a plain colour', 'BAKE': 'Bake',
                'BAKE_HI': 'Bake sharper', 'AUTO': 'automatic'}[self.choice]
        self.report({'INFO'}, f"{n_f} face(s) -> {what}. Run Bake Textures for LFS again, then Export.")
        return {'FINISHED'}


class VIEW3D_PT_LFS_SRE_FaceTex(Panel):
    """rc31an: choose the LFS texture of the selected faces"""
    bl_label = "LFS Texture for Selected Faces"
    bl_idname = "VIEW3D_PT_lfs_sre_facetex"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "LFS"

    @classmethod
    def poll(cls, context):
        return context.mode == 'EDIT_MESH'

    def draw(self, context):
        col = self.layout.column(align=True)
        cap = col.column(align=True); cap.scale_y = 0.75
        cap.label(text="Select faces (seats, a door card, the dash...)")
        cap.label(text="and give them:")
        r = col.row(align=True)
        r.operator("lfs.faces_texture", text="LFS leather", icon='MATERIAL').choice = 'LEATHER'
        r.operator("lfs.faces_texture", text="LFS carpet").choice = 'CARPET'
        r = col.row(align=True)
        r.operator("lfs.faces_texture", text="Bake", icon='RENDER_STILL').choice = 'BAKE'
        r.operator("lfs.faces_texture", text="Bake sharper").choice = 'BAKE_HI'
        r = col.row(align=True)
        r.operator("lfs.faces_texture", text="Plain colour", icon='COLOR').choice = 'PLAIN'
        r.operator("lfs.faces_texture", text="Automatic", icon='LOOP_BACK').choice = 'AUTO'
        cap = col.column(align=True); cap.scale_y = 0.75
        cap.label(text="Then run Bake Textures for LFS again.")


class VIEW3D_PT_LFS_SRE_Textures(Panel):
    """Which texture every material gets in LFS"""
    bl_label = "LFS Texture per Material"
    bl_idname = "VIEW3D_PT_lfs_sre_textures"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "LFS"
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        layout = self.layout
        objs = [o for o in context.scene.objects
                if o.type == 'MESH' and 'lfs_subobj_index' in o.keys()]
        if not objs:
            layout.label(text="Run Auto Setup first.", icon='INFO')
            return
        row = layout.row(align=True)
        row.operator("lfs.set_tex_page", text="Set by Name...", icon='TEXTURE')
        row.operator("lfs.clear_tex_page", text="", icon='X').material_name = ''
        cap = layout.column(align=True); cap.scale_y = 0.75
        cap.label(text="bake: its own picture   colour: no texture")
        cap.label(text="Click one to pick an LFS texture.")
        try:
            counts = _lfs_material_face_counts(objs)
        except Exception:
            counts = {}
        groups = {}
        for name, cnt in counts.items():
            m = bpy.data.materials.get(name)
            if m is None:
                continue
            if m.get('lfs_baked_from'):
                root = str(m['lfs_baked_from']); baked = True
            else:
                root = str(m.get('lfs_split_from') or name); baked = False
            g = groups.setdefault(root, {'faces': 0, 'copies': 0, 'baked': 0, 'first': name})
            g['faces'] += cnt
            if name != root:
                if baked:
                    g['baked'] += 1
                else:
                    g['copies'] += 1
        rows = sorted(groups.items(), key=lambda kv: -kv[1]['faces'])
        box = layout.box()
        col = box.column(align=True)
        shown = 0
        for root, g in rows:
            if shown >= 80:
                col.label(text=f"... {len(rows) - shown} more (use Set by Name)")
                break
            shown += 1
            mat = bpy.data.materials.get(root) or bpy.data.materials.get(g['first'])
            text, icon, explicit = _lfs_tex_status(mat)
            if g['baked'] and not explicit:
                text, icon = 'baked', 'RENDER_STILL'
            r = col.row(align=True)
            nm = root if len(root) <= 17 else root[:15] + '..'
            extra = f" +{g['copies']}" if g['copies'] else ''
            r.label(text=f"{nm}{extra} ({g['faces']})")
            op = r.operator("lfs.pick_tex_page_menu", text=text[:16], icon=icon)
            op.material_name = root
            if explicit:
                c = r.operator("lfs.clear_tex_page", text="", icon='X')
                c.material_name = root
            else:
                r.label(text="", icon='BLANK1')


def menu_func_export(self, context):
    self.layout.operator("export_scene.lfs_sre", text="LFS SRE (.sre)")


class LFS_OT_ToggleFlipY(Operator):
    """Toggle whether Y axis gets flipped on export.
    
    LFS uses +Y as forward; FBX/Blender typically use -Y as forward.
    If your car appears facing backwards in LFS Modeller, enable this.
    """
    bl_idname = "lfs.toggle_flip_y"
    bl_label = "Toggle Y-axis flip"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        scene = context.scene
        cur = bool(scene.get('lfs_ve_flip_y_on_export', False))
        scene['lfs_ve_flip_y_on_export'] = not cur
        _tag_redraw(context)
        self.report({'INFO'}, f"Y-flip on export: {'ON' if not cur else 'OFF'}")
        return {'FINISHED'}


class LFS_OT_ToggleNoAutoMirror(Operator):
    """Toggle whether LFS auto-mirrors faces to the opposite side.
    
    LFS's vehicle-editor 'mirror' face byte = 1 means "duplicate this face
    to the opposite side of the car automatically" (half-model convention).
    For OBJ/FBX meshes that already include BOTH sides of the car, set
    this OFF so LFS doesn't draw each face twice (causing z-fighting).
    
    Default: OFF for full-symmetric source meshes, ON for half-models.
    """
    bl_idname = "lfs.toggle_no_auto_mirror"
    bl_label = "Toggle Disable Auto-Mirror"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        scene = context.scene
        cur = bool(scene.get('lfs_ve_no_auto_mirror', False))
        scene['lfs_ve_no_auto_mirror'] = not cur
        _tag_redraw(context)
        self.report({'INFO'}, f"Disable auto-mirror: {'ON' if not cur else 'OFF'}")
        return {'FINISHED'}


class LFS_OT_BakeTextureToPalette(Operator):
    """Turn the active mesh's texture into plain face colours: every face
    gets the colour of the texture under it (up to about 250 colours). Its materials are
    replaced by colour-only ones"""
    bl_idname = "lfs.bake_texture_to_palette"
    bl_label = "Texture to Face Colours"
    bl_options = {'REGISTER', 'UNDO'}
    
    n_clusters: bpy.props.IntProperty(
        name="Color count",
        description="Max number of distinct colors to sample. LFS limits cidx "
                    "to 1 byte (256 slots), so practical max is ~253",
        default=200, min=2, max=253
    )
    
    @classmethod
    def poll(cls, context):
        obj = context.active_object
        if not obj or obj.type != 'MESH':
            return False
        if not obj.data.uv_layers:
            return False
        return True
    
    def execute(self, context):
        obj = context.active_object
        _start = 2
        try:
            _live = _lfs_live_material_names()
            for _m in bpy.data.materials:
                _c = _m.get('lfs_cidx')
                if _c is None or _m.name not in _live:
                    continue
                if any(sl.material is _m for sl in obj.material_slots):
                    continue
                _start = max(_start, int(_c) + 1)
        except Exception:
            _start = 2
        try:
            stats = _bake_texture_to_face_palette(obj, n_clusters=self.n_clusters, start_cidx=_start)
        except ValueError as e:
            self.report({'ERROR'}, str(e))
            return {'CANCELLED'}
        except Exception as e:
            self.report({'ERROR'}, f"Bake failed: {type(e).__name__}: {e}")
            return {'CANCELLED'}
        
        self.report({'INFO'},
            f"Baked {stats['n_faces']} faces into {stats['n_clusters_used']} colors "
            f"(cidx {stats['min_cidx_used']}..{stats['max_cidx_used']})")
        return {'FINISHED'}
    
    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self, width=300)


def _build_planar_maps_for_object(obj, depsgraph, u_sign=1, v_sign=1, swap_uv=False, start_cidx=2, consolidate=True, normal_bucket_deg=25.0, max_maps=200):
    me = obj.evaluated_get(depsgraph).to_mesh() if depsgraph else obj.data
    if not me.uv_layers:
        raise ValueError(f"{obj.name!r} has no UV layer")
    bm = bmesh.new()
    bm.from_mesh(me)
    bm.faces.ensure_lookup_table()
    uv_layer = bm.loops.layers.uv.active
    islands = _mp_get_uv_islands(bm, uv_layer)

    def island_normal(island):
        nx = ny = nz = 0.0
        for f in island:
            a = f.calc_area()
            n = f.normal
            nx += n.x*a; ny += n.y*a; nz += n.z*a
        ln = math.sqrt(nx*nx + ny*ny + nz*nz) or 1.0
        return (nx/ln, ny/ln, nz/ln)

    island_data = []
    for island in islands:
        if island:
            island_data.append((island, island_normal(island)))

    if consolidate:
        cos_thresh = math.cos(math.radians(normal_bucket_deg))
        groups = []
        for faces, normal in island_data:
            mi = faces[0].material_index
            placed = False
            for g in groups:
                if g['mat'] != mi:
                    continue
                gn = g['normal']
                dot = gn[0]*normal[0] + gn[1]*normal[1] + gn[2]*normal[2]
                if dot >= cos_thresh:
                    g['faces'].extend(faces)
                    g['normal'] = (gn[0]+normal[0], gn[1]+normal[1], gn[2]+normal[2])
                    ln = math.sqrt(sum(c*c for c in g['normal'])) or 1.0
                    g['normal'] = tuple(c/ln for c in g['normal'])
                    placed = True
                    break
            if not placed:
                groups.append({'mat': mi, 'normal': normal, 'faces': list(faces)})
        buckets = [(g['faces'], g['normal']) for g in groups]
    else:
        buckets = island_data

    if len(buckets) > max_maps:
        buckets.sort(key=lambda b: len(b[0]), reverse=True)
        keep = buckets[:max_maps]
        spill = buckets[max_maps:]
        for faces, normal in spill:
            best = None; best_dot = -2.0
            for kf, kn in keep:
                dot = kn[0]*normal[0] + kn[1]*normal[1] + kn[2]*normal[2]
                if dot > best_dot:
                    best_dot = dot; best = kf
            best.extend(faces)
        buckets = keep

    records = []
    face_to_cidx = {}
    for i, (faces, normal) in enumerate(buckets):
        verts3d = []
        uvs2d = []
        for f in faces:
            for loop in f.loops:
                co = loop.vert.co
                verts3d.append((co.x, co.y, co.z))
                uv = loop[uv_layer].uv
                uvs2d.append((uv.x, uv.y))
        fit = _mp_fit_planar_mapping(normal, verts3d, uvs2d, u_sign, v_sign, swap_uv)
        cidx = start_cidx + i
        records.append((cidx, fit))
        for f in faces:
            face_to_cidx[f.index] = cidx
    bm.free()
    stats = {'islands': len(island_data), 'maps': len(records), 'faces': len(face_to_cidx)}
    return records, face_to_cidx, stats


class LFS_OT_BakeUVToPlanarMaps(Operator):
    '''Experimental: fit a planar LFS Map per UV island of the active object.
    Calibrate U/V sign + swap with lfs.export_uv_calibration first.'''
    bl_idname = "lfs.bake_uv_to_planar_maps"
    bl_label = "Bake UV -> Planar Maps (Experimental)"
    bl_options = {'REGISTER', 'UNDO'}

    u_sign: bpy.props.IntProperty(name="U sign", default=1)
    v_sign: bpy.props.IntProperty(name="V sign", default=1)
    swap_uv: BoolProperty(name="Swap U/V", default=False)
    consolidate: BoolProperty(name="Consolidate islands",
        description="Group islands sharing a material and similar facing into one map",
        default=True)
    normal_bucket_deg: bpy.props.FloatProperty(name="Group angle (deg)",
        description="Islands whose normals differ by less than this are merged",
        default=25.0, min=1.0, max=90.0)
    max_maps: bpy.props.IntProperty(name="Max maps",
        description="Hard cap on number of planar maps (LFS-friendly)",
        default=200, min=1, max=1000)

    @classmethod
    def poll(cls, context):
        o = context.active_object
        return o is not None and o.type == 'MESH' and o.data.uv_layers

    def execute(self, context):
        obj = context.active_object
        try:
            depsgraph = context.evaluated_depsgraph_get()
            records, face_map, stats = _build_planar_maps_for_object(
                obj, depsgraph, self.u_sign, self.v_sign, self.swap_uv,
                consolidate=self.consolidate,
                normal_bucket_deg=self.normal_bucket_deg,
                max_maps=self.max_maps)
        except Exception as e:
            self.report({'ERROR'}, f"Planar map fit failed: {e}")
            return {'CANCELLED'}
        import base64 as _b64
        blob = bytearray()
        for cidx, fit in records:
            rec = _build_planar_map_record(cidx, f'island_{cidx}', fit)
            blob += struct.pack('<H', cidx) + rec
        context.scene['lfs_planar_maps_b64'] = _b64.b64encode(bytes(blob)).decode('ascii')
        context.scene['lfs_planar_maps_obj'] = obj.name
        self.report({'INFO'},
            f"Fitted {stats['maps']} planar maps from {stats['islands']} islands "
            f"over {stats['faces']} faces (calibrate signs if texture is off)")
        return {'FINISHED'}

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self)


class LFS_OT_ExportUVCalibration(Operator, ExportHelper):
    '''Developer tool: export 6 axis-facing quads as a calibration SRE to verify
    U_SIGN / V_SIGN / SWAP_UV orientation in LFS Modeller.'''
    bl_idname = "lfs.export_uv_calibration"
    bl_label = "Export UV Calibration SRE (Developer)"
    filename_ext = ".sre"
    filter_glob: StringProperty(default="*.sre", options={'HIDDEN'})

    def execute(self, context):
        def _cross(a, b):
            return (a[1]*b[2]-a[2]*b[1], a[2]*b[0]-a[0]*b[2], a[0]*b[1]-a[1]*b[0])
        def _quad_for_axis(nrm):
            nx, ny, nz = nrm
            up = (0, 0, 1) if abs(nz) < 0.9 else (0, 1, 0)
            u = _cross(up, nrm)
            ln = _mapping_math.sqrt(sum(c*c for c in u)) or 1.0
            u = tuple(c/ln for c in u)
            v = _cross(nrm, u)
            return [tuple(s*u[i] + t*v[i] for i in range(3))
                    for (s, t) in [(0,0),(1,0),(1,1),(0,1)]]
        faces = [
            ('px', ( 1, 0, 0)), ('nx', (-1, 0, 0)),
            ('py', ( 0, 1, 0)), ('ny', ( 0,-1, 0)),
            ('pz', ( 0, 0, 1)), ('nz', ( 0, 0,-1)),
        ]
        uvs = [(0,0),(1,0),(1,1),(0,1)]
        lines = []
        for nm, nrm in faces:
            verts = _quad_for_axis(nrm)
            fit = _mp_fit_planar_mapping(nrm, verts, uvs)
            ok = "OK" if (0.9 <= fit['Width'] <= 1.1 and 0.9 <= fit['Height'] <= 1.1) else "CHECK"
            lines.append(f"{nm}: H={fit['H']:7.1f} P={fit['P']:7.1f} "
                         f"W={fit['Width']:.3f} H={fit['Height']:.3f}  [{ok}]")
        txt = self.filepath.replace('.sre', '_calibration.txt')
        with open(txt, 'w') as fh:
            fh.write("UV CALIBRATION - properly-oriented axis-facing quad planar fits\n")
            fh.write("(every face should read W~1.0 H~1.0 and [OK])\n\n")
            fh.write("\n".join(lines) + "\n")
        self.report({'INFO'}, f"Wrote calibration table: {txt}")
        return {'FINISHED'}


class LFS_OT_QuickSetupFromScratch(Operator):
    """One-click setup for FBX / scratch-built models: assign cidx to every
    material, auto-classify paint/glass/grille, optionally fix flipped normals,
    and mark the selected mesh(es) as a sub-object - ready to export."""
    bl_idname = "lfs.quick_setup"
    bl_label = "Quick Setup (from scratch)"
    bl_options = {'REGISTER', 'UNDO'}

    sub_type: EnumProperty(
        name="Sub-Object Type",
        description="LFS sub-object type for the selected mesh",
        items=[
            ('0', "Body (type 0)", "Main exterior body - the painted shell"),
            ('3', "Interior (type 3)", "Cockpit / interior"),
            ('2', "Steering (type 2)", "Steering wheel"),
            ('1', "Generic (type 1)", "Generic sub-object"),
            ('10', "Mirror (type 10)", "The interior rear-view mirror"),
        ],
        default='0')
    paint_pick: EnumProperty(
        name="Paint",
        description="Which material is the body paint (gets white reflection + "
                    "PAINT shine + skin-default map). 'Auto' = largest coloured "
                    "material.",
        items=lambda self, ctx: _quick_material_enum(ctx, allow_auto=True),
    )
    glass_mode: EnumProperty(
        name="Glass detect",
        description="How to decide which materials are see-through glass",
        items=[
            ('AUTO', "Auto", "Transparent shaders + largest near-black material"),
            ('SHADER', "Shader only", "Only materials with alpha/transmission set"),
            ('NONE', "None", "No automatic glass - nothing made see-through"),
        ],
        default='AUTO')
    fix_normals: BoolProperty(
        name="Fix flipped faces",
        description="Recalculate normals outside so inside-out tris render right",
        default=True)
    assign_cidx: BoolProperty(
        name="Assign colour slots",
        description="Give every material a cidx (paint first, then alphabetical)",
        default=True)

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self, width=320)

    def draw(self, context):
        col = self.layout.column()
        col.prop(self, "sub_type")
        col.prop(self, "paint_pick")
        col.prop(self, "glass_mode")
        col.separator()
        col.prop(self, "fix_normals")
        col.prop(self, "assign_cidx")

    def execute(self, context):
        sel = [o for o in context.selected_objects if o.type == 'MESH']
        if not sel:
            self.report({'ERROR'}, "Select at least one mesh first.")
            return {'CANCELLED'}

        if self.fix_normals:
            import bmesh as _bm
            for o in sel:
                bm = _bm.new(); bm.from_mesh(o.data)
                _bm.ops.recalc_face_normals(bm, faces=bm.faces)
                bm.to_mesh(o.data); bm.free(); o.data.update()

        if self.assign_cidx:
            names = []
            for o in sel:
                for s in o.material_slots:
                    if s.material and s.material.name not in names:
                        names.append(s.material.name)
            paint_name = None
            if self.paint_pick and self.paint_pick != 'AUTO':
                paint_name = self.paint_pick
            else:
                try:
                    infos = _collect_mat_infos(sel)
                    p, _g = _auto_classify_materials(infos)
                    if p:
                        for nm in names:
                            if nm.lower() in p:
                                paint_name = nm
                                break
                except Exception:
                    pass
            ordered = sorted(names, key=lambda n: (0 if n == paint_name else 1, n.lower()))
            try:
                _lfs_assign_cidx(ordered, paint_names={paint_name} if paint_name else set())
            except ValueError as _ce:
                self.report({'ERROR'}, str(_ce))
                return {'CANCELLED'}

        context.scene['lfs_automap_glass_mode'] = self.glass_mode

        try:
            bpy.ops.lfs.make_subobj(sub_type=self.sub_type)
        except RuntimeError as _e:
            self.report({'ERROR'}, str(_e).replace('Error: ', '').strip())
            return {'CANCELLED'}

        self.report({'INFO'},
                    "Quick setup done - ready to export (" +
                    ("paint=" + (paint_name or "auto") + ", " if self.assign_cidx else "") +
                    "glass=" + self.glass_mode.lower() + ")")
        return {'FINISHED'}


def _collect_mat_infos(objs):
    area_by = {}
    _zs = {}
    _zlo, _zhi = 1e30, -1e30
    for o in objs:
        try:
            for c_ in o.bound_box:
                z_ = (o.matrix_world @ __import__('mathutils').Vector(c_)).z
                _zlo = min(_zlo, z_); _zhi = max(_zhi, z_)
        except Exception:
            pass
    for o in objs:
        slots = o.material_slots
        mw_ = o.matrix_world
        nm3_ = mw_.to_3x3().inverted().transposed()
        for poly in o.data.polygons:
            mi = poly.material_index
            if mi < len(slots) and slots[mi].material:
                nm = slots[mi].material.name
                area_by[nm] = area_by.get(nm, 0.0) + poly.area
                try:
                    zc_ = (mw_ @ poly.center).z
                    nz_ = (nm3_ @ poly.normal).normalized().z
                    acc_ = _zs.setdefault(nm, [0.0, 0.0, 0.0])
                    acc_[0] += poly.area * zc_; acc_[1] += poly.area * nz_; acc_[2] += poly.area
                except Exception:
                    pass
    infos = []
    seen = set()
    for o in objs:
        for s in o.material_slots:
            if s.material and s.material.name not in seen:
                seen.add(s.material.name)
                rgb, alpha, transmission = _mat_shader_info(s.material)
                _a3 = _zs.get(s.material.name)
                _zrel = None; _nzm = None
                if _a3 and _a3[2] > 0 and _zhi > _zlo:
                    _zrel = (_a3[0] / _a3[2] - _zlo) / (_zhi - _zlo)
                    _nzm = _a3[1] / _a3[2]
                infos.append({'name': s.material.name, 'rgb': rgb, 'alpha': alpha,
                              'transmission': transmission,
                              'area': area_by.get(s.material.name, 0.0),
                              'zrel': _zrel, 'nz': _nzm})
    return infos


def _quick_material_enum(context, allow_auto=True):
    items = []
    if allow_auto:
        items.append(('AUTO', "Auto (largest coloured)", "Pick automatically"))
    seen = set()
    for o in (context.selected_objects if context else []):
        if o.type != 'MESH':
            continue
        for s in o.material_slots:
            if s.material and s.material.name not in seen:
                seen.add(s.material.name)
                items.append((s.material.name, s.material.name, ""))
    if not items:
        items = [('AUTO', "Auto", "")]
    return items


class LFS_OT_SetSubObjType(Operator):
    """Change this sub-object's LFS type - pick the new type in the dialog
    (patches the stored bytes, so it takes effect on export - no need to re-mark)"""
    bl_idname = "lfs.set_subobj_type"
    bl_label = "Set Sub-Object Type"
    bl_options = {'REGISTER', 'UNDO'}

    obj_name: StringProperty()
    new_type: EnumProperty(
        name="Type",
        items=[
            ('KEEP', "Keep as it is", "Leave the type unchanged"),
            ('0', "Body (main)", "The ONE main body - exactly one per model"),
            ('3', "Interior/Detail", "Most parts, interior, details"),
            ('2', "Steering", "Steering wheel"),
            ('1', "Generic", "Generic sub-object"),
            ('10', "Mirror", "The interior rear-view mirror"),
        ],
        default='KEEP')

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self)

    def draw(self, context):
        import base64
        o = bpy.data.objects.get(self.obj_name)
        cur = '?'
        try:
            cur = base64.b64decode(o['lfs_subobj_raw_b64'])[1]
        except Exception:
            pass
        _nm = {0: "Body", 1: "Generic", 2: "Steering", 3: "Detail", 10: "Mirror", 12: "Wheel"}
        self.layout.label(text=f"{self.obj_name} - now: "
                               + (f"{_nm[cur]} (type {cur})" if cur in _nm else f"type {cur}"))
        self.layout.prop(self, "new_type")

    def execute(self, context):
        import base64
        o = bpy.data.objects.get(self.obj_name)
        if not o or 'lfs_subobj_raw_b64' not in o.keys():
            self.report({'ERROR'}, "Not a marked sub-object.")
            return {'CANCELLED'}
        if self.new_type == 'KEEP':
            return {'CANCELLED'}
        t = int(self.new_type)
        d = _SUBOBJ_TYPE_DEFAULTS.get(t, {})
        raw = bytearray(base64.b64decode(o['lfs_subobj_raw_b64']))
        if raw[1] == t:
            self.report({'INFO'}, f"{self.obj_name} is type {t} already")
            return {'CANCELLED'}
        raw[1] = t
        if 'flip' in d: raw[2] = d['flip']
        if 'sub_state' in d: raw[24] = d['sub_state']
        if 'unk3' in d: raw[26] = d['unk3']
        o['lfs_subobj_raw_b64'] = base64.b64encode(bytes(raw)).decode('ascii')
        o['lfs_subobj_type'] = t
        self.report({'INFO'}, f"{self.obj_name} -> type {t}")
        return {'FINISHED'}


class LFS_OT_UnmarkSubObj(Operator):
    """Remove sub-object marking from an object."""
    bl_idname = "lfs.unmark_subobj"
    bl_label = "Unmark Sub-Object"
    bl_options = {'REGISTER', 'UNDO'}
    obj_name: StringProperty()

    def execute(self, context):
        o = bpy.data.objects.get(self.obj_name)
        if o:
            for k in list(o.keys()):
                if k.startswith('lfs_subobj'):
                    del o[k]
            self.report({'INFO'}, f"Unmarked {self.obj_name}")
        return {'FINISHED'}


_DISH_HOST = ".LFS Dish Profile"
_DISH_HANDLES = ('AUTO', 'VECTOR', 'FREE', 'ALIGN')
_DISH_STATE = {'applied': None}
_DISH_OWNER = object()
_DISH_PRESET_ITEMS = [
    ('FLAT', "Flat (straight line)", "A straight line down the middle - nothing moves until you bend it"),
    ('LINEAR', "Linear (cone)", "A straight ramp from the centre to the edge"),
    ('SMOOTH', "Smooth", "Eased in and out - the natural dish"),
    ('ROUND', "Round (sphere)", "A spherical cap"),
    ('BELL', "Bell", "Tight bulge in the middle, flat further out"),
    ('DEEP', "Deep dish", "Flat face at full depth, then a steep wall near the edge"),
    ('LIP', "Lip (outer edge)", "Nothing at the centre, all of it at the edge"),
    ('RING', "Ring", "Strongest halfway out - a barrel or a swage line"),
]


def _dish_preset_path(key):
    pts = [[round(0.5 + 0.5 * q[0], 5), q[1], q[2]] for q in _dish_preset_visible(key)]
    return [[pts[0][0], -1.0, 'VECTOR']] + pts + [[pts[-1][0], 2.0, 'VECTOR']]


def _dish_preset_visible(key):
    import math as _m
    if key == 'FLAT':
        return [[0.0, 0.0, 'AUTO'], [0.0, 0.5, 'AUTO'], [0.0, 1.0, 'AUTO']]
    if key == 'LINEAR':
        return [[1.0, 0.0, 'VECTOR'], [0.0, 1.0, 'VECTOR']]
    if key == 'DEEP':
        return [[1.0, 0.0, 'VECTOR'], [1.0, 0.6, 'VECTOR'], [0.25, 0.85, 'AUTO'], [0.0, 1.0, 'AUTO']]
    if key == 'RING':
        return [[0.0, 0.0, 'AUTO'], [0.5, 0.25, 'AUTO'], [1.0, 0.5, 'AUTO'],
                [0.5, 0.75, 'AUTO'], [0.0, 1.0, 'AUTO']]

    def smooth(y):
        return 1.0 - y * y * (3.0 - 2.0 * y)
    if key == 'ROUND':
        ys, fn = (0.0, 0.4, 0.7, 0.9, 0.98, 1.0), (lambda y: _m.sqrt(max(0.0, 1.0 - y * y)))
    elif key == 'BELL':
        ys, fn = (0.0, 0.2, 0.4, 0.6, 1.0), (lambda y: _m.exp(-(y * 2.2) ** 2))
    elif key == 'LIP':
        ys, fn = (0.0, 0.15, 0.5, 0.85, 1.0), (lambda y: 1.0 - smooth(y))
    else:
        ys, fn = (0.0, 0.15, 0.5, 0.85, 1.0), smooth
    return [[round(fn(y), 5), y, 'AUTO'] for y in ys]


def _dish_path_get(prof):
    return [[round(pt.location[0], 5), round(pt.location[1], 5),
             pt.handle_type_1, pt.handle_type_2, bool(pt.select)] for pt in prof.points]


def _dish_path_key(pts):
    import json as _json
    return _json.dumps([list(q[:4]) for q in pts])


def _dish_path_set(prof, pts):
    pts = [q for q in pts if len(q) >= 2]
    if len(pts) < 2:
        return
    pp = prof.points
    while len(pp) > len(pts):
        try:
            pp.remove(pp[len(pp) - 2])
        except Exception:
            break
    while len(pp) < len(pts):
        try:
            pp.add(0.5, 0.5)
        except Exception:
            break
    if any(not (0.0 <= float(q[0]) <= 1.0 and 0.0 <= float(q[1]) <= 1.0) for q in pts):
        prof.use_clip = False
    for pt, q in zip(pp, pts):
        pt.location = (float(q[0]), float(q[1]))
    for pt in pp:
        pt.select = False
    for pt, q in zip(pp, pts):
        h1 = q[2] if len(q) > 2 and q[2] in _DISH_HANDLES else 'AUTO'
        h2 = q[3] if len(q) > 3 and q[3] in _DISH_HANDLES else h1
        pt.select = True
        for attr, val in (('handle_type_1', h1), ('handle_type_2', h2)):
            try:
                setattr(pt, attr, val)
            except Exception:
                pass
        pt.select = False
    for pt, q in zip(pp, pts):
        pt.select = bool(q[4]) if len(q) > 4 else False
    prof.update()


def _dish_profile(create=False):
    cu = next((c for c in bpy.data.curves if c.name == _DISH_HOST and c.library is None), None)
    if cu is None:
        if not create:
            return None
        cu = bpy.data.curves.new(_DISH_HOST, 'CURVE')
        cu.use_fake_user = True
    prof = cu.bevel_profile
    if prof is None:
        if not create:
            return None
        cu.bevel_mode = 'PROFILE'
        prof = cu.bevel_profile
        if prof is None:
            return None
        prof.initialize(8)
        _dish_path_set(prof, _dish_preset_path('FLAT'))
    return prof


def _dish_profile_fn(prof, n=256):
    import math as _m
    poly = []
    try:
        keep = max(1, len(prof.segments))
    except Exception:
        keep = 8
    try:
        prof.initialize(256)
        poly = [(float(s.location[0]), float(s.location[1])) for s in prof.segments]
    except Exception:
        poly = []
    try:
        prof.initialize(keep)
    except Exception:
        pass
    end = prof.points[len(prof.points) - 1].location
    poly.append((float(end[0]), float(end[1])))
    if len(poly) < 2:
        poly = [(pt.location[0], pt.location[1]) for pt in prof.points]
    tab = [None] * (n + 1)
    for (x0, y0), (x1, y1) in zip(poly, poly[1:]):
        k0 = max(0, int(_m.ceil(min(y0, y1) * n - 1e-6)))
        k1 = min(n, int(_m.floor(max(y0, y1) * n + 1e-6)))
        for k in range(k0, k1 + 1):
            if tab[k] is None:
                ty = k / n
                tab[k] = x0 if abs(y1 - y0) < 1e-12 else x0 + (x1 - x0) * (ty - y0) / (y1 - y0)
    for k in range(n + 1):
        if tab[k] is None:
            ty = k / n
            tab[k] = min(poly, key=lambda q: abs(q[1] - ty))[0]

    def fn(t):
        t = min(1.0, max(0.0, t)) * n
        i = min(n - 1, int(t))
        return 2.0 * (tab[i] + (tab[i + 1] - tab[i]) * (t - i)) - 1.0
    return fn


def _dish_view3d():
    best = (None, None, None)
    for win in bpy.context.window_manager.windows:
        for area in win.screen.areas:
            if area.type != 'VIEW_3D':
                continue
            reg = next((r for r in area.regions if r.type == 'WINDOW'), None)
            if reg is None:
                continue
            if getattr(area.spaces.active, 'show_region_ui', False):
                return win, area, reg
            if best[0] is None:
                best = (win, area, reg)
    return best


def _dish_obj(context):
    o = context.active_object
    if o is None and context.view_layer is not None:
        o = context.view_layer.objects.active
    return o


def _dish_look_refresh(context):
    import sys
    sc = context.scene
    if sc is None or not sc.get('lfs_look_attached'):
        return
    for m in list(sys.modules.values()):
        f = getattr(m, '_look_refresh_soon', None)
        if callable(f) and callable(getattr(m, '_look_refresh', None)):
            try:
                f(sc.name, True)
            except Exception:
                traceback.print_exc()
            return


def _dish_autoapply():
    import json as _json
    try:
        prof = _dish_profile()
        if prof is None:
            return None
        pts = _dish_path_get(prof)
        wm = bpy.context.window_manager
        last_op = wm.operators[-1] if len(wm.operators) else None
        if last_op is not None and last_op.bl_idname != 'LFS_OT_dish_part':
            last_op = None
        if last_op is not None:
            last_op.properties.curve_pts = _json.dumps(pts)
        if _dish_path_key(pts) == _DISH_STATE.get('applied'):
            return None
        win, area, reg = _dish_view3d()
        if win is None:
            return None
        last = _json.loads(win.scene.get('lfs_dish_last', '') or '{}')
        o = win.view_layer.objects.active
        if (last.get('shape') != 'CUSTOM' or o is None or o.type != 'MESH'
                or o.name != last.get('target')):
            return None
        with bpy.context.temp_override(window=win, area=area, region=reg, active_object=o, object=o,
                                       selected_objects=[o], selected_editable_objects=[o]):
            if o.mode == 'EDIT':
                if last_op is not None and last_op.properties.shape == 'CUSTOM':
                    bpy.ops.ed.undo_redo('EXEC_DEFAULT', True)
            elif o.mode == 'OBJECT' and last.get('from_original', True):
                bpy.ops.lfs.dish_part('INVOKE_DEFAULT', True)
    except Exception:
        traceback.print_exc()
    return None


def _dish_on_edit(*_a):
    if not bpy.app.timers.is_registered(_dish_autoapply):
        bpy.app.timers.register(_dish_autoapply, first_interval=0.05)


_DISH_LIVE = {'drawn': 0.0, 'dirty': False, 'changed': 0.0, 'cost': 0.0}


def _dish_live_apply(undo):
    import json as _json
    win, area, reg = _dish_view3d()
    if win is None:
        return False
    try:
        last = _json.loads(win.scene.get('lfs_dish_last', '') or '{}')
    except Exception:
        return False
    o = win.view_layer.objects.active
    if (last.get('shape') != 'CUSTOM' or o is None or o.type != 'MESH' or o.name != last.get('target')
            or o.mode != 'OBJECT' or not last.get('from_original', True)):
        return False
    with bpy.context.temp_override(window=win, area=area, region=reg, active_object=o, object=o,
                                   selected_objects=[o], selected_editable_objects=[o]):
        bpy.ops.lfs.dish_part('INVOKE_DEFAULT', bool(undo))
    return True


def _dish_live_poll():
    import time as _t
    try:
        now = _t.time()
        if now - _DISH_LIVE['drawn'] > 2.0:
            if _DISH_LIVE['dirty']:
                _DISH_LIVE['dirty'] = False
                _dish_live_apply(True)
            return None
        prof = _dish_profile()
        if prof is None:
            return 0.25
        key = _dish_path_key(_dish_path_get(prof))
        if key != _DISH_STATE.get('applied'):
            t0 = _t.time()
            if _dish_live_apply(False):
                _DISH_LIVE['dirty'] = True
                _DISH_LIVE['changed'] = _t.time()
                _DISH_LIVE['cost'] = _t.time() - t0
        elif _DISH_LIVE['dirty'] and now - _DISH_LIVE['changed'] > 0.6:
            _DISH_LIVE['dirty'] = False
            _dish_live_apply(True)
    except Exception:
        traceback.print_exc()
        return 0.5
    return max(0.1, min(1.0, _DISH_LIVE['cost'] * 1.5))


@bpy.app.handlers.persistent
def _dish_sync_post(*_a):
    _DISH_LIVE['dirty'] = False
    try:
        prof = _dish_profile()
        _DISH_STATE['applied'] = _dish_path_key(_dish_path_get(prof)) if prof is not None else None
    except Exception:
        _DISH_STATE['applied'] = None


def _dish_subscribe():
    try:
        bpy.msgbus.clear_by_owner(_DISH_OWNER)
        bpy.msgbus.subscribe_rna(key=(bpy.types.Curve, "bevel_profile"), owner=_DISH_OWNER,
                                 args=(), notify=_dish_on_edit)
    except Exception:
        traceback.print_exc()


@bpy.app.handlers.persistent
def _dish_load_post(*_a):
    _DISH_STATE['applied'] = None
    _dish_subscribe()
    _dish_sync_post()


def _dish_sidebar(layout, context):
    import json as _json
    try:
        last = _json.loads(context.scene.get('lfs_dish_last', '') or '{}')
    except Exception:
        last = {}
    if last.get('shape') != 'CUSTOM':
        return
    box = layout.box()
    row = box.row(align=True)
    row.label(text="Dish curve", icon='SPHERECURVE')
    row.operator_menu_enum("lfs.dish_profile_preset", "preset", text="Shapes")
    prof = _dish_profile()
    if prof is None:
        box.operator("lfs.dish_profile_preset", text="Make the curve", icon='ADD').preset = 'FLAT'
        return
    box.template_curveprofile(prof.id_data, "bevel_profile")
    import time as _t
    _DISH_LIVE['drawn'] = _t.time()
    try:
        if not bpy.app.timers.is_registered(_dish_live_poll):
            bpy.app.timers.register(_dish_live_poll, first_interval=0.1)
    except Exception:
        pass
    try:
        _amt = float(last.get('amount', 0.0))
    except (TypeError, ValueError):
        _amt = 0.0
    if abs(_amt) < 1e-9:
        al = box.column(align=True)
        al.alert = True
        al.label(text="Depth is 0, so the curve moves nothing:", icon='ERROR')
        al.label(text="set Depth in the Dish settings")
        al.label(text="(bottom left of the 3D View, or F9)")
    col = box.column(align=True)
    col.label(text="Bottom: centre    Top: edge")
    col.label(text="Middle: flat    Right edge: the Depth")
    col.label(text="Left of the middle: the other way")
    o = context.view_layer.objects.active
    if o is None or o.name != last.get('target'):
        col.label(text="Select the dished part to see it update", icon='INFO')
    elif o.mode == 'OBJECT' and not last.get('from_original', True):
        col.label(text="Press Dish / Curve Part to apply", icon='INFO')


class LFS_OT_DishProfilePreset(Operator):
    """Load a starting shape into the custom dish curve"""
    bl_idname = "lfs.dish_profile_preset"
    bl_label = "Dish Curve Preset"
    bl_options = {'INTERNAL'}

    preset: EnumProperty(name="Preset", items=_DISH_PRESET_ITEMS, default='FLAT')

    def execute(self, context):
        prof = _dish_profile(create=True)
        if prof is None:
            self.report({'ERROR'}, "Could not make the dish curve")
            return {'CANCELLED'}
        _dish_path_set(prof, _dish_preset_path(self.preset))
        _dish_on_edit()
        if context.screen:
            for area in context.screen.areas:
                area.tag_redraw()
        return {'FINISHED'}


_GROUPS_COL = "LFS Groups"


def _groups_colour(b):
    import colorsys
    h = (b * 0.618033988749895) % 1.0
    s = 0.45 + 0.35 * ((b * 7) % 3) / 2.0
    v = 0.95 - 0.25 * ((b * 5) % 2)
    r, g, bl = colorsys.hsv_to_rgb(h, s, v)
    return (r, g, bl, 1.0)


def _groups_of(obj):
    return _groups_and_tris(obj)[0]


def _groups_and_tris(obj):
    global _EXPORT_CACHE
    raw = base64.b64decode(obj['lfs_subobj_raw_b64'])
    if obj.mode == 'EDIT':
        obj.update_from_editmode()
    saved = _EXPORT_CACHE
    _EXPORT_CACHE = {'stats': [0, 0]}
    rep = {}
    try:
        _ve_rebuild_subobj_geometry(raw, obj, bpy.context.evaluated_depsgraph_get(), False, report=rep)
    finally:
        _EXPORT_CACHE = saved
    out = [None] * len(obj.data.polygons)
    tris = rep.get('tri', [])
    for tr in tris:
        sp, b, nc, mir, how = tr[:5]
        if 0 <= sp < len(out) and out[sp] is None:
            out[sp] = (b, nc, mir, how)
    return out, tris


def _groups_paint(obj, groups):
    me = obj.data
    grey = (0.25, 0.25, 0.25, 1.0)
    cols = [_groups_colour(g[0]) if g else grey for g in groups]
    if obj.mode == 'EDIT':
        bm = bmesh.from_edit_mesh(me)
        lay = (bm.loops.layers.float_color.get(_GROUPS_COL)
               or bm.loops.layers.float_color.new(_GROUPS_COL))
        for i, f in enumerate(bm.faces):
            c = cols[i] if i < len(cols) else grey
            for lp in f.loops:
                lp[lay] = c
        bmesh.update_edit_mesh(me, loop_triangles=False, destructive=False)
    else:
        at = me.color_attributes.get(_GROUPS_COL)
        if at is not None and (at.domain != 'CORNER' or at.data_type != 'FLOAT_COLOR'):
            me.color_attributes.remove(at)
            at = None
        if at is None:
            at = me.color_attributes.new(_GROUPS_COL, 'FLOAT_COLOR', 'CORNER')
        flat = []
        for p in me.polygons:
            flat.extend(cols[p.index] * p.loop_total)
        at.data.foreach_set('color', flat)
        me.update()
    try:
        me.color_attributes.active_color = me.color_attributes[_GROUPS_COL]
    except Exception:
        pass


def _groups_unpaint(obj):
    me = obj.data
    if obj.mode == 'EDIT':
        bm = bmesh.from_edit_mesh(me)
        lay = bm.loops.layers.float_color.get(_GROUPS_COL)
        if lay is not None:
            bm.loops.layers.float_color.remove(lay)
            bmesh.update_edit_mesh(me, loop_triangles=False, destructive=False)
    else:
        at = me.color_attributes.get(_GROUPS_COL)
        if at is not None:
            me.color_attributes.remove(at)


def _lfs_corner_normals(me, groups, tris=None):
    from mathutils import Vector as _V
    pn = [p.normal.copy() for p in me.polygons]
    acc = {}
    if tris:
        vco = [v.co for v in me.vertices]
        for tr in tris:
            b, lv, mir, ids = tr[1], tr[2], tr[3], tr[5]
            if max(ids) >= len(vco):
                continue
            a_, b_, c_ = vco[ids[0]], vco[ids[1]], vco[ids[2]]
            n = (b_ - a_).cross(c_ - a_)
            if n.length < 1e-12:
                continue
            n.normalize()
            cand = [(v, n) for v in ids]
            if mir & 1:
                cand += [(v, _V((-n.x, n.y, n.z))) for v in ids if abs(vco[v].x) < 2e-5]
            for v, nn in cand:
                a = acc.get((v, b))
                if a is None or lv > a[0]:
                    acc[(v, b)] = [lv, nn.copy()]
                elif lv == a[0]:
                    a[1] += nn
    for p in ([] if tris else me.polygons):
        g = groups[p.index] if p.index < len(groups) else None
        if g is None:
            continue
        b, lv, mir = g[0], g[1], g[2]
        n = pn[p.index]
        cand = [(v, n) for v in p.vertices]
        if mir & 1:
            cand += [(v, _V((-n.x, n.y, n.z))) for v in p.vertices
                     if abs(me.vertices[v].co.x) < 2e-5]
        for v, nn in cand:
            a = acc.get((v, b))
            if a is None or lv > a[0]:
                acc[(v, b)] = [lv, nn.copy()]
            elif lv == a[0]:
                a[1] += nn
    ln = [(0.0, 0.0, 1.0)] * len(me.loops)
    for p in me.polygons:
        g = groups[p.index] if p.index < len(groups) else None
        for li, v in zip(p.loop_indices, p.vertices):
            a = acc.get((v, g[0])) if g is not None else None
            vec = a[1] if (a is not None and a[1].length > 1e-9) else pn[p.index]
            vec = vec.normalized()
            ln[li] = (vec.x, vec.y, vec.z)
    return ln


def _groups_sidebar(layout, context):
    o = context.active_object
    if o is None or o.type != 'MESH' or not o.get('lfs_subobj_raw_b64'):
        return
    box = layout.box()
    row = box.row(align=True)
    row.label(text="Smoothing groups", icon='MOD_SMOOTH')
    shown = bool(o.get('lfs_groups_shown'))
    row.operator("lfs.groups_show", text="Hide" if shown else "Show",
                 icon='HIDE_OFF' if shown else 'COLOR', depress=shown)
    if o.mode == 'EDIT':
        col = box.column(align=True)
        r = col.row(align=True)
        r.operator("lfs.groups_set", text="New group").mode = 'NEW'
        r.operator("lfs.groups_set", text="Join around").mode = 'JOIN'
        r = col.row(align=True)
        r.operator("lfs.groups_set", text="Flat").mode = 'FLAT'
        r.operator("lfs.groups_set", text="Automatic").mode = 'AUTO'
        r = col.row(align=True)
        r.operator("lfs.groups_set", text="Number...").mode = 'NUMBER'
        r.operator("lfs.groups_select", text="Select group")
    else:
        box.label(text="Tab into Edit mode to set groups", icon='INFO')
    box.operator("lfs.groups_shade", text="Shade like LFS", icon='SHADING_SOLID')


def _groups_poll(context, edit=False):
    o = context.active_object
    return (o is not None and o.type == 'MESH' and bool(o.get('lfs_subobj_raw_b64'))
            and (not edit or o.mode == 'EDIT'))


class LFS_OT_GroupsShow(Operator):
    """Colour the active part by LFS smoothing group - the groups an export writes,
    new and edited faces included. Press again to hide"""
    bl_idname = "lfs.groups_show"
    bl_label = "Show Smoothing Groups"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return _groups_poll(context)

    def execute(self, context):
        import json as _json
        o = context.active_object
        sh = getattr(context.space_data, 'shading', None)
        if o.get('lfs_groups_shown'):
            _groups_unpaint(o)
            del o['lfs_groups_shown']
            if not any(ob.get('lfs_groups_shown') for ob in context.scene.objects):
                prev = _json.loads(context.scene.get('lfs_groups_prev', '') or '{}')
                if sh is not None and prev:
                    try:
                        sh.type = prev.get('type', 'SOLID')
                        sh.color_type = prev.get('color_type', 'MATERIAL')
                    except Exception:
                        pass
            return {'FINISHED'}
        try:
            groups = _groups_of(o)
        except Exception as e:
            traceback.print_exc()
            self.report({'ERROR'}, f"Could not work out the groups: {e}")
            return {'CANCELLED'}
        _groups_paint(o, groups)
        o['lfs_groups_shown'] = True
        if sh is not None:
            if sh.color_type != 'VERTEX':
                context.scene['lfs_groups_prev'] = _json.dumps({'type': sh.type, 'color_type': sh.color_type})
            sh.type = 'SOLID'
            sh.color_type = 'VERTEX'
        n = len({g[0] for g in groups if g})
        auto = sum(1 for g in groups if g and g[3] == 'auto')
        hand = sum(1 for g in groups if g and g[3] == 'set')
        self.report({'INFO'}, f"{o.name}: {n} group(s) - {auto} face(s) automatic, {hand} set by hand")
        return {'FINISHED'}


class LFS_OT_GroupsSet(Operator):
    """Set the LFS smoothing group of the selected faces"""
    bl_idname = "lfs.groups_set"
    bl_label = "Set Smoothing Group"
    bl_options = {'REGISTER', 'UNDO'}

    mode: EnumProperty(
        name="How", default='NEW',
        items=[('NEW', "New group", "A group nothing else in this part uses: smooth inside the "
                                    "selection, a hard edge all round"),
               ('JOIN', "Join around", "The group of the faces around the selection, so it shades "
                                       "smoothly into them"),
               ('FLAT', "Flat", "A group of its own for every face - faceted, no smoothing"),
               ('NUMBER', "Group number", "A group number you type (0-23, LFS has 24), like in the LFS editor"),
               ('AUTO', "Automatic", "Forget what was set by hand - the export decides: smooth into "
                                     "the faces around it across smooth edges, a new group past "
                                     "sharp edges")])
    number: IntProperty(name="Group", default=1, min=0, max=23)

    @classmethod
    def poll(cls, context):
        return _groups_poll(context, edit=True)

    def invoke(self, context, event):
        if self.mode == 'NUMBER':
            return context.window_manager.invoke_props_dialog(self)
        return self.execute(context)

    def draw(self, context):
        lay = self.layout
        lay.prop(self, 'mode')
        if self.mode == 'NUMBER':
            lay.prop(self, 'number')

    def execute(self, context):
        o = context.active_object
        me = o.data
        try:
            groups = _groups_of(o)
        except Exception as e:
            traceback.print_exc()
            self.report({'ERROR'}, f"Could not work out the groups: {e}")
            return {'CANCELLED'}
        bm = bmesh.from_edit_mesh(me)
        lay = (bm.faces.layers.int.get(_LFS_SMOOTH_ATTR)
               or bm.faces.layers.int.new(_LFS_SMOOTH_ATTR))
        faces = list(bm.faces)
        idx = {f: i for i, f in enumerate(faces)}
        sel = [i for i, f in enumerate(faces) if f.select]
        if not sel:
            self.report({'ERROR'}, "Select some faces first.")
            return {'CANCELLED'}
        S = set(sel)
        cur = [g[0] if g else None for g in groups] + [None] * max(0, len(faces) - len(groups))
        if self.mode == 'AUTO':
            for i in sel:
                faces[i][lay] = 0
            msg = "automatic"
        elif self.mode == 'NUMBER':
            for i in sel:
                faces[i][lay] = self.number + 1
            msg = f"group {self.number}"
        elif self.mode == 'JOIN':
            votes = Counter()
            for i in sel:
                for e in faces[i].edges:
                    for g in e.link_faces:
                        j = idx[g]
                        if j not in S and cur[j] is not None:
                            votes[cur[j]] += 1
            if not votes:
                self.report({'ERROR'}, "The selection does not touch any other face.")
                return {'CANCELLED'}
            b = min(votes, key=lambda k: (-votes[k], k))
            for i in sel:
                faces[i][lay] = b + 1
            msg = f"group {b} (the faces around it)"
        elif self.mode == 'NEW':
            used = {cur[j] for j in range(len(faces)) if j not in S and cur[j] is not None}
            near = Counter(cur[idx[g]] for i in sel for v in faces[i].verts for g in v.link_faces
                           if idx[g] not in S and cur[idx[g]] is not None)
            b = next((k for k in range(_LFS_GROUPS) if k not in used), None)
            if b is None:
                b = next((k for k in range(_LFS_GROUPS) if k not in near), None)
            if b is None:
                b = min(range(_LFS_GROUPS), key=lambda k: (near[k], k))
            for i in sel:
                faces[i][lay] = b + 1
            msg = f"new group {b}"
        else:
            newb = {}
            for i in sel:
                near = set()
                for v in faces[i].verts:
                    for g in v.link_faces:
                        j = idx[g]
                        if j == i:
                            continue
                        if j in newb:
                            near.add(newb[j])
                        elif j not in S and cur[j] is not None:
                            near.add(cur[j])
                b = next((k for k in range(_LFS_GROUPS) if k not in near), 0)
                newb[i] = b
                faces[i][lay] = b + 1
            msg = "a group each (flat)"
        bmesh.update_edit_mesh(me, loop_triangles=False, destructive=False)
        if o.get('lfs_groups_shown'):
            try:
                _groups_paint(o, _groups_of(o))
            except Exception:
                traceback.print_exc()
        self.report({'INFO'}, f"{len(sel)} face(s): {msg}")
        return {'FINISHED'}


class LFS_OT_GroupsSelect(Operator):
    """Select every face in the same smoothing group as the selected faces"""
    bl_idname = "lfs.groups_select"
    bl_label = "Select Smoothing Group"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return _groups_poll(context, edit=True)

    def execute(self, context):
        o = context.active_object
        try:
            groups = _groups_of(o)
        except Exception as e:
            self.report({'ERROR'}, f"Could not work out the groups: {e}")
            return {'CANCELLED'}
        bm = bmesh.from_edit_mesh(o.data)
        faces = list(bm.faces)
        want = {groups[i][0] for i, f in enumerate(faces) if f.select and i < len(groups) and groups[i]}
        if not want:
            self.report({'ERROR'}, "Select a face first.")
            return {'CANCELLED'}
        n = 0
        for i, f in enumerate(faces):
            if i < len(groups) and groups[i] and groups[i][0] in want:
                f.select = True
                n += 1
        bm.select_flush_mode()
        bmesh.update_edit_mesh(o.data, loop_triangles=False, destructive=False)
        self.report({'INFO'}, f"group {', '.join(str(b) for b in sorted(want))}: {n} face(s)")
        return {'FINISHED'}


class LFS_OT_GroupsShade(Operator):
    """Shade the active part the way LFS will: one normal per point and smoothing
    group, from the faces with the highest 'contribution' byte - so Blender shows the
    shading the export gives you"""
    bl_idname = "lfs.groups_shade"
    bl_label = "Shade Like LFS"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return _groups_poll(context)

    def execute(self, context):
        o = context.active_object
        try:
            groups, tris = _groups_and_tris(o)
        except Exception as e:
            self.report({'ERROR'}, f"Could not work out the groups: {e}")
            return {'CANCELLED'}
        was_edit = o.mode == 'EDIT'
        if was_edit:
            bpy.ops.object.mode_set(mode='OBJECT')
        sharp = 0
        try:
            me = o.data
            eg = {}
            for p in me.polygons:
                g = groups[p.index] if p.index < len(groups) else None
                if g is None:
                    continue
                for li in p.loop_indices:
                    eg.setdefault(me.loops[li].edge_index, set()).add(g[0])
            for ei, gs in eg.items():
                if len(gs) > 1 and not me.edges[ei].use_edge_sharp:
                    me.edges[ei].use_edge_sharp = True
                    sharp += 1
            me.normals_split_custom_set(_lfs_corner_normals(me, groups, tris))
            me.update()
        finally:
            if was_edit:
                bpy.ops.object.mode_set(mode='EDIT')
        self.report({'INFO'}, f"{o.name}: shaded from {len({g[0] for g in groups if g})} smoothing group(s)"
                              + (f", {sharp} edge(s) between groups marked sharp" if sharp else ""))
        return {'FINISHED'}


class LFS_OT_DishPart(Operator):
    """Curve a part in or out with a smooth falloff - a dished wheel face, a
    domed roof panel, a concave diffuser, a flared lip. Works on the SELECTED
    faces (Edit mode) or the whole object. The centre, the axis and the radius
    all come from the selection, so nothing has to be dragged by hand.
    Shape "Custom curve" lets you draw the profile yourself"""
    bl_idname = "lfs.dish_part"
    bl_label = "Dish / Curve Part"
    bl_options = {'REGISTER', 'UNDO'}

    axis: EnumProperty(
        name="Axis", default='AUTO',
        items=[('AUTO', "Auto (thinnest)", "The direction the part is flattest along - the axle on a wheel"),
               ('NORMAL', "Face normal", "The average normal of the selected faces - for panels"),
               ('X', "X (left-right)", ""), ('Y', "Y (front-back)", ""), ('Z', "Z (up-down)", "")])
    shape: EnumProperty(
        name="Shape", default='SMOOTH',
        items=[('SMOOTH', "Smooth", "Eased in and out - the natural dish"),
               ('ROUND', "Round (sphere)", "A spherical cap, deepest in the middle"),
               ('CONE', "Cone", "Straight sides to a point"),
               ('BELL', "Bell", "Tight bulge in the middle, flat further out"),
               ('POWER', "Power curve", "Manual: uses the Falloff value as an exponent"),
               ('CUSTOM', "Custom curve", "Draw the profile yourself, in the sidebar under this button: "
                                          "bottom = centre, top = edge; bend the line right to move "
                                          "that ring by the Depth")])
    curve_preset: EnumProperty(
        name="Preset", default='KEEP',
        description="Load a starting shape into the custom curve",
        items=[('KEEP', "Load preset...", "Keep the curve as it is drawn")] + _DISH_PRESET_ITEMS)
    curve_pts: StringProperty(
        name="Curve points", default="", options={'HIDDEN'},
        description="Copy of the custom curve, so Blender's redo keeps your edits")
    amount: FloatProperty(name="Depth (m)", default=0.0, min=-1.0, max=1.0,
                          description="Negative pulls the centre IN (dish), positive pushes it OUT (dome)")
    power: FloatProperty(name="Falloff", default=2.0, min=0.25, max=8.0,
                         description="Only used by the Power curve shape")
    taper: FloatProperty(name="Taper (m)", default=0.0, min=-0.5, max=0.5,
                         description="Also move the verts radially: negative narrows the middle, "
                                     "positive flares it (a lip)")
    r_from: FloatProperty(name="Start radius", default=0.0, min=0.0, max=1.0, subtype='FACTOR',
                          description="0 = from the centre. 0.3 keeps the inner 30% flat - a wheel's centre cap")
    r_to: FloatProperty(name="End radius", default=1.0, min=0.0, max=1.0, subtype='FACTOR',
                        description="1 = out to the outer edge. Lower leaves the outer ring alone")
    zone: EnumProperty(
        name="Zone", default='CENTRE',
        items=[('CENTRE', "Centre", "Strongest in the middle - a domed panel. On a whole wheel this moves the hub "
                                    "too (it goes out the back of the rim): use Ring there"),
               ('EDGE', "Outer edge", "Strongest at the outer edge - a deep-dish lip, a flared arch"),
               ('RING', "Ring", "Strongest halfway out, fading both ways - concave wheel spokes (the hub and the "
                                "rim's edge stay where they are), a barrel, a swage line")])
    centre: EnumProperty(
        name="Centre", default='MEDIAN',
        items=[('MEDIAN', "Selection centre", ""), ('CURSOR', "3D cursor", ""),
               ('ORIGIN', "Object origin", "")])
    from_original: BoolProperty(
        name="From original shape", default=True,
        description="Re-apply from the shape this part had BEFORE the first dish, so Depth is "
                    "absolute: press again with a smaller number and the curve gets shallower. "
                    "Turn off to add the curve on top of what is there now (to stack a centre "
                    "dish and an edge lip, for example)")
    forget_original: BoolProperty(
        name="Forget stored shape", default=False,
        description="Treat the CURRENT shape as the new original - use it once you are happy "
                    "and want to start a fresh curve from here")

    @classmethod
    def poll(cls, context):
        o = _dish_obj(context)
        return o is not None and o.type == 'MESH'

    _KEYS = ('axis', 'shape', 'amount', 'power', 'taper',
             'r_from', 'r_to', 'zone', 'centre', 'from_original')

    def invoke(self, context, event):
        try:
            import json as _json
            saved = _json.loads(context.scene.get('lfs_dish_last', '') or '{}')
            for k, v in saved.items():
                if k in self._KEYS and not self.properties.is_property_set(k):
                    setattr(self, k, v)
        except Exception:
            pass
        for k in ('forget_original', 'curve_pts', 'curve_preset'):
            if not self.properties.is_property_set(k):
                self.properties.property_unset(k)
        return self.execute(context)

    def draw(self, context):
        lay = self.layout
        lay.use_property_split = True
        lay.use_property_decorate = False
        lay.prop(self, 'shape')
        if self.shape == 'CUSTOM':
            lay.prop(self, 'curve_preset')
            col = lay.box().column(align=True)
            col.label(text="Draw the curve in the sidebar (N),", icon='INFO')
            col.label(text="LFS tab, under Dish / Curve Part.", icon='BLANK1')
            col.label(text="The part follows it while you drag.", icon='BLANK1')
            col.label(text="Depth = how far the right edge goes.", icon='BLANK1')
        else:
            lay.prop(self, 'zone')
            if self.shape == 'POWER':
                lay.prop(self, 'power')
        col = lay.column(align=True)
        col.prop(self, 'amount')
        col.prop(self, 'taper')
        col = lay.column(align=True)
        col.prop(self, 'r_from')
        col.prop(self, 'r_to')
        lay.prop(self, 'axis')
        lay.prop(self, 'centre')
        lay.prop(self, 'from_original')
        lay.prop(self, 'forget_original')

    def _custom_curve(self):
        import json as _json
        prof = _dish_profile(create=True)
        if prof is None:
            return None
        if self.curve_preset != 'KEEP':
            self.curve_pts = _json.dumps(_dish_preset_path(self.curve_preset))
            self.curve_preset = 'KEEP'
        if self.curve_pts:
            try:
                _dish_path_set(prof, _json.loads(self.curve_pts))
            except Exception:
                pass
        pts = _dish_path_get(prof)
        self.curve_pts = _json.dumps(pts)
        _DISH_STATE['applied'] = _dish_path_key(pts)
        return _dish_profile_fn(prof)

    def _remember(self, context):
        try:
            import json as _json
            d = {k: getattr(self, k) for k in self._KEYS}
            _o = _dish_obj(context)
            d['target'] = _o.name if _o else ''
            context.scene['lfs_dish_last'] = _json.dumps(d)
        except Exception:
            pass

    @staticmethod
    def _base_get(o):
        import base64 as _b64, array as _arr
        raw = o.get('lfs_dish_base_b64')
        if not raw:
            return None
        try:
            a = _arr.array('f')
            a.frombytes(_b64.b64decode(raw))
            return a if len(a) == len(o.data.vertices) * 3 else None
        except Exception:
            return None

    @staticmethod
    def _base_set(o):
        import base64 as _b64, array as _arr
        a = _arr.array('f', [0.0]) * (len(o.data.vertices) * 3)
        o.data.vertices.foreach_get('co', a)
        o['lfs_dish_base_b64'] = _b64.b64encode(a.tobytes()).decode('ascii')

    def execute(self, context):
        import bmesh as _bm
        import math as _math
        from mathutils import Vector
        o = _dish_obj(context)
        was_edit = (o.mode == 'EDIT')
        if self.shape == 'CUSTOM' and abs(self.amount) < 1e-9:
            self.amount = -0.05
        _curve = self._custom_curve() if self.shape == 'CUSTOM' else None
        if self.shape == 'CUSTOM' and _curve is None:
            self.report({'ERROR'}, "Could not make the custom curve.")
            return {'CANCELLED'}
        _restored = False
        if not was_edit:
            if self.forget_original and 'lfs_dish_base_b64' in o.keys():
                del o['lfs_dish_base_b64']
            _base = self._base_get(o)
            if self.from_original:
                if _base is None:
                    self._base_set(o)
                else:
                    o.data.vertices.foreach_set('co', _base)
                    o.data.update()
                    _restored = True
        if was_edit:
            bm = _bm.from_edit_mesh(o.data)
            faces = [f for f in bm.faces if f.select]
            verts = {v for f in faces for v in f.verts} or {v for v in bm.verts if v.select}
        else:
            bm = _bm.new(); bm.from_mesh(o.data)
            faces = list(bm.faces)
            verts = set(bm.verts)
        if len(verts) < 4:
            self.report({'ERROR'}, "Select some faces first (or run it in Object mode for the whole part).")
            if not was_edit: bm.free()
            return {'CANCELLED'}

        if self.centre == 'CURSOR':
            cen = o.matrix_world.inverted_safe() @ context.scene.cursor.location
        elif self.centre == 'ORIGIN':
            cen = Vector((0, 0, 0))
        else:
            cen = Vector((0, 0, 0))
            for v in verts:
                cen += v.co
            cen /= len(verts)

        if self.axis == 'NORMAL' and faces:
            n = Vector((0, 0, 0))
            for f in faces:
                n += f.normal * f.calc_area()
            n = n.normalized() if n.length > 1e-9 else Vector((0, 0, 1))
            ai = max(range(3), key=lambda i: abs(n[i]))
        else:
            ext = [max(v.co[i] for v in verts) - min(v.co[i] for v in verts) for i in range(3)]
            ai = ext.index(min(ext)) if self.axis == 'AUTO' else 'XYZ'.index(self.axis)
            n = Vector((0, 0, 0)); n[ai] = 1.0

        rad = {}
        rmax = 0.0
        for v in verts:
            d = v.co - cen
            r = (d - n * d.dot(n)).length
            rad[v] = r
            rmax = max(rmax, r)
        if rmax <= 1e-9:
            self.report({'ERROR'}, "The selection has no radius around that axis.")
            if not was_edit: bm.free()
            return {'CANCELLED'}
        lo = min(self.r_from, self.r_to) * rmax
        hi = max(self.r_from, self.r_to) * rmax
        _step = False
        if hi - lo < 1e-9:
            if hi <= 1e-9:
                lo, hi = 0.0, rmax
            else:
                _step = True

        def falloff(t):
            t = min(1.0, max(0.0, t))
            if self.shape == 'CONE':
                return 1.0 - t
            if self.shape == 'ROUND':
                return _math.sqrt(max(0.0, 1.0 - t * t))
            if self.shape == 'BELL':
                return _math.exp(-(t * 2.2) ** 2)
            if self.shape == 'POWER':
                return 1.0 - t ** self.power
            return 1.0 - (t * t * (3.0 - 2.0 * t))

        if abs(self.amount) < 1e-9 and abs(self.taper) < 1e-9:
            if was_edit:
                _bm.update_edit_mesh(o.data)
            else:
                bm.to_mesh(o.data); bm.free(); o.data.update()
            self._remember(context)
            _dish_look_refresh(context)
            self.report({'INFO'}, "Set a Depth (or Taper) in this panel - nothing moved.")
            return {'FINISHED'}
        moved = 0
        for v in verts:
            r = rad[v]
            if _curve is not None:
                f = _curve((0.0 if r <= lo else 1.0) if _step else (r - lo) / (hi - lo))
            elif self.zone == 'CENTRE':
                if r > hi:
                    continue
                f = 1.0 if (_step or r <= lo) else falloff((r - lo) / (hi - lo))
            elif self.zone == 'EDGE':
                if r < lo:
                    continue
                f = 1.0 if (_step or r >= hi) else falloff((hi - r) / (hi - lo))
            else:
                if r < lo or r > hi:
                    continue
                t = (r - lo) / (hi - lo)
                f = falloff(abs(t - 0.5) * 2.0)
            if abs(f) < 1e-6:
                continue
            v.co += n * (self.amount * f)
            if abs(self.taper) > 1e-9 and r > 1e-9:
                d = v.co - cen
                rv = d - n * d.dot(n)
                v.co += rv.normalized() * (self.taper * f)
            moved += 1

        if was_edit:
            _bm.update_edit_mesh(o.data)
        else:
            bm.to_mesh(o.data); bm.free(); o.data.update()
        self._remember(context)
        _dish_look_refresh(context)
        if _curve is not None and moved == 0:
            self.report({'INFO'}, "The curve is a straight line down the middle, so nothing moved. "
                                  "Bend it in the sidebar (bottom = centre, top = edge).")
            return {'FINISHED'}
        self.report({'INFO'},
                    f"{'from original: ' if _restored else ''}"
                    f"{moved} vert(s): {self.amount * 100:+.1f} cm along {'XYZ'[ai]}"
                    f"{', taper %+.1f cm' % (self.taper * 100) if self.taper else ''}"
                    f" ({'custom curve' if _curve is not None else self.zone.lower()}"
                    f"{'' if _curve is not None else ', ' + ('step' if _step else self.shape.lower())}, "
                    f"radius {lo * 100:.1f}-{hi * 100:.1f} cm)")
        return {'FINISHED'}


class LFS_OT_SelectAddedFaces(Operator):
    """Select the faces of the ACTIVE imported sub-object that are NOT in the
    file it came from - i.e. everything you modelled since the import (a
    spoiler, a diffuser, a welded-on lip). Matching is by POSITION, the same
    way the exporter matches, so renumbered verts do not matter. Handy on a
    triangulated mesh where hovering L or box-selecting is a pain."""
    bl_idname = "lfs.select_added_faces"
    bl_label = "Select Added Faces"
    bl_options = {'REGISTER', 'UNDO'}

    extend: BoolProperty(name="Extend selection", default=False)
    select_verts: BoolProperty(name="Also select their verts", default=True)

    @classmethod
    def poll(cls, context):
        o = context.active_object
        return (o is not None and o.type == 'MESH'
                and int(o.get('lfs_subobj_original_nf', 0) or 0) > 0
                and o.get('lfs_subobj_raw_b64'))

    def execute(self, context):
        import base64 as _b64
        o = context.active_object
        try:
            raw = _b64.b64decode(o['lfs_subobj_raw_b64'])
            lods = raw[3]
            geo = 28 + lods * 4
            onv, onf = struct.unpack_from('<HH', raw, geo)
            vb = geo + 28
            fb = vb + onv * 16
        except Exception as e:
            self.report({'ERROR'}, f"Could not read the original bytes: {e}")
            return {'CANCELLED'}
        _opos = []
        for i in range(onv):
            _f, x, y, z = struct.unpack_from('<iiii', raw, vb + 16 * i)
            _opos.append((x, y, z))
        orig_keys = set()
        _tris_by_pos = {}
        for fi in range(onf):
            off = fb + fi * 12
            v = []
            for k in range(3):
                q = struct.unpack_from('<h', raw, off + 6 + 2 * k)[0]
                v.append(q + 32768 if q < 0 else q)
            if max(v) >= onv:
                continue
            _t = tuple(sorted(_opos[j] for j in v))
            orig_keys.add(_t)
            for _p0 in _t:
                _tris_by_pos.setdefault(_p0, []).append(_t)
        sc = context.scene
        try:
            sf = float(sc.get('lfs_ve_scale_factor', 1.0))
        except (TypeError, ValueError):
            sf = 1.0
        flip = bool(sc.get('lfs_ve_flip_y_on_export', False))
        mw = o.matrix_world
        org = mw.translation
        me = o.data
        bpos = []
        for v in me.vertices:
            c = mw @ v.co
            x = int(round((c.x - org.x) * sf * FP))
            y = int(round(((-(c.y - org.y)) if flip else (c.y - org.y)) * sf * FP))
            z = int(round((c.z - org.z) * sf * FP))
            bpos.append((x, y, z))
        was_mode = o.mode
        if was_mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')
        n_new = 0
        for p in me.polygons:
            if not self.extend:
                p.select = False
            vs = list(p.vertices)
            _pk = [bpos[i] for i in vs]
            if len(vs) == 3:
                _is_orig = tuple(sorted(_pk)) in orig_keys
            else:
                _S = set(_pk)
                _cov = set()
                for _t in _tris_by_pos.get(_pk[0], ()):
                    if set(_t) <= _S:
                        _cov.add(_t)
                for _p1 in _pk[1:]:
                    for _t in _tris_by_pos.get(_p1, ()):
                        if set(_t) <= _S:
                            _cov.add(_t)
                _is_orig = (len(_S) == len(vs)) and (len(_cov) >= len(vs) - 2)
            if not _is_orig:
                p.select = True
                n_new += 1
        if not self.extend:
            for v in me.vertices:
                v.select = False
            for e in me.edges:
                e.select = False
        if self.select_verts:
            for p in me.polygons:
                if p.select:
                    for vi in p.vertices:
                        me.vertices[vi].select = True
        me.update()
        bpy.ops.object.mode_set(mode='EDIT')
        context.tool_settings.mesh_select_mode = (False, False, True)
        self.report({'INFO'}, f"{n_new} added face(s) selected "
                              f"({len(me.polygons) - n_new} came from the file)")
        return {'FINISHED'}


class VIEW3D_PT_LFS_SRE_SubObjects(Panel):
    """Lists marked sub-objects with editable type + warnings."""
    bl_label = "SRE Sub-Objects"
    bl_idname = "VIEW3D_PT_LFS_SRE_SubObjects"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "LFS"

    def draw(self, context):
        import base64
        layout = self.layout
        ve = [o for o in context.scene.objects
              if o.type == 'MESH' and 'lfs_subobj_index' in o.keys()]
        if not ve:
            layout.label(text="No LFS parts yet.", icon='INFO')
            layout.label(text="Import an .sre, or 1 Auto Setup")
            layout.label(text="(LFS SRE panel) for another model.")
            return

        def _t(o):
            b = o.get('lfs_subobj_raw_b64')
            if b:
                try:
                    return base64.b64decode(b)[1]
                except Exception:
                    pass
            return o.get('lfs_subobj_type', 3)

        ve.sort(key=lambda o: o.get('lfs_subobj_index', 99))
        type0 = [o for o in ve if _t(o) == 0 and not _ve_is_phantom(o)]

        box = layout.box()
        row = box.row()
        row.label(text=f"{len(ve)} sub-object(s)", icon='OBJECT_DATA')
        if len(type0) == 0:
            box.label(text="No type-0 body (fine for a part file)", icon='INFO')
        elif len(type0) > 1:
            box.label(text=f"{len(type0)} type-0 bodies!", icon='ERROR')
            box.label(text="LFS needs exactly ONE.")

        tnames = {0: "Body", 1: "Generic", 2: "Steering",
                  3: "Detail", 10: "Mirror", 12: "Wheel"}
        for o in ve:
            t = _t(o)
            row = layout.row(align=True)
            icon = 'AUTO' if t == 0 else 'DOT'
            row.label(text=o.name, icon=icon)
            op = row.operator("lfs.set_subobj_type",
                              text=tnames.get(t, f"type {t}"))
            op.obj_name = o.name
            x = row.operator("lfs.unmark_subobj", text="", icon='X')
            x.obj_name = o.name

        layout.separator()
        layout.operator("lfs.select_added_faces", icon='FACESEL')
        layout.operator_menu_enum("lfs.join_to_subobj", "target_subobj", text="Join Selected Into...",
                                  icon='AUTOMERGE_ON')
        layout.operator("lfs.dish_part", icon='SPHERECURVE')
        _dish_sidebar(layout, context)
        _groups_sidebar(layout, context)

class LFS_OT_WeldPanelGaps(Operator):
    """Close the gaps between body panels of the active object: points on
    the facing edges of two panels within the weld distance are merged. Panel outlines
    stay"""
    bl_idname = "lfs.weld_panel_gaps"
    bl_label = "Weld Panel Gaps"
    bl_options = {'REGISTER', 'UNDO'}

    dist_mm: FloatProperty(name="Max gap (mm)", default=8.0, min=0.1,
                           max=500.0, soft_min=0.5, soft_max=100.0,
                           description="Boundary-vert pairs closer than "
                                       "this (world mm) get welded. Drag "
                                       "in the redo panel to preview live")
    mode: bpy.props.EnumProperty(
        name="Mode",
        items=[('WELD', "Weld (move verts)",
                "Snap facing rims onto a shared midline - for simple "
                "facing gaps (tailgate/bumper)"),
               ('BRIDGE', "Bridge (dark strip)",
                "Keep panels untouched; span each gap with a recessed "
                "dark strip like a real shut line - for hood/fender "
                "style seams with turned-under edges")],
        default='WELD')
    use_selection: BoolProperty(
        name="Only selected verts", default=False,
        description="Restrict to the selected region. OFF by default - "
                    "stray leftover selections were silently making the "
                    "operator do nothing")

    @classmethod
    def poll(cls, context):
        o = context.active_object
        return o is not None and o.type == 'MESH'

    def _gap_material(self):
        gm = bpy.data.materials.get('xtex_gapfill')
        if gm is None:
            gm = bpy.data.materials.new('xtex_gapfill')
            gm.use_nodes = True
            for _n in gm.node_tree.nodes:
                if _n.type == 'BSDF_PRINCIPLED':
                    _n.inputs['Base Color'].default_value = (
                        0.0056, 0.0056, 0.0056, 1.0)
            gm.diffuse_color = (0.0056, 0.0056, 0.0056, 1.0)
            _nc = 1
            for _m in bpy.data.materials:
                try:
                    _nc = max(_nc, int(_m.get('lfs_cidx', -1)))
                except (ValueError, TypeError):
                    pass
            if _nc + 1 > _CIDX_MAX:
                bpy.data.materials.remove(gm)
                self.report({'ERROR'}, "Map limit (255) reached - cannot add the "
                                       "xtex_gapfill material.")
                return None
            gm['lfs_cidx'] = _nc + 1
            gm['lfs_shine'] = 0
            gm['lfs_rtype'] = 0
            gm['lfs_rmode'] = 0
        return gm

    @staticmethod
    def _rim_components(bm):
        bverts = set(); badj = {}; bel = []
        for e in bm.edges:
            if len(e.link_faces) == 1:
                bel.append(e)
                a, b = e.verts[0].index, e.verts[1].index
                bverts.add(a); bverts.add(b)
                badj.setdefault(a, set()).add(b)
                badj.setdefault(b, set()).add(a)
        comp = {}; cid = 0
        for v in sorted(bverts):
            if v in comp:
                continue
            stack = [v]; comp[v] = cid
            while stack:
                x = stack.pop()
                for y in badj.get(x, ()):
                    if y not in comp:
                        comp[y] = cid; stack.append(y)
            cid += 1
        return bverts, bel, comp

    @staticmethod
    def _small_rims(bm, comp, bverts, mw, limit=0.15):
        cbb = {}
        for vv in bverts:
            w = mw @ bm.verts[vv].co
            c = comp[vv]; b = cbb.get(c)
            if b is None:
                cbb[c] = [w.x, w.x, w.y, w.y, w.z, w.z]
            else:
                b[0] = min(b[0], w.x); b[1] = max(b[1], w.x)
                b[2] = min(b[2], w.y); b[3] = max(b[3], w.y)
                b[4] = min(b[4], w.z); b[5] = max(b[5], w.z)
        return {c for c, b in cbb.items()
                if ((b[1]-b[0])**2 + (b[3]-b[2])**2
                    + (b[5]-b[4])**2) ** 0.5 < limit}

    @staticmethod
    def _edge_tree(data, R):
        from mathutils.kdtree import KDTree
        import math
        step = 2.0 * R
        pts = []
        half = []
        max_step = step
        for j, rec in enumerate(data):
            a, b = rec[-2], rec[-1]
            L = (a - b).length
            half.append(L * 0.5)
            n = min(64, max(1, int(math.ceil(L / step)))) if step > 0 else 1
            max_step = max(max_step, L / n)
            for i in range(n):
                t = (i + 0.5) / n
                pts.append((a.lerp(b, t), j))
        kd = KDTree(len(pts))
        for pt, j in pts:
            kd.insert(pt, j)
        kd.balance()
        return kd, R + max_step * 0.5 + 1e-9

    def _bridge_multi(self, context):
        from mathutils.geometry import intersect_point_line as _ipl
        R = self.dist_mm / 1000.0
        if self.use_selection:
            objs = [ob for ob in context.selected_objects if ob.type == 'MESH']
        else:
            objs = [ob for ob in context.scene.objects
                    if ob.type == 'MESH' and not ob.name.startswith('_')
                    and ob.visible_get()]
        objs = [ob for ob in objs
                if ob.data.library is None
                and ob.data.users - (1 if ob.data.use_fake_user else 0) == 1]
        if not objs:
            self.report({'INFO'}, "No editable mesh objects to bridge.")
            return {'CANCELLED'}
        _active0 = context.view_layer.objects.active
        for ob in objs:
            if ob.mode == 'EDIT':
                context.view_layer.objects.active = ob
                bpy.ops.object.mode_set(mode='OBJECT')
        gm = self._gap_material()
        if gm is None:
            return {'CANCELLED'}
        binfo = []
        data = []
        try:
            for oi, ob in enumerate(objs):
                bm = bmesh.new(); bm.from_mesh(ob.data)
                bm.verts.ensure_lookup_table()
                mw = ob.matrix_world
                bverts, bel, comp = self._rim_components(bm)
                small = self._small_rims(bm, comp, bverts, mw)
                gslot0 = None
                for _si, _sl in enumerate(ob.material_slots):
                    if _sl.material == gm:
                        gslot0 = _si
                        break
                bel = [e for e in bel
                       if comp[e.verts[0].index] not in small
                       and not (gslot0 is not None
                                and e.link_faces[0].material_index == gslot0)]
                binfo.append((ob, bm, comp, bel, mw))
                for e in bel:
                    data.append((oi, comp[e.verts[0].index],
                                 mw @ e.verts[0].co, mw @ e.verts[1].co))
            if not data:
                self.report({'INFO'}, "No open boundary edges anywhere.")
                return {'CANCELLED'}
            kd, search = self._edge_tree(data, R)
            half = [(rec[2] - rec[3]).length * 0.5 for rec in data]
            _pcache = {}
            def proj(co, okey, ccomp, vkey):
                ck = (okey, vkey)
                if ck in _pcache:
                    return _pcache[ck]
                best = None
                seen = set()
                for (_loc, j, _d) in kd.find_range(co, search):
                    if j in seen:
                        continue
                    seen.add(j)
                    if _d - half[j] > R:
                        continue
                    oj, cj, ea, eb = data[j]
                    if oj == okey and cj == ccomp:
                        continue
                    cp, t = _ipl(co, ea, eb)
                    t = max(0.0, min(1.0, t))
                    cp = ea.lerp(eb, t)
                    d = (cp - co).length
                    if 0.001 < d <= R and (best is None or d < best[1]):
                        best = (cp, d, (oj, cj))
                _pcache[ck] = best
                return best
            per = {}
            total = 0
            for oi, (ob, bm, comp, bel, mw) in enumerate(binfo):
                inv = mw.inverted()
                gslot = None
                for _si, _sl in enumerate(ob.material_slots):
                    if _sl.material == gm:
                        gslot = _si
                        break
                nq = 0
                vcache = {}
                for e in bel:
                    a, b = e.verts[0], e.verts[1]
                    ca = comp[a.index]
                    wa = mw @ a.co; wb = mw @ b.co
                    pa = proj(wa, oi, ca, a.index); pb = proj(wb, oi, ca, b.index)
                    if not pa or not pb or pa[2] != pb[2]:
                        continue
                    if (oi, ca) > pa[2]:
                        continue
                    el = (wa - wb).length
                    if (pa[0] - pb[0]).length > max(3.0 * el, 0.002):
                        continue
                    if gslot is None:
                        ob.data.materials.append(gm)
                        gslot = len(ob.data.materials) - 1
                    ka = (round(pa[0].x, 5), round(pa[0].y, 5), round(pa[0].z, 5))
                    kb = (round(pb[0].x, 5), round(pb[0].y, 5), round(pb[0].z, 5))
                    nva = vcache.get(ka)
                    nvb = vcache.get(kb)
                    try:
                        if nva is None:
                            nva = bm.verts.new(inv @ pa[0]); vcache[ka] = nva
                        if nvb is None:
                            nvb = bm.verts.new(inv @ pb[0]); vcache[kb] = nvb
                        if nva is nvb:
                            continue
                        f = bm.faces.new((a, b, nvb, nva))
                    except ValueError:
                        continue
                    f.material_index = gslot
                    f.normal_update()
                    if e.link_faces and f.normal.dot(e.link_faces[0].normal) < 0:
                        f.normal_flip()
                    nq += 1
                if nq:
                    per[ob.name] = nq; total += nq
                    bm.to_mesh(ob.data); ob.data.update()
        finally:
            for _b in binfo:
                try:
                    _b[1].free()
                except Exception:
                    pass
            try:
                if _active0 is not None:
                    context.view_layer.objects.active = _active0
            except Exception:
                pass
        self.report({'INFO'},
            f"Bridged {total} gap segment(s) across {len(objs)} object(s) "
            f"(+{total * 2} tris): " + ", ".join(
                f"{k}:{v}" for k, v in per.items()))
        return {'FINISHED'}

    def execute(self, context):
        _o5 = context.active_object
        if _o5 is not None and _lfs_is_imported(_o5):
            self.report({'ERROR'}, "This part came from an .sre: its panel lines are part of the model. "
                                   "Weld Panel Gaps is for models from other formats (FBX, OBJ...).")
            return {'CANCELLED'}
        if self.mode == 'BRIDGE':
            return self._bridge_multi(context)
        o = context.active_object
        if o.mode == 'EDIT':
            bpy.ops.object.mode_set(mode='OBJECT')
        if o.data.library is not None:
            self.report({'ERROR'}, "Linked mesh - cannot edit in place.")
            return {'CANCELLED'}
        from mathutils.geometry import intersect_point_line as _ipl
        R = self.dist_mm / 1000.0
        me = o.data
        mw = o.matrix_world
        inv = mw.inverted()
        bm = bmesh.new(); bm.from_mesh(me)
        bm.verts.ensure_lookup_table()
        bverts, bel, comp = self._rim_components(bm)
        if not bverts:
            bm.free()
            self.report({'INFO'}, "No open boundary edges - nothing to weld.")
            return {'CANCELLED'}
        if self.use_selection:
            sel = {v.index for v in bm.verts if v.select}
            moving = bverts & sel
            if not moving:
                bm.free()
                self.report({'WARNING'}, "'Only selected verts' is on but no "
                                         "boundary vert is selected.")
                return {'CANCELLED'}
        else:
            sel = set()
            moving = set(bverts)
        _small = self._small_rims(bm, comp, bverts, mw)
        moving = {vi for vi in moving if comp[vi] not in _small}
        movable_comps = {comp[vi] for vi in moving}
        orig = {vi: bm.verts[vi].co.copy() for vi in bverts}
        bedges = []
        for e in bel:
            c = comp[e.verts[0].index]
            if c in _small:
                continue
            bedges.append((c, mw @ e.verts[0].co, mw @ e.verts[1].co))
        if not bedges:
            bm.free()
            self.report({'INFO'}, "Only ornament-sized rims found - nothing to weld.")
            return {'CANCELLED'}
        kd, search = self._edge_tree(bedges, R)
        half = [(a - b).length * 0.5 for _c, a, b in bedges]
        targets = {}
        for vi in moving:
            co = mw @ orig[vi]
            best = None
            seen = set()
            for (_loc, j, _d) in kd.find_range(co, search):
                if j in seen:
                    continue
                seen.add(j)
                if _d - half[j] > R:
                    continue
                cj, ea, eb = bedges[j]
                if cj == comp[vi]:
                    continue
                cp, t = _ipl(co, ea, eb)
                t = max(0.0, min(1.0, t))
                cp = ea.lerp(eb, t)
                d = (cp - co).length
                if d <= R and (best is None or d < best[1]):
                    best = (cp, d, cj)
            if best:
                cp, d, cj = best
                if cj not in movable_comps:
                    targets[vi] = cp
                else:
                    targets[vi] = (co + cp) / 2.0
        for vi, tco in targets.items():
            bm.verts[vi].co = inv @ tco
        nw = len(targets)
        moved = [bm.verts[vi] for vi in targets]
        if moved:
            bmesh.ops.remove_doubles(bm, verts=moved, dist=1e-5)
        bm.to_mesh(me); bm.free(); me.update()
        self.report({'INFO'},
            f"{o.name}: snapped {nw} boundary vert(s) "
            f"({'selection only' if sel else 'whole mesh'}) "
            f"(max {self.dist_mm:.1f} mm) - drag the slider (bottom-left "
            f"panel / F9) to adjust live")
        return {'FINISHED'}


def _autosetup_eval_counts(obj, dg):
    try:
        me = obj.evaluated_get(dg).to_mesh()
        nv = len(me.vertices); nt = sum(len(p.vertices) - 2 for p in me.polygons)
        obj.evaluated_get(dg).to_mesh_clear()
        return nv, nt
    except Exception:
        return len(obj.data.vertices), sum(len(p.vertices) - 2 for p in obj.data.polygons)


def _autosetup_split_object(obj, dg, max_v, max_t):
    import bmesh as _bm
    from mathutils import Vector
    if obj.modifiers:
        try:
            me2 = bpy.data.meshes.new_from_object(obj.evaluated_get(dg), preserve_all_data_layers=True, depsgraph=dg)
            me2.name = obj.data.name + '_baked'
            obj.data = me2; obj.modifiers.clear()
        except Exception as e:
            print(f"  [auto-setup] {obj.name}: modifier bake skipped: {e}")
    bm = _bm.new(); bm.from_mesh(obj.data); bm.faces.ensure_lookup_table(); bm.verts.ensure_lookup_table()
    comp = {}; cid = 0
    for f in bm.faces:
        if f.index in comp:
            continue
        stack = [f]; comp[f.index] = cid
        while stack:
            g = stack.pop()
            for v in g.verts:
                for lf in v.link_faces:
                    if lf.index not in comp:
                        comp[lf.index] = cid; stack.append(lf)
        cid += 1
    parts = {}
    for fi, c in comp.items():
        parts.setdefault(c, []).append(fi)

    def _tris(fis):
        return sum(len(bm.faces[i].verts) - 2 for i in fis)

    def _verts(fis):
        s = set()
        for i in fis:
            for v in bm.faces[i].verts:
                s.add(v.index)
        return len(s)

    def _bisect(fis):
        if _verts(fis) <= max_v and _tris(fis) <= max_t:
            return [fis]
        cs = [(i, bm.faces[i].calc_center_median()) for i in fis]
        lo = Vector((min(c.x for _, c in cs), min(c.y for _, c in cs), min(c.z for _, c in cs)))
        hi = Vector((max(c.x for _, c in cs), max(c.y for _, c in cs), max(c.z for _, c in cs)))
        ax = max(range(3), key=lambda k: hi[k] - lo[k])
        cs.sort(key=lambda t: t[1][ax])
        half = len(cs) // 2
        if half == 0:
            return [fis]
        return _bisect([i for i, _ in cs[:half]]) + _bisect([i for i, _ in cs[half:]])

    pieces = []
    for c, fis in sorted(parts.items(), key=lambda kv: -len(kv[1])):
        pieces.extend(_bisect(fis))
    pieces.sort(key=lambda fis: -_verts(fis))
    chunks = []
    for fis in pieces:
        nv = _verts(fis); nt = _tris(fis)
        for ch in chunks:
            if ch[1] + nv <= max_v and ch[2] + nt <= max_t:
                ch[0].extend(fis); ch[1] += nv; ch[2] += nt
                break
        else:
            chunks.append([list(fis), nv, nt])
    if len(chunks) <= 1:
        bm.free()
        return [obj.name]
    new_names = []
    for k, (fis, nv, nt) in enumerate(chunks):
        sub = bm.copy()
        sub.faces.ensure_lookup_table()
        keep = set(fis)
        _bm.ops.delete(sub, geom=[f for f in sub.faces if f.index not in keep], context='FACES')
        me = bpy.data.meshes.new(f"{obj.data.name}_p{k + 1}")
        sub.to_mesh(me); sub.free()
        for m in obj.data.materials:
            me.materials.append(m)
        ob = bpy.data.objects.new(f"{obj.name}_p{k + 1}", me)
        ob.matrix_world = obj.matrix_world.copy()
        for col in obj.users_collection:
            col.objects.link(ob)
        new_names.append(ob.name)
    bm.free()
    print(f"  [auto-setup] {obj.name}: over the LFS limits - split into {len(new_names)} objects")
    bpy.data.objects.remove(obj, do_unlink=True)
    return new_names


def _autosetup_chunk_group(names, dg, max_v=32000, max_t=64000):
    sizes = {}
    expanded = []
    for n in names:
        ob = bpy.data.objects.get(n)
        if ob is None:
            continue
        nv, nt = _autosetup_eval_counts(ob, dg)
        if nv > max_v or nt > max_t:
            for pn in _autosetup_split_object(ob, dg, max_v, max_t):
                pob = bpy.data.objects.get(pn)
                if pob is not None:
                    sizes[pn] = _autosetup_eval_counts(pob, dg); expanded.append(pn)
        else:
            sizes[n] = (nv, nt); expanded.append(n)
    expanded.sort(key=lambda n: -sizes[n][0])
    chunks = []
    for n in expanded:
        nv, nt = sizes[n]
        for ch in chunks:
            if ch[1] + nv <= max_v and ch[2] + nt <= max_t:
                ch[0].append(n); ch[1] += nv; ch[2] += nt
                break
        else:
            chunks.append([[n], nv, nt])
    return [ch[0] for ch in chunks]


def _bake_dir_set(n):
    import itertools, math
    axes = [(1, 0, 0), (-1, 0, 0), (0, 1, 0), (0, -1, 0), (0, 0, 1), (0, 0, -1)]
    if n <= 6:
        return axes
    out = list(axes)
    for v in itertools.product((-1, 0, 1), repeat=3):
        nz = sum(1 for c in v if c)
        if nz == 2 or (nz == 3 and n >= 26):
            l = math.sqrt(sum(c * c for c in v))
            out.append(tuple(c / l for c in v))
    return out


_BAKE_IMG_CACHE = {'on': False, 'd': {}, 'mb': 0.0}
_BAKE_IMG_CACHE_MB = 700.0


def _lfs_alpha_needs_lin(img, chan):
    if img is None or int(chan) >= 3:
        return False
    try:
        if img.is_float:
            return False
        cs = (img.colorspace_settings.name or '').lower()
    except Exception:
        return False
    return 'srgb' in cs and 'linear' not in cs


def _lfs_srgb_to_lin(a):
    import numpy as np
    a = np.clip(a, 0.0, 1.0)
    return np.where(a <= 0.04045, a / 12.92, ((a + 0.055) / 1.055) ** 2.4).astype(np.float32)


def _lfs_alpha_mask(img, chan, max_size):
    a = _bake_read_image(img, max_size=max_size)[:, :, int(chan)]
    return _lfs_srgb_to_lin(a) if _lfs_alpha_needs_lin(img, chan) else a


def _lfs_alpha_rgba(img, chan, max_size):
    a = _bake_read_image(img, max_size=max_size)
    if _lfs_alpha_needs_lin(img, chan):
        a[:, :, int(chan)] = _lfs_srgb_to_lin(a[:, :, int(chan)])
    return a


def _bake_read_image(img, max_size=2048):
    import numpy as np
    w, h = int(img.size[0]), int(img.size[1])
    C = _BAKE_IMG_CACHE
    chain = [(h, w)]
    while max(chain[-1]) > max_size:
        chain.append((chain[-1][0] // 2, chain[-1][1] // 2))
    key = (img.name, w, h)

    def _keep(arr):
        if C['on'] and max(arr.shape[0], arr.shape[1]) <= 2048:
            mb = arr.nbytes / 1e6
            if C['mb'] + mb <= _BAKE_IMG_CACHE_MB:
                C['d'].setdefault(key, {})[arr.shape[:2]] = arr
                C['mb'] += mb
    levels = C['d'].get(key) if C['on'] else None
    a = None
    k0 = 0
    if levels:
        for k in range(len(chain) - 1, -1, -1):
            if chain[k] in levels:
                a, k0 = levels[chain[k]], k
                break
    if a is None:
        buf = np.empty(w * h * 4, dtype=np.float32)
        img.pixels.foreach_get(buf)
        a = buf.reshape(h, w, 4)
        _keep(a)
    for k in range(k0 + 1, len(chain)):
        h2, w2 = a.shape[0] // 2, a.shape[1] // 2
        a = np.ascontiguousarray(0.25 * (a[0:2*h2:2, 0:2*w2:2] + a[1:2*h2:2, 0:2*w2:2]
                                         + a[0:2*h2:2, 1:2*w2:2] + a[1:2*h2:2, 1:2*w2:2]))
        _keep(a)
    if C['on']:
        return a.copy()
    return np.ascontiguousarray(a)


_LFS_NRM = {'on': False, 'cache': {}}


def _lfs_normal_map_of(mat):
    try:
        if mat is None or not mat.use_nodes or not mat.node_tree:
            return None
        bsdf = next((n for n in mat.node_tree.nodes if n.type == 'BSDF_PRINCIPLED'), None)
        ns = bsdf.inputs.get('Normal') if bsdf is not None else None
        if ns is None or not ns.links:
            return None
        nm = ns.links[0].from_node
        if nm.type != 'NORMAL_MAP' or nm.space != 'TANGENT':
            return None
        st = nm.inputs.get('Strength')
        s = 1.0 if (st is None or st.links) else abs(float(st.default_value))
        if s < 0.05:
            return None
        c = nm.inputs.get('Color')
        if c is None or not c.links:
            return None
        n = c.links[0].from_node
        while n.type == 'REROUTE' and n.inputs[0].links:
            n = n.inputs[0].links[0].from_node
        if n.type != 'TEX_IMAGE' or n.image is None:
            return None
        img = n.image
        if min(img.size) == 0:
            try:
                img.reload()
            except Exception:
                pass
        if min(img.size) == 0:
            return None
        return img, min(s, 2.0)
    except Exception:
        return None


def _lfs_box_blur(a, r):
    import numpy as np
    for ax in (0, 1):
        n = a.shape[ax]
        r_ = min(r, max(1, n // 2 - 1))
        c = np.cumsum(np.concatenate([a.take(range(-r_ - 1, 0), axis=ax), a,
                                      a.take(range(0, r_), axis=ax)], axis=ax), axis=ax)
        a = (c.take(range(2 * r_ + 1, 2 * r_ + 1 + n), axis=ax) - c.take(range(0, n), axis=ax)) / (2 * r_ + 1)
    return a


_LFS_NRM_A = 2048


def _lfs_normal_shade(nimg, strength, h, w):
    import numpy as np
    key = (nimg.name, round(float(strength), 3), int(h), int(w))
    cache = _LFS_NRM['cache']
    if key in cache:
        return cache[key]
    a = _bake_read_image(nimg, max_size=_LFS_NRM_A)
    ah, aw = a.shape[0], a.shape[1]
    nx = a[..., 0] * 2.0 - 1.0
    ny = a[..., 1] * 2.0 - 1.0
    if max(ah, aw) >= 2048:
        nx = _lfs_box_blur(nx, 1)
        ny = _lfs_box_blur(ny, 1)

    def _d(f, ax):
        return (np.roll(f, -1, ax) - np.roll(f, 1, ax)) * 0.5
    g = np.sqrt(_d(nx, 1) ** 2 + _d(nx, 0) ** 2 + _d(ny, 1) ** 2 + _d(ny, 0) ** 2)
    g *= (max(ah, aw) / 1024.0) * float(strength)
    sh = np.clip(1.0 - 2.5 * np.clip(g - 0.10, 0.0, None), 0.5, 1.0).astype(np.float32)
    while sh.shape[0] >= 2 * h and sh.shape[1] >= 2 * w:
        h2, w2 = sh.shape[0] // 2, sh.shape[1] // 2
        sh = 0.25 * (sh[0:2 * h2:2, 0:2 * w2:2] + sh[1:2 * h2:2, 0:2 * w2:2]
                     + sh[0:2 * h2:2, 1:2 * w2:2] + sh[1:2 * h2:2, 1:2 * w2:2])
    if sh.shape[0] != h or sh.shape[1] != w:
        yy = (np.arange(h) * sh.shape[0]) // h
        xx = (np.arange(w) * sh.shape[1]) // w
        sh = sh[yy][:, xx]
    sh = np.ascontiguousarray(sh, dtype=np.float32)
    if len(cache) >= 6:
        cache.clear()
    cache[key] = sh
    return sh


_LFS_NRM_R = 4096
_LFS_BUMP_MIN = 0.10
_LFS_BUMP_GROW = 83.0


def _lfs_binomial(a):
    import numpy as np
    for ax in (0, 1):
        a = 0.5 * a + 0.25 * (np.roll(a, 1, ax) + np.roll(a, -1, ax))
    return a


def _lfs_relief_full(nimg, strength):
    import numpy as np
    key = ('relief', nimg.name, round(float(strength), 3))
    cache = _LFS_NRM['cache']
    if key in cache:
        return cache[key]
    a = _bake_read_image(nimg, max_size=_LFS_NRM_R)
    ah, aw = a.shape[0], a.shape[1]
    nx = a[..., 0] * 2.0 - 1.0
    ny = a[..., 1] * 2.0 - 1.0
    a = None
    for _k in range(max(1, int(round(max(ah, aw) / 2048.0)))):
        nx = _lfs_binomial(nx)
        ny = _lfs_binomial(ny)
    nx *= float(strength)
    ny *= float(strength)
    nz = np.sqrt(np.clip(1.0 - nx * nx - ny * ny, 0.0, 1.0))
    L = np.array([-0.45, 0.55, 0.70])
    L = L / np.linalg.norm(L)
    rel = (nx * L[0] + ny * L[1] + nz * L[2] - L[2]).astype(np.float32)
    nx = ny = nz = None
    if len(cache) >= 6:
        cache.clear()
    cache[key] = rel
    return rel


def _lfs_normal_relief(nimg, strength, h, w):
    import numpy as np
    key = ('relief_hw', nimg.name, round(float(strength), 3), int(h), int(w))
    cache = _LFS_NRM['cache']
    if key in cache:
        return cache[key]
    rel = _lfs_relief_full(nimg, strength)
    while rel.shape[0] >= 2 * h and rel.shape[1] >= 2 * w:
        h2, w2 = rel.shape[0] // 2, rel.shape[1] // 2
        rel = 0.25 * (rel[0:2 * h2:2, 0:2 * w2:2] + rel[1:2 * h2:2, 0:2 * w2:2]
                      + rel[0:2 * h2:2, 1:2 * w2:2] + rel[1:2 * h2:2, 1:2 * w2:2])
    if rel.shape[0] != h or rel.shape[1] != w:
        yy = (np.arange(h) * rel.shape[0]) // h
        xx = (np.arange(w) * rel.shape[1]) // w
        rel = rel[yy][:, xx]
    rel = np.ascontiguousarray(rel, dtype=np.float32)
    R = max(1, int(round(6.0 * max(h, w) / 2048.0)))
    hp = np.ascontiguousarray(rel - _lfs_box_blur(rel, R), dtype=np.float32)
    if len(cache) >= 6:
        cache.clear()
    cache[key] = (rel, hp)
    return rel, hp


def _lfs_cavity_full(nimg, strength):
    import numpy as np
    key = ('cavity', nimg.name, round(float(strength), 3))
    cache = _LFS_NRM['cache']
    if key in cache:
        return cache[key]
    a = _bake_read_image(nimg, max_size=_LFS_NRM_R)
    ah, aw = a.shape[0], a.shape[1]
    nx = a[..., 0] * 2.0 - 1.0
    ny = a[..., 1] * 2.0 - 1.0
    a = None
    for _k in range(max(1, int(round(max(ah, aw) / 2048.0)))):
        nx = _lfs_binomial(nx)
        ny = _lfs_binomial(ny)
    nx *= float(strength)
    ny *= float(strength)
    nz = np.sqrt(np.clip(1.0 - nx * nx - ny * ny, 0.05, 1.0))
    hx = (-nx / nz).astype(np.float32)
    hv = (ny / nz).astype(np.float32)
    nx = ny = nz = None

    def _d(f, ax):
        return (np.roll(f, -1, ax) - np.roll(f, 1, ax)) * 0.5
    s_ = 4 if max(ah, aw) >= 2048 else 1
    hx_, hv_ = hx[::s_, ::s_], hv[::s_, ::s_]
    c_p = _d(hv_, 1) - _d(hx_, 0)
    c_m = -_d(hv_, 1) - _d(hx_, 0)
    sgn = 1.0 if float((c_p * c_p).mean()) <= float((c_m * c_m).mean()) else -1.0
    print(f"  [bake] {nimg.name}: bumps drawn as edges and grooves (green {'DirectX' if sgn > 0 else 'OpenGL'})")
    cav = (-(_d(hx, 1) + _d(sgn * hv, 0)) * (max(ah, aw) / 1024.0)).astype(np.float32)
    hx = hv = None
    if len(cache) >= 6:
        cache.clear()
    cache[key] = cav
    return cav


def _lfs_normal_cavity(nimg, strength, h, w):
    import numpy as np
    key = ('cavity_hw', nimg.name, round(float(strength), 3), int(h), int(w))
    cache = _LFS_NRM['cache']
    if key in cache:
        return cache[key]
    cav = _lfs_cavity_full(nimg, strength)
    while cav.shape[0] >= 2 * h and cav.shape[1] >= 2 * w:
        h2, w2 = cav.shape[0] // 2, cav.shape[1] // 2
        cav = 0.25 * (cav[0:2 * h2:2, 0:2 * w2:2] + cav[1:2 * h2:2, 0:2 * w2:2]
                      + cav[0:2 * h2:2, 1:2 * w2:2] + cav[1:2 * h2:2, 1:2 * w2:2])
    if cav.shape[0] != h or cav.shape[1] != w:
        yy = (np.arange(h) * cav.shape[0]) // h
        xx = (np.arange(w) * cav.shape[1]) // w
        cav = cav[yy][:, xx]
    cav = np.ascontiguousarray(cav, dtype=np.float32)
    if len(cache) >= 6:
        cache.clear()
    cache[key] = cav
    return cav


def _lfs_cockpit_bumps(o, me, uv_name, faces, mat, h, w):
    import numpy as np
    if not _LFS_NRM['on'] or not faces:
        return None
    nm = _lfs_normal_map_of(mat)
    if nm is None:
        return None
    stw = None
    for _o in bpy.context.scene.objects:
        try:
            if _o.type == 'MESH' and int(_o.get('lfs_subobj_type', -1)) == 2:
                stw = _o
                break
        except (TypeError, ValueError):
            pass
    if stw is None:
        return None
    from mathutils import Vector
    swc = sum((stw.matrix_world @ Vector(cc) for cc in stw.bound_box), Vector()) / 8.0
    mw = o.matrix_world
    ck = np.zeros(len(faces), dtype=bool)
    for k, fi in enumerate(faces):
        dq = (mw @ me.polygons[fi].center) - swc
        ck[k] = dq.length < 0.8 and dq.y > -0.25 and dq.z > -0.35
    if not ck.any():
        return None
    _rel, hp = _lfs_normal_relief(nm[0], nm[1], h, w)
    g = np.repeat((0.5 + np.clip(hp, -0.5, 0.5))[..., None], 4, axis=2)
    sb, _mu = _lfs_face_detail(me, uv_name, faces, g)
    sb = sb / 255.0
    fine = ck & (sb > _LFS_BUMP_MIN)
    return fine, np.where(ck, sb * _LFS_BUMP_GROW, 0.0)


_LFS_SKY_A0 = 0.525
_LFS_SKY_A1 = 0.498


def _lfs_normal_green_sign(nx, ny):
    import numpy as np
    s_ = max(1, int(max(nx.shape) // 512))
    nx = nx[::s_, ::s_]
    ny = ny[::s_, ::s_]
    nz = np.sqrt(np.clip(1.0 - nx * nx - ny * ny, 0.05, 1.0))
    hx = -nx / nz
    hv = ny / nz

    def _d(f, ax):
        return (np.roll(f, -1, ax) - np.roll(f, 1, ax)) * 0.5
    c_p = _d(hv, 1) - _d(hx, 0)
    c_m = -_d(hv, 1) - _d(hx, 0)
    return 1.0 if float((c_p * c_p).mean()) <= float((c_m * c_m).mean()) else -1.0


def _lfs_relief_field(mat):
    import numpy as np
    if not _LFS_NRM['on'] or mat is None:
        return None
    nm = _lfs_normal_map_of(mat)
    if nm is None:
        return None
    nimg, strength = nm
    key = ('relief_field', nimg.name, round(float(strength), 3))
    cache = _LFS_NRM.setdefault('relief', {})
    if key in cache:
        return cache[key]
    a = _bake_read_image(nimg, max_size=4096)
    nx = (a[..., 0] * 2.0 - 1.0).astype(np.float32)
    ny = (a[..., 1] * 2.0 - 1.0).astype(np.float32)
    a = None
    sgn = _lfs_normal_green_sign(nx, ny)
    nx = nx * float(strength)
    ny = -sgn * ny * float(strength)
    k_ = max(nx.shape) / 4096.0

    def _band(f):
        lo_ = _lfs_box_blur(f, max(1, int(round(1 * k_))))
        hi_ = _lfs_box_blur(_lfs_box_blur(f, max(2, int(round(24 * k_)))), max(2, int(round(24 * k_))))
        return (lo_ - hi_).astype(np.float32)
    fld = np.zeros(nx.shape + (4,), np.float32)
    fld[..., 0] = _band(nx)
    fld[..., 1] = _band(ny)
    if len(cache) >= 4:
        cache.clear()
    cache[key] = fld
    print(f"  [bake] {mat.name}: bumps lit by LFS's sky ({nimg.name}, green "
          f"{'DirectX' if sgn > 0 else 'OpenGL'})")
    return fld


def _lfs_relief_apply(col, fld, su, sv, P, suv, nw):
    import numpy as np
    e1 = P[1] - P[0]
    e2 = P[2] - P[0]
    du1 = suv[1][0] - suv[0][0]; dv1 = suv[1][1] - suv[0][1]
    du2 = suv[2][0] - suv[0][0]; dv2 = suv[2][1] - suv[0][1]
    r = du1 * dv2 - du2 * dv1
    if abs(r) < 1e-14:
        return False
    T = (e1 * dv2 - e2 * dv1) / r
    B = (e2 * du1 - e1 * du2) / r
    T = T - nw * nw.dot(T)
    if T.length < 1e-12:
        return False
    T.normalize()
    Bo = nw.cross(T)
    if Bo.dot(B) < 0.0:
        Bo = -Bo
    s = _bake_sample(fld, su, sv)
    dx = s[:, 0]; dy = s[:, 1]
    wx = dx * T.x + dy * Bo.x + nw.x
    wy = dx * T.y + dy * Bo.y + nw.y
    wz = dx * T.z + dy * Bo.z + nw.z
    ln = np.sqrt(wx * wx + wy * wy + wz * wz) + 1e-9
    wx /= ln; wy /= ln; wz /= ln
    A0, A1 = _LFS_SKY_A0, _LFS_SKY_A1
    c_ = 0.15
    E0 = max(A0 + A1 * float(nw.z) + c_, 0.05)
    fd = (A0 + A1 * wz + c_) / E0
    ndv = wx * nw.x + wy * nw.y + wz * nw.z
    rz = 2.0 * ndv * wz - float(nw.z)
    ks = 0.16
    dS = ks * A1 * (rz - float(nw.z))
    lin = np.clip(col[:, :3], 0.0, 1.0) ** 2.2
    lin = lin * np.clip(fd, 0.4, 1.8)[:, None]
    lin = lin * (1.0 - np.clip(0.25 * np.maximum(-dS, 0.0) / ks, 0.0, 0.6))[:, None] + np.maximum(dS, 0.0)[:, None]
    col[:, :3] = np.clip(lin, 0.0, 1.0) ** (1.0 / 2.2)
    return True


def _lfs_nshade(mat, arr, hi_lines=True):
    if not _LFS_NRM['on'] or arr is None or mat is None:
        return arr
    nm = _lfs_normal_map_of(mat)
    if nm is None:
        return arr
    try:
        import numpy as _np5
        cav = _lfs_normal_cavity(nm[0], nm[1], arr.shape[0], arr.shape[1])
        cc = _np5.sign(cav) * _np5.maximum(_np5.abs(cav) - 0.12, 0.0)
        hi = (0.5 * _np5.tanh(_np5.clip(cc, 0.0, None) * (1.0 / 0.5)))[..., None]
        if not hi_lines:
            hi = hi * 0.0
        lo = (0.6 * _np5.tanh(_np5.clip(-cc, 0.0, None) * (1.2 / 0.6)))[..., None]
        c = arr[..., :3]
        Y = 0.3 * c[..., 0:1] + 0.59 * c[..., 1:2] + 0.11 * c[..., 2:3]
        arr[..., :3] = _np5.clip((c + hi * (1.0 - Y) ** 2 * (1.0 - c)) * (1.0 - lo), 0.0, 1.0)
    except Exception as e:
        print(f"  [bake] {mat.name}: the normal-map bumps were skipped: {e!r}")
    return arr


def _bake_sample(src, u, v):
    import numpy as np
    H, W = src.shape[0], src.shape[1]
    x = (u % 1.0) * W - 0.5
    y = (v % 1.0) * H - 0.5
    x0 = np.floor(x).astype(np.int64); y0 = np.floor(y).astype(np.int64)
    fx = (x - x0)[:, None]; fy = (y - y0)[:, None]
    x1 = (x0 + 1) % W; y1 = (y0 + 1) % H
    x0 %= W; y0 %= H
    c = (src[y0, x0] * (1 - fx) * (1 - fy) + src[y0, x1] * fx * (1 - fy)
         + src[y1, x0] * (1 - fx) * fy + src[y1, x1] * fx * fy)
    return c


def _bake_dilate(rgba, written, passes=4):
    import numpy as np
    for _ in range(passes):
        acc = np.zeros_like(rgba); cnt = np.zeros(rgba.shape[:2], dtype=np.float32)
        for dy, dx in ((1, 0), (-1, 0), (0, 1), (0, -1)):
            sh = np.roll(rgba, (dy, dx), axis=(0, 1)); sw = np.roll(written, (dy, dx), axis=(0, 1))
            acc += sh * sw[..., None]; cnt += sw
        fill = (~written.astype(bool)) & (cnt > 0)
        rgba[fill] = acc[fill] / cnt[fill][:, None]
        written = written | fill
    return rgba, written


class LFS_OT_SetTileSize(Operator):
    """Set how big one repeat is on every repeating map whose material name
    contains a word - e.g. 'leath' 0.09 m, so all the leather tiles line up. Export again
    afterwards"""
    bl_idname = "lfs.set_tile_size"
    bl_label = "Set Tile Size"
    bl_options = {'REGISTER', 'UNDO'}

    name_filter: StringProperty(name="Material contains", default="leath")
    tile: FloatProperty(name="Tile size (m)", default=0.09, min=0.02, max=4.0)

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self, width=300)

    def execute(self, context):
        f = self.name_filter.lower().strip()
        n = 0
        for m in bpy.data.materials:
            if m.get('lfs_map_rot') is None or m.get('lfs_baked_from'):
                continue
            names = (m.name.lower(), str(m.get('lfs_split_from', '')).lower())
            if f and not any(f in x for x in names):
                continue
            m['lfs_map_wh'] = [float(self.tile), float(self.tile)]
            n += 1
        self.report({'INFO'}, f"Tile size {self.tile:.3f} m set on {n} map(s) matching '{f}' - export again.")
        return {'FINISHED'} if n else {'CANCELLED'}


class LFS_OT_BakeTextures(Operator):
    """Make the model's own textures work in LFS: they go into your LFS
    texture folder (data\\png) as texture pages, and every surface gets an LFS map onto
    them. Run it after Auto Setup, before Export. Undo Bake puts the model's own
    materials back"""
    bl_idname = "lfs.bake_textures"
    bl_label = "Bake Textures for LFS"
    bl_options = {'REGISTER', 'UNDO'}

    page_size: EnumProperty(
        name="Texture size",
        description="Size of the texture pages it makes (the model's own textures are made "
                    "this size or smaller)",
        items=[('256', "256", ""), ('512', "512", ""), ('1024', "1024 (LFS upload limit)", ""),
               ('2048', "2048 (editor only)", ""), ('4096', "4096 (editor only)", "")],
        default='1024')
    max_pages: IntProperty(name="Max texture pages", default=4, min=1, max=8,
                           description="How many texture pages it may make, see-through "
                                       "ones included. An LFS upload allows 5 megapixels "
                                       "in all = four 1024 pages")
    steer_own_page: BoolProperty(
        name="Steering wheel on its own page", default=True,
        description="The steering wheel gets a texture page of its own (<name>_bk<k>steer.png) as big "
                    "as LFS's 5 MP leaves next to the other pages, instead of a corner of a page it "
                    "shares with the dash")
    pages_per_part: BoolProperty(
        name="A texture page for each part", default=True,
        description="Each part (body, wheels, interior, steering wheel...) gets texture pages of its "
                    "own, named after it (<name>_bk0body.png...), each as big as its pieces need, "
                    "instead of all parts sharing the same pages. Together they stay inside LFS's "
                    "5 MP upload budget (Max texture pages is not used then)")
    directions: EnumProperty(
        name="Directions",
        description="For painted pages: 6 = a box round the model. More = less stretching "
                    "on round parts, but more of LFS's limited cutouts",
        items=[('6', "6 (box)", ""), ('18', "18", ""), ('26', "26", "")],
        default='6')
    skip_paint: BoolProperty(
        name="Keep the paint for skins", default=True, options={'HIDDEN'},
        description="Old switch, kept for scripts: Car paint decides (a script that sets only this "
                    "gets Plain paint colour for ON, Into texture pages for OFF)")
    paint_mode: EnumProperty(
        name="Car paint",
        description="What happens to the car paint's own texture",
        items=[('SKIN', "Into a skin",
                "The paint texture goes into an LFS skin in data\\skins, seen from the top, the sides, "
                "the front and the back like LFS's own cars. The body stays skinnable, colour 1 still "
                "tints it (white shows the skin as it is) and the skin is not part of the 5 MP "
                "texture budget"),
               ('PAGES', "Into texture pages",
                "The paint is baked like every other textured part (uses the 5 MP budget; skins and "
                "colour 1 no longer work on the body)"),
               ('PLAIN', "Plain paint colour",
                "The paint stays one LFS paint colour without its texture (skins and colour 1 work)")],
        default='SKIN')
    skin_size: EnumProperty(name="Skin size", description="LFS skins are square: 1024 is what LFS World "
                            "asks for, LFS also reads 2048",
                            items=[('1024', "1024", "What LFS World asks for"),
                                   ('2048', "2048", "LFS also reads 2048 skins")], default='1024')
    skin_name: StringProperty(
        name="Skin name", default="",
        description="LFS names a skin <Skin ID>_<NAME> (DEFAULT for the plain one). The Skin ID comes "
                    "with the upload: then rename the file in data\\skins and its page in the "
                    "editor, or bake again with the name here. Empty = from the .blend name")
    skip_glass: BoolProperty(
        name="Use LFS's own glass", default=False,
        description="ON: windows use LFS's stock glass (s_glass_ALP). OFF: windows and "
                    "lamp lenses keep the model's own colour and see-through look")
    max_cutouts: IntProperty(name="Max cutouts", default=180, min=20, max=230,
                             description="Cutouts are the rectangles LFS cuts out of the "
                                         "texture pages; the editor takes about 238. Past "
                                         "this number, pieces facing the same way are merged")
    page_prefix: StringProperty(name="Texture name", default="",
                                description="Start of the texture page file names (up to 12 "
                                            "letters). Empty = from the .blend file name")
    use_selection: BoolProperty(name="Selected objects only", default=False)
    split_colour: BoolProperty(
        name="Tile plain materials per direction", default=True,
        description="Materials with no picture of their own (leather, carpet, plastic) get "
                    "one repeating map per direction they face, so LFS's grain textures do "
                    "not stretch over round parts")
    tile_size: FloatProperty(name="Tile size (m)", default=0.45, min=0.05, max=4.0,
                             description="How big one repeat of those maps is (plastics etc.)")
    leather_tile: FloatProperty(name="Leather / cloth tile (m)", default=0.09, min=0.02, max=2.0)
    carpet_tile: FloatProperty(name="Carpet / roof tile (m)", default=0.12, min=0.02, max=2.0)
    mode: EnumProperty(
        name="Method",
        items=[('FIT', "Use the model's textures as they are",
                "Flat pieces of the model's texture layout (door cards, console, dash, badges) "
                "keep the model's own texture, pixel for pixel, like a hand-made LFS car. "
                "Round leftovers: see Round parts"),
               ('BAKE', "Paint new texture pages",
                "Every textured surface is painted into new texture pages from several "
                "directions: works on any model, but softer")],
        default='FIT')
    curved: EnumProperty(
        name="Round parts (seats...)",
        items=[('AUTO', "Automatic",
                "Round pieces keep their own texture, painted into new texture pages (the steering "
                "wheel with extra pixels)"),
               ('COLOUR', "Plain colour", "Round pieces get the average colour of their texture"),
               ('BAKE', "Paint into new texture pages", "Every round piece keeps its real texture "
                "(seats too) - the other pieces get a bit fewer pixels"),
               ('BEST', "One map each (may stretch)", "Textured, but the texture can stretch")],
        default='AUTO')
    fit_tol: FloatProperty(name="Flatness needed", default=0.015, min=0.002, max=0.1,
                           description="How flat a piece of the model's texture layout must be "
                                       "to keep its texture as it is. Higher = more pieces "
                                       "kept, more stretching")
    tile_max_px: IntProperty(
        name="Repeating texture up to (px)", default=256, min=0, max=2048,
        description="A picture this small is a repeating tile (leather grain, brushed "
                    "chrome, carpet): it goes into data\\png as its own page and repeats at "
                    "the model's scale instead of being baked. 0 = bake everything")
    interior_boost: FloatProperty(
        name="Interior detail boost", default=2.0, min=1.0, max=4.0,
        description="For painted pages: the inside of the car gets this many times more "
                    "texture pixels (dash and buttons need it more than door panels)")
    keep_layout: BoolProperty(
        name="Keep my texture layout", default=False,
        description="For textures you made for LFS yourself: the model's own textures go to LFS laid out "
                    "exactly as they are - nothing is cut out and rearranged, painted into new pages, "
                    "shaded with bumps or swapped for LFS leather; round pieces keep their texture too "
                    "(it may stretch a little). Pages go in at the Texture size at most (1024 = LFS's upload limit)")
    normal_detail: BoolProperty(
        name="Bumps from normal maps", default=True,
        description="LFS has no normal maps: the grooves, slats and rings the model's normal "
                    "maps show (vents, grilles, dials, seams) are drawn into the colour")
    steering_detail: BoolProperty(
        name="Steering wheel in detail", default=True,
        description="The steering wheel is what the driver looks at: its own texture (logo, "
                    "stitching, buttons) is painted into a texture page with four times the "
                    "pixels, instead of sharing the model's texture page at that page's size")
    stock_soft: BoolProperty(
        name="Seats, leather, cloth: LFS leather", default=True,
        description="Like a hand-made LFS interior: seat, leather and cloth materials get "
                    "LFS's repeating leather texture (LeathA) tinted with their colour, so "
                    "the texture space goes to the dash and badges. A choice in the LFS "
                    "Texture per Material panel wins")

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self, width=440)

    def draw(self, context):
        lay = self.layout
        lay.use_property_split = True
        lay.use_property_decorate = False
        col = lay.column()
        for k in ("mode", "keep_layout", "page_size", "steer_own_page", "pages_per_part", "max_pages",
                  "paint_mode"):
            _r = col.row()
            _r.prop(self, k)
            if k == "mode":
                _r.enabled = not self.keep_layout
            if k == "max_pages":
                _r.enabled = not self.pages_per_part
        if self.paint_mode == 'SKIN':
            sub = col.column(align=True)
            sub.prop(self, "skin_size")
            sub.prop(self, "skin_name")
        for k in ("skip_glass", "use_selection"):
            col.prop(self, k)
        try:
            hdr, body = lay.panel("lfs_bake_more_options", default_closed=True)
            hdr.label(text="More options")
        except Exception:
            body = lay.box()
        if body:
            b = body.column()
            for k in ("curved", "normal_detail", "steering_detail", "stock_soft", "fit_tol", "tile_max_px",
                      "split_colour", "tile_size",
                      "leather_tile", "carpet_tile", "directions", "max_cutouts", "interior_boost",
                      "page_prefix"):
                b.prop(self, k)

    def _bake_skin(self, context, objs, paint_names, png_dir):
        import numpy as np, os, math
        from mathutils import Vector
        scene = context.scene
        pmats = {}
        _plain_paint = False
        for o in objs:
            for sl in o.material_slots:
                m = sl.material
                if (m is None or m.name in pmats or m.get('lfs_split_from') or m.get('lfs_baked_from')
                        or m.get('lfs_fit_left') or m.get('lfs_tex_page') is not None
                        or m.get('lfs_paint') is False):
                    continue
                if not (m.name.lower() in paint_names or m.name.lower() in _PAINT_SKIN_MATERIALS
                        or bool(m.get('lfs_paint'))):
                    continue
                img = _lfs_base_color_image(m)
                if img is None:
                    _plain_paint = True
                    continue
                if min(img.size) == 0:
                    try:
                        img.reload()
                    except Exception:
                        pass
                if min(img.size) > 0:
                    pmats[m.name] = img
        if not pmats:
            return (" No skin: the car paint has no picture of its own (it stays LFS paint)."
                    if _plain_paint else '')
        base = bpy.data.materials[sorted(pmats)[0]]
        VIEWS = (('top', 0.0, -90.0), ('right', 90.0, 0.0), ('left', -90.0, 0.0),
                 ('front', 180.0, 0.0), ('back', 0.0, 0.0))
        faces = {v[0]: [] for v in VIEWS}
        inner = []
        uvs = {}
        for o in objs:
            me = o.data
            _int = any(h_ in o.name.lower() for h_ in _LFS_INT_HINTS)
            src_uv = o.get('lfs_bake_src_uv')
            if not src_uv or src_uv not in me.uv_layers or src_uv == 'LFS_BAKE':
                cands = [l for l in me.uv_layers if l.name != 'LFS_BAKE']
                src_uv = next((l for l in cands if l.active_render), cands[0]).name if cands else None
                if src_uv:
                    o['lfs_bake_src_uv'] = src_uv
            if src_uv:
                uvs[o.name] = src_uv
            nm3 = o.matrix_world.to_3x3().inverted().transposed()
            for poly in me.polygons:
                if poly.material_index >= len(o.material_slots):
                    continue
                m = o.material_slots[poly.material_index].material
                if m is None or m.name not in pmats:
                    continue
                if _int or not src_uv:
                    inner.append((o, poly.index, m.name))
                    continue
                n = (nm3 @ poly.normal)
                ax, ay, az = abs(n.x), abs(n.y), abs(n.z)
                if az >= max(ax, ay):
                    v = 'top'
                elif ax >= ay:
                    v = 'right' if n.x > 0 else 'left'
                else:
                    v = 'front' if n.y > 0 else 'back'
                faces[v].append((o, poly.index, m.name))
        try:
            from mathutils.bvhtree import BVHTree
            _occ = list(objs) + [o_ for o_ in scene.objects if o_.type == 'MESH' and o_ not in objs
                                 and 'lfs_subobj_index' in o_.keys()]
            _glass_ = set(getattr(self, '_skin_glass', ()) or ())
            _ov = []; _op = []; _tp = []
            for o_ in _occ:
                if o_.get('lfs_preview_only') or o_.get('lfs_mirror_ghost') or not o_.visible_get():
                    continue
                me_ = o_.data; mw_ = o_.matrix_world; sl_ = o_.material_slots
                b_ = len(_ov)
                _ov.extend(mw_ @ v_.co for v_ in me_.vertices)
                _see_ = {}
                for p_ in me_.polygons:
                    m_ = sl_[p_.material_index].material if p_.material_index < len(sl_) else None
                    if m_ is not None and m_.name in pmats:
                        continue
                    if len(p_.vertices) < 3:
                        continue
                    k_ = m_.name if m_ is not None else ''
                    if k_ not in _see_:
                        _see_[k_] = bool(m_ is not None and (k_.lower() in _glass_
                                                             or _is_seethrough_material(k_, k_, m_)))
                    (_tp if _see_[k_] else _op).append([b_ + i_ for i_ in p_.vertices])
            _bo = BVHTree.FromPolygons(_ov, _op, all_triangles=False) if _op else None
            _bt = BVHTree.FromPolygons(_ov, _tp, all_triangles=False) if _tp else None
            if _bo is not None or _bt is not None:
                _behind = 0
                _hid_ = []; _rehomed = 0

                def _blocked(e_, d_):
                    o_, fi_, _mn = e_
                    mw_ = o_.matrix_world; vv_ = o_.data.vertices
                    pts_ = [mw_ @ vv_[i_].co for i_ in o_.data.polygons[fi_].vertices]
                    c_ = sum(pts_, Vector((0.0, 0.0, 0.0))) / len(pts_)
                    samp_ = [c_] + [(c_ + q_) * 0.5 for q_ in pts_[:6]]
                    hit_ = 0
                    for s_ in samp_:
                        q_ = s_ + d_ * 0.005
                        if _bo is not None and _bo.ray_cast(q_, d_)[0] is not None:
                            hit_ += 1
                        elif _bt is not None:
                            hh_ = _bt.ray_cast(q_, d_)
                            if hh_[0] is not None and hh_[3] > 0.25:
                                hit_ += 1
                    return hit_ * 4 >= len(samp_) * 3

                def _rehome_bvh(v_, e_):
                    o_, fi_, _mn = e_
                    nrm_ = o_.matrix_world.to_3x3().inverted().transposed() @ o_.data.polygons[fi_].normal
                    if nrm_.length == 0:
                        return None
                    nrm_ = nrm_.normalized()
                    cands_ = []
                    for w_, hw_, pw_ in VIEWS:
                        if w_ != v_:
                            dw_ = Vector(_uvp_frame(hw_, pw_, 0.0)[2]).normalized()
                            cands_.append((nrm_.dot(dw_), w_, dw_))
                    for dd_, w_, dw_ in sorted(cands_, key=lambda t_: -t_[0]):
                        if dd_ < 0.35:
                            break
                        if not _blocked(e_, dw_):
                            return w_
                    return None
                for v_, h_, pc_ in VIEWS:
                    if not faces[v_]:
                        continue
                    d_ = Vector(_uvp_frame(h_, pc_, 0.0)[2]).normalized()
                    keep_ = []
                    for e_ in faces[v_]:
                        o_, fi_, _mn = e_
                        mw_ = o_.matrix_world; vv_ = o_.data.vertices
                        pts_ = [mw_ @ vv_[i_].co for i_ in o_.data.polygons[fi_].vertices]
                        c_ = sum(pts_, Vector((0.0, 0.0, 0.0))) / len(pts_)
                        samp_ = [c_] + [(c_ + q_) * 0.5 for q_ in pts_[:6]]
                        hit_ = 0
                        for s_ in samp_:
                            q_ = s_ + d_ * 0.005
                            if _bo is not None and _bo.ray_cast(q_, d_)[0] is not None:
                                hit_ += 1
                            elif _bt is not None:
                                h_ = _bt.ray_cast(q_, d_)
                                if h_[0] is not None and h_[3] > 0.25:
                                    hit_ += 1
                        if hit_ * 4 >= len(samp_) * 3:
                            _hid_.append((v_, e_))
                        else:
                            keep_.append(e_)
                    faces[v_] = keep_
                for v_, e_ in _hid_:
                    w_ = _rehome_bvh(v_, e_)
                    if w_ is None:
                        inner.append(e_)
                        _behind += 1
                    else:
                        faces[w_].append(e_)
                        _rehomed += 1
                if _rehomed:
                    print(f"  [skin] {_rehomed} paint face(s) hidden from their own view show from another one "
                          f"(a lamp's reflector...) - painted from there")
                if _behind:
                    print(f"  [skin] {_behind} paint face(s) behind other parts of the car (inside) -> plain colour")
        except Exception as _oe:
            print(f"  [skin] the inside check was skipped: {_oe!r}")
        info = {}
        for v, h, pch in VIEWS:
            if not faces[v]:
                continue
            U, V, N = (Vector(x) for x in _uvp_frame(h, pch, 0.0))
            us = []; vs = []; ns = []
            for o, fi, _mn in faces[v]:
                mw = o.matrix_world
                for vi in o.data.polygons[fi].vertices:
                    q = mw @ o.data.vertices[vi].co
                    us.append(q.dot(U)); vs.append(q.dot(V)); ns.append(q.dot(N))
            info[v] = {'h': h, 'p': pch, 'w': max(0.05, max(us) - min(us)), 'hh': max(0.05, max(vs) - min(vs)),
                       'n1': max(ns)}
        if not info:
            return ''
        views = [v for v, _h, _p in VIEWS if v in info]

        def _pack(s, turned, order):
            rects = []
            for v in order:
                w, hh = info[v]['w'], info[v]['hh']
                if v in turned:
                    w, hh = hh, w
                rects.append((v, max(2, int(math.ceil(w * s))), max(2, int(math.ceil(hh * s)))))
            shelves = []; out = {}
            for v, cw, ch in rects:
                if cw > 128 or ch > 128:
                    return None
                done = False
                for sh in shelves:
                    if ch <= sh[1] and sh[2] + cw <= 128:
                        out[v] = (cw, ch, sh[2], sh[0]); sh[2] += cw + 1; done = True
                        break
                if not done:
                    y = (shelves[-1][0] + shelves[-1][1] + 1) if shelves else 0
                    if y + ch > 128:
                        return None
                    shelves.append([y, ch, cw + 1]); out[v] = (cw, ch, 0, y)
            return out
        best = None
        for mask in range(1 << len(views)):
            turned = {v for k, v in enumerate(views) if mask >> k & 1}

            def _dims(v):
                w, hh = info[v]['w'], info[v]['hh']
                return (hh, w) if v in turned else (w, hh)
            for order in (sorted(views, key=lambda v: -_dims(v)[1]), sorted(views, key=lambda v: -_dims(v)[0]),
                          sorted(views, key=lambda v: -_dims(v)[0] * _dims(v)[1])):
                lo, hi = 1.0, 400.0
                if _pack(lo, turned, order) is None:
                    continue
                for _ in range(32):
                    mid = 0.5 * (lo + hi)
                    if _pack(mid, turned, order) is not None:
                        lo = mid
                    else:
                        hi = mid
                if best is None or lo > best[0] * 1.0001 or (abs(lo - best[0]) <= best[0] * 1e-4
                                                              and len(turned) < len(best[1])):
                    best = (lo, turned, order)
        if best is None:
            return " No skin: the paint does not fit a skin."
        s, turned, order = best
        place = _pack(s, turned, order)
        px = int(self.skin_size)
        skins_dir = os.path.join(os.path.dirname(os.path.normpath(png_dir)), 'skins')
        os.makedirs(skins_dir, exist_ok=True)
        own = [str(x) for x in (scene.get('lfs_own_skins', []) or [])]

        def _free(nm):
            return nm in own or not any(os.path.exists(os.path.join(skins_dir, nm + e))
                                        for e in ('.jpg', '.JPG', '.png', '.dds'))
        nm0 = ''.join(ch for ch in self.skin_name.strip() if ch.isalnum() or ch in '_-')[:19]
        if nm0:
            name = nm0
            k = 2
            while not _free(name) and k < 100:
                sfx = '_%d' % k
                name = nm0[:19 - len(sfx)] + sfx
                k += 1
        else:
            st = (self.page_prefix.strip()
                  or os.path.splitext(os.path.basename(bpy.data.filepath or 'lfscar'))[0])
            st = ''.join(ch for ch in st if ch.isalnum() or ch == '_')[:10].upper() or 'LFSCAR'
            name = st + '_DEFAULT'
            k = 2
            while not _free(name) and k < 100:
                name = st[:10 - len(str(k))] + str(k) + '_DEFAULT'
                k += 1
        path = os.path.join(skins_dir, name + '.jpg')
        rgba = np.zeros((px, px, 4), np.float32)
        depth = np.full((px, px), -1e30, np.float32)
        written = np.zeros((px, px), bool)
        _rfl_skin = {}
        for mn in pmats:
            try:
                _rfl_skin[mn] = _lfs_relief_field(bpy.data.materials.get(mn))
            except Exception as _rse:
                print(f"  [skin] {mn}: bumps by the sky skipped: {_rse!r}")
                _rfl_skin[mn] = None
        srcs = {mn: _lfs_nshade(bpy.data.materials.get(mn), _bake_read_image(img, max_size=2048),
                                hi_lines=_rfl_skin.get(mn) is None)
                for mn, img in pmats.items()}
        unit = px / 128.0
        frame = {}
        owner = np.full((px, px), -1, np.int32)
        fid_of = {}
        for v in views:
            for e in faces[v]:
                fid_of[(e[0].name, e[1])] = len(fid_of)
        cover = np.zeros(len(fid_of), np.int64)
        for v in views:
            i = info[v]
            r = 90.0 if v in turned else 0.0
            U, V, N = (Vector(x) for x in _uvp_frame(i['h'], i['p'], r))
            cw, ch, cx, cy = place[v]
            us = []; vs = []
            for o, fi, _mn in faces[v]:
                mw = o.matrix_world
                for vi in o.data.polygons[fi].vertices:
                    q = mw @ o.data.vertices[vi].co
                    us.append(q.dot(U)); vs.append(q.dot(V))
            W = cw / s; Hm = ch / s
            pos = U * (0.5 * (min(us) + max(us))) + V * (0.5 * (min(vs) + max(vs))) + N * i['n1']
            frame[v] = (U, V, N, pos, W, Hm, r)
            x0p = cx * unit; y0p = cy * unit; wp = cw * unit; hp = ch * unit
            for o, fi, mn in faces[v]:
                me = o.data; mw = o.matrix_world
                uvl = me.uv_layers[uvs[o.name]].data
                src = srcs[mn]
                poly = me.polygons[fi]
                fid = fid_of[(o.name, fi)]
                lv = list(poly.loop_indices); vv = list(poly.vertices)
                for k in range(1, len(vv) - 1):
                    tri = (0, k, k + 1)
                    P = [mw @ me.vertices[vv[t_]].co for t_ in tri]
                    suv = [uvl[lv[t_]].uv for t_ in tri]
                    ax_ = np.array([x0p + ((q - pos).dot(U) / W + 0.5) * wp for q in P])
                    ay_ = np.array([y0p + ((q - pos).dot(V) / Hm + 0.5) * hp for q in P])
                    dz = np.array([(q - pos).dot(N) for q in P])
                    xmin = max(int(math.floor(ax_.min())), 0); xmax = min(int(math.ceil(ax_.max())), px - 1)
                    ymin = max(int(math.floor(ay_.min())), 0); ymax = min(int(math.ceil(ay_.max())), px - 1)
                    if xmax < xmin or ymax < ymin:
                        continue
                    det = (ax_[1] - ax_[0]) * (ay_[2] - ay_[0]) - (ax_[2] - ax_[0]) * (ay_[1] - ay_[0])
                    if abs(det) < 1e-9:
                        continue
                    gx, gy = np.meshgrid(np.arange(xmin, xmax + 1) + 0.5, np.arange(ymin, ymax + 1) + 0.5)
                    l1 = ((gx - ax_[0]) * (ay_[2] - ay_[0]) - (ax_[2] - ax_[0]) * (gy - ay_[0])) / det
                    l2 = ((ax_[1] - ax_[0]) * (gy - ay_[0]) - (gx - ax_[0]) * (ay_[1] - ay_[0])) / det
                    l0 = 1.0 - l1 - l2
                    inside = (l0 >= -0.002) & (l1 >= -0.002) & (l2 >= -0.002)
                    if not inside.any():
                        continue
                    yy, xx = np.nonzero(inside)
                    ys = yy + ymin; xs = xx + xmin
                    cover[fid] += len(ys)
                    z = (l0 * dz[0] + l1 * dz[1] + l2 * dz[2])[yy, xx]
                    keep = z >= depth[ys, xs] - 1e-6
                    if not keep.any():
                        continue
                    ys = ys[keep]; xs = xs[keep]; yy = yy[keep]; xx = xx[keep]; z = z[keep]
                    su = l0[yy, xx] * suv[0][0] + l1[yy, xx] * suv[1][0] + l2[yy, xx] * suv[2][0]
                    sv = l0[yy, xx] * suv[0][1] + l1[yy, xx] * suv[1][1] + l2[yy, xx] * suv[2][1]
                    col = _bake_sample(src, su, sv)
                    if _rfl_skin.get(mn) is not None:
                        _nw9 = mw.to_3x3().inverted().transposed() @ poly.normal
                        if _nw9.length > 1e-12:
                            _nw9.normalize()
                            _lfs_relief_apply(col, _rfl_skin[mn], su, sv, P, suv, _nw9)
                    col[:, 3] = 1.0
                    rgba[ys, xs] = col; depth[ys, xs] = z; written[ys, xs] = True; owner[ys, xs] = fid
        owned = np.bincount(owner[owner >= 0].ravel(), minlength=len(fid_of))
        seen = (cover <= 2) | (owned * 4 >= cover)

        def _rast(w, e, write):
            U, V, N, pos, W, Hm, r = frame[w]
            cw, ch, cx, cy = place[w]
            x0p = cx * unit; y0p = cy * unit; wp = cw * unit; hp = ch * unit
            o, fi, mn = e
            me = o.data; mw = o.matrix_world
            poly = me.polygons[fi]
            lv = list(poly.loop_indices); vv = list(poly.vertices)
            P_all = [mw @ me.vertices[i_].co for i_ in vv]
            axs = [x0p + ((q - pos).dot(U) / W + 0.5) * wp for q in P_all]
            ays = [y0p + ((q - pos).dot(V) / Hm + 0.5) * hp for q in P_all]
            if min(axs) < x0p - 1 or max(axs) > x0p + wp + 1 or min(ays) < y0p - 1 or max(ays) > y0p + hp + 1:
                return 0, 0
            uvl = me.uv_layers[uvs[o.name]].data
            src = srcs[mn]
            fid = fid_of[(o.name, fi)]
            cov = 0; vis = 0
            for k in range(1, len(vv) - 1):
                tri = (0, k, k + 1)
                P = [P_all[t_] for t_ in tri]
                suv = [uvl[lv[t_]].uv for t_ in tri]
                ax_ = np.array([axs[t_] for t_ in tri])
                ay_ = np.array([ays[t_] for t_ in tri])
                dz = np.array([(q - pos).dot(N) for q in P])
                xmin = max(int(math.floor(ax_.min())), 0); xmax = min(int(math.ceil(ax_.max())), px - 1)
                ymin = max(int(math.floor(ay_.min())), 0); ymax = min(int(math.ceil(ay_.max())), px - 1)
                if xmax < xmin or ymax < ymin:
                    continue
                det = (ax_[1] - ax_[0]) * (ay_[2] - ay_[0]) - (ax_[2] - ax_[0]) * (ay_[1] - ay_[0])
                if abs(det) < 1e-9:
                    continue
                gx, gy = np.meshgrid(np.arange(xmin, xmax + 1) + 0.5, np.arange(ymin, ymax + 1) + 0.5)
                l1 = ((gx - ax_[0]) * (ay_[2] - ay_[0]) - (ax_[2] - ax_[0]) * (gy - ay_[0])) / det
                l2 = ((ax_[1] - ax_[0]) * (gy - ay_[0]) - (gx - ax_[0]) * (ay_[1] - ay_[0])) / det
                l0 = 1.0 - l1 - l2
                inside = (l0 >= -0.002) & (l1 >= -0.002) & (l2 >= -0.002)
                if not inside.any():
                    continue
                yy, xx = np.nonzero(inside)
                ys = yy + ymin; xs = xx + xmin
                cov += len(ys)
                z = (l0 * dz[0] + l1 * dz[1] + l2 * dz[2])[yy, xx]
                keep = z >= depth[ys, xs] - 1e-6
                vis += int(keep.sum())
                if not write or not keep.any():
                    continue
                ys = ys[keep]; xs = xs[keep]; yy = yy[keep]; xx = xx[keep]; z = z[keep]
                su = l0[yy, xx] * suv[0][0] + l1[yy, xx] * suv[1][0] + l2[yy, xx] * suv[2][0]
                sv = l0[yy, xx] * suv[0][1] + l1[yy, xx] * suv[1][1] + l2[yy, xx] * suv[2][1]
                col = _bake_sample(src, su, sv)
                if _rfl_skin.get(mn) is not None:
                    _nw9 = mw.to_3x3().inverted().transposed() @ poly.normal
                    if _nw9.length > 1e-12:
                        _nw9.normalize()
                        _lfs_relief_apply(col, _rfl_skin[mn], su, sv, P, suv, _nw9)
                col[:, 3] = 1.0
                rgba[ys, xs] = col; depth[ys, xs] = z; written[ys, xs] = True; owner[ys, xs] = fid
            return cov, vis

        _moved2 = {}
        for v in views:
            for e in faces[v]:
                if seen[fid_of[(e[0].name, e[1])]]:
                    continue
                o, fi, _mn = e
                nrm = o.matrix_world.to_3x3().inverted().transposed() @ o.data.polygons[fi].normal
                if nrm.length == 0:
                    continue
                nrm = nrm.normalized()
                for dd, w in sorted(((nrm.dot(frame[w_][2]), w_) for w_ in views if w_ != v), key=lambda t_: -t_[0]):
                    if dd < 0.35:
                        break
                    cov_, vis_ = _rast(w, e, False)
                    if cov_ > 2 and vis_ * 4 >= cov_:
                        _rast(w, e, True)
                        _moved2[(o.name, fi)] = (w, e)
                        break
        owner = None
        for v in views:
            keep_ = []
            for e in faces[v]:
                if seen[fid_of[(e[0].name, e[1])]]:
                    keep_.append(e)
                elif (e[0].name, e[1]) not in _moved2:
                    inner.append(e)
            faces[v] = keep_
        for w, e in _moved2.values():
            faces[w].append(e)
        if _moved2:
            print(f"  [skin] {len(_moved2)} paint face(s) covered in their own view show from another one - painted there")
        views = [v for v in views if faces[v]]
        if not views:
            srcs.clear()
            return " No skin: no part of the car paint shows from outside."
        inner_mats = {}
        if inner:
            import numpy as _np
            by_mn = {}
            for o, fi, mn in inner:
                by_mn.setdefault(mn, []).append((o, fi))
            for mn, lst in by_mn.items():
                us_ = []; vs_ = []; ws_ = []
                for o, fi in lst:
                    uvn_ = uvs.get(o.name)
                    if not uvn_:
                        continue
                    uvd_ = o.data.uv_layers[uvn_].data
                    li_ = list(o.data.polygons[fi].loop_indices)
                    us_.append(sum(uvd_[l].uv.x for l in li_) / len(li_))
                    vs_.append(sum(uvd_[l].uv.y for l in li_) / len(li_))
                    ws_.append(max(o.data.polygons[fi].area, 1e-9))
                if us_:
                    cc = _bake_sample(srcs[mn], _np.array(us_), _np.array(vs_))[:, :3]
                    avg_ = (cc * _np.array(ws_)[:, None]).sum(axis=0) / sum(ws_)
                else:
                    avg_ = srcs[mn][..., :3].reshape(-1, 3).mean(axis=0)
                inner_mats[mn] = [float(x) for x in avg_]
        srcs.clear()
        view_avg = {}
        for v in views:
            cw, ch, cx, cy = place[v]
            reg = rgba[int(cy * unit):int((cy + ch) * unit), int(cx * unit):int((cx + cw) * unit)]
            wr_ = written[int(cy * unit):int((cy + ch) * unit), int(cx * unit):int((cx + cw) * unit)]
            view_avg[v] = reg[wr_][:, :3].mean(axis=0) if wr_.any() else np.array([0.5, 0.5, 0.5])
        rgba, wr = _bake_dilate(rgba, written, passes=8)
        if wr.any():
            rgba[~wr] = rgba[wr].mean(axis=0)
        rgba[..., 3] = 1.0
        img = bpy.data.images.new(name + '_bake', px, px, alpha=False)
        img.pixels.foreach_set(rgba.reshape(-1))
        img.filepath_raw = path
        img.file_format = 'JPEG'
        try:
            img.save(filepath=path, quality=95)
        except TypeError:
            img.save()
        bpy.data.images.remove(img)
        rgba = None; depth = None
        simg = bpy.data.images.load(path, check_existing=True)
        try:
            simg.reload()
        except Exception:
            pass
        moved = {mn: 0 for mn in pmats}
        for v in views:
            for _o, _fi, mn in faces[v]:
                moved[mn] += 1
        for _o, _fi, mn in inner:
            moved[mn] += 1
        made_in = {}
        for mn, avg_ in inner_mats.items():
            lm = bpy.data.materials[mn].copy()
            lm.name = f"{mn[:9]}_in"
            for kk in ('lfs_map_rot', 'lfs_map_pos', 'lfs_map_wh', 'lfs_cutout_rect', 'lfs_tex_page', 'lfs_tex_tint',
                       'lfs_tex_tint_rgb', 'lfs_tex_auto', 'lfs_split_from', 'lfs_fit_base', 'lfs_cidx',
                       'lfs_map_name', 'lfs_m1_auto', 'lfs_tile_size'):
                if kk in lm.keys():
                    del lm[kk]
            lin_ = [c_ / 12.92 if c_ <= 0.04045 else ((c_ + 0.055) / 1.055) ** 2.4 for c_ in avg_]
            try:
                for n_ in lm.node_tree.nodes:
                    if n_.type == 'BSDF_PRINCIPLED':
                        inp_ = n_.inputs['Base Color']
                        for lk in list(inp_.links):
                            lm.node_tree.links.remove(lk)
                        inp_.default_value = (lin_[0], lin_[1], lin_[2], 1.0)
            except Exception:
                pass
            lm.diffuse_color = (lin_[0], lin_[1], lin_[2], 1.0)
            lm['lfs_fit_left'] = mn
            lm['lfs_auto_made'] = True
            lm['lfs_paint'] = False
            lm['lfs_rtype'] = 1
            _lfs_set_tex_page(lm, '', tint=False, auto=True)
            made_in[mn] = lm
        for o, fi, mn in inner:
            lm = made_in.get(mn)
            if lm is None:
                continue
            me = o.data
            si = next((k for k, sl in enumerate(o.material_slots) if sl.material is lm), None)
            if si is None:
                me.materials.append(lm); si = len(me.materials) - 1
            me.polygons[fi].material_index = si
        fc = _lfs_material_face_counts([ob for ob in bpy.data.objects if ob.type == 'MESH' and ob.users > 0
                                        and not ob.get('lfs_preview_only')])
        all_gone = all(fc.get(mn, 0) <= moved[mn] for mn in pmats)
        mats_out = {}
        for k, v in enumerate(views):
            nm = ('M1_' if (k == 0 and all_gone) else 'C1_') + v
            vm = bpy.data.materials.new(nm)
            vm.use_nodes = True
            nt = vm.node_tree
            for n_ in list(nt.nodes):
                nt.nodes.remove(n_)
            out = nt.nodes.new('ShaderNodeOutputMaterial'); bsdf = nt.nodes.new('ShaderNodeBsdfPrincipled')
            tex = nt.nodes.new('ShaderNodeTexImage'); tex.image = simg
            uvn = nt.nodes.new('ShaderNodeUVMap'); uvn.uv_map = 'LFS_BAKE'
            nt.links.new(uvn.outputs['UV'], tex.inputs['Vector'])
            nt.links.new(tex.outputs['Color'], bsdf.inputs['Base Color'])
            nt.links.new(bsdf.outputs['BSDF'], out.inputs['Surface'])
            bsdf.inputs['Roughness'].default_value = 0.35
            _a = [float(c_) for c_ in view_avg[v]]
            _a = [c_ / 12.92 if c_ <= 0.04045 else ((c_ + 0.055) / 1.055) ** 2.4 for c_ in _a]
            vm.diffuse_color = (_a[0], _a[1], _a[2], 1.0)
            U, V, N, pos, W, Hm, r = frame[v]
            cw, ch, cx, cy = place[v]
            vm['lfs_baked_from'] = base.name
            vm['lfs_auto_made'] = True
            vm['lfs_paint'] = False
            vm['lfs_skin_page'] = True
            vm['lfs_tex_page'] = name
            vm['lfs_tex_auto'] = True
            vm['lfs_map_name'] = nm
            vm['lfs_map_rot'] = int(_uvp_pack_rot(info[v]['h'], info[v]['p'], r))
            vm['lfs_map_pos'] = [float(pos.x), float(pos.y), float(pos.z)]
            vm['lfs_map_wh'] = [float(W), float(Hm)]
            vm['lfs_cutout_rect'] = [int(cw), int(ch), int(cx), int(cy)]
            mats_out[v] = vm
        for v, fl in faces.items():
            if v not in mats_out:
                continue
            vm = mats_out[v]
            U, V, N, pos, W, Hm, r = frame[v]
            cw, ch, cx, cy = place[v]
            by_obj = {}
            for o, fi, _mn in fl:
                by_obj.setdefault(o.name, (o, []))[1].append(fi)
            for o, fis in by_obj.values():
                me = o.data; mw = o.matrix_world
                si = next((k for k, sl in enumerate(o.material_slots) if sl.material is vm), None)
                if si is None:
                    me.materials.append(vm); si = len(me.materials) - 1
                if 'LFS_BAKE' not in me.uv_layers:
                    me.uv_layers.new(name='LFS_BAKE')
                buv = me.uv_layers['LFS_BAKE'].data
                for fi in fis:
                    poly = me.polygons[fi]
                    poly.material_index = si
                    for li, vi in zip(poly.loop_indices, poly.vertices):
                        q = mw @ me.vertices[vi].co
                        u = (q - pos).dot(U) / W + 0.5
                        vv_ = (q - pos).dot(V) / Hm + 0.5
                        buv[li].uv = ((cx + u * cw) / 128.0, (cy + vv_ * ch) / 128.0)
                me.update()
        first = mats_out[views[0]]
        if all_gone:
            live = _lfs_live_material_names()
            for m_ in bpy.data.materials:
                if m_.name in pmats and m_.get('lfs_cidx') is not None:
                    try:
                        if int(m_['lfs_cidx']) == 1:
                            del m_['lfs_cidx']
                    except (TypeError, ValueError):
                        pass
            holder = None
            for m_ in bpy.data.materials:
                if m_ is first or m_.name not in live or m_.get('lfs_cidx') is None:
                    continue
                try:
                    if int(m_['lfs_cidx']) == 1:
                        holder = m_
                except (TypeError, ValueError):
                    pass
            if holder is None:
                first['lfs_cidx'] = 1
        try:
            _lfs_assign_cidx([vm.name for vm in mats_out.values()] + [lm.name for lm in made_in.values()])
        except ValueError as _ve:
            self.report({'WARNING'}, str(_ve))
        if name not in own:
            own.append(name)
            scene['lfs_own_skins'] = own
        scene['lfs_skin_page'] = name
        self._skin_made = True
        ppm = s * px / 128.0
        print(f"  [skin] {sum(len(f) for f in faces.values())} paint face(s) of {sorted(pmats)} -> {path}, "
              f"{len(inner)} inside the car or hidden -> plain {sorted(lm.name for lm in made_in.values())} "
              f"({px} px, {ppm:.0f} px/m, views {[(v, place[v], v in turned) for v in views]})")
        return (f" The car paint went into the skin {name}.jpg in data\\skins ({px} px, "
                f"{ppm:.0f} px per metre) - colour 1 tints it (white shows it as it is); when the mod "
                f"has its Skin ID, rename the file and its page to <Skin ID>_DEFAULT.")

    def _split_colour_materials(self, context):
        try:
            r = bpy.ops.lfs.auto_split_maps(map_size=self.tile_size, min_share=0.05, min_area=0.05,
                                            soft_tile=self.leather_tile, carpet_tile=self.carpet_tile)
            return r == {'FINISHED'}
        except Exception as e:
            self.report({'WARNING'}, f"direction split skipped: {e}")
            return False

    def _fit_uv_mode(self, context, objs, png_dir, skip, bc_image=None, glass=()):
        import numpy as np
        vl = context.view_layer
        prev_active = vl.objects.active
        _bases = {m.name for m in bpy.data.materials if m.get('lfs_fit_base')}
        if _bases:
            _dead = set()
            for o in objs:
                me = o.data
                back = {}
                for si, sl in enumerate(o.material_slots):
                    m = sl.material
                    if m is None:
                        continue
                    base = str(m.get('lfs_fit_left') or '') or str(m.get('lfs_split_from') or '')
                    if base in _bases and m.name != base:
                        tgt = next((k for k, s2 in enumerate(o.material_slots)
                                    if s2.material and s2.material.name == base), None)
                        if tgt is None:
                            me.materials.append(bpy.data.materials[base]); tgt = len(me.materials) - 1
                        back[si] = tgt; _dead.add(m.name)
                if back:
                    for p in me.polygons:
                        if p.material_index in back:
                            p.material_index = back[p.material_index]
            for nm in _dead:
                mm = bpy.data.materials.get(nm)
                if mm is not None and mm.users <= len(objs) + 1:
                    try:
                        bpy.data.materials.remove(mm)
                    except Exception:
                        pass
            for bn in _bases:
                bm_ = bpy.data.materials.get(bn)
                if bm_ is None:
                    continue
                for k in ('lfs_tex_page', 'lfs_tex_tint', 'lfs_tex_tint_rgb', 'lfs_tex_auto',
                          'lfs_fit_base', 'lfs_map_rot', 'lfs_map_pos', 'lfs_map_wh', 'lfs_cutout_rect'):
                    if k in bm_.keys():
                        del bm_[k]
            print(f"  [fit] previous fit undone on {sorted(_bases)} ({len(_dead)} material(s) folded back)")
        cands = {}
        for o in objs:
            _with_faces = {p.material_index for p in o.data.polygons}
            for _si7, sl in enumerate(o.material_slots):
                m = sl.material
                if _si7 not in _with_faces:
                    continue
                if (m is None or m.name.lower() in skip or m.get('lfs_baked_from')
                        or m.get('lfs_split_from') or m.get('lfs_tex_page') is not None
                        or _lfs_base_color_image(m) is None
                        or m.get('lfs_user_choice') in ('BAKE', 'BAKE_HI')):
                    continue
                if m.name.lower() in glass or m.name.lower() in _GLASS_MATERIALS or m.get('lfs_glass'):
                    continue
                if bc_image is not None:
                    _t = bc_image(m)
                    if _t and (_t[1] is not None or _t[2] < 0.999):
                        continue
                if o not in cands.setdefault(m.name, []):
                    cands[m.name].append(o)
        if not cands:
            return 0
        imgs = {}
        _nmat_of = {}
        for mn in cands:
            img = _lfs_base_color_image(bpy.data.materials[mn])
            if img is None:
                continue
            if min(img.size) == 0:
                try:
                    img.reload()
                except Exception:
                    pass
            if min(img.size) > 0:
                imgs[img.name] = img
                if _LFS_NRM['on'] and _lfs_normal_map_of(bpy.data.materials[mn]) is not None:
                    _nmat_of.setdefault(img.name, bpy.data.materials[mn])
        _reserve = 0.6 if self.curved in ('AUTO', 'BAKE') else 1.0
        per = int(5_000_000 * _reserve) // max(1, len(imgs))
        max_px = int(self.page_size)
        while max_px * max_px > per and max_px > 128:
            max_px //= 2
        stem_of = {}
        _rel_faces = {}
        for mn, obs in cands.items():
            _mm9 = bpy.data.materials.get(mn)
            _im9 = _lfs_base_color_image(_mm9) if _mm9 is not None else None
            if _im9 is None or _im9.name not in _nmat_of:
                continue
            for o in obs:
                try:
                    _uv9 = next((l.name for l in o.data.uv_layers if l.active_render), None) or \
                        (o.data.uv_layers[0].name if len(o.data.uv_layers) else None)
                    _si9 = {i for i, sl in enumerate(o.material_slots) if sl.material is not None
                            and sl.material.name == mn}
                    _fs9 = [pl.index for pl in o.data.polygons if pl.material_index in _si9]
                    if _uv9 and _fs9:
                        _rel_faces.setdefault(_im9.name, []).append((o, _fs9, _uv9))
                except Exception:
                    pass
        for iname, img in imgs.items():
            st, _px = _lfs_export_image_as_page(img, png_dir, max_px=max_px,
                                                shade_mat=_nmat_of.get(iname),
                                                relief_faces=_rel_faces.get(iname))
            if st:
                stem_of[iname] = st
                self._fit_px = getattr(self, '_fit_px', 0) + _px
        budget = int(self.max_cutouts)
        if getattr(self, '_fit_budget', None) is not None:
            budget = max(0, min(budget, int(self._fit_budget)))
        next_ci = 0
        for m_ in bpy.data.materials:
            try:
                next_ci = max(next_ci, int(m_.get('lfs_cidx', -1)))
            except (ValueError, TypeError):
                pass

        def _lin(s):
            return s / 12.92 if s <= 0.04045 else ((s + 0.055) / 1.055) ** 2.4

        def _maps_obj(o_):
            try:
                _mi9 = np.empty(len(o_.data.polygons), dtype=np.int32)
                o_.data.polygons.foreach_get('material_index', _mi9)
                _cs9 = set()
                for _s9 in np.unique(_mi9).tolist():
                    _m9 = o_.material_slots[_s9].material if 0 <= _s9 < len(o_.material_slots) else None
                    if _m9 is not None and _m9.get('lfs_cidx') is not None:
                        _cs9.add(int(_m9['lfs_cidx']))
                return len(_cs9)
            except Exception:
                return next_ci
        _bud = {}
        _pairs_of = {}
        for _ol9 in cands.values():
            for _o9 in _ol9:
                _pairs_of[_o9.name] = _pairs_of.get(_o9.name, 0) + 1
                _bud.setdefault(_o9.name, budget)

        n_parts = 0; n_left = 0
        _n_pairs = sum(len(v) for v in cands.values()); _pair_i = 0
        _det_room = [64]

        def _ring_assign(o, me, si, mn, parts):
            nonlocal next_ci
            src_m = me.materials[si]
            done = set(); nr = 0
            for fit, ids, box in parts:
                if _maps_obj(o) >= _MAP_TABLE_MAX - 1:
                    break
                k = 1
                while f"{mn[:9]}_r{k}" in bpy.data.materials:
                    k += 1
                pm = src_m.copy()
                pm.name = f"{mn[:9]}_r{k}"
                pm['lfs_split_from'] = src_m.get('lfs_split_from', src_m.name)
                for kk in ('lfs_fit_left', 'lfs_tile_size'):
                    if kk in pm.keys():
                        del pm[kk]
                next_ci += 1
                pm['lfs_cidx'] = next_ci
                _lfs_write_fit_map(pm, fit, box)
                me.materials.append(pm)
                ns = len(me.materials) - 1
                for fi in ids:
                    me.polygons[fi].material_index = ns
                done.update(ids); nr += 1
            return nr, done
        for mn, olist in sorted(cands.items()):
            olist = sorted(olist, key=lambda _o: _o.name)
            m = bpy.data.materials[mn]
            img = _lfs_base_color_image(m)
            st = stem_of.get(img.name) if img is not None else None
            if not st:
                continue
            _lfs_set_tex_page(m, st, tint=False, auto=True)
            m['lfs_fit_base'] = True
            for k in ('lfs_map_rot', 'lfs_map_pos', 'lfs_map_wh', 'lfs_cutout_rect'):
                if k in m.keys():
                    del m[k]
            src = None
            src_d = None
            for o in olist:
                me = o.data
                si = next((i for i, sl in enumerate(o.material_slots) if sl.material == m), None)
                if si is None or not me.uv_layers:
                    continue
                uvn = o.get('lfs_bake_src_uv')
                if not uvn or uvn not in me.uv_layers or uvn == 'LFS_BAKE':
                    _cu = [l for l in me.uv_layers if l.name != 'LFS_BAKE']
                    if not _cu:
                        continue
                    uvn = next((l for l in _cu if l.active_render), _cu[0]).name
                    o['lfs_bake_src_uv'] = uvn
                me.uv_layers[uvn].active = True
                if not any(p.material_index == si for p in me.polygons):
                    continue
                if (getattr(self, 'steering_detail', True) and self.curved == 'AUTO' and _det_room[0] > 0
                        and _maps_obj(o) < _MAP_TABLE_MAX - 8 and str(o.get('lfs_subobj_type', '')) == '2'):
                    _sall = [p.index for p in me.polygons if p.material_index == si]
                    if len(_sall) >= 3:
                        k = 1
                        while f"{mn[:9]}_d{k}" in bpy.data.materials:
                            k += 1
                        dm = m.copy(); dm.name = f"{mn[:9]}_d{k}"
                        for kk in ('lfs_map_rot', 'lfs_map_pos', 'lfs_map_wh', 'lfs_cutout_rect',
                                   'lfs_tex_page', 'lfs_tex_tint', 'lfs_tex_tint_rgb', 'lfs_tex_auto',
                                   'lfs_split_from', 'lfs_fit_base', 'lfs_tile_size'):
                            if kk in dm.keys():
                                del dm[kk]
                        next_ci += 1
                        dm['lfs_cidx'] = next_ci
                        dm['lfs_fit_left'] = mn
                        dm['lfs_detail_bake'] = True
                        me.materials.append(dm)
                        _dsi = len(me.materials) - 1
                        for fi in _sall:
                            me.polygons[fi].material_index = _dsi
                        n_left += 1
                        _det_room[0] -= 1
                        _pair_i += 1
                        print(f"  [fit] {o.name}/{mn}: steering wheel - {len(_sall)} face(s) painted in detail "
                              f"-> {dm.name}")
                        continue
                mo = m
                if len(olist) > 1:
                    mo = m.copy()
                    mo.name = f"{mn[:10]}_{''.join(ch for ch in o.name if ch.isalnum())[:3].lower()}"
                    mo['lfs_split_from'] = mn
                    next_ci += 1
                    mo['lfs_cidx'] = next_ci
                    me.materials[si] = mo
                if mo.get('lfs_cidx') is None:
                    next_ci += 1
                    mo['lfs_cidx'] = next_ci
                vl.objects.active = o
                o.active_material_index = si
                o['lfs_fit_rejected'] = []
                n_before = len(bpy.data.materials)
                budget = _bud.get(o.name, budget)
                _pairs_left = max(1, _pairs_of.get(o.name, 1))
                _pairs_of[o.name] = _pairs_left - 1
                _cap = max(6, min(64, budget // _pairs_left))
                _pair_i += 1
                _ring_first = 0
                if self.curved != 'BAKE' and budget > 0:
                    _all = [p.index for p in me.polygons if p.material_index == si]
                    if len(_all) >= 32:
                        try:
                            _rp = _lfs_revolution_parts(o, _all, uvn, self.fit_tol * 1.5, sectors=8,
                                                        max_nx=1.01, min_sectors=6)
                        except Exception as _rpe:
                            _rp = []
                            print(f"  [fit] {o.name}/{mn}: ring fit skipped: {_rpe}")
                        _cov = sum(len(_i) for _f, _i, _b in _rp)
                        if _rp and _cov >= 0.9 * len(_all) and len(_rp) <= max(8, budget // 2):
                            _ring_first, _rdone = _ring_assign(o, me, si, mn, _rp)
                            print(f"  [fit] {o.name}/{mn}: wheel ring - {len(_rdone)}/{len(_all)} face(s) "
                                  f"-> {_ring_first} sector map(s)")
                _ci_room = _MAP_TABLE_MAX - _maps_obj(o) - (2 * _pairs_left + 8)
                if budget > 0 and not _ring_first and _ci_room > 0:
                    try:
                        bpy.ops.lfs.fit_uv_maps(
                            rms_tol=self.fit_tol,
                            fallback_rms=(0.2 if self.curved == 'BEST' else self.fit_tol),
                            max_parts=max(1, min(_cap, budget, _ci_room)), min_faces=4, min_island_faces=1,
                            parts_per_island=8, whole_island=(self.curved != 'BEST'),
                            island_min_ok=0.5, uv_name=uvn, quiet=True)
                    except Exception as e:
                        print(f"  [fit] {o.name}/{mn}: {e}")
                made = len(bpy.data.materials) - n_before
                for _m2 in bpy.data.materials:
                    try:
                        next_ci = max(next_ci, int(_m2.get('lfs_cidx', -1)))
                    except (TypeError, ValueError):
                        pass
                fitted_base = mo.get('lfs_map_rot') is not None
                if fitted_base:
                    made += 1
                budget -= made; n_parts += made
                _bud[o.name] = budget
                if fitted_base:
                    _keep = set(int(x) for x in o.get('lfs_fit_base_faces', []))
                    rej = [p.index for p in me.polygons if p.material_index == si and p.index not in _keep]
                else:
                    rej = [p.index for p in me.polygons if p.material_index == si]
                if not rej:
                    continue
                if self.curved != 'BAKE' and budget > 0 and len(rej) >= 16 and not _ring_first:
                    try:
                        _rev = _lfs_revolution_parts(o, rej, uvn, self.fit_tol * 1.5, sectors=8,
                                                     max_nx=1.01, min_sectors=3)
                    except Exception as _rev_e:
                        _rev = []
                        print(f"  [fit] {o.name}/{mn}: ring fit skipped: {_rev_e}")
                    if _rev and len(_rev) <= max(8, budget // 2):
                        _nr, _done = _ring_assign(o, me, si, mn, _rev)
                        budget -= _nr; n_parts += _nr
                        _bud[o.name] = budget
                        if _done:
                            print(f"  [fit] {o.name}/{mn}: {len(_done)} leftover face(s) on a wheel ring -> {_nr} sector map(s)")
                            rej = [fi for fi in rej if fi not in _done]
                    if not rej:
                        continue
                if src is None:
                    src = _bake_read_image(img, max_size=512)
                if self.curved == 'AUTO' and len(rej) >= 1 and _det_room[0] > 0:
                    try:
                        if src_d is None:
                            src_d = _bake_read_image(img, max_size=2048)
                        _fd, _fmu = _lfs_face_detail(me, uvn, rej, src_d)
                        _fdev = _lfs_colour_outliers(_fmu, [me.polygons[fi].area for fi in rej])
                        _seed = [(_fd[i] > _LFS_DETAIL_MIN or bool(_fdev[i])) for i in range(len(rej))]
                        _fine = None
                        try:
                            _fine = _lfs_cockpit_bumps(o, me, uvn, rej, m, src_d.shape[0], src_d.shape[1])
                        except Exception as _fbe:
                            print(f"  [fit] {o.name}/{mn}: the bumps' detail check skipped: {_fbe!r}")
                        if _fine is not None:
                            _nb = int(sum(1 for i in range(len(rej)) if _fine[0][i] and not _seed[i]))
                            _seed = [bool(_seed[i] or _fine[0][i]) for i in range(len(rej))]
                            _fd = np.maximum(_fd, _fine[1])
                            if _nb:
                                print(f"  [fit] {o.name}/{mn}: {_nb} face(s) near the driver with small bumps in "
                                      f"the normal map (vents, buttons, badges) -> detail")
                        _seed = _lfs_grow_detail(me, rej, _seed, _fd)
                        _dsel = [rej[i] for i in range(len(rej)) if _seed[i]]
                        _dar = sum(me.polygons[fi].area for fi in _dsel)
                        _tar = sum(me.polygons[fi].area for fi in rej) or 1.0
                        if len(_dsel) >= 3 and _maps_obj(o) < _MAP_TABLE_MAX - 8:
                            k = 1
                            while f"{mn[:9]}_d{k}" in bpy.data.materials:
                                k += 1
                            dm = m.copy(); dm.name = f"{mn[:9]}_d{k}"
                            for kk in ('lfs_map_rot', 'lfs_map_pos', 'lfs_map_wh', 'lfs_cutout_rect',
                                       'lfs_tex_page', 'lfs_tex_tint', 'lfs_tex_tint_rgb', 'lfs_tex_auto',
                                       'lfs_split_from', 'lfs_fit_base', 'lfs_tile_size'):
                                if kk in dm.keys():
                                    del dm[kk]
                            next_ci += 1
                            dm['lfs_cidx'] = next_ci
                            dm['lfs_fit_left'] = mn
                            dm['lfs_detail_bake'] = True
                            me.materials.append(dm)
                            _dsi = len(me.materials) - 1
                            for fi in _dsel:
                                me.polygons[fi].material_index = _dsi
                            if _fine is not None:
                                try:
                                    _fa = me.attributes.get('lfs_fine_bumps')
                                    if _fa is None:
                                        _fa = me.attributes.new('lfs_fine_bumps', 'BOOLEAN', 'FACE')
                                    _fv = np.zeros(len(me.polygons), dtype=bool)
                                    _fa.data.foreach_get('value', _fv)
                                    for i in range(len(rej)):
                                        if _seed[i] and _fine[0][i]:
                                            _fv[rej[i]] = True
                                    _fa.data.foreach_set('value', _fv)
                                except Exception as _fae:
                                    print(f"  [fit] {o.name}/{mn}: {_fae!r}")
                            _ds = set(_dsel)
                            rej = [fi for fi in rej if fi not in _ds]
                            n_left += 1
                            _det_room[0] -= 1
                            print(f"  [fit] {o.name}/{mn}: {len(_dsel)} round face(s) with detail "
                                  f"({_dar / _tar * 100:.0f} % of the round area) -> {dm.name} painted")
                    except Exception as _de:
                        print(f"  [fit] {o.name}/{mn}: detail check skipped: {_de!r}")
                    if not rej:
                        continue
                uvd = me.uv_layers[uvn].data
                us = []; vs = []; ws = []
                for fi in rej:
                    p = me.polygons[fi]
                    li = list(p.loop_indices)
                    us.append(sum(uvd[l].uv.x for l in li) / len(li))
                    vs.append(sum(uvd[l].uv.y for l in li) / len(li))
                    ws.append(max(p.area, 1e-9))
                col = _bake_sample(src, np.array(us), np.array(vs))[:, :3]
                w = np.array(ws)
                if getattr(img, 'is_float', False):
                    srgb = np.array([[_srgb_from_linear(float(v)) for v in c] for c in col], dtype=float)
                else:
                    srgb = np.clip(np.asarray(col, dtype=float) * 255.0, 0.0, 255.0)
                K = min(4, len(srgb)) if self.curved != 'BAKE' else 1
                if self.curved == 'BEST':
                    K = min(4, len(srgb))
                cent = srgb[np.argsort(-w)[:K]].copy() if K > 1 else srgb.mean(axis=0, keepdims=True)
                lab = np.zeros(len(srgb), dtype=int)
                for _it in range(12):
                    d = ((srgb[:, None, :] - cent[None, :, :]) ** 2).sum(axis=2)
                    lab = d.argmin(axis=1)
                    for ci_ in range(len(cent)):
                        sel = lab == ci_
                        if sel.any():
                            cent[ci_] = (srgb[sel] * w[sel, None]).sum(axis=0) / w[sel].sum()
                _resid = float(np.sqrt(((srgb - cent[lab]) ** 2).sum(axis=1).dot(w) / w.sum() / 3.0)) if K > 1 else 0.0
                _bake_this = (self.curved in ('BAKE', 'AUTO'))
                _small_stem = None
                if (not _bake_this and self.curved != 'BEST' and img is not None
                        and self.tile_max_px > 0 and max(img.size) <= self.tile_max_px):
                    _sst, _spx = _lfs_export_image_as_page(img, png_dir, max_px=1024)
                    if _sst:
                        _small_stem = _sst
                        self._fit_px = getattr(self, '_fit_px', 0) + _spx
                        _bake_this = False
                if _bake_this:
                    K = 1; cent = srgb.mean(axis=0, keepdims=True); lab = np.zeros(len(srgb), dtype=int)
                order = list(np.argsort([-w[lab == ci_].sum() for ci_ in range(len(cent))]))
                groups = []
                for ci_ in order:
                    if not (lab == ci_).any():
                        continue
                    for g in groups:
                        if np.abs(cent[ci_] - cent[g[0]]).max() < 40 or w[lab == ci_].sum() < 0.03 * w.sum():
                            g[1].extend(np.nonzero(lab == ci_)[0].tolist()); break
                    else:
                        groups.append([ci_, np.nonzero(lab == ci_)[0].tolist()])
                interior = any(h in o.name.lower() for h in _LFS_INT_HINTS)
                for gci, gidx in groups:
                    gw = w[gidx]; gavg_ = (srgb[gidx] * gw[:, None]).sum(axis=0) / gw.sum()
                    avg = tuple(int(round(v)) for v in gavg_)
                    if _maps_obj(o) >= _MAP_TABLE_MAX - 2:
                        _soft_ = False
                        _best_ = None
                        for _pm in bpy.data.materials:
                            if (not _pm.get('lfs_fit_left') or _pm.get('lfs_cidx') is None
                                    or _pm.get('lfs_detail_bake')):
                                continue
                            _pg = _pm.get('lfs_tex_page')
                            if (_pg == _LFS_STOCK_SOFT_PAGE) != _soft_ or (not _soft_ and _pg != ''):
                                continue
                            _rgb = _lfs_plain_rgb(_pm)
                            if _rgb is None:
                                continue
                            _d_ = sum((a_ - b_) ** 2 for a_, b_ in zip(_rgb, avg))
                            if _best_ is None or _d_ < _best_[0]:
                                _best_ = (_d_, _pm)
                        if _best_ is not None:
                            _pm = _best_[1]
                            _si2 = next((i_ for i_, s_ in enumerate(o.material_slots) if s_.material is _pm), None)
                            if _si2 is None:
                                me.materials.append(_pm)
                                _si2 = len(me.materials) - 1
                            for gi in gidx:
                                me.polygons[rej[gi]].material_index = _si2
                            print(f"  [fit] {o.name}/{mn}: {len(gidx)} curved face(s) -> {_pm.name} "
                                  f"(no map numbers left: the nearest plain colour)")
                        else:
                            print(f"  [fit] {o.name}/{mn}: no map numbers left - {len(gidx)} curved face(s) "
                                  f"keep the material")
                        continue
                    k = 1
                    while f"{mn[:9]}_c{k}" in bpy.data.materials:
                        k += 1
                    lm = m.copy(); lm.name = f"{mn[:9]}_c{k}"
                    for kk in ('lfs_map_rot', 'lfs_map_pos', 'lfs_map_wh', 'lfs_cutout_rect',
                               'lfs_tex_page', 'lfs_tex_tint', 'lfs_tex_tint_rgb', 'lfs_tex_auto',
                               'lfs_split_from', 'lfs_fit_base'):
                        if kk in lm.keys():
                            del lm[kk]
                    next_ci += 1
                    lm['lfs_cidx'] = next_ci
                    lm['lfs_fit_left'] = mn
                    if self.curved == 'AUTO' and _resid <= 28.0:
                        lm['lfs_bake_prio'] = 0.5
                    if _small_stem:
                        _lfs_set_tex_page(lm, _small_stem, tint=False, auto=True)
                        _d = _lfs_uv_density(olist, m, None)
                        if _d:
                            lm['lfs_tile_size'] = float(max(0.02, min(4.0, _d)))
                    elif not _bake_this:
                        try:
                            for n in lm.node_tree.nodes:
                                if n.type == 'BSDF_PRINCIPLED':
                                    inp = n.inputs['Base Color']
                                    for lk in list(inp.links):
                                        lm.node_tree.links.remove(lk)
                                    inp.default_value = (_lin(avg[0] / 255.0), _lin(avg[1] / 255.0),
                                                         _lin(avg[2] / 255.0), 1.0)
                        except Exception:
                            pass
                        _lfs_set_tex_page(lm, '', tint=False, auto=True)
                    me.materials.append(lm)
                    nsi = len(me.materials) - 1
                    for gi in gidx:
                        me.polygons[rej[gi]].material_index = nsi
                    n_left += 1
                    print(f"  [fit] {o.name}/{mn}: {len(gidx)} curved face(s) -> {lm.name} "
                          f"{('tiled ' + _small_stem) if _small_stem else ('BAKE' if _bake_this else 'colour rgb%s' % (avg,))} (detail {_resid:.0f})")
                print(f"  [fit] {o.name}/{mn}: {made} fitted part(s), {len(rej)} curved face(s) in {len(groups)} colour group(s)")
        vl.objects.active = prev_active
        _seen_ci = {}; _mx = 0; _fixed = 0
        _live2 = _lfs_live_material_names()
        for _m2 in bpy.data.materials:
            try:
                _mx = max(_mx, int(_m2.get('lfs_cidx', -1)))
            except (TypeError, ValueError):
                pass
        for _m2 in sorted(bpy.data.materials, key=lambda x: (bool(x.get('lfs_split_from') or x.get('lfs_fit_left')), x.name)):
            _c = _m2.get('lfs_cidx')
            if _c is None or _m2.name not in _live2:
                continue
            _c = int(_c)
            if _c in _seen_ci:
                continue
            _seen_ci[_c] = _m2.name
        _free_ci = [c_ for c_ in range(2, _CIDX_MAX + 1) if c_ not in _seen_ci]
        for _m2 in bpy.data.materials:
            _c = _m2.get('lfs_cidx')
            if _c is not None and _m2.name in _live2 and _seen_ci.get(int(_c)) not in (None, _m2.name):
                while _free_ci and _free_ci[0] in _seen_ci:
                    _free_ci.pop(0)
                if _mx < _CIDX_MAX:
                    _mx += 1
                    _m2['lfs_cidx'] = _mx
                elif _free_ci:
                    _m2['lfs_cidx'] = _free_ci.pop(0)
                else:
                    continue
                _seen_ci[int(_m2['lfs_cidx'])] = _m2.name
                _fixed += 1
        if _fixed:
            print(f"  [fit] {_fixed} duplicate map number(s) re-assigned")
        try:
            self._fit_repack(context, png_dir, stem_of, imgs, _nmat_of, _rel_faces)
        except Exception as _rpe:
            import traceback as _tb
            _tb.print_exc()
            print(f"  [fit] repacking the model's pages skipped: {_rpe!r}")
        print(f"  [fit] {n_parts} fitted map(s), {n_left} leftover material(s), pages {sorted(set(stem_of.values()))}")
        return n_parts

    def _fit_repack(self, context, png_dir, stem_of, imgs, nmat_of, rel_faces):
        import numpy as np, os, math
        scene = context.scene
        if getattr(self, 'keep_layout', False):
            return 0
        try:
            _fc = _lfs_material_face_counts([o for o in context.scene.objects if o.type == 'MESH'
                                             and 'lfs_subobj_index' in o.keys()])
        except Exception:
            _fc = None
        live = ({n for n, c in _fc.items() if c > 0} if _fc is not None else _lfs_live_material_names())
        by_page = {}
        whole = set()
        for m in bpy.data.materials:
            if m.name not in live:
                continue
            st = str(m.get('lfs_tex_page') or '')
            if not st or st not in stem_of.values():
                continue
            r = m.get('lfs_cutout_rect')
            if m.get('lfs_tile_size') or r is None or m.get('lfs_map_rot') is None:
                whole.add(st)
                print(f"  [fit] {st}: kept whole for {m.name} ("
                      f"{'tiled' if m.get('lfs_tile_size') else ('no map' if m.get('lfs_map_rot') is None else 'the whole page')})")
                continue
            wu, hu, x0, y0 = (int(v) for v in list(r)[:4])
            if wu <= 0 or hu <= 0 or wu >= 128 or hu >= 128:
                whole.add(st)
                continue
            by_page.setdefault(st, []).append((m, (wu, hu, x0, y0)))
        inv = {st: iname for iname, st in stem_of.items()}
        made = 0
        stem0 = (self.page_prefix.strip() or os.path.splitext(os.path.basename(bpy.data.filepath or 'lfsbake'))[0])
        stem0 = ''.join(ch for ch in stem0 if ch.isalnum() or ch in '_-')[:11] or 'lfsbake'
        if not self.page_prefix.strip():
            stem0 = _bake_own_prefix(scene, stem0, png_dir, getattr(self, '_own_pages', set()))
        own = [str(x) for x in (scene.get('lfs_repack_pages') or [])]

        def _shelf(rects, r):
            place = {}; x = 0; y = 0; row = 0
            for k, (wu, hu) in sorted(rects.items(), key=lambda kv: -kv[1][1]):
                w = max(1, int(round(wu * r))) + 2; h = max(1, int(round(hu * r))) + 2
                if w > 128 or h > 128:
                    return None
                if x + w > 128:
                    x = 0; y += row; row = 0
                if y + h > 128:
                    return None
                place[k] = (x, y, w - 2, h - 2); x += w; row = max(row, h)
            return place
        for st, items in sorted(by_page.items()):
            if st in whole or st not in inv:
                continue
            img = imgs.get(inv[st]) or bpy.data.images.get(inv[st])
            if img is None or min(img.size) == 0:
                continue
            P = 1024
            pg_path = os.path.join(png_dir, st + '.png')
            try:
                _pimg = bpy.data.images.load(pg_path, check_existing=False)
                P = int(_pimg.size[0]); bpy.data.images.remove(_pimg)
            except Exception:
                pass
            SH = min(2048, 2 ** int(round(math.log2(max(img.size)))))
            rmax = SH / float(P)
            if rmax < 1.15:
                continue
            rects = {k: (it[1][0], it[1][1]) for k, it in enumerate(items)}
            place = None; r = rmax
            while r >= 1.15:
                place = _shelf(rects, r)
                if place is not None:
                    break
                r *= 0.93
            if place is None:
                print(f"  [fit] {st}: its pieces fill the page already - kept as it is")
                continue
            tmp = img.copy()
            try:
                if tuple(tmp.size) != (SH, SH):
                    tmp.scale(SH, SH)
                a = np.empty(SH * SH * 4, np.float32)
                tmp.pixels.foreach_get(a)
                a = a.reshape(SH, SH, 4)
            finally:
                bpy.data.images.remove(tmp)
            sm = nmat_of.get(inv[st])
            if sm is not None:
                try:
                    rf = _lfs_relief_field(sm) if rel_faces.get(inv[st]) else None
                    a = _lfs_nshade(sm, a, hi_lines=rf is None)
                    if rf is not None:
                        _lfs_relief_page(a, rf, rel_faces.get(inv[st]))
                except Exception as _ne:
                    print(f"  [fit] {st}: the bumps skipped: {_ne!r}")
            page = np.zeros((P, P, 4), np.float32); page[..., 3] = 1.0
            upg = P / 128.0
            us = SH / 128.0
            for k, (m, (wu, hu, x0, y0)) in enumerate(items):
                nx, ny, wn, hn = place[k]
                tw = int(round((wn + 2) * upg)); th = int(round((hn + 2) * upg))
                sx = (np.arange(tw) + 0.5) / upg - 1.0
                sy = (np.arange(th) + 0.5) / upg - 1.0
                fx = (x0 + sx * (wu / float(wn))) * us - 0.5
                fy = (y0 + sy * (hu / float(hn))) * us - 0.5
                fx = np.clip(fx, 0.0, SH - 1.0); fy = np.clip(fy, 0.0, SH - 1.0)
                ix0 = np.floor(fx).astype(np.int64); iy0 = np.floor(fy).astype(np.int64)
                ix1 = np.minimum(ix0 + 1, SH - 1); iy1 = np.minimum(iy0 + 1, SH - 1)
                wx = (fx - ix0)[None, :, None]; wy = (fy - iy0)[:, None, None]
                blk = ((a[iy0][:, ix0] * (1 - wx) + a[iy0][:, ix1] * wx) * (1 - wy)
                       + (a[iy1][:, ix0] * (1 - wx) + a[iy1][:, ix1] * wx) * wy)
                px0 = int(round(nx * upg)); py0 = int(round(ny * upg))
                page[py0:py0 + th, px0:px0 + tw] = blk[:P - py0, :P - px0]
            name = f"{stem0}_fp{made}"
            pi = bpy.data.images.get(name + '.png')
            if pi is not None and tuple(pi.size) != (P, P):
                pi.name = pi.name + '_old'; pi = None
            pi = pi or bpy.data.images.new(name + '.png', P, P)
            pi.pixels.foreach_set(page.ravel())
            pi.filepath_raw = os.path.join(png_dir, name + '.png'); pi.file_format = 'PNG'
            pi.save()
            if name not in own:
                own.append(name)
            for k, (m, rr) in enumerate(items):
                nx, ny, wn, hn = place[k]
                m['lfs_tex_page'] = name
                m['lfs_cutout_rect'] = [wn, hn, nx + 1, ny + 1]
            made += 1
            print(f"  [fit] {st}: its {len(items)} piece(s) cut out and packed onto {name} ({P} px) - "
                  f"{r:.2f} x the pixels each way")
        if own:
            scene['lfs_repack_pages'] = own
        return made

    def execute(self, context):
        self._look_note = (" The LFS look (Material Preview) catches up in a few seconds."
                           if context.scene.get('lfs_look_attached') else '')
        _lfs_progress(n=100)
        try:
            _BAKE_IMG_CACHE['d'].clear(); _BAKE_IMG_CACHE['mb'] = 0.0
            _BAKE_IMG_CACHE['on'] = True
            if getattr(self, 'keep_layout', False):
                self.mode = 'FIT'; self.curved = 'BEST'; self.normal_detail = False
                self.stock_soft = False; self.steering_detail = False
            self._fit_retry = 0; self._fit_budget = None; self._fit_note = ''
            self._again = False
            r = self._bake(context)
            _k9 = 0
            while getattr(self, '_again', False) and _k9 < 3:
                self._again = False
                _k9 += 1
                r = self._bake(context)
            return r
        finally:
            _BAKE_IMG_CACHE['on'] = False
            _BAKE_IMG_CACHE['d'].clear(); _BAKE_IMG_CACHE['mb'] = 0.0
            _lfs_progress(end=True)

    def _bake(self, context):
        import numpy as np, bmesh as _bm, os, math, time
        from mathutils import Vector
        t0 = time.time()
        scene = context.scene
        _LFS_NRM['on'] = bool(getattr(self, 'normal_detail', True))
        _LFS_NRM['cache'].clear()
        for _o7 in scene.objects:
            try:
                if _o7.type == 'MESH' and _o7.data.attributes.get('lfs_fine_bumps') is not None:
                    _o7.data.attributes.remove(_o7.data.attributes['lfs_fine_bumps'])
            except Exception:
                pass
        if self.use_selection:
            objs = [o for o in context.selected_objects if o.type == 'MESH']
        else:
            objs = [o for o in scene.objects if o.type == 'MESH'
                    and 'lfs_subobj_index' in o.keys()]
        if not objs:
            self.report({'ERROR'}, "No LFS parts yet: run Auto Setup first.")
            return {'CANCELLED'}
        if any(int(o.get('lfs_subobj_original_nf', 0) or 0) > 0 for o in scene.objects
               if o.type == 'MESH' and 'lfs_subobj_index' in o.keys()):
            self.report({'ERROR'}, "This car came from an .sre: its parts already use LFS texture pages. "
                                   "Bake Textures is for models from other formats (FBX, OBJ...). "
                                   "Give a new part one of the car's materials, or a plain colour.")
            return {'CANCELLED'}
        png_dir = _resolve_png_dir()
        if not os.path.isdir(png_dir):
            self.report({'ERROR'}, (f"Texture folder not found: {png_dir}. " if png_dir else
                                    "The texture folder is not set. ") +
                        "Bake writes into your LFS data\\png folder: set it in the LFS tab "
                        "(LFS SRE panel) or in Preferences > Add-ons > LFS SRE Tools.")
            return {'CANCELLED'}
        _found_tex, _missing_tex = _lfs_find_missing_images(objs)
        _tex_note = _lfs_missing_note(_found_tex, _missing_tex)
        self._tex_note = (' ' + _tex_note) if _tex_note else ''
        self._tex_warn = bool(_missing_tex)
        _own_pages = {str(m.get('lfs_tex_page')) for m in bpy.data.materials
                      if m.get('lfs_baked_from') and m.get('lfs_tex_page')}
        _own_pages |= {str(x) for x in (scene.get('lfs_repack_pages') or [])}
        self._own_pages = _own_pages
        _n_rm, _n_back = _lfs_undo_auto(objs)
        try:
            _lfs_restore_cidx()
            bpy.ops.lfs.purge_unused_maps(also_unused_zero_face_mats=True)
            _lfs_record_cidx(objs)
        except Exception as _ce:
            print(f"  [bake] map numbers: {_ce!r}")
        if _n_rm:
            print(f"  [bake] previous run undone: {_n_rm} material(s) removed, {_n_back} face(s) restored")
        _linked = _lfs_autolink_missing_textures(objs, png_dir)
        if _linked:
            self.report({'INFO'}, f"{len(_linked)} material(s) had no texture in Blender - linked the "
                                  f"matching file(s) from disk: " + ", ".join(f"{a}<-{b}" for a, b in _linked[:4]))
        _mats_before = {m.name for m in bpy.data.materials}
        _maps_before = {m.name for m in bpy.data.materials if m.get('lfs_map_rot') is not None}
        self._fit_px = 0
        page_px = int(self.page_size)
        upx = page_px // 128
        _budget_pages = max(1, int(5_000_000 // (page_px * page_px)))
        if self.max_pages > _budget_pages:
            self.report({'WARNING'}, f"{self.max_pages} pages of {page_px}px exceed LFS's 5-megapixel upload "
                                     f"budget - using {_budget_pages}")
        _total_pages = min(self.max_pages, _budget_pages)
        dirs = [Vector(d) for d in _bake_dir_set(int(self.directions))]
        _n_dirs0 = len(dirs)

        def _bc_image(mat):
            if not (mat and mat.use_nodes and mat.node_tree):
                return None
            for n in mat.node_tree.nodes:
                if n.type == 'BSDF_PRINCIPLED':
                    col = n.inputs.get('Base Color')
                    if col and col.links:
                        src = col.links[0].from_node
                        if src.type == 'TEX_IMAGE' and src.image:
                            a_img = None; a_const = 1.0; a_chan = 0
                            a = n.inputs.get('Alpha')
                            if a is not None:
                                if a.links and a.links[0].from_node.type == 'TEX_IMAGE' and a.links[0].from_node.image:
                                    a_img = a.links[0].from_node.image
                                    a_chan = 3 if a.links[0].from_socket.name == 'Alpha' else 0
                                elif not a.links:
                                    a_const = float(a.default_value)
                            return (src.image, a_img, a_const, a_chan)
            return None
        try:
            _ap, _ag = _auto_detect_from_scene(
                [m.name for m in bpy.data.materials], glass_mode=scene.get('lfs_automap_glass_mode', 'AUTO'))
        except Exception:
            _ap, _ag = set(), set()
        try:
            _lfs_enforce_m1(_ap)
        except Exception as _e:
            print(f"  [bake] m1 rule skipped: {_e}")
        try:
            _pr = self.properties
            if _pr.is_property_set('skip_paint') and not _pr.is_property_set('paint_mode'):
                self.paint_mode = 'PLAIN' if self.skip_paint else 'PAGES'
        except Exception:
            pass
        skip = set()
        if self.paint_mode != 'PAGES':
            skip |= {n for n in _ap}
        if self.skip_glass:
            skip |= {n for n in _ag} | set(_GLASS_MATERIALS)
        def _paintish(m):
            return m is not None and (m.name.lower() in _ap or m.name.lower() in _PAINT_SKIN_MATERIALS
                                      or bool(m.get('lfs_paint')))

        def _will_bake(m):
            return (m is not None and m.get('lfs_tex_page') is None and not m.get('lfs_baked_from')
                    and not m.get('lfs_split_from') and m.name.lower() not in skip
                    and _bc_image(m) is not None)
        for o in objs:
            back = {}
            for si, sl in enumerate(o.material_slots):
                m = sl.material
                srcn = None
                if m is not None and m.get('lfs_baked_from'):
                    srcn = str(m['lfs_baked_from'])
                elif m is not None and m.get('lfs_split_from'):
                    _sm = bpy.data.materials.get(str(m['lfs_split_from']))
                    if _sm is not None and (_will_bake(_sm) or _paintish(_sm)):
                        srcn = _sm.name
                if srcn is not None:
                    tgt = next((k for k, s2 in enumerate(o.material_slots) if s2.material and s2.material.name == srcn), None)
                    if tgt is None and srcn in bpy.data.materials:
                        o.data.materials.append(bpy.data.materials[srcn]); tgt = len(o.material_slots) - 1
                    if tgt is not None:
                        back[si] = tgt
            if back:
                for p in o.data.polygons:
                    if p.material_index in back:
                        p.material_index = back[p.material_index]
        for m in bpy.data.materials:
            if (not m.get('lfs_split_from') and not m.get('lfs_baked_from')
                    and (_will_bake(m) or _paintish(m))):
                for k in ('lfs_map_rot', 'lfs_map_pos', 'lfs_map_wh'):
                    if k in m.keys():
                        del m[k]
        _n_soft = 0
        for o in objs:
            for sl in o.material_slots:
                m = sl.material
                if m is None or m.get('lfs_baked_from') or m.get('lfs_split_from'):
                    continue
                if m.get('lfs_tex_auto'):
                    if not self.stock_soft:
                        _lfs_apply_tex_page_group(m.name, None)
                    continue
                if m.get('lfs_tex_page') is not None or m.name.lower() in skip:
                    continue
                if (self.stock_soft and _lfs_is_soft_name(m.name) and _bc_image(m)
                        and _lfs_soft_fits(_lfs_image_avg_rgb(_bc_image(m)), png_dir)):
                    _lfs_apply_tex_page_group(m.name, _LFS_STOCK_SOFT_PAGE, tint=True, auto=True)
                    _n_soft += 1
        if self.stock_soft:
            _hard = ('glass', 'chrome', 'metal', 'mirror', 'light', 'lamp', 'lens', 'screen',
                     'lcd', 'display', 'gauge', 'paint', 'wire', 'logo', 'badge', 'neon',
                     'emiss', 'carbon', 'wood')
            def _root_of(mm):
                return str(mm.get('lfs_split_from') or mm.get('lfs_fit_left') or mm.name)
            _ext_used, _int_used = set(), set()
            for o in [x for x in scene.objects if x.type == 'MESH']:
                _idx = {p.material_index for p in o.data.polygons}
                _u = {_root_of(o.material_slots[i].material) for i in _idx
                      if i < len(o.material_slots) and o.material_slots[i].material}
                if any(h in o.name.lower() for h in _LFS_INT_HINTS):
                    _int_used |= _u
                else:
                    _ext_used |= _u
            for root in sorted(_int_used - _ext_used):
                m = bpy.data.materials.get(root)
                if (m is None or m.get('lfs_baked_from') or m.get('lfs_tex_page') is not None
                        or root.lower() in skip or _paintish(m) or m.get('lfs_glass')
                        or _bc_image(m) is not None):
                    continue
                if any(h in ''.join(c for c in root.lower() if c.isalnum()) for h in _hard):
                    continue
                if not _lfs_soft_fits(_mat_rgb(m), png_dir):
                    continue
                _lfs_apply_tex_page_group(root, _LFS_STOCK_SOFT_PAGE, tint=True, auto=True)
                _n_soft += 1
        if _n_soft:
            print(f"  [bake] {_n_soft} seat/leather material(s) -> stock {_LFS_STOCK_SOFT_PAGE} (not baked)")
        _n_tile = 0
        if self.tile_max_px > 0:
            _seen_tile = set()
            for o in objs:
                for sl in o.material_slots:
                    m = sl.material
                    if (m is None or m.name in _seen_tile or m.get('lfs_baked_from')
                            or m.get('lfs_split_from') or m.get('lfs_tex_page') is not None
                            or m.name.lower() in skip):
                        continue
                    _seen_tile.add(m.name)
                    img = _lfs_base_color_image(m)
                    if img is None:
                        continue
                    if min(img.size) == 0:
                        try:
                            img.reload()
                        except Exception:
                            pass
                    if min(img.size) == 0 or max(img.size) > self.tile_max_px:
                        continue
                    if _lfs_uv_span(objs, m) < 2.0:
                        continue
                    stem, _px = _lfs_export_image_as_page(img, png_dir, max_px=1024)
                    if not stem:
                        continue
                    self._fit_px = getattr(self, '_fit_px', 0) + _px
                    dens = _lfs_uv_density(objs, m, None)
                    _lfs_apply_tex_page_group(m.name, stem, tint=False, auto=True)
                    if dens:
                        m['lfs_tile_size'] = float(max(0.02, min(4.0, dens)))
                    _n_tile += 1
                    print(f"  [bake] {m.name}: {img.size[0]}px tile -> page {stem}, tile {dens and round(dens, 3)} m (not baked)")
        if _n_tile:
            self.report({'INFO'}, f"{_n_tile} tiling texture(s) exported as pages instead of baked")
        self._skin_note = ''
        self._skin_made = False
        if self.paint_mode == 'SKIN':
            try:
                self._skin_glass = set(_ag or ())
                self._skin_note = self._bake_skin(context, objs, _ap, png_dir) or ''
            except Exception as _se:
                import traceback as _tb
                _tb.print_exc()
                self.report({'WARNING'}, f"The skin was not made ({_se}) - the paint stays a plain colour")
        _fit_parts = 0
        if self.mode == 'FIT':
            _fit_parts = self._fit_uv_mode(context, objs, png_dir, skip, _bc_image, _ag)
        if self._fit_px:
            while page_px > 128 and (5_000_000 - self._fit_px) < page_px * page_px:
                page_px //= 2
            upx = max(1, page_px // 128)
            _budget_pages = max(1, int(max(0, 5_000_000 - self._fit_px) // (page_px * page_px)))
            _total_pages = min(self.max_pages, _budget_pages)
            print(f"  [bake] fitted pages use {self._fit_px/1e6:.2f} MP -> atlas: up to {_total_pages} page(s) of {page_px}px")
        bakeable = {}
        _faces_of = _lfs_material_face_counts(objs)
        for o in objs:
            for sl in o.material_slots:
                m = sl.material
                if m is None or m.name.lower() in skip or m.get('lfs_baked_from'):
                    continue
                if m.get('lfs_tex_page') is not None:
                    continue
                if not _faces_of.get(m.name):
                    continue
                trip = _bc_image(m)
                for img in ([trip[0], trip[1]] if trip else []):
                    if img is None:
                        continue
                    if min(img.size) == 0:
                        try:
                            _abs = bpy.path.abspath(img.filepath)
                            if not os.path.exists(_abs) and bpy.data.filepath:
                                _bd = os.path.dirname(bpy.data.filepath)
                                _bn = bpy.path.basename(img.filepath)
                                for _cand in (os.path.join(_bd, _bn), os.path.join(_bd, 'textures', _bn),
                                              os.path.join(_bd, 'Textures', _bn)):
                                    if os.path.exists(_cand):
                                        img.filepath = _cand
                                        print(f"  [bake] {img.name}: found at {_cand}")
                                        break
                            img.reload()
                        except Exception:
                            pass
                    if min(img.size) == 0:
                        self.report({'WARNING'}, f"{m.name}: texture '{img.name}' could not be loaded "
                                                 f"({img.filepath})")
                if trip and min(trip[0].size) > 0:
                    a_img = trip[1] if (trip[1] is not None and min(trip[1].size) > 0) else None
                    _achan = trip[3] if len(trip) > 3 else 0
                    _has_trans = False
                    if a_img is not None:
                        try:
                            _aa = _lfs_alpha_mask(a_img, _achan, 512)
                            _has_trans = bool((_aa < 0.9).mean() > 0.001)
                        except Exception:
                            _has_trans = True
                    is_alpha = (_has_trans or trip[2] < 0.999
                                or m.name.lower() in _ag or m.name.lower() in _GLASS_MATERIALS)
                    bakeable[m.name] = (trip[0], a_img, trip[2], is_alpha, (trip[3] if len(trip) > 3 else 0))
        if not bakeable and (_fit_parts or getattr(self, '_skin_made', False)):
            if self.split_colour:
                self._split_colour_materials(context)
            for _mn in ({m.name for m in bpy.data.materials} - _mats_before):
                _mm = bpy.data.materials.get(_mn)
                if _mm is not None:
                    _mm['lfs_auto_made'] = True
            for _mn in ({m.name for m in bpy.data.materials if m.get('lfs_map_rot') is not None} - _maps_before):
                _mm = bpy.data.materials.get(_mn)
                if _mm is not None and _mn in _mats_before:
                    _mm['lfs_auto_map'] = True
            try:
                bpy.ops.lfs.purge_unused_maps(also_unused_zero_face_mats=True)
            except Exception as _e:
                print(f"  [bake] purge skipped: {_e}")
            self.report({'WARNING'} if getattr(self, '_tex_warn', False) else {'INFO'},
                        (f"Done: {_fit_parts} piece(s) keep the model's own texture, the round parts "
                         f"got {'a plain colour or LFS leather' if self.curved in ('COLOUR', 'AUTO') else 'one map each'}."
                         if _fit_parts else "Done:")
                        + f"{getattr(self, '_skin_note', '')}{getattr(self, '_tex_note', '')}{getattr(self, '_fit_note', '')} Now Export to LFS."
                        + getattr(self, '_look_note', ''))
            return {'FINISHED'}
        if not bakeable:
            _split_ok = bool(self.split_colour and self._split_colour_materials(context))
            for _mn in ({m.name for m in bpy.data.materials} - _mats_before):
                _mm = bpy.data.materials.get(_mn)
                if _mm is not None:
                    _mm['lfs_auto_made'] = True
            for _mn in ({m.name for m in bpy.data.materials if m.get('lfs_map_rot') is not None} - _maps_before):
                _mm = bpy.data.materials.get(_mn)
                if _mm is not None and _mn in _mats_before:
                    _mm['lfs_auto_map'] = True
            if _split_ok:
                self.report({'INFO'}, "No image textures to bake - the colour materials were "
                                      "direction-split instead (one tiling map per facing direction)."
                            + getattr(self, '_look_note', ''))
                return {'FINISHED'}
            self.report({'ERROR'}, "Nothing to bake: no material has a picture in Base Color "
                                   "(the paint and the glass are left out by default)."
                        + getattr(self, '_tex_note', ''))
            return {'CANCELLED'}

        print(f"  [bake] after the fit: {time.time() - t0:.0f} s")
        clusters = []
        obj_uv = {}
        for o in objs:
            me = o.data
            if not me.uv_layers:
                continue
            src_uv = o.get('lfs_bake_src_uv')
            if not src_uv or src_uv not in me.uv_layers or src_uv == 'LFS_BAKE':
                cands = [l for l in me.uv_layers if l.name != 'LFS_BAKE']
                if not cands:
                    continue
                uv = next((l for l in cands if l.active_render), cands[0])
                src_uv = uv.name
                o['lfs_bake_src_uv'] = src_uv
            obj_uv[o.name] = src_uv
            mw = o.matrix_world
            nmat = mw.to_3x3().inverted().transposed()
            fdir = {}
            _lens7 = {}
            try:
                for _si7, _sl7 in enumerate(o.material_slots):
                    _m7 = _sl7.material
                    if _m7 is None or _m7.name not in bakeable or not bakeable[_m7.name][3]:
                        continue
                    _img7 = bakeable[_m7.name][0]
                    _fs7 = [p_.index for p_ in me.polygons if p_.material_index == _si7]
                    if not _fs7 or _img7 is None:
                        continue
                    _sd7, _mu7 = _lfs_face_detail(me, src_uv, _fs7, _bake_read_image(_img7, max_size=512))
                    for _k7, _f7 in enumerate(_fs7):
                        _c7 = _mu7[_k7]
                        _mx7 = float(max(_c7))
                        if _mx7 > 20.0 and (_mx7 - float(min(_c7))) / _mx7 > 0.35:
                            _lens7[_f7] = True
                    _set7 = set(_fs7)
                    _ek7 = {}
                    for _f7 in _fs7:
                        for _e7 in me.polygons[_f7].edge_keys:
                            _ek7.setdefault(_e7, []).append(_f7)
                    _sc7 = abs(mw.to_3x3().determinant()) ** (2.0 / 3.0)
                    _seen7 = set()
                    for _f7 in _fs7:
                        if _f7 in _seen7:
                            continue
                        _st7 = [_f7]; _seen7.add(_f7); _cp7 = []
                        while _st7:
                            _g7 = _st7.pop(); _cp7.append(_g7)
                            for _e7 in me.polygons[_g7].edge_keys:
                                for _h7 in _ek7.get(_e7, ()):
                                    if _h7 not in _seen7:
                                        _seen7.add(_h7); _st7.append(_h7)
                        if sum(me.polygons[_g7].area for _g7 in _cp7) * _sc7 < 0.15:
                            for _g7 in _cp7:
                                _lens7[_g7] = True
            except Exception as _le7:
                print(f"  [bake] {o.name}: lens colours not checked: {_le7!r}")
                _lens7 = {}
            _fv7 = None
            try:
                _fa7 = me.attributes.get('lfs_fine_bumps')
                if _fa7 is not None and _fa7.domain == 'FACE' and len(_fa7.data) == len(me.polygons):
                    _fv7 = np.zeros(len(me.polygons), dtype=bool)
                    _fa7.data.foreach_get('value', _fv7)
            except Exception:
                _fv7 = None
            _stv = None
            if str(o.get('lfs_subobj_type', '')) == '2' and len(me.vertices) >= 8:
                try:
                    _co9 = np.empty(len(me.vertices) * 3, dtype=np.float64)
                    me.vertices.foreach_get('co', _co9)
                    _co9 = _co9.reshape(-1, 3)
                    _mw9 = np.array(mw, dtype=np.float64)
                    _co9 = _co9 @ _mw9[:3, :3].T + _mw9[:3, 3]
                    _co9 = _co9 - _co9.mean(axis=0)
                    _ev9, _evec9 = np.linalg.eigh(_co9.T @ _co9)
                    if _ev9[0] < 0.5 * _ev9[1]:
                        _a9 = _evec9[:, 0]
                        if _a9[1] * -0.7 + _a9[2] * 0.7 < 0.0:
                            _a9 = -_a9
                        dirs.append(Vector((float(_a9[0]), float(_a9[1]), float(_a9[2]))).normalized())
                        _stv = len(dirs) - 1
                        print(f"  [bake] {o.name}: one picture seen from the driver (axis "
                              f"{tuple(round(float(x), 2) for x in _a9)})")
                except Exception as _sve:
                    print(f"  [bake] {o.name}: steering wheel view skipped: {_sve!r}")
                    _stv = None
            _keys9 = {}
            for p in me.polygons:
                m = o.material_slots[p.material_index].material if p.material_index < len(o.material_slots) else None
                if m is None or m.name not in bakeable:
                    continue
                _keys9[p.index] = (m.name, bool(_fv7[p.index]) if _fv7 is not None else False,
                                   bool(_lens7.get(p.index, False)))
            _view9 = {}
            try:
                _view9 = _lfs_piece_views(me, nmat, mw, _keys9, dirs, _n_dirs0)
            except Exception as _pve:
                import traceback as _tb9
                _tb9.print_exc()
                print(f"  [bake] {o.name}: one view per piece skipped: {_pve!r}")
                _view9 = {}
            for _pi9, (_mn9, _fi9, _le9) in _keys9.items():
                best = _view9.get(_pi9)
                if best is None:
                    n = (nmat @ me.polygons[_pi9].normal).normalized()
                    best = max(range(_n_dirs0), key=lambda i: n.dot(dirs[i]))
                if _stv is not None and not bakeable[_mn9][3]:
                    best = _stv
                fdir[_pi9] = (_mn9, best, _fi9, _le9)
            edge_faces = {}
            for p in me.polygons:
                if p.index not in fdir:
                    continue
                for ek in p.edge_keys:
                    edge_faces.setdefault(ek, []).append(p.index)
            seen = set()
            for pi, key in fdir.items():
                if pi in seen:
                    continue
                comp = []; stack = [pi]; seen.add(pi)
                while stack:
                    f = stack.pop(); comp.append(f)
                    for ek in me.polygons[f].edge_keys:
                        for g in edge_faces.get(ek, ()):
                            if g not in seen and fdir.get(g) == key:
                                seen.add(g); stack.append(g)
                clusters.append({'obj': o, 'mat': key[0], 'dir': key[1], 'faces': comp, 'fine': key[2], 'lens': key[3],
                                 'alpha': bool(bakeable[key[0]][3])})
        _int_hints = _LFS_INT_HINTS
        for c in clusters:
            _on = c['obj'].name.lower()
            _stw_c = str(c['obj'].get('lfs_subobj_type', '')) == '2'
            c['prio'] = (float(self.interior_boost) * (2.0 if _stw_c else 1.0)
                         if (_stw_c or any(h in _on for h in _int_hints)) else 1.0)
            try:
                _bp = bpy.data.materials.get(c['mat'])
                if _bp is not None and _bp.get('lfs_bake_prio') is not None and not _stw_c:
                    c['prio'] *= float(_bp['lfs_bake_prio'])
            except (TypeError, ValueError):
                pass
        if not clusters and (_fit_parts or getattr(self, '_skin_made', False)):
            if self.split_colour:
                self._split_colour_materials(context)
            for _mn in ({m.name for m in bpy.data.materials} - _mats_before):
                _mm = bpy.data.materials.get(_mn)
                if _mm is not None:
                    _mm['lfs_auto_made'] = True
            for _mn in ({m.name for m in bpy.data.materials if m.get('lfs_map_rot') is not None} - _maps_before):
                _mm = bpy.data.materials.get(_mn)
                if _mm is not None and _mn in _mats_before:
                    _mm['lfs_auto_map'] = True
            try:
                bpy.ops.lfs.purge_unused_maps(also_unused_zero_face_mats=True)
            except Exception as _e:
                print(f"  [bake] purge skipped: {_e}")
            self.report({'WARNING'} if getattr(self, '_tex_warn', False) else {'INFO'},
                        (f"Done: {_fit_parts} piece(s) keep the model's own texture, nothing left to paint."
                         if _fit_parts else "Done:")
                        + f"{getattr(self, '_skin_note', '')}{getattr(self, '_tex_note', '')}{getattr(self, '_fit_note', '')} Now Export to LFS."
                        + getattr(self, '_look_note', ''))
            return {'FINISHED'}
        if not clusters:
            self.report({'ERROR'}, "Nothing to bake: the parts have no UV map or no textured faces.")
            return {'CANCELLED'}
        try:
            _stw = None
            for _o5 in scene.objects:
                try:
                    if _o5.type == 'MESH' and int(_o5.get('lfs_subobj_type', -1)) == 2:
                        _stw = _o5
                        break
                except (TypeError, ValueError):
                    pass
            if _stw is not None:
                _swc = sum((_stw.matrix_world @ Vector(cc) for cc in _stw.bound_box), Vector()) / 8.0
                _n_ck = 0
                for c in clusters:
                    if c.get('prio', 1.0) <= 1.0:
                        continue
                    mw = c['obj'].matrix_world; me5 = c['obj'].data
                    _a5 = 0.0
                    _in5 = 0.0
                    for fi in c['faces']:
                        _pf5 = me5.polygons[fi]
                        _dq5 = (mw @ _pf5.center) - _swc
                        _a5 += _pf5.area
                        if _dq5.length < 0.8 and _dq5.y > -0.35 and _dq5.z > -0.45:
                            _in5 += _pf5.area
                    if _a5 > 0.0 and _in5 >= 0.5 * _a5:
                        c['prio'] *= 2.0
                        _n_ck += 1
                if _n_ck:
                    print(f"  [bake] {_n_ck} piece(s) near the driver get twice the pixels")
        except Exception as _pe:
            print(f"  [bake] cockpit pixels skipped: {_pe!r}")
        _n_fine = 0
        for c in clusters:
            if c.get('fine'):
                c['prio'] = c.get('prio', 1.0) * 2.0
                _n_fine += 1
        if _n_fine:
            print(f"  [bake] {_n_fine} piece(s) with small bumps near the driver get twice the pixels again")
        try:
            _small = {}
            _ndet = [0, 0]
            _bary = np.array([(1 / 3, 1 / 3, 1 / 3), (2 / 3, 1 / 6, 1 / 6), (1 / 6, 2 / 3, 1 / 6),
                              (1 / 6, 1 / 6, 2 / 3), (0.5, 0.5, 0.0), (0.0, 0.5, 0.5), (0.5, 0.0, 0.5)])
            for c in clusters:
                if c.get('alpha'):
                    continue
                _bk = bakeable.get(c['mat'])
                if not _bk or _bk[0] is None:
                    continue
                _im = _bk[0]
                if _im.name not in _small:
                    try:
                        _small[_im.name] = _bake_read_image(_im, max_size=256)
                    except Exception:
                        _small[_im.name] = None
                _sa = _small[_im.name]
                o = c['obj']; me = o.data
                _un = obj_uv.get(o.name)
                if _sa is None or not _un or _un not in me.uv_layers:
                    continue
                uvl = me.uv_layers[_un].data
                _uv = []
                for fi in c['faces'][:3000]:
                    lv = list(me.polygons[fi].loop_indices)
                    for k in range(1, len(lv) - 1):
                        _uv.append((tuple(uvl[lv[0]].uv), tuple(uvl[lv[k]].uv), tuple(uvl[lv[k + 1]].uv)))
                if not _uv:
                    continue
                _t = np.array(_uv)
                _pts = np.einsum('bk,nkd->nbd', _bary, _t).reshape(-1, 2) % 1.0
                _H, _W = _sa.shape[0], _sa.shape[1]
                _xi = np.clip((_pts[:, 0] * _W).astype(np.int64), 0, _W - 1)
                _yi = np.clip((_pts[:, 1] * _H).astype(np.int64), 0, _H - 1)
                _sd = float(_sa[_yi, _xi, :3].mean(axis=1).std())
                _f = max(0.35, min(3.0, 0.35 + 16.0 * _sd))
                c['det_f'] = _f
                _ndet[0 if _f < 1.0 else 1] += 1
            _grp9 = {}
            for c in clusters:
                if c.get('det_f') is not None:
                    _grp9.setdefault((c['obj'].name, bool(c.get('alpha'))), []).append(c)
            for _cs9 in _grp9.values():
                _s0 = sum(_lfs_cluster_area(c) * c.get('prio', 1.0) ** 2 for c in _cs9)
                _s1 = sum(_lfs_cluster_area(c) * (c.get('prio', 1.0) * c['det_f']) ** 2 for c in _cs9)
                _k9 = math.sqrt(_s0 / _s1) if _s1 > 0 else 1.0
                for c in _cs9:
                    c['det_f'] *= _k9
                    c['prio'] = c.get('prio', 1.0) * c['det_f']
            if _ndet[0] or _ndet[1]:
                print(f"  [bake] pixels by detail: {_ndet[0]} plain piece(s) fewer, {_ndet[1]} detailed more")
        except Exception as _de:
            print(f"  [bake] pixels by detail skipped: {_de!r}")
        try:
            _stw8 = next((o_ for o_ in scene.objects if o_.type == 'MESH' and 'lfs_subobj_index' in o_.keys()
                          and str(o_.get('lfs_subobj_type', '')) == '2'), None)
            _int8 = [c for c in clusters if not c.get('alpha') and (
                str(c['obj'].get('lfs_subobj_type', '')) == '2'
                or any(h in c['obj'].name.lower() for h in _LFS_INT_HINTS))]
            if _stw8 is not None and _int8:
                from mathutils import Vector as _V8
                _bb8 = [_stw8.matrix_world @ _V8(q) for q in _stw8.bound_box]
                _sc8 = sum(_bb8, _V8((0.0, 0.0, 0.0))) / 8.0
                _eye8 = _sc8 + _V8((0.0, -0.5, 0.26))
                _bvh8 = _lfs_ao_bvh(scene, context.evaluated_depsgraph_get()).get('all')
                _nv8 = [0, 0]
                for c in _int8:
                    o8 = c['obj']; me8 = o8.data; mw8 = o8.matrix_world
                    nm8 = mw8.to_3x3().inverted().transposed()
                    fs8 = sorted(c['faces'], key=lambda f_: -me8.polygons[f_].area)
                    pick8 = fs8[:8] + fs8[8::max(1, (len(fs8) - 8) // 8 or 1)][:8]
                    seen8 = 0.0; tot8 = 0.0; dsum8 = 0.0
                    for f_ in pick8:
                        pl8 = me8.polygons[f_]
                        q8 = mw8 @ pl8.center
                        n8 = (nm8 @ pl8.normal).normalized()
                        w8 = max(pl8.area, 1e-9)
                        tot8 += w8
                        d8 = _eye8 - q8
                        r8 = d8.length
                        dsum8 += w8 * r8
                        if r8 < 1e-4 or n8.dot(d8) <= 0.0:
                            continue
                        q8o = q8 + n8 * 0.003
                        d8 = _eye8 - q8o
                        r8 = d8.length
                        hit8 = _bvh8.ray_cast(q8o, d8 / r8, r8 - 0.01) if _bvh8 is not None else (None,)
                        if hit8[0] is None:
                            seen8 += w8
                    if tot8 <= 0.0:
                        continue
                    vis8 = seen8 / tot8
                    g8 = max(0.4, min(1.8, 0.8 / max(0.05, dsum8 / tot8)))
                    c['vis_f'] = max(0.25, min(1.8, (0.25 + 0.75 * vis8) * g8))
                    _nv8[0 if c['vis_f'] < 1.0 else 1] += 1
                _vco8 = {}

                def _cap8(c_):
                    o_ = c_['obj']
                    if o_.name not in _vco8:
                        _a8 = np.empty(len(o_.data.vertices) * 3, np.float64)
                        o_.data.vertices.foreach_get('co', _a8)
                        _m8 = np.array(o_.matrix_world, dtype=np.float64)
                        _vco8[o_.name] = _a8.reshape(-1, 3) @ _m8[:3, :3].T + _m8[:3, 3]
                    _vv8 = [v_ for f_ in c_['faces'][:4000] for v_ in o_.data.polygons[f_].vertices]
                    if not _vv8:
                        return 3.5
                    _p8 = _vco8[o_.name][np.array(_vv8, dtype=np.int64)]
                    L_ = float((_p8.max(axis=0) - _p8.min(axis=0)).max())
                    return 1.5 if L_ > 0.5 else (2.5 if L_ > 0.25 else 3.5)
                _grp8 = {}
                for c in _int8:
                    if c.get('vis_f') is not None:
                        _grp8.setdefault((c['obj'].name, bool(c.get('alpha'))), []).append(c)
                for _cs8 in _grp8.values():
                    _s0 = sum(_lfs_cluster_area(c) * c.get('prio', 1.0) ** 2 for c in _cs8)
                    _s1 = sum(_lfs_cluster_area(c) * (c.get('prio', 1.0) * c['vis_f']) ** 2 for c in _cs8)
                    _k8 = math.sqrt(_s0 / _s1) if _s1 > 0 else 1.0
                    for c in _cs8:
                        _d8 = max(1e-6, float(c.get('det_f', 1.0)))
                        _p08 = c.get('prio', 1.0) / _d8
                        _f8 = max(0.2, min(_cap8(c), _d8 * c['vis_f'] * _k8))
                        c['vis_f'] = _f8 / _d8
                        c['prio'] = _p08 * _f8
                        c['det_f'] = _f8
                print(f"  [bake] pixels by the driver's view: {_nv8[1]} piece(s) he sees well more, "
                      f"{_nv8[0]} hidden or far fewer (eye at {tuple(round(v_, 2) for v_ in _eye8)})")
        except Exception as _ve8:
            import traceback as _tb8
            _tb8.print_exc()
            print(f"  [bake] pixels by the driver's view skipped: {_ve8!r}")
        for c in clusters:
            if c.get('alpha') and c.get('lens'):
                c['prio'] = c.get('prio', 1.0) * 2.0
        try:
            _n_back = 0
            _ax_of = {}
            for c in clusters:
                _o8 = c['obj']
                if str(_o8.get('lfs_subobj_type', '')) != '2' or c.get('alpha'):
                    continue
                if _o8.name not in _ax_of:
                    _ax8 = None
                    _me8 = _o8.data
                    if len(_me8.vertices) >= 8:
                        _co8 = np.empty(len(_me8.vertices) * 3, dtype=np.float64)
                        _me8.vertices.foreach_get('co', _co8)
                        _co8 = _co8.reshape(-1, 3)
                        _mw8 = np.array(_o8.matrix_world, dtype=np.float64)
                        _co8 = _co8 @ _mw8[:3, :3].T + _mw8[:3, 3]
                        _co8 = _co8 - _co8.mean(axis=0)
                        _ev8, _evec8 = np.linalg.eigh(_co8.T @ _co8)
                        if _ev8[0] < 0.5 * _ev8[1]:
                            _a8 = _evec8[:, 0]
                            if _a8[1] * -0.7 + _a8[2] * 0.7 < 0.0:
                                _a8 = -_a8
                            _ax8 = Vector((float(_a8[0]), float(_a8[1]), float(_a8[2]))).normalized()
                    _ax_of[_o8.name] = _ax8
                _ax8 = _ax_of[_o8.name]
                if _ax8 is None:
                    continue
                _nm8 = _o8.matrix_world.to_3x3().inverted_safe().transposed()
                _ns8 = Vector()
                for fi in c['faces']:
                    _pf8 = _o8.data.polygons[fi]
                    _ns8 += (_nm8 @ _pf8.normal).normalized() * _pf8.area
                if _ns8.length > 0.0 and _ns8.normalized().dot(_ax8) < -0.3:
                    c['prio'] = c.get('prio', 1.0) * 0.25
                    c['st_back'] = True
                    _n_back += 1
            if _n_back:
                print(f"  [bake] the back of the steering wheel ({_n_back} piece(s)) gets a quarter of the pixels")
        except Exception as _sbe:
            print(f"  [bake] steering wheel back not checked: {_sbe!r}")
        for _o6 in objs:
            try:
                if _o6.type == 'MESH' and _o6.data.attributes.get('lfs_fine_bumps') is not None:
                    _o6.data.attributes.remove(_o6.data.attributes['lfs_fine_bumps'])
            except Exception:
                pass
        _by_obj = {}
        for c in clusters:
            _by_obj.setdefault(c['obj'].name, []).append(c)
        _caps = {}
        for _on, _cl in _by_obj.items():
            _o9 = bpy.data.objects.get(_on)
            _used9 = set()
            try:
                _mi9 = np.empty(len(_o9.data.polygons), dtype=np.int32)
                _o9.data.polygons.foreach_get('material_index', _mi9)
                for _s9 in np.unique(_mi9).tolist():
                    _m9 = _o9.material_slots[_s9].material if 0 <= _s9 < len(_o9.material_slots) else None
                    if _m9 is not None and _m9.get('lfs_cidx') is not None and not bakeable.get(_m9.name):
                        _used9.add(int(_m9['lfs_cidx']))
            except Exception:
                pass
            _rsv9 = 0
            if (getattr(self, 'split_colour', False) and _o9 is not None
                    and str(_o9.get('lfs_subobj_type', 3)) != '0'):
                try:
                    _pa9 = np.empty(len(_o9.data.polygons), dtype=np.float64)
                    _o9.data.polygons.foreach_get('area', _pa9)
                    _sa9 = np.bincount(np.clip(_mi9, 0, max(0, len(_o9.material_slots) - 1)), weights=_pa9,
                                       minlength=len(_o9.material_slots))
                    _tc9 = set()
                    for _s9 in np.unique(_mi9).tolist():
                        _m9 = _o9.material_slots[_s9].material if 0 <= _s9 < len(_o9.material_slots) else None
                        if (_m9 is None or bakeable.get(_m9.name) or _m9.get('lfs_cidx') is None
                                or _m9.get('lfs_map_rot') is not None or int(_m9['lfs_cidx']) == 1
                                or _m9.get('lfs_paint') or _m9.get('lfs_glass') or _m9.get('lfs_fit_base')
                                or float(_sa9[_s9]) < 0.05):
                            continue
                        _ml9 = _m9.name.lower()
                        if (_ml9 in _PAINT_SKIN_MATERIALS or _ml9 in _GLASS_MATERIALS
                                or any(g_ in _ml9 for g_ in ('glass', 'window', 'windscreen', 'windshield'))):
                            continue
                        _tp9 = _m9.get('lfs_tex_page')
                        if _tp9 is not None and str(_tp9) == '':
                            continue
                        if _lfs_shows_texture(_m9):
                            _tc9.add(int(_m9['lfs_cidx']))
                    _rsv9 = min(40, 5 * len(_tc9))
                except Exception as _re9:
                    print(f"  [bake] {_on}: room for the direction split not counted: {_re9!r}")
                    _rsv9 = 0
            _caps[_on] = max(1, min(int(self.max_cutouts), max(8, _MAP_TABLE_MAX - 6 - len(_used9) - _rsv9)))
            if _rsv9:
                print(f"  [bake] {_on}: {_rsv9} map(s) kept for the direction split of {_rsv9 // 5} tiled "
                      f"material(s)")
        _n0 = len(clusters)
        _new9 = []
        _over = 0
        for _on, _cl in _by_obj.items():
            _cp = _caps[_on]
            if len(_cl) > _cp:
                _cl = _lfs_merge_min_waste(_cl, _cp, dirs)
                if len(_cl) > _cp:
                    _cl = _lfs_merge_min_waste(_cl, _cp, dirs, coarse=True)
            _over = max(_over, len(_cl) - _cp)
            _new9.append((_on, _cl, _cp))
        clusters = [c for _on, _cl, _cp in _new9 for c in _cl]
        _cap_cl = len(clusters) - _over
        print(f"  [bake] {_n0} piece(s) -> {len(clusters)} after merging (room per part: "
              + ", ".join(f"{_on} {len(_cl)}/{_cp}" for _on, _cl, _cp in _new9) + ")")
        if (_over > 0 and self.mode == 'FIT' and not getattr(self, 'keep_layout', False)
                and int(getattr(self, '_fit_retry', 0) or 0) < 2):
            _short = _over
            self._fit_retry = int(getattr(self, '_fit_retry', 0) or 0) + 1
            if self._fit_retry == 1 and int(_fit_parts) > 2 * _short + 16:
                self._fit_budget = max(0, int(_fit_parts) - 2 * _short - 8)
                self._fit_note = (f" The model's own texture stays on {self._fit_budget} flat piece(s) - more "
                                  f"would take the map numbers the painted pieces need (LFS's map list).")
                print(f"  [bake] {len(clusters)} painted pieces, room for {_cap_cl}: the fit again with "
                      f"{self._fit_budget} map(s) instead of {_fit_parts}")
            else:
                self.mode = 'BAKE'
                self._fit_note = (" Everything was painted into new pages (Method: Paint new texture pages) - "
                                  "with the model's own textures the car has more pieces than LFS's map list holds.")
                print(f"  [bake] {len(clusters)} painted pieces, room for {_cap_cl}: painting everything instead")
            self._again = True
            return {'CANCELLED'}
        if _over > 0:
            clusters = []
            for _on, _cl, _cp in _new9:
                _cl.sort(key=lambda c: -len(c['faces']))
                clusters += _cl[:_cp]
        _pp9 = {}
        for c in clusters:
            _pp9.setdefault(c['obj'].name, []).append(c)
        if any(len(_cl) > int(self.max_cutouts) for _cl in _pp9.values()):
            _out9 = []
            for _on, _cl in _pp9.items():
                if len(_cl) > int(self.max_cutouts):
                    merged = {}
                    for c in _cl:
                        k = (c['obj'].name, c['mat'], c['dir'])
                        if k in merged:
                            merged[k]['faces'].extend(c['faces'])
                        else:
                            merged[k] = c
                    _cl = list(merged.values())
                    if len(_cl) > int(self.max_cutouts):
                        _cl.sort(key=lambda c: -len(c['faces']))
                        _cl = _cl[:int(self.max_cutouts)]
                _out9 += _cl
            clusters = _out9

        _alpha_cache = {}

        def _alpha_map(mn):
            if mn not in _alpha_cache:
                _bc, _ai, _ac, _isa, _ach = bakeable[mn]
                try:
                    if _ai is not None:
                        _alpha_cache[mn] = _lfs_alpha_mask(_ai, _ach, 1024)
                    else:
                        _alpha_cache[mn] = _bake_read_image(_bc, max_size=1024)[:, :, 3]
                except Exception:
                    _alpha_cache[mn] = None
            return _alpha_cache[mn]

        _n_opaqued = 0
        for c in clusters:
            if not c['alpha']:
                continue
            _mn = c['mat']
            if _mn.lower() in _ag or _mn.lower() in _GLASS_MATERIALS:
                continue
            _bc, _ai, _ac, _isa, _ach = bakeable[_mn]
            if _ai is None and _ac < 0.999:
                continue
            A = _alpha_map(_mn)
            if A is None:
                continue
            o = c['obj']; me = o.data
            uvl = me.uv_layers[obj_uv[o.name]].data
            H, W = A.shape[0], A.shape[1]
            _n = 0; _t = 0
            for fi in c['faces']:
                poly = me.polygons[fi]
                li = list(poly.loop_indices)
                u = sum(uvl[l].uv[0] for l in li) / len(li)
                v = sum(uvl[l].uv[1] for l in li) / len(li)
                x = int((u % 1.0) * W) % W; y = int((v % 1.0) * H) % H
                _n += 1
                if A[y, x] < 0.9:
                    _t += 1
            if _n and _t / _n < 0.02:
                c['alpha'] = False
                _n_opaqued += 1
        if _n_opaqued:
            print(f"  [bake] {_n_opaqued}/{len(clusters)} cluster(s) are opaque after all "
                  f"(their faces sample no transparent texel)")

        print(f"  [bake] pieces merged: {time.time() - t0:.0f} s")
        for c in clusters:
            o = c['obj']; me = o.data; mw = o.matrix_world
            d = dirs[c['dir']]
            h, p = _uvp_hp_from_normal((d.x, d.y, d.z))
            U, V, N = (Vector(x) for x in _uvp_frame(h, p, 0.0))
            pts = []
            for fi in c['faces']:
                for vi in me.polygons[fi].vertices:
                    pts.append(mw @ me.vertices[vi].co)
            us = [pt.dot(U) for pt in pts]; vs = [pt.dot(V) for pt in pts]; ns = [pt.dot(N) for pt in pts]
            c.update({'h': h, 'p': p, 'U': U, 'V': V, 'N': N,
                      'umin': min(us), 'umax': max(us), 'vmin': min(vs), 'vmax': max(vs),
                      'ncen': 0.5 * (min(ns) + max(ns))})
            c['w'] = max(c['umax'] - c['umin'], 1e-4); c['hgt'] = max(c['vmax'] - c['vmin'], 1e-4)
        for c in clusters:
            try:
                _o8 = c['obj']; _me8 = _o8.data; _mw8 = _o8.matrix_world
                _U8, _V8 = c['U'], c['V']
                _tr8 = []
                for _fi8 in c['faces']:
                    _q8 = [_mw8 @ _me8.vertices[_vi8].co for _vi8 in _me8.polygons[_fi8].vertices]
                    _p8 = [(_qq8.dot(_U8) - c['umin'], _qq8.dot(_V8) - c['vmin']) for _qq8 in _q8]
                    for _k8 in range(1, len(_p8) - 1):
                        _tr8.append((_p8[0], _p8[_k8], _p8[_k8 + 1]))
                c['_tri2'] = np.array(_tr8, dtype=np.float64).reshape(-1, 3, 2)
            except Exception:
                c['_tri2'] = None

        def _pack(S, idxs, max_pages):
            rects = []
            for i in idxs:
                c = clusters[i]
                _pr = c.get('prio', 1.0)
                wu = max(1, int(math.ceil(c['w'] * _pr / S)) + 1)
                hu = max(1, int(math.ceil(c['hgt'] * _pr / S)) + 1)
                rects.append((hu, wu, i))
            rects.sort(reverse=True)
            pages = []
            place = {}
            for hu, wu, i in rects:
                if wu > 128 or hu > 128:
                    return None
                done = False
                for pg, shelves in enumerate(pages):
                    for sh in shelves:
                        if sh[1] >= hu and sh[2] + wu <= 128:
                            place[i] = (pg, sh[2], sh[0], wu, hu); sh[2] += wu; done = True; break
                    if done:
                        break
                    ytop = shelves[-1][0] + shelves[-1][1] if shelves else 0
                    if ytop + hu <= 128:
                        shelves.append([ytop, hu, wu]); place[i] = (pg, 0, ytop, wu, hu); done = True; break
                if not done:
                    if len(pages) >= max_pages:
                        return None
                    pages.append([[0, hu, wu]]); place[i] = (len(pages) - 1, 0, 0, wu, hu)
            return place, len(pages)
        opaque_idx = [i for i, c in enumerate(clusters) if not c['alpha']]
        alpha_idx = [i for i, c in enumerate(clusters) if c['alpha']]
        _n_alpha_pages = 1 if alpha_idx else 0
        _n_opaque_pages = max(1, _total_pages - _n_alpha_pages) if opaque_idx else 0

        def _pack_shape(S, idxs, max_pages, fail=None):
            items = []
            for i in idxs:
                m_ = _lfs_piece_mask(clusters[i], S)
                if m_ is None:
                    if fail is not None:
                        fail.append(i)
                    return None
                items.append((i, m_))
            return _lfs_shape_pack(items, max_pages, fail=fail)

        def _fit_scale(idxs, npg):
            if not idxs:
                return 1.0, ({}, 0)
            area = sum(clusters[i]['w'] * clusters[i]['hgt'] * clusters[i].get('prio', 1.0) ** 2 for i in idxs)
            S_ = max(1e-4, math.sqrt(area / (128.0 * 128.0 * max(1, npg))) * 0.9)
            S_hi = r_hi = None
            for _ in range(80):
                r_ = _pack(S_, idxs, npg)
                if r_ is not None:
                    S_hi, r_hi = S_, r_
                    break
                S_ *= 1.06
            if S_hi is None:
                return S_, None
            try:
                r_ = _pack_shape(S_hi, idxs, npg)
                if r_ is None:
                    return S_hi, r_hi
                best = (S_hi, r_)
                lo = None
                for _ in range(12):
                    S_t = best[0] * 0.94
                    r_ = _pack_shape(S_t, idxs, npg)
                    if r_ is None:
                        lo = S_t
                        break
                    best = (S_t, r_)
                if lo is not None:
                    for _ in range(3):
                        S_t = math.sqrt(best[0] * lo)
                        r_ = _pack_shape(S_t, idxs, npg)
                        if r_ is None:
                            lo = S_t
                        else:
                            best = (S_t, r_)
                return best
            except Exception as _spe:
                print(f"  [bake] packing by shape skipped: {_spe!r}")
                return S_hi, r_hi
        def _pack_per_part(budget_px):
            groups = {}
            for i_, c_ in enumerate(clusters):
                groups.setdefault((c_['obj'].name, bool(c_['alpha'])), []).append(i_)
            keys = sorted(groups, key=lambda k_: (k_[1], k_[0]))
            sizes = [s_ for s_ in (128, 256, 512, 1024, 2048, 4096) if s_ <= page_px] or [page_px]
            one_page = set()
            for k_ in keys:
                try:
                    if int(clusters[groups[k_][0]]['obj'].get('lfs_subobj_type', 3)) == 2:
                        one_page.add(k_)
                except (TypeError, ValueError):
                    pass
            area = sum(c_['w'] * c_['hgt'] * c_.get('prio', 1.0) ** 2 for c_ in clusters)
            T = math.sqrt(max(1.0, float(budget_px)) * 0.85 / max(area, 1e-9))

            def _fit_group(k_, T_):
                idxs = groups[k_]
                for P_ in ([s9 for s9 in sizes if s9 >= min(512, sizes[-1])] if k_ in one_page else sizes):
                    r_ = _pack((P_ / 128.0) / T_, idxs, 1)
                    if r_ is not None:
                        return P_, r_, T_
                if k_ not in one_page:
                    for n_ in range(2, 9):
                        r_ = _pack((sizes[-1] / 128.0) / T_, idxs, n_)
                        if r_ is not None:
                            return sizes[-1], r_, T_
                    return None
                Tg_ = T_
                for _s in range(200):
                    Tg_ *= 0.95
                    r_ = _pack((sizes[-1] / 128.0) / Tg_, idxs, 1)
                    if r_ is not None:
                        return sizes[-1], r_, Tg_
                return None

            plan = None
            for _it in range(160):
                pl_ = []; total = 0; ok_ = True; smallest = True
                for k_ in keys:
                    got = _fit_group(k_, T)
                    if got is None:
                        ok_ = False; break
                    pl_.append((k_, got[0], got[1], got[2]))
                    total += got[0] * got[0] * got[1][1]
                    smallest = smallest and got[0] == sizes[0] and got[1][1] == 1
                if ok_ and (total <= budget_px or smallest):
                    plan = pl_
                    break
                T *= 0.95
            if plan is None:
                return None
            plan = [list(e_) for e_ in plan]
            def _val(e_):
                v_ = sum(clusters[i_]['w'] * clusters[i_]['hgt'] * clusters[i_].get('prio', 1.0)
                         for i_ in groups[e_[0]])
                return v_ * (0.5 if e_[0][1] else 1.0)
            _used = sum(e_[1] * e_[1] * e_[2][1] for e_ in plan)
            def _up_cost(e_):
                P_, n_ = e_[1], e_[2][1]
                if n_ == 1 and P_ < sizes[-1]:
                    return 3 * P_ * P_
                if P_ == sizes[-1] and e_[0] not in one_page and n_ < 4:
                    return P_ * P_
                return None
            def _up(e_):
                if e_[2][1] == 1 and e_[1] < sizes[-1]:
                    e_[1] *= 2
                else:
                    e_[2] = (e_[2][0], e_[2][1] + 1)
            _order = sorted(plan, key=lambda e_: (bool(e_[0][1]), -_val(e_)))
            for _pass in range(6):
                _grew = False
                for _r, e_ in enumerate(_order):
                    _c = _up_cost(e_)
                    if _c is None:
                        continue
                    if _used + _c > budget_px:
                        if _pass > 0:
                            continue
                        _give = [f_ for f_ in reversed(_order[_r + 1:])
                                 if f_[2][1] == 1 and f_[1] > 256 and f_[0] not in one_page]
                        _give.sort(key=lambda f_: (not f_[0][1], _val(f_)))
                        _freed = 0; _took = []
                        for f_ in _give:
                            if _used - _freed + _c <= budget_px:
                                break
                            _freed += f_[1] * f_[1] * 3 // 4; _took.append(f_)
                        if _used - _freed + _c > budget_px:
                            continue
                        for f_ in _took:
                            f_[1] //= 2
                        _used -= _freed
                    _up(e_); _used += _c; _grew = True
                    break
                if not _grew:
                    break
            place_ = {}; alpha_ = []; px_ = []; part_ = []
            for (pname, is_a), P_, (pl, n_), Tg in plan:
                idxs = groups[(pname, is_a)]
                _best = None
                _t = Tg
                for _g in range(40):
                    _r = _pack_shape((P_ / 128.0) / _t, idxs, n_)
                    if _r is None:
                        break
                    _best = (_t, _r[0])
                    _t *= 1.06
                if _best is not None:
                    _lo, _hi = _best[0], _t
                    for _b in range(4):
                        _m = 0.5 * (_lo + _hi)
                        _r = _pack_shape((P_ / 128.0) / _m, idxs, n_)
                        if _r is None:
                            _hi = _m
                        else:
                            _lo = _m; _best = (_m, _r[0])
                    Tg, pl = _best
                print(f"  [bake] {pname}{' (see-through)' if is_a else ''}: {n_} page(s) of {P_} px, "
                      f"{Tg:.0f} px/m before the boosts")
                for _g in range(60):
                    r_ = _pack((P_ / 128.0) / (Tg * 1.03), idxs, n_)
                    if r_ is None:
                        break
                    Tg *= 1.03
                    pl = r_[0]
                try:
                    import time as _tm9
                    _Sg = (P_ / 128.0) / Tg
                    _base = {i_: clusters[i_].get('prio', 1.0) for i_ in idxs}
                    _gr = {i_: 1.0 for i_ in idxs}
                    _pos = {i_: pl[i_] for i_ in idxs if i_ in pl}
                    _mk = {i_: _lfs_piece_mask(clusters[i_], _Sg) for i_ in _pos}
                    if _pos and all(v_ is not None and tuple(v_.shape) == (_pos[i_][4], _pos[i_][3])
                                    for i_, v_ in _mk.items()):
                        _npg = max(pg_ for pg_, _x, _y, _w, _h in _pos.values()) + 1
                        _cnt = [np.zeros((128, 128), np.int32) for _ in range(_npg)]
                        for i_, (pg_, x_, y_, wu_, hu_) in _pos.items():
                            _cnt[pg_][y_:y_ + hu_, x_:x_ + wu_] += _mk[i_]
                        _order = sorted(_pos, key=lambda i_: -(clusters[i_].get('det_f', 1.0) * _base[i_]))
                        _t9 = _tm9.time() + 8.0
                        _grew = True
                        while _grew and _tm9.time() < _t9:
                            _grew = False
                            for i_ in _order:
                                if _tm9.time() > _t9:
                                    break
                                pg_, x_, y_, wu_, hu_ = _pos[i_]
                                clusters[i_]['prio'] = _base[i_] * _gr[i_] * 1.1
                                _m2 = _lfs_piece_mask(clusters[i_], _Sg)
                                if _m2 is None:
                                    clusters[i_]['prio'] = _base[i_] * _gr[i_]
                                    continue
                                _cnt[pg_][y_:y_ + hu_, x_:x_ + wu_] -= _mk[i_]
                                _fr = _lfs_free_spots(_lfs_dilate1(_cnt[pg_] > 0), _m2)
                                _sp = None
                                if _fr is not None:
                                    _ys, _xs = np.nonzero(_fr)
                                    if len(_ys):
                                        h2_, w2_ = _m2.shape
                                        _cy = y_ + 0.5 * (hu_ - h2_); _cx = x_ + 0.5 * (wu_ - w2_)
                                        _k = int(np.argmin((_ys - _cy) ** 2 + (_xs - _cx) ** 2))
                                        _sp = (int(_xs[_k]), int(_ys[_k]))
                                if _sp is None:
                                    _cnt[pg_][y_:y_ + hu_, x_:x_ + wu_] += _mk[i_]
                                    clusters[i_]['prio'] = _base[i_] * _gr[i_]
                                    continue
                                h2_, w2_ = _m2.shape
                                _cnt[pg_][_sp[1]:_sp[1] + h2_, _sp[0]:_sp[0] + w2_] += _m2
                                _mk[i_] = _m2
                                _gr[i_] *= 1.1
                                _pos[i_] = (pg_, _sp[0], _sp[1], w2_, h2_)
                                _grew = True
                        for i_ in _pos:
                            pl[i_] = _pos[i_]
                    for i_ in idxs:
                        clusters[i_]['prio'] = _base[i_] * _gr[i_]
                    _n9 = sum(1 for v_ in _gr.values() if v_ > 1.0)
                    if _n9:
                        _fill9 = sum(int(np.count_nonzero(c9)) for c9 in _cnt) / float(128 * 128 * len(_cnt))
                        print(f"  [bake] {pname}{' (see-through)' if is_a else ''}: page filled - {_n9} of "
                              f"{len(idxs)} piece(s) grew, up to {max(_gr.values()):.1f} x, "
                              f"{_fill9 * 100:.0f} % of the page painted")
                except Exception as _ge:
                    import traceback as _tb9
                    _tb9.print_exc()
                    print(f"  [bake] {pname}: page fill skipped: {_ge!r}")
                base_ = len(alpha_)
                for i_, (pg_, x0_, y0_, wu_, hu_) in pl.items():
                    place_[i_] = (base_ + pg_, x0_, y0_, wu_, hu_)
                    clusters[i_]['S'] = (P_ / 128.0) / Tg
                alpha_ += [is_a] * n_; px_ += [P_] * n_; part_ += [pname] * n_
            return place_, alpha_, px_, part_, T

        _pp_part = []
        _st_page = None; n_st = 0
        if self.pages_per_part and clusters:
            _r5 = _pack_per_part(max(0, 5_000_000 - int(self._fit_px) - int(bpy.context.scene.get('lfs_photo_px', 0))))
            if _r5 is None:
                self.report({'ERROR'}, "The pieces do not fit on texture pages of their own part: raise "
                                       "Texture size or switch A texture page for each part off (More "
                                       "options: fewer Directions).")
                return {'CANCELLED'}
            place, page_is_alpha, page_px_of, _pp_part, _T5 = _r5
            npages = len(page_is_alpha)
            S = (page_px / 128.0) / _T5
            print(f"  [bake] one page per part: {npages} page(s), {sum(q * q for q in page_px_of) / 1e6:.2f} MP, "
                  f"{_T5:.0f} px/m or more")
        else:
            _bud = max(0, 5_000_000 - int(self._fit_px) - int(bpy.context.scene.get('lfs_photo_px', 0)))
            _n_op = _n_opaque_pages
            if opaque_idx:
                if alpha_idx:
                    _n_op = max(_n_op, min(int(self.max_pages) - 1, (_bud - 128 * 128) // (page_px * page_px)))
                else:
                    _n_op = max(_n_op, min(int(self.max_pages), _bud // (page_px * page_px)))
            _st_idx = []; _P_st = 0; S_st = None; r_st = None
            if getattr(self, 'steer_own_page', True) and opaque_idx:
                _st_nm = {o_.name for o_ in objs if o_.type == 'MESH' and str(o_.get('lfs_subobj_type', '')) == '2'}
                _st_idx = [i for i in opaque_idx if clusters[i]['obj'].name in _st_nm]
                if len(_st_idx) == len(opaque_idx):
                    _st_idx = []
            if _st_idx:
                _n_op2 = _n_op
                _pages_left = int(self.max_pages) - (1 if alpha_idx else 0)
                if _n_op2 + 1 > _pages_left:
                    _n_op2 = _pages_left - 1
                _P_st = 0
                while _n_op2 >= 1 and not _P_st:
                    _left = _bud - _n_op2 * page_px * page_px - (128 * 128 if alpha_idx else 0)
                    for _P in (page_px, page_px // 2, page_px // 4):
                        if _P >= 256 and _P * _P <= _left:
                            _P_st = _P
                            break
                    if not _P_st:
                        _n_op2 -= 1
                if _P_st and _n_op2 >= 1:
                    S_st, r_st = _fit_scale(_st_idx, 1)
                if r_st is not None:
                    _st_set = set(_st_idx)
                    opaque_idx = [i for i in opaque_idx if i not in _st_set]
                    _n_op = _n_op2
                    print(f"  [bake] the steering wheel on a page of its own: {_P_st} px, "
                          f"{(_P_st / 128.0) / S_st:.0f} px/m")
                else:
                    _st_idx = []; _P_st = 0
            S_op, r_op = _fit_scale(opaque_idx, _n_op)
            _al_px = page_px
            if alpha_idx and opaque_idx and r_op is not None:
                _room = _bud - r_op[1] * page_px * page_px - _P_st * _P_st
                _cap = page_px
                while _cap > 128 and _cap * _cap > _room:
                    _cap //= 2
                S_min, r_min = _fit_scale(alpha_idx, 1)
                _T_op = (page_px / 128.0) / S_op
                _al_px = None
                if r_min is not None:
                    for _P in (128, 256, 512, 1024, 2048, 4096):
                        if _P > _cap:
                            break
                        if (_P / 128.0) / _T_op >= S_min:
                            _al_px = _P
                            break
                if _al_px is None:
                    _al_px = _cap
                    S_al, r_al = S_min, r_min
                else:
                    S_al = (_al_px / 128.0) / _T_op
                    r_al = _pack_shape(S_al, alpha_idx, 1) or _pack(S_al, alpha_idx, 1)
                    if r_al is None:
                        S_al, r_al = S_min, r_min
            else:
                S_al, r_al = _fit_scale(alpha_idx, _n_alpha_pages)
            result = (r_op, r_al) if (r_op is not None and r_al is not None) else None
            for i in opaque_idx:
                clusters[i]['S'] = S_op
            for i in alpha_idx:
                clusters[i]['S'] = S_al
            for i in _st_idx:
                clusters[i]['S'] = S_st
            S = S_op if opaque_idx else S_al
            if result is None:
                self.report({'ERROR'}, "The pieces do not fit on the texture pages: raise Max texture pages "
                                       "(More options: fewer Directions).")
                return {'CANCELLED'}
            (place, n_op), (place_a, n_al) = result
            place = dict(place)
            n_st = 0
            if _st_idx:
                for i, (pg, x0, y0, wu, hu) in r_st[0].items():
                    place[i] = (n_op, x0, y0, wu, hu)
                n_st = 1
                _st_page = n_op
            for i, (pg, x0, y0, wu, hu) in place_a.items():
                place[i] = (pg + n_op + n_st, x0, y0, wu, hu)
            npages = n_op + n_st + n_al
            page_is_alpha = [False] * (n_op + n_st) + [True] * n_al
            page_px_of = [page_px] * n_op + [_P_st] * n_st + [_al_px] * n_al
            print(f"  [bake] atlas: {n_op} opaque page(s) of {page_px} px"
                  + (f" + the steering wheel's page of {_P_st} px" if n_st else "")
                  + (f" + a see-through page of {_al_px} px" if n_al else "")
                  + f", {sum(q_ * q_ for q_ in page_px_of) / 1e6:.2f} MP (+ {self._fit_px / 1e6:.2f} MP fitted), "
                  + (f"{(page_px / 128.0) / S_op:.0f} px/m before the boosts" if opaque_idx else ""))
        texels_per_m = upx / S

        stem0 = (self.page_prefix.strip() or os.path.splitext(os.path.basename(bpy.data.filepath or 'lfsbake'))[0])
        stem0 = ''.join(ch for ch in stem0 if ch.isalnum() or ch in '_-')[:11] or 'lfsbake'
        if not self.page_prefix.strip():
            stem0 = _bake_own_prefix(scene, stem0, png_dir, _own_pages)
        page_stems = [(f"{stem0}_bk{k}" + ('_ALP' if page_is_alpha[k] else '')) for k in range(npages)]
        if not _pp_part and _st_page is not None and n_st:
            _k9 = _st_page
            _room9 = 19 - len(f"{stem0}_bk{_k9}")
            _code9 = next((a_ for a_ in ('steer', 'str', 's') if len(a_) <= _room9), '')
            page_stems[_k9] = f"{stem0}_bk{_k9}" + _code9
        if _pp_part:
            _abbr = {'body': ('body', 'bdy', 'b'), 'wheels': ('wheels', 'wheel', 'whl', 'w'),
                     'interior': ('interior', 'inter', 'int', 'i'), 'steering': ('steering', 'steer', 'str', 's')}
            for k in range(npages):
                _sfx = '_ALP' if page_is_alpha[k] else ''
                _nm = ''.join(ch for ch in _pp_part[k].lower() if ch.isalnum())
                _room = 19 - len(f"{stem0}_bk{k}") - len(_sfx)
                _code = next((a_ for a_ in _abbr.get(_nm, (_nm[:6],)) if len(a_) <= _room), _nm[:max(0, _room)])
                page_stems[k] = f"{stem0}_bk{k}" + _code + _sfx
        pages_rgba = [np.zeros((page_px_of[_k], page_px_of[_k], 4), dtype=np.float32) for _k in range(npages)]
        pages_depth = [np.full((page_px_of[_k], page_px_of[_k]), -1e30, dtype=np.float32) for _k in range(npages)]
        pages_written = [np.zeros((page_px_of[_k], page_px_of[_k]), dtype=np.float32) for _k in range(npages)]
        src_cache = {}

        print(f"  [bake] pieces packed: {time.time() - t0:.0f} s")
        n_tris = 0
        _lfs_progress(i=40)
        for ci, c in enumerate(clusters):
            _lfs_progress(i=40 + (50 * ci) // max(1, len(clusters)))
            o = c['obj']; me = o.data; mw = o.matrix_world
            pg, x0, y0, wu, hu = place[ci]
            _Sc = c.get('S', S) / c.get('prio', 1.0)
            W = wu * _Sc; Hh = hu * _Sc
            ucen = 0.5 * (c['umin'] + c['umax']); vcen = 0.5 * (c['vmin'] + c['vmax'])
            U, V, N = c['U'], c['V'], c['N']
            pos = U * ucen + V * vcen + N * c['ncen']
            c.update({'pos': pos, 'W': W, 'H': Hh, 'rect': (wu, hu, x0, y0), 'page': pg})
            if c['mat'] not in src_cache:
                _bc, _ai, _ac, _isa, _ach = bakeable[c['mat']]
                _m8 = bpy.data.materials.get(c['mat'])
                try:
                    _rf8 = _lfs_relief_field(_m8)
                except Exception as _re8:
                    print(f"  [bake] {c['mat']}: bumps by the sky skipped: {_re8!r}")
                    _rf8 = None
                _src8 = _bake_read_image(_bc, max_size=max(2048, page_px))
                src_cache[c['mat']] = (_lfs_nshade(_m8, _src8, hi_lines=_rf8 is None),
                                       _lfs_alpha_rgba(_ai, _ach, max(2048, page_px)) if _ai is not None else None,
                                       _ac, _ach, _rf8)
            src, src_a, a_const, a_chan, _rf8 = src_cache[c['mat']]
            _nm8 = mw.to_3x3().inverted().transposed()
            uvl = me.uv_layers[obj_uv[o.name]].data
            rgba = pages_rgba[pg]; depth = pages_depth[pg]; written = pages_written[pg]
            _ppx = page_px_of[pg]; _upx = _ppx // 128
            tx0 = x0 * _upx; ty0 = y0 * _upx; wt = wu * _upx; ht = hu * _upx
            for fi in c['faces']:
                poly = me.polygons[fi]
                lv = list(poly.loop_indices); vv = list(poly.vertices)
                for k in range(1, len(vv) - 1):
                    tri = (0, k, k + 1)
                    P = [mw @ me.vertices[vv[t]].co for t in tri]
                    suv = [uvl[lv[t]].uv for t in tri]
                    ax = np.array([tx0 + ((q - pos).dot(U) / W + 0.5) * wt for q in P])
                    ay = np.array([ty0 + ((q - pos).dot(V) / Hh + 0.5) * ht for q in P])
                    dz = np.array([(q - pos).dot(N) for q in P])
                    xmin = max(int(math.floor(ax.min())), 0); xmax = min(int(math.ceil(ax.max())), _ppx - 1)
                    ymin = max(int(math.floor(ay.min())), 0); ymax = min(int(math.ceil(ay.max())), _ppx - 1)
                    if xmax < xmin or ymax < ymin:
                        continue
                    gx, gy = np.meshgrid(np.arange(xmin, xmax + 1) + 0.5, np.arange(ymin, ymax + 1) + 0.5)
                    det = (ax[1] - ax[0]) * (ay[2] - ay[0]) - (ax[2] - ax[0]) * (ay[1] - ay[0])
                    if abs(det) < 1e-9:
                        continue
                    l1 = ((gx - ax[0]) * (ay[2] - ay[0]) - (ax[2] - ax[0]) * (gy - ay[0])) / det
                    l2 = ((ax[1] - ax[0]) * (gy - ay[0]) - (gx - ax[0]) * (ay[1] - ay[0])) / det
                    l0 = 1.0 - l1 - l2
                    eps = -0.002
                    inside = (l0 >= eps) & (l1 >= eps) & (l2 >= eps)
                    if not inside.any():
                        cx = int(ax.mean()); cy = int(ay.mean())
                        if 0 <= cx < _ppx and 0 <= cy < _ppx:
                            inside = np.zeros_like(l0, dtype=bool)
                            if ymin <= cy <= ymax and xmin <= cx <= xmax:
                                inside[cy - ymin, cx - xmin] = True
                                l0 = np.full_like(l0, 1/3.0); l1 = np.full_like(l0, 1/3.0); l2 = np.full_like(l0, 1/3.0)
                    if not inside.any():
                        continue
                    z = l0 * dz[0] + l1 * dz[1] + l2 * dz[2]
                    yy, xx = np.nonzero(inside)
                    ys = yy + ymin; xs = xx + xmin
                    zsel = z[yy, xx]
                    keep = zsel >= depth[ys, xs] - 1e-6
                    if not keep.any():
                        continue
                    ys = ys[keep]; xs = xs[keep]; yy = yy[keep]; xx = xx[keep]; zsel = zsel[keep]
                    su = l0[yy, xx] * suv[0][0] + l1[yy, xx] * suv[1][0] + l2[yy, xx] * suv[2][0]
                    sv = l0[yy, xx] * suv[0][1] + l1[yy, xx] * suv[1][1] + l2[yy, xx] * suv[2][1]
                    col = _bake_sample(src, su, sv)
                    if _rf8 is not None:
                        _nw8 = _nm8 @ poly.normal
                        if _nw8.length > 1e-12:
                            _nw8.normalize()
                            _lfs_relief_apply(col, _rf8, su, sv, P, suv, _nw8)
                    if c['alpha']:
                        if src_a is not None:
                            col[:, 3] = _bake_sample(src_a, su, sv)[:, a_chan]
                        elif src.shape[2] == 4 and a_const >= 0.999:
                            pass
                        else:
                            col[:, 3] = a_const
                    else:
                        col[:, 3] = 1.0
                    rgba[ys, xs] = col; depth[ys, xs] = zsel; written[ys, xs] = float(ci + 1)
                    n_tris += 1
        src_cache.clear()

        _glass_mats = {mn_.lower() for mn_ in _ag} | set(_GLASS_MATERIALS)
        for _ci5, c in enumerate(clusters):
            c['_alpha_mean'] = None
            if not c['alpha'] or c.get('page') is None or c.get('rect') is None:
                continue
            wu, hu, x0, y0 = c['rect']
            _u5 = page_px_of[c['page']] // 128
            reg_w = pages_written[c['page']][y0 * _u5:(y0 + hu) * _u5, x0 * _u5:(x0 + wu) * _u5] == float(_ci5 + 1)
            if reg_w.any():
                reg_a = pages_rgba[c['page']][y0 * _u5:(y0 + hu) * _u5, x0 * _u5:(x0 + wu) * _u5, 3]
                c['_alpha_mean'] = float(reg_a[reg_w].mean())
                _rg5 = pages_rgba[c['page']][y0 * _u5:(y0 + hu) * _u5, x0 * _u5:(x0 + wu) * _u5, :3][reg_w]
                _wa5 = reg_a[reg_w][:, None] + 0.02
                _mc5 = (_rg5 * _wa5).sum(axis=0) / _wa5.sum()
                c['_sat'] = float((_mc5.max() - _mc5.min()) / max(1e-4, float(_mc5.max())))
                try:
                    _sc5 = abs(c['obj'].matrix_world.to_3x3().determinant()) ** (2.0 / 3.0)
                    c['_area'] = float(sum(c['obj'].data.polygons[_f5].area for _f5 in c['faces'])) * _sc5
                except Exception:
                    c['_area'] = 1.0
        print(f"  [bake] painted: {time.time() - t0:.0f} s")
        for pg in range(npages):
            rgba, wr = _bake_dilate(pages_rgba[pg], pages_written[pg].astype(bool), passes=6)
            if not page_is_alpha[pg]:
                rgba[..., 3] = 1.0
            img = bpy.data.images.get(page_stems[pg] + '.png')
            if img is not None:
                bpy.data.images.remove(img)
            img = bpy.data.images.new(page_stems[pg] + '.png', page_px_of[pg], page_px_of[pg], alpha=page_is_alpha[pg])
            if page_is_alpha[pg]:
                img.alpha_mode = 'STRAIGHT'
            img.pixels.foreach_set(rgba.reshape(-1))
            img.filepath_raw = os.path.join(png_dir, page_stems[pg] + '.png')
            img.file_format = 'PNG'
            img.save()
            pages_rgba[pg] = None

        print(f"  [bake] pages saved: {time.time() - t0:.0f} s")
        ov = dict(scene.get('lfs_tex_overrides', {}) or {})
        new_names = []
        counters = {}
        obj_slot = {}
        for ci, c in enumerate(clusters):
            o = c['obj']; me = o.data
            src_mat = bpy.data.materials[c['mat']]
            base = ''.join(ch for ch in c['mat'] if ch.isalnum())[:9]
            counters[base] = counters.get(base, 0) + 1
            while f"{base}_b{counters[base]:02d}" in bpy.data.materials:
                counters[base] += 1
            nm = f"{base}_b{counters[base]:02d}"
            mat = bpy.data.materials.new(nm)
            mat.use_nodes = True
            nt = mat.node_tree
            for n in list(nt.nodes):
                nt.nodes.remove(n)
            out = nt.nodes.new('ShaderNodeOutputMaterial'); bsdf = nt.nodes.new('ShaderNodeBsdfPrincipled')
            tex = nt.nodes.new('ShaderNodeTexImage'); tex.image = bpy.data.images[page_stems[c['page']] + '.png']
            uvn = nt.nodes.new('ShaderNodeUVMap'); uvn.uv_map = 'LFS_BAKE'
            nt.links.new(uvn.outputs['UV'], tex.inputs['Vector'])
            nt.links.new(tex.outputs['Color'], bsdf.inputs['Base Color'])
            nt.links.new(bsdf.outputs['BSDF'], out.inputs['Surface'])
            bsdf.inputs['Roughness'].default_value = 0.6
            if c['alpha']:
                nt.links.new(tex.outputs['Alpha'], bsdf.inputs['Alpha'])
                if hasattr(mat, 'surface_render_method'):
                    mat.surface_render_method = 'BLENDED'
                elif hasattr(mat, 'blend_method'):
                    mat.blend_method = 'BLEND'
            mat['lfs_alpha_page'] = bool(c['alpha'])
            _srcm = bpy.data.materials.get(c['mat'])
            _is_glass_src = (c['mat'].lower() in _glass_mats
                             or (_srcm is not None and bool(_srcm.get('lfs_glass'))))
            if (c['alpha'] and _is_glass_src and c.get('_alpha_mean') is not None and c['_alpha_mean'] < 0.35
                    and c.get('_sat', 0.0) < 0.35 and c.get('_area', 1.0) >= 0.05
                    and not c.get('lens')):
                mat['lfs_glass_dark'] = True
            elif 'lfs_glass_dark' in mat.keys():
                del mat['lfs_glass_dark']
            mat['lfs_baked_from'] = c['mat']
            mat['lfs_tex_page'] = page_stems[c['page']]
            mat['lfs_map_rot'] = int(_uvp_pack_rot(c['h'], c['p'], 0.0))
            mat['lfs_map_pos'] = [float(c['pos'].x), float(c['pos'].y), float(c['pos'].z)]
            mat['lfs_map_wh'] = [float(c['W']), float(c['H'])]
            wu, hu, x0, y0 = c['rect']
            mat['lfs_cutout_rect'] = [int(wu), int(hu), int(x0), int(y0)]
            for k in ('lfs_shine', 'lfs_rtype', 'lfs_rmode'):
                if k in src_mat.keys():
                    mat[k] = src_mat[k]
            mat['lfs_paint'] = False
            if 'lfs_rtype' not in src_mat.keys():
                mat['lfs_rtype'] = 2 if c['alpha'] else (1 if c['mat'].lower() in _ap else 0)
                if not c['alpha'] and c['mat'].lower() not in _ap and 'lfs_rmode' not in src_mat.keys():
                    mat['lfs_rmode'] = 0
            ov[nm.lower()] = page_stems[c['page']]
            new_names.append(nm)
            key = (o.name, nm)
            if key not in obj_slot:
                idx = None
                for si, sl in enumerate(o.material_slots):
                    if sl.material == mat:
                        idx = si; break
                if idx is None:
                    me.materials.append(mat); idx = len(me.materials) - 1
                obj_slot[key] = idx
            si = obj_slot[key]
            if 'LFS_BAKE' not in me.uv_layers:
                me.uv_layers.new(name='LFS_BAKE')
            buv = me.uv_layers['LFS_BAKE'].data
            mw = o.matrix_world
            for fi in c['faces']:
                poly = me.polygons[fi]
                poly.material_index = si
                for li, vi in zip(poly.loop_indices, poly.vertices):
                    q = mw @ me.vertices[vi].co
                    u = (q - c['pos']).dot(c['U']) / c['W'] + 0.5
                    v = (q - c['pos']).dot(c['V']) / c['H'] + 0.5
                    buv[li].uv = ((x0 + u * wu) / 128.0, (y0 + v * hu) / 128.0)
        for o in objs:
            if 'LFS_BAKE' in o.data.uv_layers:
                o.data.uv_layers['LFS_BAKE'].active = True
                o.data.update()
        scene['lfs_tex_overrides'] = ov
        try:
            _lfs_assign_cidx(new_names)
        except ValueError as e:
            self.report({'ERROR'}, str(e))
            return {'CANCELLED'}
        if self.split_colour:
            self._split_colour_materials(context)
        for _mn in ({m.name for m in bpy.data.materials} - _mats_before):
            _mm = bpy.data.materials.get(_mn)
            if _mm is not None:
                _mm['lfs_auto_made'] = True
        for _mn in ({m.name for m in bpy.data.materials if m.get('lfs_map_rot') is not None} - _maps_before):
            _mm = bpy.data.materials.get(_mn)
            if _mm is not None and _mn in _mats_before:
                _mm['lfs_auto_map'] = True
        try:
            bpy.ops.lfs.purge_unused_maps(also_unused_zero_face_mats=True)
        except Exception as _e:
            print(f"  [bake] purge skipped: {_e}")
        self.report({'WARNING'} if getattr(self, '_tex_warn', False) else {'INFO'},
            (f"Done in {time.time() - t0:.0f} s: {npages} new texture page(s) ({', '.join(page_stems)}, "
             f"{'/'.join(str(q_) for q_ in sorted(set(page_px_of), reverse=True))} px) for {len(clusters)} piece(s)" if not _pp_part else
             f"Done in {time.time() - t0:.0f} s: {npages} new texture page(s), one for each part ("
             + ', '.join(f"{s_} {q_} px" for s_, q_ in zip(page_stems, page_px_of))
             + f") for {len(clusters)} piece(s)")
            + (f", {_fit_parts} more keep the model's own texture" if _fit_parts else "")
            + f".{getattr(self, '_skin_note', '')}{getattr(self, '_tex_note', '')}{getattr(self, '_fit_note', '')} Now Export to LFS."
            + getattr(self, '_look_note', ''))
        return {'FINISHED'}


_MS_ATTR = 'lfs_mirror_show'
_MS_KEY = 'lfs_mirror_side'
_MS_COLL = 'LFS Mirrored Side'
_MS_NG = '.LFS Mirrored Side'
_MS_NG_VER = 1
_MS_MOD = 'LFS Mirrored Side'
_MS_STATE = {'sig': {}, 'need': {}, 'dirty': set(), 'all': True, 'busy': False}


def _ms_parts(sc):
    out = []
    for o in sc.objects:
        if o.type != 'MESH' or 'lfs_subobj_index' not in o.keys() or o.get('lfs_preview_only'):
            continue
        try:
            if _ve_is_phantom(o):
                continue
        except Exception:
            pass
        out.append(o)
    return out


def _ms_raw(o):
    try:
        return base64.b64decode(o.get('lfs_subobj_raw_b64', '') or '')
    except Exception:
        return b''


def _ms_whole(raw):
    return len(raw) > 24 and raw[1] != 0 and bool(raw[24] & 1)


def _ms_file_flags(o, raw):
    me = o.data
    n = len(me.polygons)
    at = me.attributes.get('lfs_face')
    try:
        tag = int(o.get('lfs_face_tag', -1))
    except (TypeError, ValueError):
        tag = -1
    if at is None or at.domain != 'FACE' or at.data_type != 'INT' or tag < 0 or n == 0:
        return None
    vals = [0] * n
    at.data.foreach_get('value', vals)
    try:
        p_ = 28 + raw[3] * 4
        nv_, nf_ = struct.unpack_from('<HH', raw, p_)
    except Exception:
        return None
    fo = p_ + 28 + nv_ * 16
    if fo + 12 * nf_ > len(raw):
        return None
    out = [0] * n
    for i, v in enumerate(vals):
        if v <= 0 or (v >> 16) != tag:
            return None
        k = (v & 0xFFFF) - 1
        if not (0 <= k < nf_):
            return None
        out[i] = raw[fo + 12 * k] & 1
    return out


def _ms_flags(o):
    n = len(o.data.polygons)
    raw = _ms_raw(o)
    if not raw or n == 0:
        return [0] * n
    try:
        if not _ve_detect_geometry_change(o):
            f = _ms_file_flags(o, raw)
            if f is not None:
                return f
    except Exception:
        traceback.print_exc()
    try:
        g = _groups_of(o)
    except Exception:
        traceback.print_exc()
        return None
    return [1 if (x is not None and (x[2] & 1)) else 0 for x in g]


def _ms_sig(o, sc):
    m = o.matrix_world
    return '%s|%s|%s' % (_ve_geometry_hash(o.data, o.material_slots),
                         ','.join('%.6f' % m[i][j] for i in range(3) for j in range(3)),
                         sc.get('lfs_ve_no_auto_mirror', ''))


def _ms_write(o, flags):
    me = o.data
    at = me.attributes.get(_MS_ATTR)
    if at is not None and (at.domain != 'FACE' or at.data_type != 'INT'):
        me.attributes.remove(at)
        at = None
    if at is None:
        at = me.attributes.new(_MS_ATTR, 'INT', 'FACE')
    cur = [0] * len(me.polygons)
    at.data.foreach_get('value', cur)
    if cur != flags:
        at.data.foreach_set('value', flags)
        me.update()


def _ms_read(o):
    at = o.data.attributes.get(_MS_ATTR)
    if at is None or at.domain != 'FACE' or at.data_type != 'INT':
        return None
    v = [0] * len(o.data.polygons)
    at.data.foreach_get('value', v)
    return v


def _ms_node_group():
    ng = bpy.data.node_groups.get(_MS_NG)
    if ng is not None and ng.bl_idname == 'GeometryNodeTree' and ng.get('lfs_ms_ver') == _MS_NG_VER:
        return ng
    if ng is None or ng.bl_idname != 'GeometryNodeTree':
        ng = bpy.data.node_groups.new(_MS_NG, 'GeometryNodeTree')
    else:
        ng.nodes.clear()
        ng.interface.clear()
    ng['lfs_ms_ver'] = _MS_NG_VER
    itf = ng.interface
    itf.new_socket('Geometry', in_out='INPUT', socket_type='NodeSocketGeometry')
    itf.new_socket('Part', in_out='INPUT', socket_type='NodeSocketObject')
    itf.new_socket('Whole Part', in_out='INPUT', socket_type='NodeSocketBool')
    itf.new_socket('Geometry', in_out='OUTPUT', socket_type='NodeSocketGeometry')
    N, L = ng.nodes, ng.links

    def node(kind, x, y):
        n_ = N.new(kind)
        n_.location = (x, y)
        return n_
    gi = node('NodeGroupInput', -900, 0)
    go = node('NodeGroupOutput', 900, 0)
    oi = node('GeometryNodeObjectInfo', -700, 0)
    oi.transform_space = 'ORIGINAL'
    L.new(gi.outputs['Part'], oi.inputs['Object'])
    na = node('GeometryNodeInputNamedAttribute', -700, -300)
    na.data_type = 'BOOLEAN'
    na.inputs['Name'].default_value = _MS_ATTR
    sep = node('GeometryNodeSeparateGeometry', -500, 0)
    sep.domain = 'FACE'
    L.new(oi.outputs['Geometry'], sep.inputs['Geometry'])
    L.new(na.outputs['Attribute'], sep.inputs['Selection'])
    mx = node('GeometryNodeTransform', -300, 0)
    mx.inputs['Scale'].default_value = (-1.0, 1.0, 1.0)
    L.new(sep.outputs['Selection'], mx.inputs['Geometry'])
    ff = node('GeometryNodeFlipFaces', -100, 0)
    L.new(mx.outputs['Geometry'], ff.inputs['Mesh'])

    def to_world(src, x, y):
        tw = node('GeometryNodeTransform', x, y)
        L.new(src, tw.inputs['Geometry'])
        L.new(oi.outputs['Location'], tw.inputs['Translation'])
        L.new(oi.outputs['Rotation'], tw.inputs['Rotation'])
        L.new(oi.outputs['Scale'], tw.inputs['Scale'])
        return tw
    w1 = to_world(ff.outputs['Mesh'], 100, 0)
    jw = node('GeometryNodeJoinGeometry', 100, -250)
    L.new(ff.outputs['Mesh'], jw.inputs['Geometry'])
    L.new(oi.outputs['Geometry'], jw.inputs['Geometry'])
    w2 = to_world(jw.outputs['Geometry'], 300, -250)
    cx = node('GeometryNodeTransform', 500, -250)
    cx.inputs['Scale'].default_value = (-1.0, 1.0, 1.0)
    L.new(w2.outputs['Geometry'], cx.inputs['Geometry'])
    f2 = node('GeometryNodeFlipFaces', 600, -250)
    L.new(cx.outputs['Geometry'], f2.inputs['Mesh'])
    sw = node('GeometryNodeSwitch', 700, -150)
    sw.input_type = 'GEOMETRY'
    L.new(gi.outputs['Whole Part'], sw.inputs['Switch'])
    L.new(f2.outputs['Mesh'], sw.inputs['True'])
    jo = node('GeometryNodeJoinGeometry', 800, 0)
    L.new(w1.outputs['Geometry'], jo.inputs['Geometry'])
    L.new(sw.outputs['Output'], jo.inputs['Geometry'])
    L.new(jo.outputs['Geometry'], go.inputs['Geometry'])
    return ng


def _ms_set_input(m, ident, v):
    P = getattr(m, 'properties', None)
    it = getattr(getattr(P, 'inputs', None), ident, None) if P is not None else None
    if it is not None and hasattr(it, 'value'):
        it.value = v
    else:
        m[ident] = v


def _ms_get_input(m, ident, default=None):
    P = getattr(m, 'properties', None)
    it = getattr(getattr(P, 'inputs', None), ident, None) if P is not None else None
    if it is not None and hasattr(it, 'value'):
        return it.value
    try:
        return m[ident]
    except Exception:
        return default


def _ms_sock_ids(ng):
    ids = {}
    for it in ng.interface.items_tree:
        if getattr(it, 'in_out', '') == 'INPUT':
            ids[it.name] = it.identifier
    return ids


def _ms_coll(sc, create=True):
    c = next((c_ for c_ in bpy.data.collections if c_.get('lfs_mirror_side')), None)
    if c is None:
        if not create:
            return None
        c = bpy.data.collections.new(_MS_COLL)
        c['lfs_mirror_side'] = True
        c.hide_render = True
    if create and sc.collection.children.get(c.name) is None:
        try:
            sc.collection.children.link(c)
        except Exception:
            pass
    return c


def _ms_ghost_part(g):
    m = g.modifiers.get(_MS_MOD)
    if m is None or m.node_group is None:
        return None
    sid = _ms_sock_ids(m.node_group).get('Part')
    return _ms_get_input(m, sid) if sid else None


def _ms_remove(g):
    d = g.data
    try:
        bpy.data.objects.remove(g, do_unlink=True)
    except Exception:
        return
    try:
        if d is not None and d.users == 0:
            bpy.data.hair_curves.remove(d)
    except Exception:
        pass


def _ms_new_ghost(sc, part, ng, coll):
    cv = bpy.data.hair_curves.new('.LFS mirrored side')
    g = bpy.data.objects.new(part.name + ' (mirrored side)', cv)
    g['lfs_preview_only'] = True
    g['lfs_mirror_ghost'] = True
    coll.objects.link(g)
    g.hide_select = True
    g.hide_render = True
    m = g.modifiers.new(_MS_MOD, 'NODES')
    m.node_group = ng
    ids = _ms_sock_ids(ng)
    _ms_set_input(m, ids['Part'], part)
    if sc.get('lfs_look_attached'):
        try:
            g.hide_set(True)
            sc['lfs_look_hidden'] = (str(sc.get('lfs_look_hidden', '')) + '\n' + g.name).strip('\n')
        except Exception:
            pass
    return g


def _ms_ghosts(sc):
    coll = _ms_coll(sc, create=False)
    out = {}
    if coll is None:
        return out
    for g in list(coll.objects):
        if not g.get('lfs_mirror_ghost'):
            continue
        p_ = _ms_ghost_part(g)
        if p_ is None or p_.name not in sc.objects or p_ in out:
            _ms_remove(g)
            continue
        out[p_] = g
    return out


def _ms_sync(sc, parts=None):
    if _MS_STATE['busy']:
        return 0
    _MS_STATE['busy'] = True
    try:
        allp = _ms_parts(sc)
        todo = allp if parts is None else [p_ for p_ in allp if p_.name in parts]
        for p_ in todo:
            if p_.mode == 'EDIT':
                continue
            sig = _ms_sig(p_, sc)
            if _MS_STATE['sig'].get(p_.name) == sig and p_.name in _MS_STATE['need']:
                continue
            fl = None
            if p_.get('lfs_ms_sig') == sig:
                fl = _ms_read(p_)
            if fl is None:
                fl = _ms_flags(p_)
                if fl is None:
                    continue
                _ms_write(p_, fl)
                p_['lfs_ms_sig'] = sig
            _MS_STATE['sig'][p_.name] = sig
            _MS_STATE['need'][p_.name] = (any(fl), bool(fl) and _ms_whole(_ms_raw(p_)))
        ghosts = _ms_ghosts(sc)
        ng = None
        coll = None
        for p_ in allp:
            nd = _MS_STATE['need'].get(p_.name)
            if nd is None:
                if p_.mode == 'EDIT' and _ms_read(p_) is not None:
                    nd = (True, _ms_whole(_ms_raw(p_)))
                else:
                    continue
            want = nd[0] or nd[1]
            g = ghosts.get(p_)
            if not want:
                if g is not None:
                    _ms_remove(g)
                continue
            if g is None:
                if ng is None:
                    ng = _ms_node_group()
                    coll = _ms_coll(sc)
                g = _ms_new_ghost(sc, p_, ng, coll)
                ghosts[p_] = g
            m = g.modifiers.get(_MS_MOD)
            if m is not None:
                if m.node_group is None or m.node_group.get('lfs_ms_ver') != _MS_NG_VER:
                    m.node_group = _ms_node_group()
                sid = _ms_sock_ids(m.node_group).get('Whole Part')
                if sid and bool(_ms_get_input(m, sid, False)) != bool(nd[1]):
                    _ms_set_input(m, sid, bool(nd[1]))
                    g.update_tag()
            if not sc.get('lfs_look_attached'):
                try:
                    h = p_.hide_get()
                    if g.hide_get() != h:
                        g.hide_set(h)
                except Exception:
                    pass
            if g.hide_viewport != p_.hide_viewport:
                g.hide_viewport = p_.hide_viewport
        return len(ghosts)
    finally:
        _MS_STATE['busy'] = False


def _ms_off(sc):
    for g in list(_ms_ghosts(sc).values()):
        _ms_remove(g)
    c = _ms_coll(sc, create=False)
    if c is not None:
        for g in list(c.objects):
            if g.get('lfs_mirror_ghost'):
                _ms_remove(g)
        if len(c.objects) == 0 and len(c.children) == 0:
            try:
                bpy.data.collections.remove(c)
            except Exception:
                pass
    for p_ in _ms_parts(sc):
        if p_.mode != 'EDIT':
            at = p_.data.attributes.get(_MS_ATTR)
            if at is not None:
                try:
                    p_.data.attributes.remove(at)
                except Exception:
                    pass
        if 'lfs_ms_sig' in p_.keys():
            del p_['lfs_ms_sig']
    ng = bpy.data.node_groups.get(_MS_NG)
    if ng is not None and ng.users == 0:
        try:
            bpy.data.node_groups.remove(ng)
        except Exception:
            pass
    if _MS_KEY in sc.keys():
        del sc[_MS_KEY]
    _MS_STATE['sig'].clear()
    _MS_STATE['need'].clear()


def _ms_modal_running():
    try:
        return any(len(w.modal_operators) for w in bpy.context.window_manager.windows)
    except Exception:
        return False


def _ms_timer():
    try:
        if _ms_modal_running():
            return 0.5
        dirty, _MS_STATE['dirty'] = _MS_STATE['dirty'], set()
        full, _MS_STATE['all'] = _MS_STATE['all'], False
        for sc in bpy.data.scenes:
            if sc.get(_MS_KEY):
                _ms_sync(sc, None if full else dirty)
    except Exception:
        traceback.print_exc()
    return None


def _ms_soon(names=None, full=False):
    if names:
        _MS_STATE['dirty'].update(names)
    if full:
        _MS_STATE['all'] = True
    try:
        if not bpy.app.timers.is_registered(_ms_timer):
            bpy.app.timers.register(_ms_timer, first_interval=0.4)
    except Exception:
        traceback.print_exc()


@bpy.app.handlers.persistent
def _ms_on_depsgraph(scene, depsgraph):
    if _MS_STATE['busy']:
        return
    try:
        if not scene.get(_MS_KEY):
            return
        names = set()
        other = False
        for u in depsgraph.updates:
            idd = u.id
            if isinstance(idd, bpy.types.Object):
                o = idd.original
                if o.type == 'MESH' and 'lfs_subobj_index' in o.keys():
                    if u.is_updated_geometry or u.is_updated_transform:
                        names.add(o.name)
                    else:
                        other = True
            elif isinstance(idd, (bpy.types.Scene, bpy.types.Collection)):
                other = True
        if names or other:
            _ms_soon(names)
    except Exception:
        traceback.print_exc()


@bpy.app.handlers.persistent
def _ms_load_post(*_a):
    _MS_STATE['sig'].clear()
    _MS_STATE['need'].clear()
    _MS_STATE['dirty'].clear()
    _MS_STATE['busy'] = False
    try:
        if any(sc.get(_MS_KEY) for sc in bpy.data.scenes):
            _ms_soon(full=True)
    except Exception:
        traceback.print_exc()


class LFS_OT_MirrorSide(Operator):
    """Show the other side of the car the way LFS draws it - the mirror image of every face marked mirrored and of parts marked mirrored - in Solid view and while you model. Display only: nothing is exported and the file does not change. Press again to hide it"""
    bl_idname = 'lfs.mirror_side'
    bl_label = 'Show Mirrored Side'
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return context.scene is not None

    def execute(self, context):
        sc = context.scene
        if sc.get(_MS_KEY):
            _ms_off(sc)
            self.report({'INFO'}, "Mirrored side hidden")
            _tag_redraw(context)
            return {'FINISHED'}
        if not _ms_parts(sc):
            self.report({'WARNING'}, "No LFS sub-objects in this scene - import an .sre first")
            return {'CANCELLED'}
        sc[_MS_KEY] = True
        _MS_STATE['sig'].clear()
        _MS_STATE['need'].clear()
        for p_ in _ms_parts(sc):
            if p_.mode == 'EDIT':
                try:
                    p_.update_from_editmode()
                    fl = _ms_flags(p_)
                    if fl is not None:
                        bm = bmesh.from_edit_mesh(p_.data)
                        lay = bm.faces.layers.int.get(_MS_ATTR) or bm.faces.layers.int.new(_MS_ATTR)
                        for f_, v_ in zip(bm.faces, fl):
                            f_[lay] = v_
                        bmesh.update_edit_mesh(p_.data, loop_triangles=False, destructive=False)
                        _MS_STATE['need'][p_.name] = (any(fl), bool(fl) and _ms_whole(_ms_raw(p_)))
                except Exception:
                    traceback.print_exc()
        n = _ms_sync(sc)
        if n:
            self.report({'INFO'}, f"Mirrored side shown for {n} part(s) - display only, never exported")
        else:
            self.report({'INFO'}, "Nothing on this car is mirrored by LFS")
        _tag_redraw(context)
        return {'FINISHED'}


classes = (
    LFS_OT_ExportSRE,
    LFS_OT_MirrorSide,
    LFS_OT_CopyBugReport,
    LFS_OT_FindBadTris,
    LFS_OT_AutoSmoothGroups,
    LFS_OT_BakeTextures,
    LFS_OT_SetTileSize,
    LFS_OT_PickTexPageMenu,
    LFS_OT_SetTexPage,
    LFS_OT_ResetTextures,
    LFS_OT_ClearTexPage,
    LFS_OT_FitMaps,
    LFS_OT_SplitMapDirections,
    LFS_OT_ProMapMaterial,
    LFS_OT_FitUVMaps,
    LFS_OT_PurgeUnusedMaps,
    LFS_OT_WeldPanelGaps,
    LFS_OT_FillPanelGaps,
    LFS_OT_MarkDoubleSided,
    LFS_OT_FixInsideOut,
    LFS_OT_AutoSplitMaps,
    LFS_OT_RotateCar180,
    LFS_OT_PrepSteering,
    LFS_OT_SpinSteering,
    LFS_OT_QuickSetupFromScratch,
    LFS_OT_AutoMapMaterials,
    LFS_OT_ClearMaterialCidx,
    LFS_OT_ClearAllMaterialCidx,
    LFS_OT_PickCidxMenu,
    LFS_OT_JoinToSubObj,
    LFS_OT_CreateEmptySre,
    LFS_OT_AutoSetup,
    LFS_OT_MakeSubObj,
    LFS_OT_ToggleFlipY,
    LFS_OT_ToggleNoAutoMirror,
    LFS_OT_BakeTextureToPalette,
    VIEW3D_PT_LFS_SRE_Export,
    VIEW3D_PT_LFS_SRE_Other,
    VIEW3D_PT_LFS_SRE_Materials,
    VIEW3D_PT_LFS_SRE_Textures,
    LFS_OT_FacesTexture,
    VIEW3D_PT_LFS_SRE_FaceTex,
    LFS_OT_SetSubObjType,
    LFS_OT_UnmarkSubObj,
    LFS_OT_SelectAddedFaces,
    LFS_OT_DishPart,
    LFS_OT_DishProfilePreset,
    LFS_OT_GroupsShow,
    LFS_OT_GroupsSet,
    LFS_OT_GroupsSelect,
    LFS_OT_GroupsShade,
    VIEW3D_PT_LFS_SRE_SubObjects,
    LFS_OT_BakeUVToPlanarMaps,
)


def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.types.TOPBAR_MT_file_export.append(menu_func_export)
    for h in list(bpy.app.handlers.load_post):
        if getattr(h, '__name__', '') == '_dish_load_post':
            bpy.app.handlers.load_post.remove(h)
    bpy.app.handlers.load_post.append(_dish_load_post)
    _dish_subscribe()
    for _hl in (bpy.app.handlers.undo_post, bpy.app.handlers.redo_post):
        for h in list(_hl):
            if getattr(h, '__name__', '') == '_dish_sync_post':
                _hl.remove(h)
        _hl.append(_dish_sync_post)
    for _hl, _hf in ((bpy.app.handlers.depsgraph_update_post, _ms_on_depsgraph),
                     (bpy.app.handlers.load_post, _ms_load_post),
                     (bpy.app.handlers.undo_post, _ms_load_post),
                     (bpy.app.handlers.redo_post, _ms_load_post)):
        for h in list(_hl):
            if getattr(h, '__name__', '') == _hf.__name__:
                _hl.remove(h)
        _hl.append(_hf)
    _MS_STATE['busy'] = False
    _ms_soon(full=True)


def unregister():
    for _hl, _hf in ((bpy.app.handlers.depsgraph_update_post, _ms_on_depsgraph),
                     (bpy.app.handlers.load_post, _ms_load_post),
                     (bpy.app.handlers.undo_post, _ms_load_post),
                     (bpy.app.handlers.redo_post, _ms_load_post)):
        for h in list(_hl):
            if getattr(h, '__name__', '') == _hf.__name__:
                try:
                    _hl.remove(h)
                except Exception:
                    pass
    try:
        if bpy.app.timers.is_registered(_ms_timer):
            bpy.app.timers.unregister(_ms_timer)
    except Exception:
        pass
    try:
        if bpy.app.timers.is_registered(_dish_live_poll):
            bpy.app.timers.unregister(_dish_live_poll)
    except Exception:
        pass
    for _hl in (bpy.app.handlers.undo_post, bpy.app.handlers.redo_post):
        for h in list(_hl):
            if getattr(h, '__name__', '') == '_dish_sync_post':
                try:
                    _hl.remove(h)
                except Exception:
                    pass
    for step in (lambda: bpy.msgbus.clear_by_owner(_DISH_OWNER),
                 lambda: bpy.app.handlers.load_post.remove(_dish_load_post),
                 lambda: bpy.app.timers.unregister(_dish_autoapply),
                 lambda: bpy.types.TOPBAR_MT_file_export.remove(menu_func_export)):
        try:
            step()
        except Exception:
            pass
    for cls in reversed(classes):
        try:
            bpy.utils.unregister_class(cls)
        except Exception:
            pass
